---@class System.Collections.Specialized.StringEnumerator
---instance properties
---@field public Current System.String
local m = {};

---@return System.Boolean
function m:MoveNext() end
function m:Reset() end
System.Collections.Specialized.StringEnumerator=m
return m;