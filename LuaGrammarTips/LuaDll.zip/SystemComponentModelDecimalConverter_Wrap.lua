---@class System.ComponentModel.DecimalConverter : System.ComponentModel.BaseNumberConverter
local m = {};

---@param context System.ComponentModel.ITypeDescriptorContext
---@param destinationType System.Type
---@return System.Boolean
function m:CanConvertTo(context, destinationType) end
---@param context System.ComponentModel.ITypeDescriptorContext
---@param culture System.Globalization.CultureInfo
---@param value System.Object
---@param destinationType System.Type
---@return System.Object
function m:ConvertTo(context, culture, value, destinationType) end
System.ComponentModel.DecimalConverter=m
return m;