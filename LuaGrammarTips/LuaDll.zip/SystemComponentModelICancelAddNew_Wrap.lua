---@class System.ComponentModel.ICancelAddNew
local m = {};

---@param itemIndex System.Int32
function m:CancelNew(itemIndex) end
---@param itemIndex System.Int32
function m:EndNew(itemIndex) end
System.ComponentModel.ICancelAddNew=m
return m;