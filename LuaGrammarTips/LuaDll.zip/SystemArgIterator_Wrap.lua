---@class System.ArgIterator : System.ValueType
local m = {};

function m:End() end
---@param o System.Object
---@return System.Boolean
function m:Equals(o) end
---@return System.Int32
function m:GetHashCode() end
---@return System.TypedReference
function m:GetNextArg() end
---@param rth System.RuntimeTypeHandle
---@return System.TypedReference
function m:GetNextArg(rth) end
---@return System.RuntimeTypeHandle
function m:GetNextArgType() end
---@return System.Int32
function m:GetRemainingCount() end
System.ArgIterator=m
return m;