---@class System.CodeDom.Compiler.CompilerResults
---instance properties
---@field public CompiledAssembly System.Reflection.Assembly
---@field public Errors System.CodeDom.Compiler.CompilerErrorCollection
---@field public Evidence System.Security.Policy.Evidence
---@field public NativeCompilerReturnValue System.Int32
---@field public Output System.Collections.Specialized.StringCollection
---@field public PathToAssembly System.String
---@field public TempFiles System.CodeDom.Compiler.TempFileCollection
local m = {};

System.CodeDom.Compiler.CompilerResults=m
return m;