---@class System.CodeDom.CodeSnippetCompileUnit : System.CodeDom.CodeCompileUnit
---instance properties
---@field public LinePragma System.CodeDom.CodeLinePragma
---@field public Value System.String
local m = {};

System.CodeDom.CodeSnippetCompileUnit=m
return m;