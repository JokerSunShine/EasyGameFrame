---@class System.CodeDom.CodeVariableDeclarationStatement : System.CodeDom.CodeStatement
---instance properties
---@field public InitExpression System.CodeDom.CodeExpression
---@field public Name System.String
---@field public Type System.CodeDom.CodeTypeReference
local m = {};

System.CodeDom.CodeVariableDeclarationStatement=m
return m;