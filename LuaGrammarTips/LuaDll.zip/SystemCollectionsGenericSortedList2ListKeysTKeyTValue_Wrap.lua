---@class System.Collections.Generic.SortedList2ListKeysTKeyTValue
---instance properties
---@field public Item TKey
---@field public Count System.Int32
---@field public IsSynchronized System.Boolean
---@field public IsReadOnly System.Boolean
---@field public SyncRoot System.Object
local m = {};

---@param item TKey
function m:Add(item) end
---@param key TKey
---@return System.Boolean
function m:Remove(key) end
function m:Clear() end
---@param array TKey
---@param arrayIndex System.Int32
function m:CopyTo(array, arrayIndex) end
---@param item TKey
---@return System.Boolean
function m:Contains(item) end
---@param item TKey
---@return System.Int32
function m:IndexOf(item) end
---@param index System.Int32
---@param item TKey
function m:Insert(index, item) end
---@param index System.Int32
function m:RemoveAt(index) end
---@return System.Collections.Generic.IEnumerator1TKey
function m:GetEnumerator() end
---@param array System.Array
---@param arrayIndex System.Int32
function m:CopyTo(array, arrayIndex) end
System.Collections.Generic.SortedList2ListKeysTKeyTValue=m
return m;