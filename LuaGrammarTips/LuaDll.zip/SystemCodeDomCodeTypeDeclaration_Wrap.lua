---@class System.CodeDom.CodeTypeDeclaration : System.CodeDom.CodeTypeMember
---instance properties
---@field public BaseTypes System.CodeDom.CodeTypeReferenceCollection
---@field public IsClass System.Boolean
---@field public IsEnum System.Boolean
---@field public IsInterface System.Boolean
---@field public IsStruct System.Boolean
---@field public Members System.CodeDom.CodeTypeMemberCollection
---@field public TypeAttributes System.Reflection.TypeAttributes
---@field public IsPartial System.Boolean
---@field public TypeParameters System.CodeDom.CodeTypeParameterCollection
local m = {};

---@param value System.EventHandler
function m:add_PopulateBaseTypes(value) end
---@param value System.EventHandler
function m:remove_PopulateBaseTypes(value) end
---@param value System.EventHandler
function m:add_PopulateMembers(value) end
---@param value System.EventHandler
function m:remove_PopulateMembers(value) end
System.CodeDom.CodeTypeDeclaration=m
return m;