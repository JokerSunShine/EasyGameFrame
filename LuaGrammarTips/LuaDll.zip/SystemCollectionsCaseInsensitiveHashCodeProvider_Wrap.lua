---@class System.Collections.CaseInsensitiveHashCodeProvider
---properties
---@field public Default System.Collections.CaseInsensitiveHashCodeProvider
---@field public DefaultInvariant System.Collections.CaseInsensitiveHashCodeProvider
local m = {};

---@param obj System.Object
---@return System.Int32
function m:GetHashCode(obj) end
System.Collections.CaseInsensitiveHashCodeProvider=m
return m;