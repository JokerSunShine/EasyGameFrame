---@class System.ComponentModel.ISupportInitialize
local m = {};

function m:BeginInit() end
function m:EndInit() end
System.ComponentModel.ISupportInitialize=m
return m;