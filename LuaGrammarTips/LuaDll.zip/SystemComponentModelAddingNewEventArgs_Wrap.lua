---@class System.ComponentModel.AddingNewEventArgs : System.EventArgs
---instance properties
---@field public NewObject System.Object
local m = {};

System.ComponentModel.AddingNewEventArgs=m
return m;