---@class System.ArgumentException : System.SystemException
---instance properties
---@field public ParamName System.String
---@field public Message System.String
local m = {};

---@param info System.Runtime.Serialization.SerializationInfo
---@param context System.Runtime.Serialization.StreamingContext
function m:GetObjectData(info, context) end
System.ArgumentException=m
return m;