---@class System.ComponentModel.IEditableObject
local m = {};

function m:BeginEdit() end
function m:CancelEdit() end
function m:EndEdit() end
System.ComponentModel.IEditableObject=m
return m;