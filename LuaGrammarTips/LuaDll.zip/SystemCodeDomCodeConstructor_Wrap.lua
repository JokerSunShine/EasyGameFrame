---@class System.CodeDom.CodeConstructor : System.CodeDom.CodeMemberMethod
---instance properties
---@field public BaseConstructorArgs System.CodeDom.CodeExpressionCollection
---@field public ChainedConstructorArgs System.CodeDom.CodeExpressionCollection
local m = {};

System.CodeDom.CodeConstructor=m
return m;