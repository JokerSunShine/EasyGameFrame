---@class System.ByteMatcher
local m = {};

---@param key System.TermInfoStrings
---@param val System.Byte
function m:AddMapping(key, val) end
function m:Sort() end
---@param c System.Int32
---@return System.Boolean
function m:StartsWith(c) end
---@param buffer System.Char
---@param offset System.Int32
---@param length System.Int32
---@param used System.Int32 @out
---@return System.TermInfoStrings
function m:Match(buffer, offset, length, used) end
System.ByteMatcher=m
return m;