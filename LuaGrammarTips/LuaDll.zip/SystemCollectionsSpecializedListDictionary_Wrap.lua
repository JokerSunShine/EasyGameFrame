---@class System.Collections.Specialized.ListDictionary
---instance properties
---@field public Count System.Int32
---@field public IsSynchronized System.Boolean
---@field public SyncRoot System.Object
---@field public IsFixedSize System.Boolean
---@field public IsReadOnly System.Boolean
---@field public Item System.Object
---@field public Keys System.Collections.ICollection
---@field public Values System.Collections.ICollection
local m = {};

---@param array System.Array
---@param index System.Int32
function m:CopyTo(array, index) end
---@param key System.Object
---@param value System.Object
function m:Add(key, value) end
function m:Clear() end
---@param key System.Object
---@return System.Boolean
function m:Contains(key) end
---@return System.Collections.IDictionaryEnumerator
function m:GetEnumerator() end
---@param key System.Object
function m:Remove(key) end
System.Collections.Specialized.ListDictionary=m
return m;