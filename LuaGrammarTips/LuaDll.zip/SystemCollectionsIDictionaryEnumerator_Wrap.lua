---@class System.Collections.IDictionaryEnumerator
---instance properties
---@field public Entry System.Collections.DictionaryEntry
---@field public Key System.Object
---@field public Value System.Object
local m = {};

System.Collections.IDictionaryEnumerator=m
return m;