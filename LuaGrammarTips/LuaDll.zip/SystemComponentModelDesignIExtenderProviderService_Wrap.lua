---@class System.ComponentModel.Design.IExtenderProviderService
local m = {};

---@param provider System.ComponentModel.IExtenderProvider
function m:AddExtenderProvider(provider) end
---@param provider System.ComponentModel.IExtenderProvider
function m:RemoveExtenderProvider(provider) end
System.ComponentModel.Design.IExtenderProviderService=m
return m;