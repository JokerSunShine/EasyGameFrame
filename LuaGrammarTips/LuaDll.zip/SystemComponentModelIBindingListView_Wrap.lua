---@class System.ComponentModel.IBindingListView
---instance properties
---@field public Filter System.String
---@field public SortDescriptions System.ComponentModel.ListSortDescriptionCollection
---@field public SupportsAdvancedSorting System.Boolean
---@field public SupportsFiltering System.Boolean
local m = {};

---@param sorts System.ComponentModel.ListSortDescriptionCollection
function m:ApplySort(sorts) end
function m:RemoveFilter() end
System.ComponentModel.IBindingListView=m
return m;