---@class System.ComponentModel.EnumConverterEnumComparer
local m = {};

System.ComponentModel.EnumConverterEnumComparer=m
return m;