---@class System.Collections.Generic.SortedDictionary2NodeTKeyTValue : System.Collections.Generic.RBTreeNode
---instance fields
---@field public key TKey
---@field public value TValue
local m = {};

---@param other System.Collections.Generic.RBTreeNode
function m:SwapValue(other) end
---@return System.Collections.Generic.KeyValuePair2TKeyTValue
function m:AsKV() end
---@return System.Collections.DictionaryEntry
function m:AsDE() end
System.Collections.Generic.SortedDictionary2NodeTKeyTValue=m
return m;