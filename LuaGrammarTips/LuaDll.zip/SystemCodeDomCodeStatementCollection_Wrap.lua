---@class System.CodeDom.CodeStatementCollection : System.Collections.CollectionBase
---instance properties
---@field public Item System.CodeDom.CodeStatement
local m = {};

---@param value System.CodeDom.CodeStatement
---@return System.Int32
function m:Add(value) end
---@param value System.CodeDom.CodeExpression
---@return System.Int32
function m:Add(value) end
---@param value System.CodeDom.CodeStatement
function m:AddRange(value) end
---@param value System.CodeDom.CodeStatementCollection
function m:AddRange(value) end
---@param value System.CodeDom.CodeStatement
---@return System.Boolean
function m:Contains(value) end
---@param array System.CodeDom.CodeStatement
---@param index System.Int32
function m:CopyTo(array, index) end
---@param value System.CodeDom.CodeStatement
---@return System.Int32
function m:IndexOf(value) end
---@param index System.Int32
---@param value System.CodeDom.CodeStatement
function m:Insert(index, value) end
---@param value System.CodeDom.CodeStatement
function m:Remove(value) end
System.CodeDom.CodeStatementCollection=m
return m;