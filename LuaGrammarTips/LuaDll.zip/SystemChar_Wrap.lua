---@class System.Char : System.ValueType
---fields
---@field public MaxValue System.Char
---@field public MinValue System.Char
local m = {};
---@param utf32 System.Int32
---@return System.String
function m.ConvertFromUtf32(utf32) end
---@param highSurrogate System.Char
---@param lowSurrogate System.Char
---@return System.Int32
function m.ConvertToUtf32(highSurrogate, lowSurrogate) end
---@param s System.String
---@param index System.Int32
---@return System.Int32
function m.ConvertToUtf32(s, index) end
---@param highSurrogate System.Char
---@param lowSurrogate System.Char
---@return System.Boolean
function m.IsSurrogatePair(highSurrogate, lowSurrogate) end
---@param s System.String
---@param index System.Int32
---@return System.Boolean
function m.IsSurrogatePair(s, index) end
---@param c System.Char
---@return System.Double
function m.GetNumericValue(c) end
---@param s System.String
---@param index System.Int32
---@return System.Double
function m.GetNumericValue(s, index) end
---@param c System.Char
---@return System.Globalization.UnicodeCategory
function m.GetUnicodeCategory(c) end
---@param s System.String
---@param index System.Int32
---@return System.Globalization.UnicodeCategory
function m.GetUnicodeCategory(s, index) end
---@param c System.Char
---@return System.Boolean
function m.IsControl(c) end
---@param s System.String
---@param index System.Int32
---@return System.Boolean
function m.IsControl(s, index) end
---@param c System.Char
---@return System.Boolean
function m.IsDigit(c) end
---@param s System.String
---@param index System.Int32
---@return System.Boolean
function m.IsDigit(s, index) end
---@param c System.Char
---@return System.Boolean
function m.IsHighSurrogate(c) end
---@param s System.String
---@param index System.Int32
---@return System.Boolean
function m.IsHighSurrogate(s, index) end
---@param c System.Char
---@return System.Boolean
function m.IsLetter(c) end
---@param s System.String
---@param index System.Int32
---@return System.Boolean
function m.IsLetter(s, index) end
---@param c System.Char
---@return System.Boolean
function m.IsLetterOrDigit(c) end
---@param s System.String
---@param index System.Int32
---@return System.Boolean
function m.IsLetterOrDigit(s, index) end
---@param c System.Char
---@return System.Boolean
function m.IsLower(c) end
---@param s System.String
---@param index System.Int32
---@return System.Boolean
function m.IsLower(s, index) end
---@param c System.Char
---@return System.Boolean
function m.IsLowSurrogate(c) end
---@param s System.String
---@param index System.Int32
---@return System.Boolean
function m.IsLowSurrogate(s, index) end
---@param c System.Char
---@return System.Boolean
function m.IsNumber(c) end
---@param s System.String
---@param index System.Int32
---@return System.Boolean
function m.IsNumber(s, index) end
---@param c System.Char
---@return System.Boolean
function m.IsPunctuation(c) end
---@param s System.String
---@param index System.Int32
---@return System.Boolean
function m.IsPunctuation(s, index) end
---@param c System.Char
---@return System.Boolean
function m.IsSeparator(c) end
---@param s System.String
---@param index System.Int32
---@return System.Boolean
function m.IsSeparator(s, index) end
---@param c System.Char
---@return System.Boolean
function m.IsSurrogate(c) end
---@param s System.String
---@param index System.Int32
---@return System.Boolean
function m.IsSurrogate(s, index) end
---@param c System.Char
---@return System.Boolean
function m.IsSymbol(c) end
---@param s System.String
---@param index System.Int32
---@return System.Boolean
function m.IsSymbol(s, index) end
---@param c System.Char
---@return System.Boolean
function m.IsUpper(c) end
---@param s System.String
---@param index System.Int32
---@return System.Boolean
function m.IsUpper(s, index) end
---@param c System.Char
---@return System.Boolean
function m.IsWhiteSpace(c) end
---@param s System.String
---@param index System.Int32
---@return System.Boolean
function m.IsWhiteSpace(s, index) end
---@param s System.String
---@param result System.Char @out
---@return System.Boolean
function m.TryParse(s, result) end
---@param s System.String
---@return System.Char
function m.Parse(s) end
---@param c System.Char
---@return System.Char
function m.ToLower(c) end
---@param c System.Char
---@return System.Char
function m.ToLowerInvariant(c) end
---@param c System.Char
---@param culture System.Globalization.CultureInfo
---@return System.Char
function m.ToLower(c, culture) end
---@param c System.Char
---@return System.Char
function m.ToUpper(c) end
---@param c System.Char
---@return System.Char
function m.ToUpperInvariant(c) end
---@param c System.Char
---@param culture System.Globalization.CultureInfo
---@return System.Char
function m.ToUpper(c, culture) end
---@param c System.Char
---@return System.String
function m.ToString(c) end

---@param value System.Object
---@return System.Int32
function m:CompareTo(value) end
---@param obj System.Object
---@return System.Boolean
function m:Equals(obj) end
---@param value System.Char
---@return System.Int32
function m:CompareTo(value) end
---@param obj System.Char
---@return System.Boolean
function m:Equals(obj) end
---@return System.Int32
function m:GetHashCode() end
---@return System.String
function m:ToString() end
---@param provider System.IFormatProvider
---@return System.String
function m:ToString(provider) end
---@return System.TypeCode
function m:GetTypeCode() end
System.Char=m
return m;