---@class System.CodeDom.CodeObjectCreateExpression : System.CodeDom.CodeExpression
---instance properties
---@field public CreateType System.CodeDom.CodeTypeReference
---@field public Parameters System.CodeDom.CodeExpressionCollection
local m = {};

System.CodeDom.CodeObjectCreateExpression=m
return m;