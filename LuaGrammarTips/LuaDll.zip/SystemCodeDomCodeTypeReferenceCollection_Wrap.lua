---@class System.CodeDom.CodeTypeReferenceCollection : System.Collections.CollectionBase
---instance properties
---@field public Item System.CodeDom.CodeTypeReference
local m = {};

---@param value System.CodeDom.CodeTypeReference
---@return System.Int32
function m:Add(value) end
---@param value System.String
function m:Add(value) end
---@param value System.Type
function m:Add(value) end
---@param value System.CodeDom.CodeTypeReference
function m:AddRange(value) end
---@param value System.CodeDom.CodeTypeReferenceCollection
function m:AddRange(value) end
---@param value System.CodeDom.CodeTypeReference
---@return System.Boolean
function m:Contains(value) end
---@param array System.CodeDom.CodeTypeReference
---@param index System.Int32
function m:CopyTo(array, index) end
---@param value System.CodeDom.CodeTypeReference
---@return System.Int32
function m:IndexOf(value) end
---@param index System.Int32
---@param value System.CodeDom.CodeTypeReference
function m:Insert(index, value) end
---@param value System.CodeDom.CodeTypeReference
function m:Remove(value) end
System.CodeDom.CodeTypeReferenceCollection=m
return m;