---@class System.ComponentModel.AsyncCompletedEventArgs : System.EventArgs
---instance properties
---@field public Cancelled System.Boolean
---@field public Error System.Exception
---@field public UserState System.Object
local m = {};

System.ComponentModel.AsyncCompletedEventArgs=m
return m;