---@class System.CodeDom.CodePropertySetValueReferenceExpression : System.CodeDom.CodeExpression
local m = {};

System.CodeDom.CodePropertySetValueReferenceExpression=m
return m;