---@class System.CodeDom.CodeNamespace : System.CodeDom.CodeObject
---instance properties
---@field public Comments System.CodeDom.CodeCommentStatementCollection
---@field public Imports System.CodeDom.CodeNamespaceImportCollection
---@field public Name System.String
---@field public Types System.CodeDom.CodeTypeDeclarationCollection
local m = {};

---@param value System.EventHandler
function m:add_PopulateComments(value) end
---@param value System.EventHandler
function m:remove_PopulateComments(value) end
---@param value System.EventHandler
function m:add_PopulateImports(value) end
---@param value System.EventHandler
function m:remove_PopulateImports(value) end
---@param value System.EventHandler
function m:add_PopulateTypes(value) end
---@param value System.EventHandler
function m:remove_PopulateTypes(value) end
System.CodeDom.CodeNamespace=m
return m;