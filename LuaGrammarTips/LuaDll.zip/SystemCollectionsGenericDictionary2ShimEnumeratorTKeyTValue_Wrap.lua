---@class System.Collections.Generic.Dictionary2ShimEnumeratorTKeyTValue
---instance properties
---@field public Entry System.Collections.DictionaryEntry
---@field public Key System.Object
---@field public Value System.Object
---@field public Current System.Object
local m = {};

function m:Dispose() end
---@return System.Boolean
function m:MoveNext() end
function m:Reset() end
System.Collections.Generic.Dictionary2ShimEnumeratorTKeyTValue=m
return m;