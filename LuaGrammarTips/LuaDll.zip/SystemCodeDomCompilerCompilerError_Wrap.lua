---@class System.CodeDom.Compiler.CompilerError
---instance properties
---@field public Line System.Int32
---@field public Column System.Int32
---@field public ErrorNumber System.String
---@field public ErrorText System.String
---@field public IsWarning System.Boolean
---@field public FileName System.String
local m = {};

---@return System.String
function m:ToString() end
System.CodeDom.Compiler.CompilerError=m
return m;