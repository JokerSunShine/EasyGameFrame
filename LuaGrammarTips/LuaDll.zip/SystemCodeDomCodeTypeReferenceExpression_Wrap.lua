---@class System.CodeDom.CodeTypeReferenceExpression : System.CodeDom.CodeExpression
---instance properties
---@field public Type System.CodeDom.CodeTypeReference
local m = {};

System.CodeDom.CodeTypeReferenceExpression=m
return m;