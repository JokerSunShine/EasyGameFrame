---@class System.ComponentModel.LicenseUsageMode
---@field Runtime @0
---@field Designtime @1
local m = {};
System.ComponentModel.LicenseUsageMode=m
return m;