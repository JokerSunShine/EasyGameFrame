---@class System.Collections.HashtableHashValues
---instance properties
---@field public Count System.Int32
---@field public IsSynchronized System.Boolean
---@field public SyncRoot System.Object
local m = {};

---@param array System.Array
---@param arrayIndex System.Int32
function m:CopyTo(array, arrayIndex) end
---@return System.Collections.IEnumerator
function m:GetEnumerator() end
System.Collections.HashtableHashValues=m
return m;