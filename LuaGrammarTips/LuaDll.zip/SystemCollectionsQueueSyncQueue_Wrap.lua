---@class System.Collections.QueueSyncQueue : System.Collections.Queue
---instance properties
---@field public Count System.Int32
---@field public IsSynchronized System.Boolean
---@field public SyncRoot System.Object
local m = {};

---@param array System.Array
---@param index System.Int32
function m:CopyTo(array, index) end
---@return System.Collections.IEnumerator
function m:GetEnumerator() end
---@return System.Object
function m:Clone() end
function m:Clear() end
function m:TrimToSize() end
---@param obj System.Object
---@return System.Boolean
function m:Contains(obj) end
---@return System.Object
function m:Dequeue() end
---@param obj System.Object
function m:Enqueue(obj) end
---@return System.Object
function m:Peek() end
---@return System.Object
function m:ToArray() end
System.Collections.QueueSyncQueue=m
return m;