---@class System.Collections.Generic.LinkedList1T
---instance properties
---@field public Count System.Int32
---@field public First System.Collections.Generic.LinkedListNode1T
---@field public Last System.Collections.Generic.LinkedListNode1T
local m = {};

---@param node System.Collections.Generic.LinkedListNode1T
---@param value T
---@return System.Collections.Generic.LinkedListNode1T
function m:AddAfter(node, value) end
---@param node System.Collections.Generic.LinkedListNode1T
---@param newNode System.Collections.Generic.LinkedListNode1T
function m:AddAfter(node, newNode) end
---@param node System.Collections.Generic.LinkedListNode1T
---@param value T
---@return System.Collections.Generic.LinkedListNode1T
function m:AddBefore(node, value) end
---@param node System.Collections.Generic.LinkedListNode1T
---@param newNode System.Collections.Generic.LinkedListNode1T
function m:AddBefore(node, newNode) end
---@param node System.Collections.Generic.LinkedListNode1T
function m:AddFirst(node) end
---@param value T
---@return System.Collections.Generic.LinkedListNode1T
function m:AddFirst(value) end
---@param value T
---@return System.Collections.Generic.LinkedListNode1T
function m:AddLast(value) end
---@param node System.Collections.Generic.LinkedListNode1T
function m:AddLast(node) end
function m:Clear() end
---@param value T
---@return System.Boolean
function m:Contains(value) end
---@param array T
---@param index System.Int32
function m:CopyTo(array, index) end
---@param value T
---@return System.Collections.Generic.LinkedListNode1T
function m:Find(value) end
---@param value T
---@return System.Collections.Generic.LinkedListNode1T
function m:FindLast(value) end
---@return System.Collections.Generic.LinkedList1EnumeratorT
function m:GetEnumerator() end
---@param info System.Runtime.Serialization.SerializationInfo
---@param context System.Runtime.Serialization.StreamingContext
function m:GetObjectData(info, context) end
---@param sender System.Object
function m:OnDeserialization(sender) end
---@param value T
---@return System.Boolean
function m:Remove(value) end
---@param node System.Collections.Generic.LinkedListNode1T
function m:Remove(node) end
function m:RemoveFirst() end
function m:RemoveLast() end
System.Collections.Generic.LinkedList1T=m
return m;