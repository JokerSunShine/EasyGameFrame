---@class System.CodeDom.CodeVariableReferenceExpression : System.CodeDom.CodeExpression
---instance properties
---@field public VariableName System.String
local m = {};

System.CodeDom.CodeVariableReferenceExpression=m
return m;