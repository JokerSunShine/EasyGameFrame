---@class System.Collections.Generic.SortedDictionary2KeyCollectionTKeyTValue
---instance properties
---@field public Count System.Int32
local m = {};

---@param array TKey
---@param arrayIndex System.Int32
function m:CopyTo(array, arrayIndex) end
---@return System.Collections.Generic.SortedDictionary2KeyCollectionEnumeratorTKeyTValue
function m:GetEnumerator() end
System.Collections.Generic.SortedDictionary2KeyCollectionTKeyTValue=m
return m;