---@class System.CodeDom.CodeCatchClause
---instance properties
---@field public CatchExceptionType System.CodeDom.CodeTypeReference
---@field public LocalName System.String
---@field public Statements System.CodeDom.CodeStatementCollection
local m = {};

System.CodeDom.CodeCatchClause=m
return m;