---@class System.CodeDom.CodeCastExpression : System.CodeDom.CodeExpression
---instance properties
---@field public Expression System.CodeDom.CodeExpression
---@field public TargetType System.CodeDom.CodeTypeReference
local m = {};

System.CodeDom.CodeCastExpression=m
return m;