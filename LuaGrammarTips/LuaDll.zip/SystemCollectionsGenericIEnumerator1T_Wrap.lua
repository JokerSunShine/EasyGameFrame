---@class System.Collections.Generic.IEnumerator1T
---instance properties
---@field public Current T
local m = {};

System.Collections.Generic.IEnumerator1T=m
return m;