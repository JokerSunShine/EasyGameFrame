---@class System.CodeDom.CodeTypeReferenceOptions
---@field GlobalReference @1
---@field GenericTypeParameter @2
local m = {};
System.CodeDom.CodeTypeReferenceOptions=m
return m;