---@class System.CodeDom.CodeDirectiveCollection : System.Collections.CollectionBase
---instance properties
---@field public Item System.CodeDom.CodeDirective
local m = {};

---@param value System.CodeDom.CodeDirective
---@return System.Int32
function m:Add(value) end
---@param value System.CodeDom.CodeDirective
function m:AddRange(value) end
---@param value System.CodeDom.CodeDirectiveCollection
function m:AddRange(value) end
---@param value System.CodeDom.CodeDirective
---@return System.Boolean
function m:Contains(value) end
---@param array System.CodeDom.CodeDirective
---@param index System.Int32
function m:CopyTo(array, index) end
---@param value System.CodeDom.CodeDirective
---@return System.Int32
function m:IndexOf(value) end
---@param index System.Int32
---@param value System.CodeDom.CodeDirective
function m:Insert(index, value) end
---@param value System.CodeDom.CodeDirective
function m:Remove(value) end
System.CodeDom.CodeDirectiveCollection=m
return m;