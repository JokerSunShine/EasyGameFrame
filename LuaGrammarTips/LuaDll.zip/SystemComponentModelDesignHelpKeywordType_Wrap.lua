---@class System.ComponentModel.Design.HelpKeywordType
---@field F1Keyword @0
---@field GeneralKeyword @1
---@field FilterKeyword @2
local m = {};
System.ComponentModel.Design.HelpKeywordType=m
return m;