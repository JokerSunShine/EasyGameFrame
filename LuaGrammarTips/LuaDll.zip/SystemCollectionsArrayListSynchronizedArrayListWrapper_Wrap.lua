---@class System.Collections.ArrayListSynchronizedArrayListWrapper : System.Collections.ArrayListArrayListWrapper
---instance properties
---@field public Item System.Object
---@field public Count System.Int32
---@field public Capacity System.Int32
---@field public IsFixedSize System.Boolean
---@field public IsReadOnly System.Boolean
---@field public IsSynchronized System.Boolean
---@field public SyncRoot System.Object
local m = {};

---@param value System.Object
---@return System.Int32
function m:Add(value) end
function m:Clear() end
---@param value System.Object
---@return System.Boolean
function m:Contains(value) end
---@param value System.Object
---@return System.Int32
function m:IndexOf(value) end
---@param value System.Object
---@param startIndex System.Int32
---@return System.Int32
function m:IndexOf(value, startIndex) end
---@param value System.Object
---@param startIndex System.Int32
---@param count System.Int32
---@return System.Int32
function m:IndexOf(value, startIndex, count) end
---@param value System.Object
---@return System.Int32
function m:LastIndexOf(value) end
---@param value System.Object
---@param startIndex System.Int32
---@return System.Int32
function m:LastIndexOf(value, startIndex) end
---@param value System.Object
---@param startIndex System.Int32
---@param count System.Int32
---@return System.Int32
function m:LastIndexOf(value, startIndex, count) end
---@param index System.Int32
---@param value System.Object
function m:Insert(index, value) end
---@param index System.Int32
---@param c System.Collections.ICollection
function m:InsertRange(index, c) end
---@param value System.Object
function m:Remove(value) end
---@param index System.Int32
function m:RemoveAt(index) end
---@param index System.Int32
---@param count System.Int32
function m:RemoveRange(index, count) end
function m:Reverse() end
---@param index System.Int32
---@param count System.Int32
function m:Reverse(index, count) end
---@param array System.Array
function m:CopyTo(array) end
---@param array System.Array
---@param index System.Int32
function m:CopyTo(array, index) end
---@param index System.Int32
---@param array System.Array
---@param arrayIndex System.Int32
---@param count System.Int32
function m:CopyTo(index, array, arrayIndex, count) end
---@return System.Collections.IEnumerator
function m:GetEnumerator() end
---@param index System.Int32
---@param count System.Int32
---@return System.Collections.IEnumerator
function m:GetEnumerator(index, count) end
---@param c System.Collections.ICollection
function m:AddRange(c) end
---@param value System.Object
---@return System.Int32
function m:BinarySearch(value) end
---@param value System.Object
---@param comparer System.Collections.IComparer
---@return System.Int32
function m:BinarySearch(value, comparer) end
---@param index System.Int32
---@param count System.Int32
---@param value System.Object
---@param comparer System.Collections.IComparer
---@return System.Int32
function m:BinarySearch(index, count, value, comparer) end
---@return System.Object
function m:Clone() end
---@param index System.Int32
---@param count System.Int32
---@return System.Collections.ArrayList
function m:GetRange(index, count) end
function m:TrimToSize() end
function m:Sort() end
---@param comparer System.Collections.IComparer
function m:Sort(comparer) end
---@param index System.Int32
---@param count System.Int32
---@param comparer System.Collections.IComparer
function m:Sort(index, count, comparer) end
---@return System.Object
function m:ToArray() end
---@param elementType System.Type
---@return System.Array
function m:ToArray(elementType) end
System.Collections.ArrayListSynchronizedArrayListWrapper=m
return m;