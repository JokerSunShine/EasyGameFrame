---@class System.Collections.Specialized.StringCollection
---instance properties
---@field public Item System.String
---@field public Count System.Int32
---@field public IsReadOnly System.Boolean
---@field public IsSynchronized System.Boolean
---@field public SyncRoot System.Object
local m = {};

---@param value System.String
---@return System.Int32
function m:Add(value) end
---@param value System.String
function m:AddRange(value) end
function m:Clear() end
---@param value System.String
---@return System.Boolean
function m:Contains(value) end
---@param array System.String
---@param index System.Int32
function m:CopyTo(array, index) end
---@return System.Collections.Specialized.StringEnumerator
function m:GetEnumerator() end
---@param value System.String
---@return System.Int32
function m:IndexOf(value) end
---@param index System.Int32
---@param value System.String
function m:Insert(index, value) end
---@param value System.String
function m:Remove(value) end
---@param index System.Int32
function m:RemoveAt(index) end
System.Collections.Specialized.StringCollection=m
return m;