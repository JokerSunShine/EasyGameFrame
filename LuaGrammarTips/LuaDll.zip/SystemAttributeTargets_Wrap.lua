---@class System.AttributeTargets
---@field Assembly @1
---@field Module @2
---@field Class @4
---@field Struct @8
---@field Enum @16
---@field Constructor @32
---@field Method @64
---@field Property @128
---@field Field @256
---@field Event @512
---@field Interface @1024
---@field Parameter @2048
---@field Delegate @4096
---@field ReturnValue @8192
---@field GenericParameter @16384
---@field All @32767
local m = {};
System.AttributeTargets=m
return m;