---@class System.Collections.Generic.CollectionDebuggerView2TU
---instance properties
---@field public Items System.Collections.Generic.KeyValuePair2TU
local m = {};

System.Collections.Generic.CollectionDebuggerView2TU=m
return m;