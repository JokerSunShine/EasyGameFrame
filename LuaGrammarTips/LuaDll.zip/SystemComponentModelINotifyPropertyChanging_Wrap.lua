---@class System.ComponentModel.INotifyPropertyChanging
local m = {};

---@param value System.ComponentModel.PropertyChangingEventHandler
function m:add_PropertyChanging(value) end
---@param value System.ComponentModel.PropertyChangingEventHandler
function m:remove_PropertyChanging(value) end
System.ComponentModel.INotifyPropertyChanging=m
return m;