---@class System.Collections.Generic.RBTreeNode
---instance fields
---@field public left System.Collections.Generic.RBTreeNode
---@field public right System.Collections.Generic.RBTreeNode
---instance properties
---@field public IsBlack System.Boolean
---@field public Size System.UInt32
local m = {};

---@return System.UInt32
function m:FixSize() end
---@param other System.Collections.Generic.RBTreeNode
function m:SwapValue(other) end
System.Collections.Generic.RBTreeNode=m
return m;