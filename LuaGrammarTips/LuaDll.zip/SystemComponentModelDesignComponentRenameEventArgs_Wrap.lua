---@class System.ComponentModel.Design.ComponentRenameEventArgs : System.EventArgs
---instance properties
---@field public Component System.Object
---@field public NewName System.String
---@field public OldName System.String
local m = {};

System.ComponentModel.Design.ComponentRenameEventArgs=m
return m;