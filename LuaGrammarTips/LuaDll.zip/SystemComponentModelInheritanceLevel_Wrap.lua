---@class System.ComponentModel.InheritanceLevel
---@field Inherited @1
---@field InheritedReadOnly @2
---@field NotInherited @3
local m = {};
System.ComponentModel.InheritanceLevel=m
return m;