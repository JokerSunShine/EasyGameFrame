---@class System.CodeDom.CodeAttributeDeclaration
---instance properties
---@field public Arguments System.CodeDom.CodeAttributeArgumentCollection
---@field public Name System.String
---@field public AttributeType System.CodeDom.CodeTypeReference
local m = {};

System.CodeDom.CodeAttributeDeclaration=m
return m;