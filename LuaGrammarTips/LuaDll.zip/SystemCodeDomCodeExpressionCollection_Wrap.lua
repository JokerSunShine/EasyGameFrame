---@class System.CodeDom.CodeExpressionCollection : System.Collections.CollectionBase
---instance properties
---@field public Item System.CodeDom.CodeExpression
local m = {};

---@param value System.CodeDom.CodeExpression
---@return System.Int32
function m:Add(value) end
---@param value System.CodeDom.CodeExpression
function m:AddRange(value) end
---@param value System.CodeDom.CodeExpressionCollection
function m:AddRange(value) end
---@param value System.CodeDom.CodeExpression
---@return System.Boolean
function m:Contains(value) end
---@param array System.CodeDom.CodeExpression
---@param index System.Int32
function m:CopyTo(array, index) end
---@param value System.CodeDom.CodeExpression
---@return System.Int32
function m:IndexOf(value) end
---@param index System.Int32
---@param value System.CodeDom.CodeExpression
function m:Insert(index, value) end
---@param value System.CodeDom.CodeExpression
function m:Remove(value) end
System.CodeDom.CodeExpressionCollection=m
return m;