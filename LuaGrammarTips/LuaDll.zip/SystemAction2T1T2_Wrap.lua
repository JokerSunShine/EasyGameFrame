---@class System.Action2T1T2 : System.MulticastDelegate
local m = {};

---@param arg1 T1
---@param arg2 T2
function m:Invoke(arg1, arg2) end
---@param arg1 T1
---@param arg2 T2
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(arg1, arg2, callback, object) end
---@param result System.IAsyncResult
function m:EndInvoke(result) end
System.Action2T1T2=m
return m;