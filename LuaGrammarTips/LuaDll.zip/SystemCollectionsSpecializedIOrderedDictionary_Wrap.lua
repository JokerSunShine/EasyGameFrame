---@class System.Collections.Specialized.IOrderedDictionary
---instance properties
---@field public Item System.Object
local m = {};

---@return System.Collections.IDictionaryEnumerator
function m:GetEnumerator() end
---@param idx System.Int32
---@param key System.Object
---@param value System.Object
function m:Insert(idx, key, value) end
---@param idx System.Int32
function m:RemoveAt(idx) end
System.Collections.Specialized.IOrderedDictionary=m
return m;