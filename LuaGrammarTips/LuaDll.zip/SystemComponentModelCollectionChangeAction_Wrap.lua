---@class System.ComponentModel.CollectionChangeAction
---@field Add @1
---@field Remove @2
---@field Refresh @3
local m = {};
System.ComponentModel.CollectionChangeAction=m
return m;