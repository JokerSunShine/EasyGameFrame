---@class System.Collections.ArrayListFixedSizeListWrapper : System.Collections.ArrayListListWrapper
---instance properties
---@field public IsFixedSize System.Boolean
local m = {};

---@param value System.Object
---@return System.Int32
function m:Add(value) end
function m:Clear() end
---@param index System.Int32
---@param value System.Object
function m:Insert(index, value) end
---@param value System.Object
function m:Remove(value) end
---@param index System.Int32
function m:RemoveAt(index) end
System.Collections.ArrayListFixedSizeListWrapper=m
return m;