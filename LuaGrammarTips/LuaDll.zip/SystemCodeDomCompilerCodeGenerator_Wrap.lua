---@class System.CodeDom.Compiler.CodeGenerator
local m = {};
---@param value System.String
---@return System.Boolean
function m.IsValidLanguageIndependentIdentifier(value) end
---@param e System.CodeDom.CodeObject
function m.ValidateIdentifiers(e) end

---@param member System.CodeDom.CodeTypeMember
---@param writer System.IO.TextWriter
---@param options System.CodeDom.Compiler.CodeGeneratorOptions
function m:GenerateCodeFromMember(member, writer, options) end
System.CodeDom.Compiler.CodeGenerator=m
return m;