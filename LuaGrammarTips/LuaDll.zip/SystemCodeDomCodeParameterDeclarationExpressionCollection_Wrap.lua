---@class System.CodeDom.CodeParameterDeclarationExpressionCollection : System.Collections.CollectionBase
---instance properties
---@field public Item System.CodeDom.CodeParameterDeclarationExpression
local m = {};

---@param value System.CodeDom.CodeParameterDeclarationExpression
---@return System.Int32
function m:Add(value) end
---@param value System.CodeDom.CodeParameterDeclarationExpression
function m:AddRange(value) end
---@param value System.CodeDom.CodeParameterDeclarationExpressionCollection
function m:AddRange(value) end
---@param value System.CodeDom.CodeParameterDeclarationExpression
---@return System.Boolean
function m:Contains(value) end
---@param array System.CodeDom.CodeParameterDeclarationExpression
---@param index System.Int32
function m:CopyTo(array, index) end
---@param value System.CodeDom.CodeParameterDeclarationExpression
---@return System.Int32
function m:IndexOf(value) end
---@param index System.Int32
---@param value System.CodeDom.CodeParameterDeclarationExpression
function m:Insert(index, value) end
---@param value System.CodeDom.CodeParameterDeclarationExpression
function m:Remove(value) end
System.CodeDom.CodeParameterDeclarationExpressionCollection=m
return m;