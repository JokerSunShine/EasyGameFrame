---@class System.Collections.Concurrent.ConcurrentQueue1T
---instance properties
---@field public Count System.Int32
---@field public IsEmpty System.Boolean
local m = {};

---@param item T
function m:Enqueue(item) end
---@param result T @out
---@return System.Boolean
function m:TryDequeue(result) end
---@param result T @out
---@return System.Boolean
function m:TryPeek(result) end
---@return System.Collections.Generic.IEnumerator1T
function m:GetEnumerator() end
---@param array T
---@param index System.Int32
function m:CopyTo(array, index) end
---@return T
function m:ToArray() end
System.Collections.Concurrent.ConcurrentQueue1T=m
return m;