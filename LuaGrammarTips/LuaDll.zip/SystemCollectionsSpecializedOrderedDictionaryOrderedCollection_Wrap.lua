---@class System.Collections.Specialized.OrderedDictionaryOrderedCollection
---instance properties
---@field public Count System.Int32
---@field public IsSynchronized System.Boolean
---@field public SyncRoot System.Object
local m = {};

---@param array System.Array
---@param index System.Int32
function m:CopyTo(array, index) end
---@return System.Collections.IEnumerator
function m:GetEnumerator() end
System.Collections.Specialized.OrderedDictionaryOrderedCollection=m
return m;