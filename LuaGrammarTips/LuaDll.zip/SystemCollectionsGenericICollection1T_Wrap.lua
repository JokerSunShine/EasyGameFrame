---@class System.Collections.Generic.ICollection1T
---instance properties
---@field public Count System.Int32
---@field public IsReadOnly System.Boolean
local m = {};

---@param item T
function m:Add(item) end
function m:Clear() end
---@param item T
---@return System.Boolean
function m:Contains(item) end
---@param array T
---@param arrayIndex System.Int32
function m:CopyTo(array, arrayIndex) end
---@param item T
---@return System.Boolean
function m:Remove(item) end
System.Collections.Generic.ICollection1T=m
return m;