---@class System.ArrayInternalEnumerator1T : System.ValueType
---instance properties
---@field public Current T
local m = {};

function m:Dispose() end
---@return System.Boolean
function m:MoveNext() end
System.ArrayInternalEnumerator1T=m
return m;