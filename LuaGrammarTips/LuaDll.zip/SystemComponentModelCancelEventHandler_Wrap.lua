---@class System.ComponentModel.CancelEventHandler : System.MulticastDelegate
local m = {};

---@param sender System.Object
---@param e System.ComponentModel.CancelEventArgs
function m:Invoke(sender, e) end
---@param sender System.Object
---@param e System.ComponentModel.CancelEventArgs
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(sender, e, callback, object) end
---@param result System.IAsyncResult
function m:EndInvoke(result) end
System.ComponentModel.CancelEventHandler=m
return m;