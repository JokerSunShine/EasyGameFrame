---@class System.ComponentModel.Design.ComponentChangedEventArgs : System.EventArgs
---instance properties
---@field public Component System.Object
---@field public Member System.ComponentModel.MemberDescriptor
---@field public NewValue System.Object
---@field public OldValue System.Object
local m = {};

System.ComponentModel.Design.ComponentChangedEventArgs=m
return m;