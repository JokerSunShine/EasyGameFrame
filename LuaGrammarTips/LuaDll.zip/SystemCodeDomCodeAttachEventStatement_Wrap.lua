---@class System.CodeDom.CodeAttachEventStatement : System.CodeDom.CodeStatement
---instance properties
---@field public Event System.CodeDom.CodeEventReferenceExpression
---@field public Listener System.CodeDom.CodeExpression
local m = {};

System.CodeDom.CodeAttachEventStatement=m
return m;