---@class System.Collections.Specialized.ListDictionaryDictionaryNodeCollectionDictionaryNodeCollectionEnumerator
---instance properties
---@field public Current System.Object
local m = {};

---@return System.Boolean
function m:MoveNext() end
function m:Reset() end
System.Collections.Specialized.ListDictionaryDictionaryNodeCollectionDictionaryNodeCollectionEnumerator=m
return m;