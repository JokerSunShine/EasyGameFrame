---@class System.Collections.Generic.SortedList2TKeyTValue
---instance properties
---@field public Count System.Int32
---@field public Item TValue
---@field public Capacity System.Int32
---@field public Keys System.Collections.Generic.IList1TKey
---@field public Values System.Collections.Generic.IList1TValue
---@field public Comparer System.Collections.Generic.IComparer1TKey
local m = {};

---@param key TKey
---@param value TValue
function m:Add(key, value) end
---@param key TKey
---@return System.Boolean
function m:ContainsKey(key) end
---@return System.Collections.Generic.IEnumerator1System.Collections.Generic.KeyValuePair2TKeyTValue
function m:GetEnumerator() end
---@param key TKey
---@return System.Boolean
function m:Remove(key) end
function m:Clear() end
---@param index System.Int32
function m:RemoveAt(index) end
---@param key TKey
---@return System.Int32
function m:IndexOfKey(key) end
---@param value TValue
---@return System.Int32
function m:IndexOfValue(value) end
---@param value TValue
---@return System.Boolean
function m:ContainsValue(value) end
function m:TrimExcess() end
---@param key TKey
---@param value TValue @out
---@return System.Boolean
function m:TryGetValue(key, value) end
System.Collections.Generic.SortedList2TKeyTValue=m
return m;