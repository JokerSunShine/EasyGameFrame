---@class System.Collections.Generic.HashSet1PrimeHelperT
local m = {};
---@param x System.Int32
---@return System.Int32
function m.ToPrime(x) end

System.Collections.Generic.HashSet1PrimeHelperT=m
return m;