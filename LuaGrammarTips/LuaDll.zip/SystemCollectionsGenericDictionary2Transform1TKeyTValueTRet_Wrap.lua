---@class System.Collections.Generic.Dictionary2Transform1TKeyTValueTRet : System.MulticastDelegate
local m = {};

---@param key TKey
---@param value TValue
---@return TRet
function m:Invoke(key, value) end
---@param key TKey
---@param value TValue
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(key, value, callback, object) end
---@param result System.IAsyncResult
---@return TRet
function m:EndInvoke(result) end
System.Collections.Generic.Dictionary2Transform1TKeyTValueTRet=m
return m;