---@class System.CodeDom.CodeLinePragma
---instance properties
---@field public FileName System.String
---@field public LineNumber System.Int32
local m = {};

System.CodeDom.CodeLinePragma=m
return m;