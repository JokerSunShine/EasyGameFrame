---@class System.CodeDom.CodeCompileUnit : System.CodeDom.CodeObject
---instance properties
---@field public AssemblyCustomAttributes System.CodeDom.CodeAttributeDeclarationCollection
---@field public Namespaces System.CodeDom.CodeNamespaceCollection
---@field public ReferencedAssemblies System.Collections.Specialized.StringCollection
---@field public StartDirectives System.CodeDom.CodeDirectiveCollection
---@field public EndDirectives System.CodeDom.CodeDirectiveCollection
local m = {};

System.CodeDom.CodeCompileUnit=m
return m;