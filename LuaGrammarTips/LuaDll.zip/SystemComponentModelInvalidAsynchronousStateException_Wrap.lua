---@class System.ComponentModel.InvalidAsynchronousStateException : System.ArgumentException
local m = {};

System.ComponentModel.InvalidAsynchronousStateException=m
return m;