---@class System.ComponentModel.Design.IResourceService
local m = {};

---@param info System.Globalization.CultureInfo
---@return System.Resources.IResourceReader
function m:GetResourceReader(info) end
---@param info System.Globalization.CultureInfo
---@return System.Resources.IResourceWriter
function m:GetResourceWriter(info) end
System.ComponentModel.Design.IResourceService=m
return m;