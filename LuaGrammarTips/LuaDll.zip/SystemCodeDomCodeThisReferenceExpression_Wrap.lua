---@class System.CodeDom.CodeThisReferenceExpression : System.CodeDom.CodeExpression
local m = {};

System.CodeDom.CodeThisReferenceExpression=m
return m;