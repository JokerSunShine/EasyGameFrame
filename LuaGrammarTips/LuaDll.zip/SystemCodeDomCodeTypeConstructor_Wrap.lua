---@class System.CodeDom.CodeTypeConstructor : System.CodeDom.CodeMemberMethod
local m = {};

System.CodeDom.CodeTypeConstructor=m
return m;