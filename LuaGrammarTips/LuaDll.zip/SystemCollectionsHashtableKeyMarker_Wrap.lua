---@class System.Collections.HashtableKeyMarker
---fields
---@field public Removed System.Collections.HashtableKeyMarker
local m = {};

---@param context System.Runtime.Serialization.StreamingContext
---@return System.Object
function m:GetRealObject(context) end
System.Collections.HashtableKeyMarker=m
return m;