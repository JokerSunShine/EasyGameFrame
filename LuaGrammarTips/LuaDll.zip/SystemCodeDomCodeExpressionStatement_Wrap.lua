---@class System.CodeDom.CodeExpressionStatement : System.CodeDom.CodeStatement
---instance properties
---@field public Expression System.CodeDom.CodeExpression
local m = {};

System.CodeDom.CodeExpressionStatement=m
return m;