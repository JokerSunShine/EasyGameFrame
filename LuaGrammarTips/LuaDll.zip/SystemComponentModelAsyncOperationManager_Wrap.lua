---@class System.ComponentModel.AsyncOperationManager
---properties
---@field public SynchronizationContext System.Threading.SynchronizationContext
local m = {};
---@param userSuppliedState System.Object
---@return System.ComponentModel.AsyncOperation
function m.CreateOperation(userSuppliedState) end

System.ComponentModel.AsyncOperationManager=m
return m;