---@class System.ComponentModel.ByteConverter : System.ComponentModel.BaseNumberConverter
local m = {};

System.ComponentModel.ByteConverter=m
return m;