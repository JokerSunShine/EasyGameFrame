---@class System.Collections.Specialized.NameObjectCollectionBaseKeysCollection
---instance properties
---@field public Count System.Int32
---@field public Item System.String
local m = {};

---@param index System.Int32
---@return System.String
function m:Get(index) end
---@return System.Collections.IEnumerator
function m:GetEnumerator() end
System.Collections.Specialized.NameObjectCollectionBaseKeysCollection=m
return m;