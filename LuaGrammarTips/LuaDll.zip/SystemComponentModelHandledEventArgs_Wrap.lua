---@class System.ComponentModel.HandledEventArgs : System.EventArgs
---instance properties
---@field public Handled System.Boolean
local m = {};

System.ComponentModel.HandledEventArgs=m
return m;