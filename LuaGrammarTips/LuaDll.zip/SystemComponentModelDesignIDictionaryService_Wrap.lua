---@class System.ComponentModel.Design.IDictionaryService
local m = {};

---@param value System.Object
---@return System.Object
function m:GetKey(value) end
---@param key System.Object
---@return System.Object
function m:GetValue(key) end
---@param key System.Object
---@param value System.Object
function m:SetValue(key, value) end
System.ComponentModel.Design.IDictionaryService=m
return m;