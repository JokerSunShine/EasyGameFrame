---@class System.ComponentModel.Design.DesignerEventArgs : System.EventArgs
---instance properties
---@field public Designer System.ComponentModel.Design.IDesignerHost
local m = {};

System.ComponentModel.Design.DesignerEventArgs=m
return m;