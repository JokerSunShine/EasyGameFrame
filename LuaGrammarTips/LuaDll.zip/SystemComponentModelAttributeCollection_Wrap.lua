---@class System.ComponentModel.AttributeCollection
---fields
---@field public Empty System.ComponentModel.AttributeCollection
---instance properties
---@field public Count System.Int32
---@field public Item System.Attribute
---@field public Item System.Attribute
local m = {};
---@param existing System.ComponentModel.AttributeCollection
---@param newAttributes System.Attribute
---@return System.ComponentModel.AttributeCollection
function m.FromExisting(existing, newAttributes) end

---@param attr System.Attribute
---@return System.Boolean
function m:Contains(attr) end
---@param attributes System.Attribute
---@return System.Boolean
function m:Contains(attributes) end
---@param array System.Array
---@param index System.Int32
function m:CopyTo(array, index) end
---@return System.Collections.IEnumerator
function m:GetEnumerator() end
---@param attr System.Attribute
---@return System.Boolean
function m:Matches(attr) end
---@param attributes System.Attribute
---@return System.Boolean
function m:Matches(attributes) end
System.ComponentModel.AttributeCollection=m
return m;