---@class System.ComponentModel.BindingList1T : System.Collections.ObjectModel.Collection1T
---instance properties
---@field public AllowEdit System.Boolean
---@field public AllowNew System.Boolean
---@field public AllowRemove System.Boolean
---@field public RaiseListChangedEvents System.Boolean
local m = {};

---@param value System.ComponentModel.AddingNewEventHandler
function m:add_AddingNew(value) end
---@param value System.ComponentModel.AddingNewEventHandler
function m:remove_AddingNew(value) end
---@param value System.ComponentModel.ListChangedEventHandler
function m:add_ListChanged(value) end
---@param value System.ComponentModel.ListChangedEventHandler
function m:remove_ListChanged(value) end
---@return T
function m:AddNew() end
---@param itemIndex System.Int32
function m:CancelNew(itemIndex) end
---@param itemIndex System.Int32
function m:EndNew(itemIndex) end
function m:ResetBindings() end
---@param position System.Int32
function m:ResetItem(position) end
System.ComponentModel.BindingList1T=m
return m;