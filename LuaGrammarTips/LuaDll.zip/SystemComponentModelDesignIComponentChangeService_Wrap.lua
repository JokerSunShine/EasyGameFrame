---@class System.ComponentModel.Design.IComponentChangeService
local m = {};

---@param value System.ComponentModel.Design.ComponentEventHandler
function m:add_ComponentAdded(value) end
---@param value System.ComponentModel.Design.ComponentEventHandler
function m:remove_ComponentAdded(value) end
---@param value System.ComponentModel.Design.ComponentEventHandler
function m:add_ComponentAdding(value) end
---@param value System.ComponentModel.Design.ComponentEventHandler
function m:remove_ComponentAdding(value) end
---@param value System.ComponentModel.Design.ComponentChangedEventHandler
function m:add_ComponentChanged(value) end
---@param value System.ComponentModel.Design.ComponentChangedEventHandler
function m:remove_ComponentChanged(value) end
---@param value System.ComponentModel.Design.ComponentChangingEventHandler
function m:add_ComponentChanging(value) end
---@param value System.ComponentModel.Design.ComponentChangingEventHandler
function m:remove_ComponentChanging(value) end
---@param value System.ComponentModel.Design.ComponentEventHandler
function m:add_ComponentRemoved(value) end
---@param value System.ComponentModel.Design.ComponentEventHandler
function m:remove_ComponentRemoved(value) end
---@param value System.ComponentModel.Design.ComponentEventHandler
function m:add_ComponentRemoving(value) end
---@param value System.ComponentModel.Design.ComponentEventHandler
function m:remove_ComponentRemoving(value) end
---@param value System.ComponentModel.Design.ComponentRenameEventHandler
function m:add_ComponentRename(value) end
---@param value System.ComponentModel.Design.ComponentRenameEventHandler
function m:remove_ComponentRename(value) end
---@param component System.Object
---@param member System.ComponentModel.MemberDescriptor
---@param oldValue System.Object
---@param newValue System.Object
function m:OnComponentChanged(component, member, oldValue, newValue) end
---@param component System.Object
---@param member System.ComponentModel.MemberDescriptor
function m:OnComponentChanging(component, member) end
System.ComponentModel.Design.IComponentChangeService=m
return m;