---@class System.ComponentModel.Design.Serialization.ResolveNameEventArgs : System.EventArgs
---instance properties
---@field public Name System.String
---@field public Value System.Object
local m = {};

System.ComponentModel.Design.Serialization.ResolveNameEventArgs=m
return m;