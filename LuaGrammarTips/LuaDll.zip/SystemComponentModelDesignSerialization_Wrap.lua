System.ComponentModel.Design.Serialization = {};
