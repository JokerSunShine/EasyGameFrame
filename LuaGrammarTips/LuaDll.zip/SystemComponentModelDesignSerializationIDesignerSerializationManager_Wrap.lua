---@class System.ComponentModel.Design.Serialization.IDesignerSerializationManager
---instance properties
---@field public Context System.ComponentModel.Design.Serialization.ContextStack
---@field public Properties System.ComponentModel.PropertyDescriptorCollection
local m = {};

---@param value System.ComponentModel.Design.Serialization.ResolveNameEventHandler
function m:add_ResolveName(value) end
---@param value System.ComponentModel.Design.Serialization.ResolveNameEventHandler
function m:remove_ResolveName(value) end
---@param value System.EventHandler
function m:add_SerializationComplete(value) end
---@param value System.EventHandler
function m:remove_SerializationComplete(value) end
---@param provider System.ComponentModel.Design.Serialization.IDesignerSerializationProvider
function m:AddSerializationProvider(provider) end
---@param type System.Type
---@param arguments System.Collections.ICollection
---@param name System.String
---@param addToContainer System.Boolean
---@return System.Object
function m:CreateInstance(type, arguments, name, addToContainer) end
---@param name System.String
---@return System.Object
function m:GetInstance(name) end
---@param value System.Object
---@return System.String
function m:GetName(value) end
---@param objectType System.Type
---@param serializerType System.Type
---@return System.Object
function m:GetSerializer(objectType, serializerType) end
---@param typeName System.String
---@return System.Type
function m:GetType(typeName) end
---@param provider System.ComponentModel.Design.Serialization.IDesignerSerializationProvider
function m:RemoveSerializationProvider(provider) end
---@param errorInformation System.Object
function m:ReportError(errorInformation) end
---@param instance System.Object
---@param name System.String
function m:SetName(instance, name) end
System.ComponentModel.Design.Serialization.IDesignerSerializationManager=m
return m;