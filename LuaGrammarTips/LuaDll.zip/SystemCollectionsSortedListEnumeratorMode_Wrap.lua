---@class System.Collections.SortedListEnumeratorMode
---@field KEY_MODE @0
---@field VALUE_MODE @1
---@field ENTRY_MODE @2
local m = {};
System.Collections.SortedListEnumeratorMode=m
return m;