---@class System.AssemblyLoadEventArgs : System.EventArgs
---instance properties
---@field public LoadedAssembly System.Reflection.Assembly
local m = {};

System.AssemblyLoadEventArgs=m
return m;