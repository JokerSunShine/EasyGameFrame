---@class System.ComponentModel.Design.DesignerOptionServiceDesignerOptionCollection
---instance properties
---@field public Item System.ComponentModel.Design.DesignerOptionServiceDesignerOptionCollection
---@field public Item System.ComponentModel.Design.DesignerOptionServiceDesignerOptionCollection
---@field public Name System.String
---@field public Count System.Int32
---@field public Parent System.ComponentModel.Design.DesignerOptionServiceDesignerOptionCollection
---@field public Properties System.ComponentModel.PropertyDescriptorCollection
local m = {};

---@return System.Boolean
function m:ShowDialog() end
---@return System.Collections.IEnumerator
function m:GetEnumerator() end
---@param item System.ComponentModel.Design.DesignerOptionServiceDesignerOptionCollection
---@return System.Int32
function m:IndexOf(item) end
---@param array System.Array
---@param index System.Int32
function m:CopyTo(array, index) end
System.ComponentModel.Design.DesignerOptionServiceDesignerOptionCollection=m
return m;