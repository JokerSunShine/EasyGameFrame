---@class System.ComponentModel.Design.IInheritanceService
local m = {};

---@param component System.ComponentModel.IComponent
---@param container System.ComponentModel.IContainer
function m:AddInheritedComponents(component, container) end
---@param component System.ComponentModel.IComponent
---@return System.ComponentModel.InheritanceAttribute
function m:GetInheritanceAttribute(component) end
System.ComponentModel.Design.IInheritanceService=m
return m;