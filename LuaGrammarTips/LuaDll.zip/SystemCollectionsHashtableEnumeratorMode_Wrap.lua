---@class System.Collections.HashtableEnumeratorMode
---@field KEY_MODE @0
---@field VALUE_MODE @1
---@field ENTRY_MODE @2
local m = {};
System.Collections.HashtableEnumeratorMode=m
return m;