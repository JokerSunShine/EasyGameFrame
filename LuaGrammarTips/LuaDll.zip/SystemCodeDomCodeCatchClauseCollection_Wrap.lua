---@class System.CodeDom.CodeCatchClauseCollection : System.Collections.CollectionBase
---instance properties
---@field public Item System.CodeDom.CodeCatchClause
local m = {};

---@param value System.CodeDom.CodeCatchClause
---@return System.Int32
function m:Add(value) end
---@param value System.CodeDom.CodeCatchClause
function m:AddRange(value) end
---@param value System.CodeDom.CodeCatchClauseCollection
function m:AddRange(value) end
---@param value System.CodeDom.CodeCatchClause
---@return System.Boolean
function m:Contains(value) end
---@param array System.CodeDom.CodeCatchClause
---@param index System.Int32
function m:CopyTo(array, index) end
---@param value System.CodeDom.CodeCatchClause
---@return System.Int32
function m:IndexOf(value) end
---@param index System.Int32
---@param value System.CodeDom.CodeCatchClause
function m:Insert(index, value) end
---@param value System.CodeDom.CodeCatchClause
function m:Remove(value) end
System.CodeDom.CodeCatchClauseCollection=m
return m;