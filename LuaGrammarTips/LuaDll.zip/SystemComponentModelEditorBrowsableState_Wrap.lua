---@class System.ComponentModel.EditorBrowsableState
---@field Always @0
---@field Never @1
---@field Advanced @2
local m = {};
System.ComponentModel.EditorBrowsableState=m
return m;