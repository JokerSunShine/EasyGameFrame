---@class System.ApplicationId
---instance properties
---@field public Culture System.String
---@field public Name System.String
---@field public ProcessorArchitecture System.String
---@field public PublicKeyToken System.Byte
---@field public Version System.Version
local m = {};

---@return System.ApplicationId
function m:Copy() end
---@param o System.Object
---@return System.Boolean
function m:Equals(o) end
---@return System.Int32
function m:GetHashCode() end
---@return System.String
function m:ToString() end
System.ApplicationId=m
return m;