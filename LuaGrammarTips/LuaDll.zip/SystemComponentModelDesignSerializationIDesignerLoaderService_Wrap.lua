---@class System.ComponentModel.Design.Serialization.IDesignerLoaderService
local m = {};

function m:AddLoadDependency() end
---@param successful System.Boolean
---@param errorCollection System.Collections.ICollection
function m:DependentLoadComplete(successful, errorCollection) end
---@return System.Boolean
function m:Reload() end
System.ComponentModel.Design.Serialization.IDesignerLoaderService=m
return m;