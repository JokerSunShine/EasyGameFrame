---@class System.Collections.Generic.KeyNotFoundException : System.SystemException
local m = {};

System.Collections.Generic.KeyNotFoundException=m
return m;