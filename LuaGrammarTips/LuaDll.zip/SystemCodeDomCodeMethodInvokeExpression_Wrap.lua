---@class System.CodeDom.CodeMethodInvokeExpression : System.CodeDom.CodeExpression
---instance properties
---@field public Method System.CodeDom.CodeMethodReferenceExpression
---@field public Parameters System.CodeDom.CodeExpressionCollection
local m = {};

System.CodeDom.CodeMethodInvokeExpression=m
return m;