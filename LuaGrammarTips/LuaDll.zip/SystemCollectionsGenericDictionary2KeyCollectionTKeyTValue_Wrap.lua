---@class System.Collections.Generic.Dictionary2KeyCollectionTKeyTValue
---instance properties
---@field public Count System.Int32
local m = {};

---@param array TKey
---@param index System.Int32
function m:CopyTo(array, index) end
---@return System.Collections.Generic.Dictionary2KeyCollectionEnumeratorTKeyTValue
function m:GetEnumerator() end
System.Collections.Generic.Dictionary2KeyCollectionTKeyTValue=m
return m;