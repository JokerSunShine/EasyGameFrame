---@class System.Action1T : System.MulticastDelegate
local m = {};

---@param obj T
function m:Invoke(obj) end
---@param obj T
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(obj, callback, object) end
---@param result System.IAsyncResult
function m:EndInvoke(result) end
System.Action1T=m
return m;