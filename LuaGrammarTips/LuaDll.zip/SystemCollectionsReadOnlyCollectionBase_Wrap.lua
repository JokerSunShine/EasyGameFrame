---@class System.Collections.ReadOnlyCollectionBase
---instance properties
---@field public Count System.Int32
local m = {};

---@return System.Collections.IEnumerator
function m:GetEnumerator() end
System.Collections.ReadOnlyCollectionBase=m
return m;