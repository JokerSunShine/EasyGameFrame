---@class System.ComponentModel.Design.ITypeDiscoveryService
local m = {};

---@param baseType System.Type
---@param excludeGlobalTypes System.Boolean
---@return System.Collections.ICollection
function m:GetTypes(baseType, excludeGlobalTypes) end
System.ComponentModel.Design.ITypeDiscoveryService=m
return m;