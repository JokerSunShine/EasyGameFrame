---@class System.ComponentModel.Design.ServiceContainer
local m = {};

---@param serviceType System.Type
---@param serviceInstance System.Object
function m:AddService(serviceType, serviceInstance) end
---@param serviceType System.Type
---@param callback System.ComponentModel.Design.ServiceCreatorCallback
function m:AddService(serviceType, callback) end
---@param serviceType System.Type
---@param serviceInstance System.Object
---@param promote System.Boolean
function m:AddService(serviceType, serviceInstance, promote) end
---@param serviceType System.Type
---@param callback System.ComponentModel.Design.ServiceCreatorCallback
---@param promote System.Boolean
function m:AddService(serviceType, callback, promote) end
---@param serviceType System.Type
function m:RemoveService(serviceType) end
---@param serviceType System.Type
---@param promote System.Boolean
function m:RemoveService(serviceType, promote) end
---@param serviceType System.Type
---@return System.Object
function m:GetService(serviceType) end
function m:Dispose() end
System.ComponentModel.Design.ServiceContainer=m
return m;