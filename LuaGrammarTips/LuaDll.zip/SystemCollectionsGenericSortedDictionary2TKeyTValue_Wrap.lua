---@class System.Collections.Generic.SortedDictionary2TKeyTValue
---instance properties
---@field public Comparer System.Collections.Generic.IComparer1TKey
---@field public Count System.Int32
---@field public Item TValue
---@field public Keys System.Collections.Generic.SortedDictionary2KeyCollectionTKeyTValue
---@field public Values System.Collections.Generic.SortedDictionary2ValueCollectionTKeyTValue
local m = {};

---@param key TKey
---@param value TValue
function m:Add(key, value) end
function m:Clear() end
---@param key TKey
---@return System.Boolean
function m:ContainsKey(key) end
---@param value TValue
---@return System.Boolean
function m:ContainsValue(value) end
---@param array System.Collections.Generic.KeyValuePair2TKeyTValue
---@param arrayIndex System.Int32
function m:CopyTo(array, arrayIndex) end
---@return System.Collections.Generic.SortedDictionary2EnumeratorTKeyTValue
function m:GetEnumerator() end
---@param key TKey
---@return System.Boolean
function m:Remove(key) end
---@param key TKey
---@param value TValue @out
---@return System.Boolean
function m:TryGetValue(key, value) end
System.Collections.Generic.SortedDictionary2TKeyTValue=m
return m;