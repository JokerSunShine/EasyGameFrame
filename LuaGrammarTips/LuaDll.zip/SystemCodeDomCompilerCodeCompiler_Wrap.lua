---@class System.CodeDom.Compiler.CodeCompiler : System.CodeDom.Compiler.CodeGenerator
local m = {};

System.CodeDom.Compiler.CodeCompiler=m
return m;