---@class System.ComponentModel.Design.IComponentDiscoveryService
local m = {};

---@param designerHost System.ComponentModel.Design.IDesignerHost
---@param baseType System.Type
---@return System.Collections.ICollection
function m:GetComponentTypes(designerHost, baseType) end
System.ComponentModel.Design.IComponentDiscoveryService=m
return m;