---@class System.ComponentModel.EventHandlerList
---instance properties
---@field public Item System.Delegate
local m = {};

---@param key System.Object
---@param value System.Delegate
function m:AddHandler(key, value) end
---@param listToAddFrom System.ComponentModel.EventHandlerList
function m:AddHandlers(listToAddFrom) end
---@param key System.Object
---@param value System.Delegate
function m:RemoveHandler(key, value) end
function m:Dispose() end
System.ComponentModel.EventHandlerList=m
return m;