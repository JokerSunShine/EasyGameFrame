---@class System.CodeDom.CodePrimitiveExpression : System.CodeDom.CodeExpression
---instance properties
---@field public Value System.Object
local m = {};

System.CodeDom.CodePrimitiveExpression=m
return m;