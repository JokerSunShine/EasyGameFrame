---@class System.CodeDom.Compiler.Executor
local m = {};
---@param cmd System.String
---@param tempFiles System.CodeDom.Compiler.TempFileCollection
function m.ExecWait(cmd, tempFiles) end
---@param userToken System.IntPtr
---@param cmd System.String
---@param currentDir System.String
---@param tempFiles System.CodeDom.Compiler.TempFileCollection
---@param outputName System.String
---@param errorName System.String
---@return System.Int32
function m.ExecWaitWithCapture(userToken, cmd, currentDir, tempFiles, outputName, errorName) end
---@param userToken System.IntPtr
---@param cmd System.String
---@param tempFiles System.CodeDom.Compiler.TempFileCollection
---@param outputName System.String
---@param errorName System.String
---@return System.Int32
function m.ExecWaitWithCapture(userToken, cmd, tempFiles, outputName, errorName) end
---@param cmd System.String
---@param currentDir System.String
---@param tempFiles System.CodeDom.Compiler.TempFileCollection
---@param outputName System.String
---@param errorName System.String
---@return System.Int32
function m.ExecWaitWithCapture(cmd, currentDir, tempFiles, outputName, errorName) end
---@param cmd System.String
---@param tempFiles System.CodeDom.Compiler.TempFileCollection
---@param outputName System.String
---@param errorName System.String
---@return System.Int32
function m.ExecWaitWithCapture(cmd, tempFiles, outputName, errorName) end

System.CodeDom.Compiler.Executor=m
return m;