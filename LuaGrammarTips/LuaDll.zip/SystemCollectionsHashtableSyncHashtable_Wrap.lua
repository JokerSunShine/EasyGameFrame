---@class System.Collections.HashtableSyncHashtable : System.Collections.Hashtable
---instance properties
---@field public Count System.Int32
---@field public IsSynchronized System.Boolean
---@field public SyncRoot System.Object
---@field public IsFixedSize System.Boolean
---@field public IsReadOnly System.Boolean
---@field public Keys System.Collections.ICollection
---@field public Values System.Collections.ICollection
---@field public Item System.Object
local m = {};

---@param info System.Runtime.Serialization.SerializationInfo
---@param context System.Runtime.Serialization.StreamingContext
function m:GetObjectData(info, context) end
---@param array System.Array
---@param arrayIndex System.Int32
function m:CopyTo(array, arrayIndex) end
---@param key System.Object
---@param value System.Object
function m:Add(key, value) end
function m:Clear() end
---@param key System.Object
---@return System.Boolean
function m:Contains(key) end
---@return System.Collections.IDictionaryEnumerator
function m:GetEnumerator() end
---@param key System.Object
function m:Remove(key) end
---@param key System.Object
---@return System.Boolean
function m:ContainsKey(key) end
---@param value System.Object
---@return System.Boolean
function m:ContainsValue(value) end
---@return System.Object
function m:Clone() end
System.Collections.HashtableSyncHashtable=m
return m;