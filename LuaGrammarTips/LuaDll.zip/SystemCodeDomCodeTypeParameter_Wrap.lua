---@class System.CodeDom.CodeTypeParameter : System.CodeDom.CodeObject
---instance properties
---@field public Constraints System.CodeDom.CodeTypeReferenceCollection
---@field public CustomAttributes System.CodeDom.CodeAttributeDeclarationCollection
---@field public HasConstructorConstraint System.Boolean
---@field public Name System.String
local m = {};

System.CodeDom.CodeTypeParameter=m
return m;