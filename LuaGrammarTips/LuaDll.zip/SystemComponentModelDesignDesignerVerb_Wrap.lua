---@class System.ComponentModel.Design.DesignerVerb : System.ComponentModel.Design.MenuCommand
---instance properties
---@field public Text System.String
---@field public Description System.String
local m = {};

---@return System.String
function m:ToString() end
System.ComponentModel.Design.DesignerVerb=m
return m;