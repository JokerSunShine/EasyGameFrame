---@class System.Attribute
---instance properties
---@field public TypeId System.Object
local m = {};
---@param element System.Reflection.ParameterInfo
---@param attributeType System.Type
---@return System.Attribute
function m.GetCustomAttribute(element, attributeType) end
---@param element System.Reflection.MemberInfo
---@param attributeType System.Type
---@return System.Attribute
function m.GetCustomAttribute(element, attributeType) end
---@param element System.Reflection.Assembly
---@param attributeType System.Type
---@return System.Attribute
function m.GetCustomAttribute(element, attributeType) end
---@param element System.Reflection.Module
---@param attributeType System.Type
---@return System.Attribute
function m.GetCustomAttribute(element, attributeType) end
---@param element System.Reflection.Module
---@param attributeType System.Type
---@param inherit System.Boolean
---@return System.Attribute
function m.GetCustomAttribute(element, attributeType, inherit) end
---@param element System.Reflection.Assembly
---@param attributeType System.Type
---@param inherit System.Boolean
---@return System.Attribute
function m.GetCustomAttribute(element, attributeType, inherit) end
---@param element System.Reflection.ParameterInfo
---@param attributeType System.Type
---@param inherit System.Boolean
---@return System.Attribute
function m.GetCustomAttribute(element, attributeType, inherit) end
---@param element System.Reflection.MemberInfo
---@param attributeType System.Type
---@param inherit System.Boolean
---@return System.Attribute
function m.GetCustomAttribute(element, attributeType, inherit) end
---@param element System.Reflection.Assembly
---@return System.Attribute
function m.GetCustomAttributes(element) end
---@param element System.Reflection.ParameterInfo
---@return System.Attribute
function m.GetCustomAttributes(element) end
---@param element System.Reflection.MemberInfo
---@return System.Attribute
function m.GetCustomAttributes(element) end
---@param element System.Reflection.Module
---@return System.Attribute
function m.GetCustomAttributes(element) end
---@param element System.Reflection.Assembly
---@param attributeType System.Type
---@return System.Attribute
function m.GetCustomAttributes(element, attributeType) end
---@param element System.Reflection.Module
---@param attributeType System.Type
---@return System.Attribute
function m.GetCustomAttributes(element, attributeType) end
---@param element System.Reflection.ParameterInfo
---@param attributeType System.Type
---@return System.Attribute
function m.GetCustomAttributes(element, attributeType) end
---@param element System.Reflection.MemberInfo
---@param type System.Type
---@return System.Attribute
function m.GetCustomAttributes(element, type) end
---@param element System.Reflection.Assembly
---@param attributeType System.Type
---@param inherit System.Boolean
---@return System.Attribute
function m.GetCustomAttributes(element, attributeType, inherit) end
---@param element System.Reflection.ParameterInfo
---@param attributeType System.Type
---@param inherit System.Boolean
---@return System.Attribute
function m.GetCustomAttributes(element, attributeType, inherit) end
---@param element System.Reflection.Module
---@param attributeType System.Type
---@param inherit System.Boolean
---@return System.Attribute
function m.GetCustomAttributes(element, attributeType, inherit) end
---@param element System.Reflection.MemberInfo
---@param type System.Type
---@param inherit System.Boolean
---@return System.Attribute
function m.GetCustomAttributes(element, type, inherit) end
---@param element System.Reflection.Module
---@param inherit System.Boolean
---@return System.Attribute
function m.GetCustomAttributes(element, inherit) end
---@param element System.Reflection.Assembly
---@param inherit System.Boolean
---@return System.Attribute
function m.GetCustomAttributes(element, inherit) end
---@param element System.Reflection.MemberInfo
---@param inherit System.Boolean
---@return System.Attribute
function m.GetCustomAttributes(element, inherit) end
---@param element System.Reflection.ParameterInfo
---@param inherit System.Boolean
---@return System.Attribute
function m.GetCustomAttributes(element, inherit) end
---@param element System.Reflection.Module
---@param attributeType System.Type
---@return System.Boolean
function m.IsDefined(element, attributeType) end
---@param element System.Reflection.ParameterInfo
---@param attributeType System.Type
---@return System.Boolean
function m.IsDefined(element, attributeType) end
---@param element System.Reflection.MemberInfo
---@param attributeType System.Type
---@return System.Boolean
function m.IsDefined(element, attributeType) end
---@param element System.Reflection.Assembly
---@param attributeType System.Type
---@return System.Boolean
function m.IsDefined(element, attributeType) end
---@param element System.Reflection.MemberInfo
---@param attributeType System.Type
---@param inherit System.Boolean
---@return System.Boolean
function m.IsDefined(element, attributeType, inherit) end
---@param element System.Reflection.Assembly
---@param attributeType System.Type
---@param inherit System.Boolean
---@return System.Boolean
function m.IsDefined(element, attributeType, inherit) end
---@param element System.Reflection.Module
---@param attributeType System.Type
---@param inherit System.Boolean
---@return System.Boolean
function m.IsDefined(element, attributeType, inherit) end
---@param element System.Reflection.ParameterInfo
---@param attributeType System.Type
---@param inherit System.Boolean
---@return System.Boolean
function m.IsDefined(element, attributeType, inherit) end

---@return System.Int32
function m:GetHashCode() end
---@return System.Boolean
function m:IsDefaultAttribute() end
---@param obj System.Object
---@return System.Boolean
function m:Match(obj) end
---@param obj System.Object
---@return System.Boolean
function m:Equals(obj) end
System.Attribute=m
return m;