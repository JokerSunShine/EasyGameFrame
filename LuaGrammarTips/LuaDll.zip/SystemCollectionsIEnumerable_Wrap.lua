---@class System.Collections.IEnumerable
local m = {};

---@return System.Collections.IEnumerator
function m:GetEnumerator() end
System.Collections.IEnumerable=m
return m;