---@class System.ComponentModel.BindableSupport
---@field No @0
---@field Yes @1
---@field Default @2
local m = {};
System.ComponentModel.BindableSupport=m
return m;