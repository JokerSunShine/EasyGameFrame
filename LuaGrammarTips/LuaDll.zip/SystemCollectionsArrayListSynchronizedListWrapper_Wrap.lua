---@class System.Collections.ArrayListSynchronizedListWrapper : System.Collections.ArrayListListWrapper
---instance properties
---@field public Count System.Int32
---@field public IsSynchronized System.Boolean
---@field public SyncRoot System.Object
---@field public IsFixedSize System.Boolean
---@field public IsReadOnly System.Boolean
---@field public Item System.Object
local m = {};

---@param value System.Object
---@return System.Int32
function m:Add(value) end
function m:Clear() end
---@param value System.Object
---@return System.Boolean
function m:Contains(value) end
---@param value System.Object
---@return System.Int32
function m:IndexOf(value) end
---@param index System.Int32
---@param value System.Object
function m:Insert(index, value) end
---@param value System.Object
function m:Remove(value) end
---@param index System.Int32
function m:RemoveAt(index) end
---@param array System.Array
---@param index System.Int32
function m:CopyTo(array, index) end
---@return System.Collections.IEnumerator
function m:GetEnumerator() end
System.Collections.ArrayListSynchronizedListWrapper=m
return m;