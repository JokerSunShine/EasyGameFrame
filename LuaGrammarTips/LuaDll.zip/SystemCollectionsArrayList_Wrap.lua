---@class System.Collections.ArrayList
---instance properties
---@field public Item System.Object
---@field public Count System.Int32
---@field public Capacity System.Int32
---@field public IsFixedSize System.Boolean
---@field public IsReadOnly System.Boolean
---@field public IsSynchronized System.Boolean
---@field public SyncRoot System.Object
local m = {};
---@param list System.Collections.IList
---@return System.Collections.ArrayList
function m.Adapter(list) end
---@param list System.Collections.ArrayList
---@return System.Collections.ArrayList
function m.Synchronized(list) end
---@param list System.Collections.IList
---@return System.Collections.IList
function m.Synchronized(list) end
---@param list System.Collections.ArrayList
---@return System.Collections.ArrayList
function m.ReadOnly(list) end
---@param list System.Collections.IList
---@return System.Collections.IList
function m.ReadOnly(list) end
---@param list System.Collections.ArrayList
---@return System.Collections.ArrayList
function m.FixedSize(list) end
---@param list System.Collections.IList
---@return System.Collections.IList
function m.FixedSize(list) end
---@param value System.Object
---@param count System.Int32
---@return System.Collections.ArrayList
function m.Repeat(value, count) end

---@param value System.Object
---@return System.Int32
function m:Add(value) end
function m:Clear() end
---@param item System.Object
---@return System.Boolean
function m:Contains(item) end
---@param value System.Object
---@return System.Int32
function m:IndexOf(value) end
---@param value System.Object
---@param startIndex System.Int32
---@return System.Int32
function m:IndexOf(value, startIndex) end
---@param value System.Object
---@param startIndex System.Int32
---@param count System.Int32
---@return System.Int32
function m:IndexOf(value, startIndex, count) end
---@param value System.Object
---@return System.Int32
function m:LastIndexOf(value) end
---@param value System.Object
---@param startIndex System.Int32
---@return System.Int32
function m:LastIndexOf(value, startIndex) end
---@param value System.Object
---@param startIndex System.Int32
---@param count System.Int32
---@return System.Int32
function m:LastIndexOf(value, startIndex, count) end
---@param index System.Int32
---@param value System.Object
function m:Insert(index, value) end
---@param index System.Int32
---@param c System.Collections.ICollection
function m:InsertRange(index, c) end
---@param obj System.Object
function m:Remove(obj) end
---@param index System.Int32
function m:RemoveAt(index) end
---@param index System.Int32
---@param count System.Int32
function m:RemoveRange(index, count) end
function m:Reverse() end
---@param index System.Int32
---@param count System.Int32
function m:Reverse(index, count) end
---@param array System.Array
function m:CopyTo(array) end
---@param array System.Array
---@param arrayIndex System.Int32
function m:CopyTo(array, arrayIndex) end
---@param index System.Int32
---@param array System.Array
---@param arrayIndex System.Int32
---@param count System.Int32
function m:CopyTo(index, array, arrayIndex, count) end
---@return System.Collections.IEnumerator
function m:GetEnumerator() end
---@param index System.Int32
---@param count System.Int32
---@return System.Collections.IEnumerator
function m:GetEnumerator(index, count) end
---@param c System.Collections.ICollection
function m:AddRange(c) end
---@param value System.Object
---@return System.Int32
function m:BinarySearch(value) end
---@param value System.Object
---@param comparer System.Collections.IComparer
---@return System.Int32
function m:BinarySearch(value, comparer) end
---@param index System.Int32
---@param count System.Int32
---@param value System.Object
---@param comparer System.Collections.IComparer
---@return System.Int32
function m:BinarySearch(index, count, value, comparer) end
---@param index System.Int32
---@param count System.Int32
---@return System.Collections.ArrayList
function m:GetRange(index, count) end
---@param index System.Int32
---@param c System.Collections.ICollection
function m:SetRange(index, c) end
function m:TrimToSize() end
function m:Sort() end
---@param comparer System.Collections.IComparer
function m:Sort(comparer) end
---@param index System.Int32
---@param count System.Int32
---@param comparer System.Collections.IComparer
function m:Sort(index, count, comparer) end
---@return System.Object
function m:ToArray() end
---@param type System.Type
---@return System.Array
function m:ToArray(type) end
---@return System.Object
function m:Clone() end
System.Collections.ArrayList=m
return m;