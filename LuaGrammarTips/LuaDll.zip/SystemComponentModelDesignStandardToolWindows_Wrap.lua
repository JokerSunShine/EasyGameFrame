---@class System.ComponentModel.Design.StandardToolWindows
---fields
---@field public ObjectBrowser System.Guid
---@field public OutputWindow System.Guid
---@field public ProjectExplorer System.Guid
---@field public PropertyBrowser System.Guid
---@field public RelatedLinks System.Guid
---@field public ServerExplorer System.Guid
---@field public TaskList System.Guid
---@field public Toolbox System.Guid
local m = {};

System.ComponentModel.Design.StandardToolWindows=m
return m;