---@class System.CodeDom.CodeCommentStatementCollection : System.Collections.CollectionBase
---instance properties
---@field public Item System.CodeDom.CodeCommentStatement
local m = {};

---@param value System.CodeDom.CodeCommentStatement
---@return System.Int32
function m:Add(value) end
---@param value System.CodeDom.CodeCommentStatement
function m:AddRange(value) end
---@param value System.CodeDom.CodeCommentStatementCollection
function m:AddRange(value) end
---@param value System.CodeDom.CodeCommentStatement
---@return System.Boolean
function m:Contains(value) end
---@param array System.CodeDom.CodeCommentStatement
---@param index System.Int32
function m:CopyTo(array, index) end
---@param value System.CodeDom.CodeCommentStatement
---@return System.Int32
function m:IndexOf(value) end
---@param index System.Int32
---@param value System.CodeDom.CodeCommentStatement
function m:Insert(index, value) end
---@param value System.CodeDom.CodeCommentStatement
function m:Remove(value) end
System.CodeDom.CodeCommentStatementCollection=m
return m;