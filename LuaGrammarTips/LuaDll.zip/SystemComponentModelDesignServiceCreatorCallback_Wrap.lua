---@class System.ComponentModel.Design.ServiceCreatorCallback : System.MulticastDelegate
local m = {};

---@param container System.ComponentModel.Design.IServiceContainer
---@param serviceType System.Type
---@return System.Object
function m:Invoke(container, serviceType) end
---@param container System.ComponentModel.Design.IServiceContainer
---@param serviceType System.Type
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(container, serviceType, callback, object) end
---@param result System.IAsyncResult
---@return System.Object
function m:EndInvoke(result) end
System.ComponentModel.Design.ServiceCreatorCallback=m
return m;