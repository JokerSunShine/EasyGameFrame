---@class System.ComponentModel.Design.SelectionTypes
---@field Auto @1
---@field Auto @1
---@field Replace @2
---@field MouseDown @4
---@field MouseUp @8
---@field Click @16
---@field Click @16
---@field Valid @31
---@field Toggle @32
---@field Add @64
---@field Remove @128
local m = {};
System.ComponentModel.Design.SelectionTypes=m
return m;