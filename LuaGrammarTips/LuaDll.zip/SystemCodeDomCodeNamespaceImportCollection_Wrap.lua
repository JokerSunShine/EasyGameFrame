---@class System.CodeDom.CodeNamespaceImportCollection
---instance properties
---@field public Count System.Int32
---@field public Item System.CodeDom.CodeNamespaceImport
local m = {};

---@param value System.CodeDom.CodeNamespaceImport
function m:Add(value) end
---@param value System.CodeDom.CodeNamespaceImport
function m:AddRange(value) end
function m:Clear() end
---@return System.Collections.IEnumerator
function m:GetEnumerator() end
System.CodeDom.CodeNamespaceImportCollection=m
return m;