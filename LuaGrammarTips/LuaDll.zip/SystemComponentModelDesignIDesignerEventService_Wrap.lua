---@class System.ComponentModel.Design.IDesignerEventService
---instance properties
---@field public ActiveDesigner System.ComponentModel.Design.IDesignerHost
---@field public Designers System.ComponentModel.Design.DesignerCollection
local m = {};

---@param value System.ComponentModel.Design.ActiveDesignerEventHandler
function m:add_ActiveDesignerChanged(value) end
---@param value System.ComponentModel.Design.ActiveDesignerEventHandler
function m:remove_ActiveDesignerChanged(value) end
---@param value System.ComponentModel.Design.DesignerEventHandler
function m:add_DesignerCreated(value) end
---@param value System.ComponentModel.Design.DesignerEventHandler
function m:remove_DesignerCreated(value) end
---@param value System.ComponentModel.Design.DesignerEventHandler
function m:add_DesignerDisposed(value) end
---@param value System.ComponentModel.Design.DesignerEventHandler
function m:remove_DesignerDisposed(value) end
---@param value System.EventHandler
function m:add_SelectionChanged(value) end
---@param value System.EventHandler
function m:remove_SelectionChanged(value) end
System.ComponentModel.Design.IDesignerEventService=m
return m;