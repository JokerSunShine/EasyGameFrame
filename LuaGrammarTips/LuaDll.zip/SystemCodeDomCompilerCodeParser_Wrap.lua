---@class System.CodeDom.Compiler.CodeParser
local m = {};

---@param codeStream System.IO.TextReader
---@return System.CodeDom.CodeCompileUnit
function m:Parse(codeStream) end
System.CodeDom.Compiler.CodeParser=m
return m;