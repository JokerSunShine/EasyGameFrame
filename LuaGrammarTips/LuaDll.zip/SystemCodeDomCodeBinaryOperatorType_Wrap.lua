---@class System.CodeDom.CodeBinaryOperatorType
---@field Add @0
---@field Subtract @1
---@field Multiply @2
---@field Divide @3
---@field Modulus @4
---@field Assign @5
---@field IdentityInequality @6
---@field IdentityEquality @7
---@field ValueEquality @8
---@field BitwiseOr @9
---@field BitwiseAnd @10
---@field BooleanOr @11
---@field BooleanAnd @12
---@field LessThan @13
---@field LessThanOrEqual @14
---@field GreaterThan @15
---@field GreaterThanOrEqual @16
local m = {};
System.CodeDom.CodeBinaryOperatorType=m
return m;