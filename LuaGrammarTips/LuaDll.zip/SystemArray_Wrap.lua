---@class System.Array
---instance properties
---@field public Length System.Int32
---@field public LongLength System.Int64
---@field public Rank System.Int32
---@field public IsSynchronized System.Boolean
---@field public SyncRoot System.Object
---@field public IsFixedSize System.Boolean
---@field public IsReadOnly System.Boolean
local m = {};
---@param elementType System.Type
---@param length System.Int32
---@return System.Array
function m.CreateInstance(elementType, length) end
---@param elementType System.Type
---@param length1 System.Int32
---@param length2 System.Int32
---@return System.Array
function m.CreateInstance(elementType, length1, length2) end
---@param elementType System.Type
---@param length1 System.Int32
---@param length2 System.Int32
---@param length3 System.Int32
---@return System.Array
function m.CreateInstance(elementType, length1, length2, length3) end
---@param elementType System.Type
---@param lengths System.Int32
---@return System.Array
function m.CreateInstance(elementType, lengths) end
---@param elementType System.Type
---@param lengths System.Int32
---@param lowerBounds System.Int32
---@return System.Array
function m.CreateInstance(elementType, lengths, lowerBounds) end
---@param elementType System.Type
---@param lengths System.Int64
---@return System.Array
function m.CreateInstance(elementType, lengths) end
---@param array System.Array
---@param value System.Object
---@return System.Int32
function m.BinarySearch(array, value) end
---@param array System.Array
---@param value System.Object
---@param comparer System.Collections.IComparer
---@return System.Int32
function m.BinarySearch(array, value, comparer) end
---@param array System.Array
---@param index System.Int32
---@param length System.Int32
---@param value System.Object
---@return System.Int32
function m.BinarySearch(array, index, length, value) end
---@param array System.Array
---@param index System.Int32
---@param length System.Int32
---@param value System.Object
---@param comparer System.Collections.IComparer
---@return System.Int32
function m.BinarySearch(array, index, length, value, comparer) end
---@param array System.Array
---@param index System.Int32
---@param length System.Int32
function m.Clear(array, index, length) end
---@param sourceArray System.Array
---@param destinationArray System.Array
---@param length System.Int32
function m.Copy(sourceArray, destinationArray, length) end
---@param sourceArray System.Array
---@param sourceIndex System.Int32
---@param destinationArray System.Array
---@param destinationIndex System.Int32
---@param length System.Int32
function m.Copy(sourceArray, sourceIndex, destinationArray, destinationIndex, length) end
---@param sourceArray System.Array
---@param sourceIndex System.Int64
---@param destinationArray System.Array
---@param destinationIndex System.Int64
---@param length System.Int64
function m.Copy(sourceArray, sourceIndex, destinationArray, destinationIndex, length) end
---@param sourceArray System.Array
---@param destinationArray System.Array
---@param length System.Int64
function m.Copy(sourceArray, destinationArray, length) end
---@param array System.Array
---@param value System.Object
---@return System.Int32
function m.IndexOf(array, value) end
---@param array System.Array
---@param value System.Object
---@param startIndex System.Int32
---@return System.Int32
function m.IndexOf(array, value, startIndex) end
---@param array System.Array
---@param value System.Object
---@param startIndex System.Int32
---@param count System.Int32
---@return System.Int32
function m.IndexOf(array, value, startIndex, count) end
---@param array System.Array
---@param value System.Object
---@return System.Int32
function m.LastIndexOf(array, value) end
---@param array System.Array
---@param value System.Object
---@param startIndex System.Int32
---@return System.Int32
function m.LastIndexOf(array, value, startIndex) end
---@param array System.Array
---@param value System.Object
---@param startIndex System.Int32
---@param count System.Int32
---@return System.Int32
function m.LastIndexOf(array, value, startIndex, count) end
---@param array System.Array
function m.Reverse(array) end
---@param array System.Array
---@param index System.Int32
---@param length System.Int32
function m.Reverse(array, index, length) end
---@param array System.Array
function m.Sort(array) end
---@param keys System.Array
---@param items System.Array
function m.Sort(keys, items) end
---@param array System.Array
---@param comparer System.Collections.IComparer
function m.Sort(array, comparer) end
---@param array System.Array
---@param index System.Int32
---@param length System.Int32
function m.Sort(array, index, length) end
---@param keys System.Array
---@param items System.Array
---@param comparer System.Collections.IComparer
function m.Sort(keys, items, comparer) end
---@param keys System.Array
---@param items System.Array
---@param index System.Int32
---@param length System.Int32
function m.Sort(keys, items, index, length) end
---@param array System.Array
---@param index System.Int32
---@param length System.Int32
---@param comparer System.Collections.IComparer
function m.Sort(array, index, length, comparer) end
---@param keys System.Array
---@param items System.Array
---@param index System.Int32
---@param length System.Int32
---@param comparer System.Collections.IComparer
function m.Sort(keys, items, index, length, comparer) end
---@param sourceArray System.Array
---@param sourceIndex System.Int32
---@param destinationArray System.Array
---@param destinationIndex System.Int32
---@param length System.Int32
function m.ConstrainedCopy(sourceArray, sourceIndex, destinationArray, destinationIndex, length) end

---@param dimension System.Int32
---@return System.Int32
function m:GetLength(dimension) end
---@param dimension System.Int32
---@return System.Int64
function m:GetLongLength(dimension) end
---@param dimension System.Int32
---@return System.Int32
function m:GetLowerBound(dimension) end
---@param indices System.Int32
---@return System.Object
function m:GetValue(indices) end
---@param value System.Object
---@param indices System.Int32
function m:SetValue(value, indices) end
---@return System.Collections.IEnumerator
function m:GetEnumerator() end
---@param dimension System.Int32
---@return System.Int32
function m:GetUpperBound(dimension) end
---@param index System.Int32
---@return System.Object
function m:GetValue(index) end
---@param index1 System.Int32
---@param index2 System.Int32
---@return System.Object
function m:GetValue(index1, index2) end
---@param index1 System.Int32
---@param index2 System.Int32
---@param index3 System.Int32
---@return System.Object
function m:GetValue(index1, index2, index3) end
---@param index System.Int64
---@return System.Object
function m:GetValue(index) end
---@param index1 System.Int64
---@param index2 System.Int64
---@return System.Object
function m:GetValue(index1, index2) end
---@param index1 System.Int64
---@param index2 System.Int64
---@param index3 System.Int64
---@return System.Object
function m:GetValue(index1, index2, index3) end
---@param value System.Object
---@param index System.Int64
function m:SetValue(value, index) end
---@param value System.Object
---@param index1 System.Int64
---@param index2 System.Int64
function m:SetValue(value, index1, index2) end
---@param value System.Object
---@param index1 System.Int64
---@param index2 System.Int64
---@param index3 System.Int64
function m:SetValue(value, index1, index2, index3) end
---@param value System.Object
---@param index System.Int32
function m:SetValue(value, index) end
---@param value System.Object
---@param index1 System.Int32
---@param index2 System.Int32
function m:SetValue(value, index1, index2) end
---@param value System.Object
---@param index1 System.Int32
---@param index2 System.Int32
---@param index3 System.Int32
function m:SetValue(value, index1, index2, index3) end
---@param indices System.Int64
---@return System.Object
function m:GetValue(indices) end
---@param value System.Object
---@param indices System.Int64
function m:SetValue(value, indices) end
---@return System.Object
function m:Clone() end
function m:Initialize() end
---@param array System.Array
---@param index System.Int32
function m:CopyTo(array, index) end
---@param array System.Array
---@param index System.Int64
function m:CopyTo(array, index) end
System.Array=m
return m;