---@class System.CodeDom.Compiler.CompilerErrorCollection : System.Collections.CollectionBase
---instance properties
---@field public Item System.CodeDom.Compiler.CompilerError
---@field public HasErrors System.Boolean
---@field public HasWarnings System.Boolean
local m = {};

---@param value System.CodeDom.Compiler.CompilerError
---@return System.Int32
function m:Add(value) end
---@param value System.CodeDom.Compiler.CompilerError
function m:AddRange(value) end
---@param value System.CodeDom.Compiler.CompilerErrorCollection
function m:AddRange(value) end
---@param value System.CodeDom.Compiler.CompilerError
---@return System.Boolean
function m:Contains(value) end
---@param array System.CodeDom.Compiler.CompilerError
---@param index System.Int32
function m:CopyTo(array, index) end
---@param value System.CodeDom.Compiler.CompilerError
---@return System.Int32
function m:IndexOf(value) end
---@param index System.Int32
---@param value System.CodeDom.Compiler.CompilerError
function m:Insert(index, value) end
---@param value System.CodeDom.Compiler.CompilerError
function m:Remove(value) end
System.CodeDom.Compiler.CompilerErrorCollection=m
return m;