---@class System.ComponentModel.InstanceCreationEditor
---instance properties
---@field public Text System.String
local m = {};

---@param context System.ComponentModel.ITypeDescriptorContext
---@param type System.Type
---@return System.Object
function m:CreateInstance(context, type) end
System.ComponentModel.InstanceCreationEditor=m
return m;