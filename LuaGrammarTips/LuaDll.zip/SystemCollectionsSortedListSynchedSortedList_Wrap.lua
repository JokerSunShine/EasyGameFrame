---@class System.Collections.SortedListSynchedSortedList : System.Collections.SortedList
---instance properties
---@field public Capacity System.Int32
---@field public Count System.Int32
---@field public IsSynchronized System.Boolean
---@field public SyncRoot System.Object
---@field public IsFixedSize System.Boolean
---@field public IsReadOnly System.Boolean
---@field public Keys System.Collections.ICollection
---@field public Values System.Collections.ICollection
---@field public Item System.Object
local m = {};

---@param array System.Array
---@param arrayIndex System.Int32
function m:CopyTo(array, arrayIndex) end
---@param key System.Object
---@param value System.Object
function m:Add(key, value) end
function m:Clear() end
---@param key System.Object
---@return System.Boolean
function m:Contains(key) end
---@return System.Collections.IDictionaryEnumerator
function m:GetEnumerator() end
---@param key System.Object
function m:Remove(key) end
---@param key System.Object
---@return System.Boolean
function m:ContainsKey(key) end
---@param value System.Object
---@return System.Boolean
function m:ContainsValue(value) end
---@return System.Object
function m:Clone() end
---@param index System.Int32
---@return System.Object
function m:GetByIndex(index) end
---@param index System.Int32
---@return System.Object
function m:GetKey(index) end
---@return System.Collections.IList
function m:GetKeyList() end
---@return System.Collections.IList
function m:GetValueList() end
---@param index System.Int32
function m:RemoveAt(index) end
---@param key System.Object
---@return System.Int32
function m:IndexOfKey(key) end
---@param val System.Object
---@return System.Int32
function m:IndexOfValue(val) end
---@param index System.Int32
---@param value System.Object
function m:SetByIndex(index, value) end
function m:TrimToSize() end
System.Collections.SortedListSynchedSortedList=m
return m;