---@class System.ComponentModel.Design.Serialization.DesignerLoader
---instance properties
---@field public Loading System.Boolean
local m = {};

---@param host System.ComponentModel.Design.Serialization.IDesignerLoaderHost
function m:BeginLoad(host) end
function m:Dispose() end
function m:Flush() end
System.ComponentModel.Design.Serialization.DesignerLoader=m
return m;