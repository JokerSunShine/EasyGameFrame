---@class System.ComponentModel.Design.IComponentInitializer
local m = {};

---@param defaultValues System.Collections.IDictionary
function m:InitializeExistingComponent(defaultValues) end
---@param defaultValues System.Collections.IDictionary
function m:InitializeNewComponent(defaultValues) end
System.ComponentModel.Design.IComponentInitializer=m
return m;