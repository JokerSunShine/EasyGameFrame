---@class System.ComponentModel.Design.HelpContextType
---@field Ambient @0
---@field Window @1
---@field Selection @2
---@field ToolWindowSelection @3
local m = {};
System.ComponentModel.Design.HelpContextType=m
return m;