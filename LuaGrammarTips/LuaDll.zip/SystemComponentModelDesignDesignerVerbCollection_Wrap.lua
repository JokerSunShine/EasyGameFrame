---@class System.ComponentModel.Design.DesignerVerbCollection : System.Collections.CollectionBase
---instance properties
---@field public Item System.ComponentModel.Design.DesignerVerb
local m = {};

---@param value System.ComponentModel.Design.DesignerVerb
---@return System.Int32
function m:Add(value) end
---@param value System.ComponentModel.Design.DesignerVerb
function m:AddRange(value) end
---@param value System.ComponentModel.Design.DesignerVerbCollection
function m:AddRange(value) end
---@param value System.ComponentModel.Design.DesignerVerb
---@return System.Boolean
function m:Contains(value) end
---@param array System.ComponentModel.Design.DesignerVerb
---@param index System.Int32
function m:CopyTo(array, index) end
---@param value System.ComponentModel.Design.DesignerVerb
---@return System.Int32
function m:IndexOf(value) end
---@param index System.Int32
---@param value System.ComponentModel.Design.DesignerVerb
function m:Insert(index, value) end
---@param value System.ComponentModel.Design.DesignerVerb
function m:Remove(value) end
System.ComponentModel.Design.DesignerVerbCollection=m
return m;