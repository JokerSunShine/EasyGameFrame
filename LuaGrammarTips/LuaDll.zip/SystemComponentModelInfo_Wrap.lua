---@class System.ComponentModel.Info
---instance properties
---@field public InfoType System.Type
local m = {};

---@return System.ComponentModel.AttributeCollection
function m:GetAttributes() end
---@return System.ComponentModel.EventDescriptorCollection
function m:GetEvents() end
---@return System.ComponentModel.PropertyDescriptorCollection
function m:GetProperties() end
---@param attributes System.Attribute
---@return System.ComponentModel.EventDescriptorCollection
function m:GetEvents(attributes) end
---@param attributes System.Attribute
---@return System.ComponentModel.PropertyDescriptorCollection
function m:GetProperties(attributes) end
---@return System.ComponentModel.EventDescriptor
function m:GetDefaultEvent() end
---@return System.ComponentModel.PropertyDescriptor
function m:GetDefaultProperty() end
System.ComponentModel.Info=m
return m;