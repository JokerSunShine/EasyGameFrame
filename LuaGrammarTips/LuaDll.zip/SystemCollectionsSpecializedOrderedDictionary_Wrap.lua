---@class System.Collections.Specialized.OrderedDictionary
---instance properties
---@field public Count System.Int32
---@field public IsReadOnly System.Boolean
---@field public Item System.Object
---@field public Item System.Object
---@field public Keys System.Collections.ICollection
---@field public Values System.Collections.ICollection
local m = {};

---@param info System.Runtime.Serialization.SerializationInfo
---@param context System.Runtime.Serialization.StreamingContext
function m:GetObjectData(info, context) end
---@param array System.Array
---@param index System.Int32
function m:CopyTo(array, index) end
---@param key System.Object
---@param value System.Object
function m:Add(key, value) end
function m:Clear() end
---@param key System.Object
---@return System.Boolean
function m:Contains(key) end
---@return System.Collections.IDictionaryEnumerator
function m:GetEnumerator() end
---@param key System.Object
function m:Remove(key) end
---@return System.Collections.Specialized.OrderedDictionary
function m:AsReadOnly() end
---@param index System.Int32
---@param key System.Object
---@param value System.Object
function m:Insert(index, key, value) end
---@param index System.Int32
function m:RemoveAt(index) end
System.Collections.Specialized.OrderedDictionary=m
return m;