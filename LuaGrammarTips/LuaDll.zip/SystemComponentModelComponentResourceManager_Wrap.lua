---@class System.ComponentModel.ComponentResourceManager : System.Resources.ResourceManager
local m = {};

---@param value System.Object
---@param objectName System.String
function m:ApplyResources(value, objectName) end
---@param value System.Object
---@param objectName System.String
---@param culture System.Globalization.CultureInfo
function m:ApplyResources(value, objectName, culture) end
System.ComponentModel.ComponentResourceManager=m
return m;