---@class System.ArraySimpleEnumerator
---instance properties
---@field public Current System.Object
local m = {};

---@return System.Boolean
function m:MoveNext() end
function m:Reset() end
---@return System.Object
function m:Clone() end
System.ArraySimpleEnumerator=m
return m;