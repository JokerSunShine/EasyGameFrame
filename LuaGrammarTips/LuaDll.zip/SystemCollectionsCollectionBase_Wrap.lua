---@class System.Collections.CollectionBase
---instance properties
---@field public Count System.Int32
---@field public Capacity System.Int32
local m = {};

---@return System.Collections.IEnumerator
function m:GetEnumerator() end
function m:Clear() end
---@param index System.Int32
function m:RemoveAt(index) end
System.Collections.CollectionBase=m
return m;