---@class System.ComponentModel.Design.ComponentEventArgs : System.EventArgs
---instance properties
---@field public Component System.ComponentModel.IComponent
local m = {};

System.ComponentModel.Design.ComponentEventArgs=m
return m;