---@class System.CodeDom.CodeBinaryOperatorExpression : System.CodeDom.CodeExpression
---instance properties
---@field public Left System.CodeDom.CodeExpression
---@field public Operator System.CodeDom.CodeBinaryOperatorType
---@field public Right System.CodeDom.CodeExpression
local m = {};

System.CodeDom.CodeBinaryOperatorExpression=m
return m;