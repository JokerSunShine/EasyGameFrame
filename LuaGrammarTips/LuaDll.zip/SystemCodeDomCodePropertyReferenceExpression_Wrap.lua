---@class System.CodeDom.CodePropertyReferenceExpression : System.CodeDom.CodeExpression
---instance properties
---@field public PropertyName System.String
---@field public TargetObject System.CodeDom.CodeExpression
local m = {};

System.CodeDom.CodePropertyReferenceExpression=m
return m;