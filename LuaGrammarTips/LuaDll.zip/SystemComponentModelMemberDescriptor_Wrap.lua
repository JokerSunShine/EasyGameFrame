---@class System.ComponentModel.MemberDescriptor
---instance properties
---@field public Attributes System.ComponentModel.AttributeCollection
---@field public Category System.String
---@field public Description System.String
---@field public DesignTimeOnly System.Boolean
---@field public DisplayName System.String
---@field public Name System.String
---@field public IsBrowsable System.Boolean
local m = {};

---@return System.Int32
function m:GetHashCode() end
---@param obj System.Object
---@return System.Boolean
function m:Equals(obj) end
System.ComponentModel.MemberDescriptor=m
return m;