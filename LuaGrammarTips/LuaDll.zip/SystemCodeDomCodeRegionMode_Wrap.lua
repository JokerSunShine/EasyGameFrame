---@class System.CodeDom.CodeRegionMode
---@field None @0
---@field Start @1
---@field End @2
local m = {};
System.CodeDom.CodeRegionMode=m
return m;