---@class System.Collections.ArrayListReadOnlyListWrapper : System.Collections.ArrayListFixedSizeListWrapper
---instance properties
---@field public IsReadOnly System.Boolean
---@field public Item System.Object
local m = {};

System.Collections.ArrayListReadOnlyListWrapper=m
return m;