---@class System.ComponentModel.ListChangedEventArgs : System.EventArgs
---instance properties
---@field public ListChangedType System.ComponentModel.ListChangedType
---@field public OldIndex System.Int32
---@field public NewIndex System.Int32
---@field public PropertyDescriptor System.ComponentModel.PropertyDescriptor
local m = {};

System.ComponentModel.ListChangedEventArgs=m
return m;