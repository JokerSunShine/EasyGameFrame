---@class System.ComponentModel.IListSource
---instance properties
---@field public ContainsListCollection System.Boolean
local m = {};

---@return System.Collections.IList
function m:GetList() end
System.ComponentModel.IListSource=m
return m;