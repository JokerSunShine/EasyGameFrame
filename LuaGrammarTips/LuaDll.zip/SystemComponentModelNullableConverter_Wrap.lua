---@class System.ComponentModel.NullableConverter : System.ComponentModel.TypeConverter
---instance properties
---@field public NullableType System.Type
---@field public UnderlyingType System.Type
---@field public UnderlyingTypeConverter System.ComponentModel.TypeConverter
local m = {};

---@param context System.ComponentModel.ITypeDescriptorContext
---@param sourceType System.Type
---@return System.Boolean
function m:CanConvertFrom(context, sourceType) end
---@param context System.ComponentModel.ITypeDescriptorContext
---@param destinationType System.Type
---@return System.Boolean
function m:CanConvertTo(context, destinationType) end
---@param context System.ComponentModel.ITypeDescriptorContext
---@param culture System.Globalization.CultureInfo
---@param value System.Object
---@return System.Object
function m:ConvertFrom(context, culture, value) end
---@param context System.ComponentModel.ITypeDescriptorContext
---@param culture System.Globalization.CultureInfo
---@param value System.Object
---@param destinationType System.Type
---@return System.Object
function m:ConvertTo(context, culture, value, destinationType) end
---@param context System.ComponentModel.ITypeDescriptorContext
---@param propertyValues System.Collections.IDictionary
---@return System.Object
function m:CreateInstance(context, propertyValues) end
---@param context System.ComponentModel.ITypeDescriptorContext
---@return System.Boolean
function m:GetCreateInstanceSupported(context) end
---@param context System.ComponentModel.ITypeDescriptorContext
---@param value System.Object
---@param attributes System.Attribute
---@return System.ComponentModel.PropertyDescriptorCollection
function m:GetProperties(context, value, attributes) end
---@param context System.ComponentModel.ITypeDescriptorContext
---@return System.Boolean
function m:GetPropertiesSupported(context) end
---@param context System.ComponentModel.ITypeDescriptorContext
---@return System.ComponentModel.TypeConverterStandardValuesCollection
function m:GetStandardValues(context) end
---@param context System.ComponentModel.ITypeDescriptorContext
---@return System.Boolean
function m:GetStandardValuesExclusive(context) end
---@param context System.ComponentModel.ITypeDescriptorContext
---@return System.Boolean
function m:GetStandardValuesSupported(context) end
---@param context System.ComponentModel.ITypeDescriptorContext
---@param value System.Object
---@return System.Boolean
function m:IsValid(context, value) end
System.ComponentModel.NullableConverter=m
return m;