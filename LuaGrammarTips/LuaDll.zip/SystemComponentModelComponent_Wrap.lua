---@class System.ComponentModel.Component : System.MarshalByRefObject
---instance properties
---@field public Site System.ComponentModel.ISite
---@field public Container System.ComponentModel.IContainer
local m = {};

---@param value System.EventHandler
function m:add_Disposed(value) end
---@param value System.EventHandler
function m:remove_Disposed(value) end
function m:Dispose() end
---@return System.String
function m:ToString() end
System.ComponentModel.Component=m
return m;