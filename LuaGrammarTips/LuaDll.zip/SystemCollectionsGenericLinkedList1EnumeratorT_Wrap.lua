---@class System.Collections.Generic.LinkedList1EnumeratorT : System.ValueType
---instance properties
---@field public Current T
local m = {};

---@return System.Boolean
function m:MoveNext() end
function m:Dispose() end
System.Collections.Generic.LinkedList1EnumeratorT=m
return m;