---@class System.ComponentModel.CultureInfoConverterCultureInfoComparer
local m = {};

---@param first System.Object
---@param second System.Object
---@return System.Int32
function m:Compare(first, second) end
System.ComponentModel.CultureInfoConverterCultureInfoComparer=m
return m;