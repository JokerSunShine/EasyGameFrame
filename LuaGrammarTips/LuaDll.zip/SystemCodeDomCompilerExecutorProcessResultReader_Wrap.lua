---@class System.CodeDom.Compiler.ExecutorProcessResultReader
local m = {};

function m:Read() end
System.CodeDom.Compiler.ExecutorProcessResultReader=m
return m;