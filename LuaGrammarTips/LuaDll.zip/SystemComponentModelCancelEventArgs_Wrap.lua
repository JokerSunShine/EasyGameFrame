---@class System.ComponentModel.CancelEventArgs : System.EventArgs
---instance properties
---@field public Cancel System.Boolean
local m = {};

System.ComponentModel.CancelEventArgs=m
return m;