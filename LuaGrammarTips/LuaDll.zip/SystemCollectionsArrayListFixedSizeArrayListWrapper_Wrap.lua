---@class System.Collections.ArrayListFixedSizeArrayListWrapper : System.Collections.ArrayListArrayListWrapper
---instance properties
---@field public Capacity System.Int32
---@field public IsFixedSize System.Boolean
local m = {};

---@param value System.Object
---@return System.Int32
function m:Add(value) end
---@param c System.Collections.ICollection
function m:AddRange(c) end
function m:Clear() end
---@param index System.Int32
---@param value System.Object
function m:Insert(index, value) end
---@param index System.Int32
---@param c System.Collections.ICollection
function m:InsertRange(index, c) end
---@param value System.Object
function m:Remove(value) end
---@param index System.Int32
function m:RemoveAt(index) end
---@param index System.Int32
---@param count System.Int32
function m:RemoveRange(index, count) end
function m:TrimToSize() end
System.Collections.ArrayListFixedSizeArrayListWrapper=m
return m;