---@class System.Collections.Generic.RBTree
---instance properties
---@field public Count System.Int32
---@field public Item System.Collections.Generic.RBTreeNode
local m = {};

function m:Clear() end
---@return System.Collections.Generic.RBTreeNodeEnumerator
function m:GetEnumerator() end
System.Collections.Generic.RBTree=m
return m;