---@class System.CodeDom.Compiler.GeneratorSupport
---@field ArraysOfArrays @1
---@field EntryPointMethod @2
---@field GotoStatements @4
---@field MultidimensionalArrays @8
---@field StaticConstructors @16
---@field TryCatchStatements @32
---@field ReturnTypeAttributes @64
---@field DeclareValueTypes @128
---@field DeclareEnums @256
---@field DeclareDelegates @512
---@field DeclareInterfaces @1024
---@field DeclareEvents @2048
---@field AssemblyAttributes @4096
---@field ParameterAttributes @8192
---@field ReferenceParameters @16384
---@field ChainedConstructorArguments @32768
---@field NestedTypes @65536
---@field MultipleInterfaceMembers @131072
---@field PublicStaticMembers @262144
---@field ComplexExpressions @524288
---@field Win32Resources @1048576
---@field Resources @2097152
---@field PartialTypes @4194304
---@field GenericTypeReference @8388608
---@field GenericTypeDeclaration @16777216
---@field DeclareIndexerProperties @33554432
local m = {};
System.CodeDom.Compiler.GeneratorSupport=m
return m;