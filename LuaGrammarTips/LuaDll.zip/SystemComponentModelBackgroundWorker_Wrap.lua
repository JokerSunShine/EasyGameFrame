---@class System.ComponentModel.BackgroundWorker : System.ComponentModel.Component
---instance properties
---@field public CancellationPending System.Boolean
---@field public IsBusy System.Boolean
---@field public WorkerReportsProgress System.Boolean
---@field public WorkerSupportsCancellation System.Boolean
local m = {};

---@param value System.ComponentModel.DoWorkEventHandler
function m:add_DoWork(value) end
---@param value System.ComponentModel.DoWorkEventHandler
function m:remove_DoWork(value) end
---@param value System.ComponentModel.ProgressChangedEventHandler
function m:add_ProgressChanged(value) end
---@param value System.ComponentModel.ProgressChangedEventHandler
function m:remove_ProgressChanged(value) end
---@param value System.ComponentModel.RunWorkerCompletedEventHandler
function m:add_RunWorkerCompleted(value) end
---@param value System.ComponentModel.RunWorkerCompletedEventHandler
function m:remove_RunWorkerCompleted(value) end
function m:CancelAsync() end
---@param percentProgress System.Int32
function m:ReportProgress(percentProgress) end
---@param percentProgress System.Int32
---@param userState System.Object
function m:ReportProgress(percentProgress, userState) end
function m:RunWorkerAsync() end
---@param argument System.Object
function m:RunWorkerAsync(argument) end
System.ComponentModel.BackgroundWorker=m
return m;