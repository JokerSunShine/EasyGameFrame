---@class System.CodeDom.CodeTypeDeclarationCollection : System.Collections.CollectionBase
---instance properties
---@field public Item System.CodeDom.CodeTypeDeclaration
local m = {};

---@param value System.CodeDom.CodeTypeDeclaration
---@return System.Int32
function m:Add(value) end
---@param value System.CodeDom.CodeTypeDeclaration
function m:AddRange(value) end
---@param value System.CodeDom.CodeTypeDeclarationCollection
function m:AddRange(value) end
---@param value System.CodeDom.CodeTypeDeclaration
---@return System.Boolean
function m:Contains(value) end
---@param array System.CodeDom.CodeTypeDeclaration
---@param index System.Int32
function m:CopyTo(array, index) end
---@param value System.CodeDom.CodeTypeDeclaration
---@return System.Int32
function m:IndexOf(value) end
---@param index System.Int32
---@param value System.CodeDom.CodeTypeDeclaration
function m:Insert(index, value) end
---@param value System.CodeDom.CodeTypeDeclaration
function m:Remove(value) end
System.CodeDom.CodeTypeDeclarationCollection=m
return m;