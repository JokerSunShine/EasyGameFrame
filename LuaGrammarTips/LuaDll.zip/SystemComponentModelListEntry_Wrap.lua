---@class System.ComponentModel.ListEntry
---instance fields
---@field public key System.Object
---@field public value System.Delegate
---@field public next System.ComponentModel.ListEntry
local m = {};

System.ComponentModel.ListEntry=m
return m;