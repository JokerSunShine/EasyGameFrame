---@class System.Collections.DictionaryEntry : System.ValueType
---instance properties
---@field public Key System.Object
---@field public Value System.Object
local m = {};

System.Collections.DictionaryEntry=m
return m;