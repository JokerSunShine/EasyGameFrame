---@class System.CodeDom.MemberAttributes
---@field Abstract @1
---@field Final @2
---@field Static @3
---@field Override @4
---@field Const @5
---@field ScopeMask @15
---@field New @16
---@field VTableMask @240
---@field Overloaded @256
---@field Assembly @4096
---@field FamilyAndAssembly @8192
---@field Family @12288
---@field FamilyOrAssembly @16384
---@field Private @20480
---@field Public @24576
---@field AccessMask @61440
local m = {};
System.CodeDom.MemberAttributes=m
return m;