---@class System.AsyncCallback : System.MulticastDelegate
local m = {};

---@param ar System.IAsyncResult
function m:Invoke(ar) end
---@param ar System.IAsyncResult
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(ar, callback, object) end
---@param result System.IAsyncResult
function m:EndInvoke(result) end
System.AsyncCallback=m
return m;