---@class System.CodeDom.Compiler.CodeDomConfigurationHandler : System.Configuration.ConfigurationSection
---instance properties
---@field public Compilers System.CodeDom.Compiler.CompilerCollection
---@field public CompilerInfos System.CodeDom.Compiler.CompilerInfo
local m = {};

System.CodeDom.Compiler.CodeDomConfigurationHandler=m
return m;