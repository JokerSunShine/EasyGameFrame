---@class System.ComponentModel.Design.DesignerTransactionCloseEventHandler : System.MulticastDelegate
local m = {};

---@param sender System.Object
---@param e System.ComponentModel.Design.DesignerTransactionCloseEventArgs
function m:Invoke(sender, e) end
---@param sender System.Object
---@param e System.ComponentModel.Design.DesignerTransactionCloseEventArgs
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(sender, e, callback, object) end
---@param result System.IAsyncResult
function m:EndInvoke(result) end
System.ComponentModel.Design.DesignerTransactionCloseEventHandler=m
return m;