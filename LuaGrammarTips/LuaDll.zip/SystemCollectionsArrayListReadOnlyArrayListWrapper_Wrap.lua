---@class System.Collections.ArrayListReadOnlyArrayListWrapper : System.Collections.ArrayListFixedSizeArrayListWrapper
---instance properties
---@field public IsReadOnly System.Boolean
---@field public Item System.Object
local m = {};

function m:Reverse() end
---@param index System.Int32
---@param count System.Int32
function m:Reverse(index, count) end
---@param index System.Int32
---@param c System.Collections.ICollection
function m:SetRange(index, c) end
function m:Sort() end
---@param comparer System.Collections.IComparer
function m:Sort(comparer) end
---@param index System.Int32
---@param count System.Int32
---@param comparer System.Collections.IComparer
function m:Sort(index, count, comparer) end
System.Collections.ArrayListReadOnlyArrayListWrapper=m
return m;