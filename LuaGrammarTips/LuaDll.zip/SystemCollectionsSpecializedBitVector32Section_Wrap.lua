---@class System.Collections.Specialized.BitVector32Section : System.ValueType
---instance properties
---@field public Mask System.Int16
---@field public Offset System.Int16
local m = {};
---@param value System.Collections.Specialized.BitVector32Section
---@return System.String
function m.ToString(value) end
---@param v1 System.Collections.Specialized.BitVector32Section
---@param v2 System.Collections.Specialized.BitVector32Section
---@return System.Boolean
function m.op_Equality(v1, v2) end
---@param v1 System.Collections.Specialized.BitVector32Section
---@param v2 System.Collections.Specialized.BitVector32Section
---@return System.Boolean
function m.op_Inequality(v1, v2) end

---@param obj System.Collections.Specialized.BitVector32Section
---@return System.Boolean
function m:Equals(obj) end
---@param o System.Object
---@return System.Boolean
function m:Equals(o) end
---@return System.Int32
function m:GetHashCode() end
---@return System.String
function m:ToString() end
System.Collections.Specialized.BitVector32Section=m
return m;