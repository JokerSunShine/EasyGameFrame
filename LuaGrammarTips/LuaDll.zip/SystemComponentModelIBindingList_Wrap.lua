---@class System.ComponentModel.IBindingList
---instance properties
---@field public AllowEdit System.Boolean
---@field public AllowNew System.Boolean
---@field public AllowRemove System.Boolean
---@field public IsSorted System.Boolean
---@field public SortDirection System.ComponentModel.ListSortDirection
---@field public SortProperty System.ComponentModel.PropertyDescriptor
---@field public SupportsChangeNotification System.Boolean
---@field public SupportsSearching System.Boolean
---@field public SupportsSorting System.Boolean
local m = {};

---@param value System.ComponentModel.ListChangedEventHandler
function m:add_ListChanged(value) end
---@param value System.ComponentModel.ListChangedEventHandler
function m:remove_ListChanged(value) end
---@param property System.ComponentModel.PropertyDescriptor
function m:AddIndex(property) end
---@return System.Object
function m:AddNew() end
---@param property System.ComponentModel.PropertyDescriptor
---@param direction System.ComponentModel.ListSortDirection
function m:ApplySort(property, direction) end
---@param property System.ComponentModel.PropertyDescriptor
---@param key System.Object
---@return System.Int32
function m:Find(property, key) end
---@param property System.ComponentModel.PropertyDescriptor
function m:RemoveIndex(property) end
function m:RemoveSort() end
System.ComponentModel.IBindingList=m
return m;