---@class System.Collections.Specialized.OrderedDictionaryOrderedCollectionOrderedCollectionEnumerator
---instance properties
---@field public Current System.Object
local m = {};

---@return System.Boolean
function m:MoveNext() end
function m:Reset() end
System.Collections.Specialized.OrderedDictionaryOrderedCollectionOrderedCollectionEnumerator=m
return m;