---@class System.ComponentModel.Design.Serialization.InstanceDescriptor
---instance properties
---@field public Arguments System.Collections.ICollection
---@field public IsComplete System.Boolean
---@field public MemberInfo System.Reflection.MemberInfo
local m = {};

---@return System.Object
function m:Invoke() end
System.ComponentModel.Design.Serialization.InstanceDescriptor=m
return m;