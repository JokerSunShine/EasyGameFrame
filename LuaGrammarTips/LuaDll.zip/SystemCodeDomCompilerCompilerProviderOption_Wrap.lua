---@class System.CodeDom.Compiler.CompilerProviderOption : System.Configuration.ConfigurationElement
---instance properties
---@field public Name System.String
---@field public Value System.String
local m = {};

System.CodeDom.Compiler.CompilerProviderOption=m
return m;