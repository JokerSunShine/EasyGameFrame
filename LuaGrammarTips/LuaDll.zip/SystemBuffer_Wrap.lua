---@class System.Buffer
local m = {};
---@param array System.Array
---@return System.Int32
function m.ByteLength(array) end
---@param array System.Array
---@param index System.Int32
---@return System.Byte
function m.GetByte(array, index) end
---@param array System.Array
---@param index System.Int32
---@param value System.Byte
function m.SetByte(array, index, value) end
---@param src System.Array
---@param srcOffset System.Int32
---@param dst System.Array
---@param dstOffset System.Int32
---@param count System.Int32
function m.BlockCopy(src, srcOffset, dst, dstOffset, count) end

System.Buffer=m
return m;