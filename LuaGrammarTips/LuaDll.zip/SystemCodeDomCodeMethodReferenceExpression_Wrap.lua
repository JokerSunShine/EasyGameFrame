---@class System.CodeDom.CodeMethodReferenceExpression : System.CodeDom.CodeExpression
---instance properties
---@field public MethodName System.String
---@field public TargetObject System.CodeDom.CodeExpression
---@field public TypeArguments System.CodeDom.CodeTypeReferenceCollection
local m = {};

System.CodeDom.CodeMethodReferenceExpression=m
return m;