---@class System.Collections.Generic.SortedList2EnumeratorModeTKeyTValue
---@field KEY_MODE @0
---@field VALUE_MODE @1
---@field ENTRY_MODE @2
local m = {};
System.Collections.Generic.SortedList2EnumeratorModeTKeyTValue=m
return m;