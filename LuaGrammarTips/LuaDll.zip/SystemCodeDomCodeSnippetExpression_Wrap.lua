---@class System.CodeDom.CodeSnippetExpression : System.CodeDom.CodeExpression
---instance properties
---@field public Value System.String
local m = {};

System.CodeDom.CodeSnippetExpression=m
return m;