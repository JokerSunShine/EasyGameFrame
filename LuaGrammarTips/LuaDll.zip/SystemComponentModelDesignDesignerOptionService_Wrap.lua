---@class System.ComponentModel.Design.DesignerOptionService
---instance properties
---@field public Options System.ComponentModel.Design.DesignerOptionServiceDesignerOptionCollection
local m = {};

System.ComponentModel.Design.DesignerOptionService=m
return m;