---@class System.CodeDom.CodeSnippetStatement : System.CodeDom.CodeStatement
---instance properties
---@field public Value System.String
local m = {};

System.CodeDom.CodeSnippetStatement=m
return m;