---@class System.ComponentModel.AsyncOperation
---instance properties
---@field public SynchronizationContext System.Threading.SynchronizationContext
---@field public UserSuppliedState System.Object
local m = {};

function m:OperationCompleted() end
---@param d System.Threading.SendOrPostCallback
---@param arg System.Object
function m:Post(d, arg) end
---@param d System.Threading.SendOrPostCallback
---@param arg System.Object
function m:PostOperationCompleted(d, arg) end
System.ComponentModel.AsyncOperation=m
return m;