---@class System.CodeDom.CodeMemberProperty : System.CodeDom.CodeTypeMember
---instance properties
---@field public GetStatements System.CodeDom.CodeStatementCollection
---@field public HasGet System.Boolean
---@field public HasSet System.Boolean
---@field public ImplementationTypes System.CodeDom.CodeTypeReferenceCollection
---@field public Parameters System.CodeDom.CodeParameterDeclarationExpressionCollection
---@field public PrivateImplementationType System.CodeDom.CodeTypeReference
---@field public SetStatements System.CodeDom.CodeStatementCollection
---@field public Type System.CodeDom.CodeTypeReference
local m = {};

System.CodeDom.CodeMemberProperty=m
return m;