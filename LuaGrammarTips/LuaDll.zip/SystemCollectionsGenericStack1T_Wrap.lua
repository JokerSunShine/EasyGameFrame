---@class System.Collections.Generic.Stack1T
---instance properties
---@field public Count System.Int32
local m = {};

function m:Clear() end
---@param t T
---@return System.Boolean
function m:Contains(t) end
---@param dest T
---@param idx System.Int32
function m:CopyTo(dest, idx) end
---@return T
function m:Peek() end
---@return T
function m:Pop() end
---@param t T
function m:Push(t) end
---@return T
function m:ToArray() end
function m:TrimExcess() end
---@return System.Collections.Generic.Stack1EnumeratorT
function m:GetEnumerator() end
System.Collections.Generic.Stack1T=m
return m;