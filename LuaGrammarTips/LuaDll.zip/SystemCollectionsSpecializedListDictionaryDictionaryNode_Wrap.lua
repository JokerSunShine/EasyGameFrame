---@class System.Collections.Specialized.ListDictionaryDictionaryNode
---instance fields
---@field public key System.Object
---@field public value System.Object
---@field public next System.Collections.Specialized.ListDictionaryDictionaryNode
local m = {};

System.Collections.Specialized.ListDictionaryDictionaryNode=m
return m;