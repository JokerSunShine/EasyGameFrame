---@class System.Collections.CaseInsensitiveComparer
---properties
---@field public Default System.Collections.CaseInsensitiveComparer
---@field public DefaultInvariant System.Collections.CaseInsensitiveComparer
local m = {};

---@param a System.Object
---@param b System.Object
---@return System.Int32
function m:Compare(a, b) end
System.Collections.CaseInsensitiveComparer=m
return m;