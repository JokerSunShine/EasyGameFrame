---@class System.ActivationContextContextForm
---@field Loose @0
---@field StoreBounded @1
local m = {};
System.ActivationContextContextForm=m
return m;