---@class System.ComponentModel.IChangeTracking
---instance properties
---@field public IsChanged System.Boolean
local m = {};

function m:AcceptChanges() end
System.ComponentModel.IChangeTracking=m
return m;