---@class System.ComponentModel.Int32Converter : System.ComponentModel.BaseNumberConverter
local m = {};

System.ComponentModel.Int32Converter=m
return m;