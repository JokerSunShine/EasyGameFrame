---@class System.CodeDom.CodeIterationStatement : System.CodeDom.CodeStatement
---instance properties
---@field public IncrementStatement System.CodeDom.CodeStatement
---@field public InitStatement System.CodeDom.CodeStatement
---@field public Statements System.CodeDom.CodeStatementCollection
---@field public TestExpression System.CodeDom.CodeExpression
local m = {};

System.CodeDom.CodeIterationStatement=m
return m;