---@class System.ComponentModel.Design.ActiveDesignerEventArgs : System.EventArgs
---instance properties
---@field public NewDesigner System.ComponentModel.Design.IDesignerHost
---@field public OldDesigner System.ComponentModel.Design.IDesignerHost
local m = {};

System.ComponentModel.Design.ActiveDesignerEventArgs=m
return m;