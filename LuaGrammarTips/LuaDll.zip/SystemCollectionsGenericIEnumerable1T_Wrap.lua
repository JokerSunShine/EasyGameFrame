---@class System.Collections.Generic.IEnumerable1T
local m = {};

---@return System.Collections.Generic.IEnumerator1T
function m:GetEnumerator() end
System.Collections.Generic.IEnumerable1T=m
return m;