---@class System.Byte : System.ValueType
---fields
---@field public MinValue System.Byte
---@field public MaxValue System.Byte
local m = {};
---@param s System.String
---@param provider System.IFormatProvider
---@return System.Byte
function m.Parse(s, provider) end
---@param s System.String
---@param style System.Globalization.NumberStyles
---@return System.Byte
function m.Parse(s, style) end
---@param s System.String
---@param style System.Globalization.NumberStyles
---@param provider System.IFormatProvider
---@return System.Byte
function m.Parse(s, style, provider) end
---@param s System.String
---@return System.Byte
function m.Parse(s) end
---@param s System.String
---@param result System.Byte @out
---@return System.Boolean
function m.TryParse(s, result) end
---@param s System.String
---@param style System.Globalization.NumberStyles
---@param provider System.IFormatProvider
---@param result System.Byte @out
---@return System.Boolean
function m.TryParse(s, style, provider, result) end

---@param value System.Object
---@return System.Int32
function m:CompareTo(value) end
---@param obj System.Object
---@return System.Boolean
function m:Equals(obj) end
---@return System.Int32
function m:GetHashCode() end
---@param value System.Byte
---@return System.Int32
function m:CompareTo(value) end
---@param obj System.Byte
---@return System.Boolean
function m:Equals(obj) end
---@return System.String
function m:ToString() end
---@param format System.String
---@return System.String
function m:ToString(format) end
---@param provider System.IFormatProvider
---@return System.String
function m:ToString(provider) end
---@param format System.String
---@param provider System.IFormatProvider
---@return System.String
function m:ToString(format, provider) end
---@return System.TypeCode
function m:GetTypeCode() end
System.Byte=m
return m;