---@class System.ComponentModel.Design.Serialization.IDesignerLoaderHost
local m = {};

---@param baseClassName System.String
---@param successful System.Boolean
---@param errorCollection System.Collections.ICollection
function m:EndLoad(baseClassName, successful, errorCollection) end
function m:Reload() end
System.ComponentModel.Design.Serialization.IDesignerLoaderHost=m
return m;