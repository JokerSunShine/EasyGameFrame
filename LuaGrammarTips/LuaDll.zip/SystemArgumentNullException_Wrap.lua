---@class System.ArgumentNullException : System.ArgumentException
local m = {};

System.ArgumentNullException=m
return m;