---@class System.CodeDom.CodeArrayIndexerExpression : System.CodeDom.CodeExpression
---instance properties
---@field public Indices System.CodeDom.CodeExpressionCollection
---@field public TargetObject System.CodeDom.CodeExpression
local m = {};

System.CodeDom.CodeArrayIndexerExpression=m
return m;