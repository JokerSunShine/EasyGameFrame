---@class System.CodeDom.CodeArgumentReferenceExpression : System.CodeDom.CodeExpression
---instance properties
---@field public ParameterName System.String
local m = {};

System.CodeDom.CodeArgumentReferenceExpression=m
return m;