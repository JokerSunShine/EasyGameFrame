---@class System.Base64FormattingOptions
---@field None @0
---@field InsertLineBreaks @1
local m = {};
System.Base64FormattingOptions=m
return m;