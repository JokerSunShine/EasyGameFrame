---@class System.AppDomainLoader
local m = {};

function m:Load() end
System.AppDomainLoader=m
return m;