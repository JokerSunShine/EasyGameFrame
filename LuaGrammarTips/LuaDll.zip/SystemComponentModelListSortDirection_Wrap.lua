---@class System.ComponentModel.ListSortDirection
---@field Ascending @0
---@field Descending @1
local m = {};
System.ComponentModel.ListSortDirection=m
return m;