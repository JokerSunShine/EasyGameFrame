---@class System.Collections.Stack
---instance properties
---@field public Count System.Int32
---@field public IsSynchronized System.Boolean
---@field public SyncRoot System.Object
local m = {};
---@param stack System.Collections.Stack
---@return System.Collections.Stack
function m.Synchronized(stack) end

function m:Clear() end
---@return System.Object
function m:Clone() end
---@param obj System.Object
---@return System.Boolean
function m:Contains(obj) end
---@param array System.Array
---@param index System.Int32
function m:CopyTo(array, index) end
---@return System.Collections.IEnumerator
function m:GetEnumerator() end
---@return System.Object
function m:Peek() end
---@return System.Object
function m:Pop() end
---@param obj System.Object
function m:Push(obj) end
---@return System.Object
function m:ToArray() end
System.Collections.Stack=m
return m;