---@class System.ComponentModel.InvalidEnumArgumentException : System.ArgumentException
local m = {};

System.ComponentModel.InvalidEnumArgumentException=m
return m;