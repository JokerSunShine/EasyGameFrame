---@class System.ComponentModel.Design.DesignerOptionServiceDesignerOptionCollectionWrappedPropertyDescriptor : System.ComponentModel.PropertyDescriptor
---instance properties
---@field public Attributes System.ComponentModel.AttributeCollection
---@field public IsReadOnly System.Boolean
---@field public ComponentType System.Type
---@field public PropertyType System.Type
local m = {};

---@param ignored System.Object
---@return System.Object
function m:GetValue(ignored) end
---@param ignored System.Object
---@param value System.Object
function m:SetValue(ignored, value) end
---@param ignored System.Object
---@return System.Boolean
function m:CanResetValue(ignored) end
---@param ignored System.Object
function m:ResetValue(ignored) end
---@param ignored System.Object
---@return System.Boolean
function m:ShouldSerializeValue(ignored) end
System.ComponentModel.Design.DesignerOptionServiceDesignerOptionCollectionWrappedPropertyDescriptor=m
return m;