---@class System.CharEnumerator
---instance properties
---@field public Current System.Char
local m = {};

---@return System.Object
function m:Clone() end
---@return System.Boolean
function m:MoveNext() end
function m:Reset() end
System.CharEnumerator=m
return m;