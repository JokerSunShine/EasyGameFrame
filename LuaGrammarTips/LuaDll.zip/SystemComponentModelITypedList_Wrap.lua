---@class System.ComponentModel.ITypedList
local m = {};

---@param listAccessors System.ComponentModel.PropertyDescriptor
---@return System.ComponentModel.PropertyDescriptorCollection
function m:GetItemProperties(listAccessors) end
---@param listAccessors System.ComponentModel.PropertyDescriptor
---@return System.String
function m:GetListName(listAccessors) end
System.ComponentModel.ITypedList=m
return m;