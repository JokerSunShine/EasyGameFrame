---@class System.AssemblyLoadEventHandler : System.MulticastDelegate
local m = {};

---@param sender System.Object
---@param args System.AssemblyLoadEventArgs
function m:Invoke(sender, args) end
---@param sender System.Object
---@param args System.AssemblyLoadEventArgs
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(sender, args, callback, object) end
---@param result System.IAsyncResult
function m:EndInvoke(result) end
System.AssemblyLoadEventHandler=m
return m;