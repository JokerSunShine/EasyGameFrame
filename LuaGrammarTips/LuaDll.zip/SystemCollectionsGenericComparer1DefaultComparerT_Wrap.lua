---@class System.Collections.Generic.Comparer1DefaultComparerT : System.Collections.Generic.Comparer1T
local m = {};

---@param x T
---@param y T
---@return System.Int32
function m:Compare(x, y) end
System.Collections.Generic.Comparer1DefaultComparerT=m
return m;