---@class System.CodeDom.Compiler.CompilerCollection : System.Configuration.ConfigurationElementCollection
---instance properties
---@field public AllKeys System.String
---@field public CollectionType System.Configuration.ConfigurationElementCollectionType
---@field public Item System.CodeDom.Compiler.Compiler
---@field public Item System.CodeDom.Compiler.CompilerInfo
---@field public CompilerInfos System.CodeDom.Compiler.CompilerInfo
local m = {};

---@param language System.String
---@return System.CodeDom.Compiler.CompilerInfo
function m:GetCompilerInfoForLanguage(language) end
---@param extension System.String
---@return System.CodeDom.Compiler.CompilerInfo
function m:GetCompilerInfoForExtension(extension) end
---@param extension System.String
---@return System.String
function m:GetLanguageFromExtension(extension) end
---@param index System.Int32
---@return System.CodeDom.Compiler.Compiler
function m:Get(index) end
---@param language System.String
---@return System.CodeDom.Compiler.Compiler
function m:Get(language) end
---@param index System.Int32
---@return System.String
function m:GetKey(index) end
System.CodeDom.Compiler.CompilerCollection=m
return m;