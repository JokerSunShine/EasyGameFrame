---@class System.AppDomainManager : System.MarshalByRefObject
---instance properties
---@field public ApplicationActivator System.Runtime.Hosting.ApplicationActivator
---@field public EntryAssembly System.Reflection.Assembly
---@field public HostExecutionContextManager System.Threading.HostExecutionContextManager
---@field public HostSecurityManager System.Security.HostSecurityManager
---@field public InitializationFlags System.AppDomainManagerInitializationOptions
local m = {};

---@param friendlyName System.String
---@param securityInfo System.Security.Policy.Evidence
---@param appDomainInfo System.AppDomainSetup
---@return System.AppDomain
function m:CreateDomain(friendlyName, securityInfo, appDomainInfo) end
---@param appDomainInfo System.AppDomainSetup
function m:InitializeNewDomain(appDomainInfo) end
---@param state System.Security.SecurityState
---@return System.Boolean
function m:CheckSecuritySettings(state) end
System.AppDomainManager=m
return m;