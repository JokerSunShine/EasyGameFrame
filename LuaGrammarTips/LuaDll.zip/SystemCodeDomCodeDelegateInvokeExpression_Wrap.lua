---@class System.CodeDom.CodeDelegateInvokeExpression : System.CodeDom.CodeExpression
---instance properties
---@field public Parameters System.CodeDom.CodeExpressionCollection
---@field public TargetObject System.CodeDom.CodeExpression
local m = {};

System.CodeDom.CodeDelegateInvokeExpression=m
return m;