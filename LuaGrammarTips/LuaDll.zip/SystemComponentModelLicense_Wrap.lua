---@class System.ComponentModel.License
---instance properties
---@field public LicenseKey System.String
local m = {};

function m:Dispose() end
System.ComponentModel.License=m
return m;