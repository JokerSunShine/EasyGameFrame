---@class System.Collections.Generic.HashSet1EnumeratorT : System.ValueType
---instance properties
---@field public Current T
local m = {};

---@return System.Boolean
function m:MoveNext() end
function m:Dispose() end
System.Collections.Generic.HashSet1EnumeratorT=m
return m;