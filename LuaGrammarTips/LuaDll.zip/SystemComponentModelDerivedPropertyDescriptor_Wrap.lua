---@class System.ComponentModel.DerivedPropertyDescriptor : System.ComponentModel.PropertyDescriptor
---instance properties
---@field public ComponentType System.Type
---@field public IsReadOnly System.Boolean
---@field public PropertyType System.Type
local m = {};

---@param value System.Boolean
function m:SetReadOnly(value) end
---@param type System.Type
function m:SetComponentType(type) end
---@param type System.Type
function m:SetPropertyType(type) end
---@param component System.Object
---@return System.Object
function m:GetValue(component) end
---@param component System.Object
---@param value System.Object
function m:SetValue(component, value) end
---@param component System.Object
function m:ResetValue(component) end
---@param component System.Object
---@return System.Boolean
function m:CanResetValue(component) end
---@param component System.Object
---@return System.Boolean
function m:ShouldSerializeValue(component) end
System.ComponentModel.DerivedPropertyDescriptor=m
return m;