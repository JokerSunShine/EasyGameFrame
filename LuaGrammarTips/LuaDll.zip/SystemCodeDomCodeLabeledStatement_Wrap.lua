---@class System.CodeDom.CodeLabeledStatement : System.CodeDom.CodeStatement
---instance properties
---@field public Label System.String
---@field public Statement System.CodeDom.CodeStatement
local m = {};

System.CodeDom.CodeLabeledStatement=m
return m;