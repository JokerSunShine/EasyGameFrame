---@class System.Collections.Generic.HashSet1T
---instance properties
---@field public Count System.Int32
---@field public Comparer System.Collections.Generic.IEqualityComparer1T
local m = {};
---@return System.Collections.Generic.IEqualityComparer1System.Collections.Generic.HashSet1T
function m.CreateSetComparer() end

---@param array T
function m:CopyTo(array) end
---@param array T
---@param index System.Int32
function m:CopyTo(array, index) end
---@param array T
---@param index System.Int32
---@param count System.Int32
function m:CopyTo(array, index, count) end
---@param item T
---@return System.Boolean
function m:Add(item) end
function m:Clear() end
---@param item T
---@return System.Boolean
function m:Contains(item) end
---@param item T
---@return System.Boolean
function m:Remove(item) end
---@param predicate System.Predicate1T
---@return System.Int32
function m:RemoveWhere(predicate) end
function m:TrimExcess() end
---@param other System.Collections.Generic.IEnumerable1T
function m:IntersectWith(other) end
---@param other System.Collections.Generic.IEnumerable1T
function m:ExceptWith(other) end
---@param other System.Collections.Generic.IEnumerable1T
---@return System.Boolean
function m:Overlaps(other) end
---@param other System.Collections.Generic.IEnumerable1T
---@return System.Boolean
function m:SetEquals(other) end
---@param other System.Collections.Generic.IEnumerable1T
function m:SymmetricExceptWith(other) end
---@param other System.Collections.Generic.IEnumerable1T
function m:UnionWith(other) end
---@param other System.Collections.Generic.IEnumerable1T
---@return System.Boolean
function m:IsSubsetOf(other) end
---@param other System.Collections.Generic.IEnumerable1T
---@return System.Boolean
function m:IsProperSubsetOf(other) end
---@param other System.Collections.Generic.IEnumerable1T
---@return System.Boolean
function m:IsSupersetOf(other) end
---@param other System.Collections.Generic.IEnumerable1T
---@return System.Boolean
function m:IsProperSupersetOf(other) end
---@param info System.Runtime.Serialization.SerializationInfo
---@param context System.Runtime.Serialization.StreamingContext
function m:GetObjectData(info, context) end
---@param sender System.Object
function m:OnDeserialization(sender) end
---@return System.Collections.Generic.HashSet1EnumeratorT
function m:GetEnumerator() end
System.Collections.Generic.HashSet1T=m
return m;