---@class System.AppDomainSetup
---instance properties
---@field public ApplicationBase System.String
---@field public ApplicationName System.String
---@field public CachePath System.String
---@field public ConfigurationFile System.String
---@field public DisallowPublisherPolicy System.Boolean
---@field public DynamicBase System.String
---@field public LicenseFile System.String
---@field public LoaderOptimization System.LoaderOptimization
---@field public PrivateBinPath System.String
---@field public PrivateBinPathProbe System.String
---@field public ShadowCopyDirectories System.String
---@field public ShadowCopyFiles System.String
---@field public DisallowBindingRedirects System.Boolean
---@field public DisallowCodeDownload System.Boolean
---@field public ActivationArguments System.Runtime.Hosting.ActivationArguments
---@field public AppDomainInitializer System.AppDomainInitializer
---@field public AppDomainInitializerArguments System.String
---@field public ApplicationTrust System.Security.Policy.ApplicationTrust
---@field public DisallowApplicationBaseProbing System.Boolean
local m = {};

---@return System.Byte
function m:GetConfigurationBytes() end
---@param value System.Byte
function m:SetConfigurationBytes(value) end
System.AppDomainSetup=m
return m;