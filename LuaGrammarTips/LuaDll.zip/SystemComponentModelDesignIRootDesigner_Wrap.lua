---@class System.ComponentModel.Design.IRootDesigner
---instance properties
---@field public SupportedTechnologies System.ComponentModel.Design.ViewTechnology
local m = {};

---@param technology System.ComponentModel.Design.ViewTechnology
---@return System.Object
function m:GetView(technology) end
System.ComponentModel.Design.IRootDesigner=m
return m;