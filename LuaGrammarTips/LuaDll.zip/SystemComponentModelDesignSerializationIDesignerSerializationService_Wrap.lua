---@class System.ComponentModel.Design.Serialization.IDesignerSerializationService
local m = {};

---@param serializationData System.Object
---@return System.Collections.ICollection
function m:Deserialize(serializationData) end
---@param objects System.Collections.ICollection
---@return System.Object
function m:Serialize(objects) end
System.ComponentModel.Design.Serialization.IDesignerSerializationService=m
return m;