---@class System.ComponentModel.ListChangedType
---@field Reset @0
---@field ItemAdded @1
---@field ItemDeleted @2
---@field ItemMoved @3
---@field ItemChanged @4
---@field PropertyDescriptorAdded @5
---@field PropertyDescriptorDeleted @6
---@field PropertyDescriptorChanged @7
local m = {};
System.ComponentModel.ListChangedType=m
return m;