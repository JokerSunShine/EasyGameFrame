---@class System.CodeDom.CodeChecksumPragma : System.CodeDom.CodeDirective
---instance properties
---@field public ChecksumAlgorithmId System.Guid
---@field public ChecksumData System.Byte
---@field public FileName System.String
local m = {};

System.CodeDom.CodeChecksumPragma=m
return m;