---@class System.ComponentModel.ComponentCollection : System.Collections.ReadOnlyCollectionBase
---instance properties
---@field public Item System.ComponentModel.IComponent
---@field public Item System.ComponentModel.IComponent
local m = {};

---@param array System.ComponentModel.IComponent
---@param index System.Int32
function m:CopyTo(array, index) end
System.ComponentModel.ComponentCollection=m
return m;