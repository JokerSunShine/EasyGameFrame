---@class System.CodeDom.CodeEventReferenceExpression : System.CodeDom.CodeExpression
---instance properties
---@field public EventName System.String
---@field public TargetObject System.CodeDom.CodeExpression
local m = {};

System.CodeDom.CodeEventReferenceExpression=m
return m;