---@class System.ComponentModel.Design.IExtenderListService
local m = {};

---@return System.ComponentModel.IExtenderProvider
function m:GetExtenderProviders() end
System.ComponentModel.Design.IExtenderListService=m
return m;