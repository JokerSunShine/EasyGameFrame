---@class System.CodeDom.CodeCommentStatement : System.CodeDom.CodeStatement
---instance properties
---@field public Comment System.CodeDom.CodeComment
local m = {};

System.CodeDom.CodeCommentStatement=m
return m;