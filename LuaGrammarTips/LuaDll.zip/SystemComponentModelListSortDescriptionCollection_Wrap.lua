---@class System.ComponentModel.ListSortDescriptionCollection
---instance properties
---@field public Count System.Int32
---@field public Item System.ComponentModel.ListSortDescription
local m = {};

---@param value System.Object
---@return System.Boolean
function m:Contains(value) end
---@param array System.Array
---@param index System.Int32
function m:CopyTo(array, index) end
---@param value System.Object
---@return System.Int32
function m:IndexOf(value) end
System.ComponentModel.ListSortDescriptionCollection=m
return m;