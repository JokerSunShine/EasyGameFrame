---@class System.CodeDom.Compiler.LanguageOptions
---@field None @0
---@field CaseInsensitive @1
local m = {};
System.CodeDom.Compiler.LanguageOptions=m
return m;