---@class System.ComponentModel.DesignerSerializationVisibility
---@field Hidden @0
---@field Visible @1
---@field Content @2
local m = {};
System.ComponentModel.DesignerSerializationVisibility=m
return m;