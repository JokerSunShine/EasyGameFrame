---@class System.Collections.Generic.IList1T
---instance properties
---@field public Item T
local m = {};

---@param item T
---@return System.Int32
function m:IndexOf(item) end
---@param index System.Int32
---@param item T
function m:Insert(index, item) end
---@param index System.Int32
function m:RemoveAt(index) end
System.Collections.Generic.IList1T=m
return m;