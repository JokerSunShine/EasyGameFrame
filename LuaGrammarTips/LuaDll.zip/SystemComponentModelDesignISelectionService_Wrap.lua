---@class System.ComponentModel.Design.ISelectionService
---instance properties
---@field public PrimarySelection System.Object
---@field public SelectionCount System.Int32
local m = {};

---@param value System.EventHandler
function m:add_SelectionChanged(value) end
---@param value System.EventHandler
function m:remove_SelectionChanged(value) end
---@param value System.EventHandler
function m:add_SelectionChanging(value) end
---@param value System.EventHandler
function m:remove_SelectionChanging(value) end
---@param component System.Object
---@return System.Boolean
function m:GetComponentSelected(component) end
---@return System.Collections.ICollection
function m:GetSelectedComponents() end
---@param components System.Collections.ICollection
---@param selectionType System.ComponentModel.Design.SelectionTypes
function m:SetSelectedComponents(components, selectionType) end
---@param components System.Collections.ICollection
function m:SetSelectedComponents(components) end
System.ComponentModel.Design.ISelectionService=m
return m;