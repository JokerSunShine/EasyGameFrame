---@class System.ComponentModel.Design.DesignerCollection
---instance properties
---@field public Count System.Int32
---@field public Item System.ComponentModel.Design.IDesignerHost
local m = {};

---@return System.Collections.IEnumerator
function m:GetEnumerator() end
System.ComponentModel.Design.DesignerCollection=m
return m;