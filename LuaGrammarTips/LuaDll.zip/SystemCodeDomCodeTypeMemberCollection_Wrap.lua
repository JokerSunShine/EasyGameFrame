---@class System.CodeDom.CodeTypeMemberCollection : System.Collections.CollectionBase
---instance properties
---@field public Item System.CodeDom.CodeTypeMember
local m = {};

---@param value System.CodeDom.CodeTypeMember
---@return System.Int32
function m:Add(value) end
---@param value System.CodeDom.CodeTypeMember
function m:AddRange(value) end
---@param value System.CodeDom.CodeTypeMemberCollection
function m:AddRange(value) end
---@param value System.CodeDom.CodeTypeMember
---@return System.Boolean
function m:Contains(value) end
---@param array System.CodeDom.CodeTypeMember
---@param index System.Int32
function m:CopyTo(array, index) end
---@param value System.CodeDom.CodeTypeMember
---@return System.Int32
function m:IndexOf(value) end
---@param index System.Int32
---@param value System.CodeDom.CodeTypeMember
function m:Insert(index, value) end
---@param value System.CodeDom.CodeTypeMember
function m:Remove(value) end
System.CodeDom.CodeTypeMemberCollection=m
return m;