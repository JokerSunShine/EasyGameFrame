---@class System.Collections.DictionaryBase
---instance properties
---@field public Count System.Int32
local m = {};

function m:Clear() end
---@param array System.Array
---@param index System.Int32
function m:CopyTo(array, index) end
---@return System.Collections.IDictionaryEnumerator
function m:GetEnumerator() end
System.Collections.DictionaryBase=m
return m;