---@class System.Collections.Generic.EqualityComparer1DefaultComparerT : System.Collections.Generic.EqualityComparer1T
local m = {};

---@param obj T
---@return System.Int32
function m:GetHashCode(obj) end
---@param x T
---@param y T
---@return System.Boolean
function m:Equals(x, y) end
System.Collections.Generic.EqualityComparer1DefaultComparerT=m
return m;