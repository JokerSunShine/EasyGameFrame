---@class System.CodeDom.CodeMemberField : System.CodeDom.CodeTypeMember
---instance properties
---@field public InitExpression System.CodeDom.CodeExpression
---@field public Type System.CodeDom.CodeTypeReference
local m = {};

System.CodeDom.CodeMemberField=m
return m;