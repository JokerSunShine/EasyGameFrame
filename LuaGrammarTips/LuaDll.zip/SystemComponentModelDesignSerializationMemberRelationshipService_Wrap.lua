---@class System.ComponentModel.Design.Serialization.MemberRelationshipService
---instance properties
---@field public Item System.ComponentModel.Design.Serialization.MemberRelationship
---@field public Item System.ComponentModel.Design.Serialization.MemberRelationship
local m = {};

---@param source System.ComponentModel.Design.Serialization.MemberRelationship
---@param relationship System.ComponentModel.Design.Serialization.MemberRelationship
---@return System.Boolean
function m:SupportsRelationship(source, relationship) end
System.ComponentModel.Design.Serialization.MemberRelationshipService=m
return m;