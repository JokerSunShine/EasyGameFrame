---@class System.ComponentModel.ISynchronizeInvoke
---instance properties
---@field public InvokeRequired System.Boolean
local m = {};

---@param method System.Delegate
---@param args System.Object
---@return System.IAsyncResult
function m:BeginInvoke(method, args) end
---@param result System.IAsyncResult
---@return System.Object
function m:EndInvoke(result) end
---@param method System.Delegate
---@param args System.Object
---@return System.Object
function m:Invoke(method, args) end
System.ComponentModel.ISynchronizeInvoke=m
return m;