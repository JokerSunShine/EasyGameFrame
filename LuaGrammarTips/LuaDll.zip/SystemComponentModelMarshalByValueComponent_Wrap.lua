---@class System.ComponentModel.MarshalByValueComponent
---instance properties
---@field public Container System.ComponentModel.IContainer
---@field public DesignMode System.Boolean
---@field public Site System.ComponentModel.ISite
local m = {};

---@param value System.EventHandler
function m:add_Disposed(value) end
---@param value System.EventHandler
function m:remove_Disposed(value) end
function m:Dispose() end
---@param service System.Type
---@return System.Object
function m:GetService(service) end
---@return System.String
function m:ToString() end
System.ComponentModel.MarshalByValueComponent=m
return m;