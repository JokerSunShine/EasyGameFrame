---@class System.ComponentModel.MaskedTextProviderEditState
---@field None @0
---@field UpperCase @1
---@field LowerCase @2
local m = {};
System.ComponentModel.MaskedTextProviderEditState=m
return m;