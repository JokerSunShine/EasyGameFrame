---@class System.Collections.Generic.LinkedListNode1T
---instance properties
---@field public List System.Collections.Generic.LinkedList1T
---@field public Next System.Collections.Generic.LinkedListNode1T
---@field public Previous System.Collections.Generic.LinkedListNode1T
---@field public Value T
local m = {};

System.Collections.Generic.LinkedListNode1T=m
return m;