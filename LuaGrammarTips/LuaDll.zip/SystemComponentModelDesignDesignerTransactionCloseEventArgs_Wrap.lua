---@class System.ComponentModel.Design.DesignerTransactionCloseEventArgs : System.EventArgs
---instance properties
---@field public LastTransaction System.Boolean
---@field public TransactionCommitted System.Boolean
local m = {};

System.ComponentModel.Design.DesignerTransactionCloseEventArgs=m
return m;