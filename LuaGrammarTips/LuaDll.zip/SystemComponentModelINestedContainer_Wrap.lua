---@class System.ComponentModel.INestedContainer
---instance properties
---@field public Owner System.ComponentModel.IComponent
local m = {};

System.ComponentModel.INestedContainer=m
return m;