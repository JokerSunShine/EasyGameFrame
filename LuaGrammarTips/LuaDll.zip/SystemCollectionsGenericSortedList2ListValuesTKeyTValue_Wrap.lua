---@class System.Collections.Generic.SortedList2ListValuesTKeyTValue
---instance properties
---@field public Item TValue
---@field public Count System.Int32
---@field public IsSynchronized System.Boolean
---@field public IsReadOnly System.Boolean
---@field public SyncRoot System.Object
local m = {};

---@param item TValue
function m:Add(item) end
---@param value TValue
---@return System.Boolean
function m:Remove(value) end
function m:Clear() end
---@param array TValue
---@param arrayIndex System.Int32
function m:CopyTo(array, arrayIndex) end
---@param item TValue
---@return System.Boolean
function m:Contains(item) end
---@param item TValue
---@return System.Int32
function m:IndexOf(item) end
---@param index System.Int32
---@param item TValue
function m:Insert(index, item) end
---@param index System.Int32
function m:RemoveAt(index) end
---@return System.Collections.Generic.IEnumerator1TValue
function m:GetEnumerator() end
---@param array System.Array
---@param arrayIndex System.Int32
function m:CopyTo(array, arrayIndex) end
System.Collections.Generic.SortedList2ListValuesTKeyTValue=m
return m;