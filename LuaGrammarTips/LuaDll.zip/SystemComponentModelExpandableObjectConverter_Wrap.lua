---@class System.ComponentModel.ExpandableObjectConverter : System.ComponentModel.TypeConverter
local m = {};

---@param context System.ComponentModel.ITypeDescriptorContext
---@param value System.Object
---@param attributes System.Attribute
---@return System.ComponentModel.PropertyDescriptorCollection
function m:GetProperties(context, value, attributes) end
---@param context System.ComponentModel.ITypeDescriptorContext
---@return System.Boolean
function m:GetPropertiesSupported(context) end
System.ComponentModel.ExpandableObjectConverter=m
return m;