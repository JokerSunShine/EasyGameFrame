---@class System.ComponentModel.IComNativeDescriptorHandler
local m = {};

---@param component System.Object
---@return System.ComponentModel.AttributeCollection
function m:GetAttributes(component) end
---@param component System.Object
---@return System.String
function m:GetClassName(component) end
---@param component System.Object
---@return System.ComponentModel.TypeConverter
function m:GetConverter(component) end
---@param component System.Object
---@return System.ComponentModel.EventDescriptor
function m:GetDefaultEvent(component) end
---@param component System.Object
---@return System.ComponentModel.PropertyDescriptor
function m:GetDefaultProperty(component) end
---@param component System.Object
---@param baseEditorType System.Type
---@return System.Object
function m:GetEditor(component, baseEditorType) end
---@param component System.Object
---@return System.ComponentModel.EventDescriptorCollection
function m:GetEvents(component) end
---@param component System.Object
---@param attributes System.Attribute
---@return System.ComponentModel.EventDescriptorCollection
function m:GetEvents(component, attributes) end
---@param component System.Object
---@return System.String
function m:GetName(component) end
---@param component System.Object
---@param attributes System.Attribute
---@return System.ComponentModel.PropertyDescriptorCollection
function m:GetProperties(component, attributes) end
---@param component System.Object
---@param dispid System.Int32
---@param success System.Boolean
---@return System.Object
function m:GetPropertyValue(component, dispid, success) end
---@param component System.Object
---@param propertyName System.String
---@param success System.Boolean
---@return System.Object
function m:GetPropertyValue(component, propertyName, success) end
System.ComponentModel.IComNativeDescriptorHandler=m
return m;