---@class System.Collections.Generic.List1T
---instance properties
---@field public Capacity System.Int32
---@field public Count System.Int32
---@field public Item T
local m = {};

---@param item T
function m:Add(item) end
---@param collection System.Collections.Generic.IEnumerable1T
function m:AddRange(collection) end
---@return System.Collections.ObjectModel.ReadOnlyCollection1T
function m:AsReadOnly() end
---@param item T
---@return System.Int32
function m:BinarySearch(item) end
---@param item T
---@param comparer System.Collections.Generic.IComparer1T
---@return System.Int32
function m:BinarySearch(item, comparer) end
---@param index System.Int32
---@param count System.Int32
---@param item T
---@param comparer System.Collections.Generic.IComparer1T
---@return System.Int32
function m:BinarySearch(index, count, item, comparer) end
function m:Clear() end
---@param item T
---@return System.Boolean
function m:Contains(item) end
---@param array T
function m:CopyTo(array) end
---@param array T
---@param arrayIndex System.Int32
function m:CopyTo(array, arrayIndex) end
---@param index System.Int32
---@param array T
---@param arrayIndex System.Int32
---@param count System.Int32
function m:CopyTo(index, array, arrayIndex, count) end
---@param match System.Predicate1T
---@return System.Boolean
function m:Exists(match) end
---@param match System.Predicate1T
---@return T
function m:Find(match) end
---@param match System.Predicate1T
---@return System.Collections.Generic.List1T
function m:FindAll(match) end
---@param match System.Predicate1T
---@return System.Int32
function m:FindIndex(match) end
---@param startIndex System.Int32
---@param match System.Predicate1T
---@return System.Int32
function m:FindIndex(startIndex, match) end
---@param startIndex System.Int32
---@param count System.Int32
---@param match System.Predicate1T
---@return System.Int32
function m:FindIndex(startIndex, count, match) end
---@param match System.Predicate1T
---@return T
function m:FindLast(match) end
---@param match System.Predicate1T
---@return System.Int32
function m:FindLastIndex(match) end
---@param startIndex System.Int32
---@param match System.Predicate1T
---@return System.Int32
function m:FindLastIndex(startIndex, match) end
---@param startIndex System.Int32
---@param count System.Int32
---@param match System.Predicate1T
---@return System.Int32
function m:FindLastIndex(startIndex, count, match) end
---@param action System.Action1T
function m:ForEach(action) end
---@return System.Collections.Generic.List1EnumeratorT
function m:GetEnumerator() end
---@param index System.Int32
---@param count System.Int32
---@return System.Collections.Generic.List1T
function m:GetRange(index, count) end
---@param item T
---@return System.Int32
function m:IndexOf(item) end
---@param item T
---@param index System.Int32
---@return System.Int32
function m:IndexOf(item, index) end
---@param item T
---@param index System.Int32
---@param count System.Int32
---@return System.Int32
function m:IndexOf(item, index, count) end
---@param index System.Int32
---@param item T
function m:Insert(index, item) end
---@param index System.Int32
---@param collection System.Collections.Generic.IEnumerable1T
function m:InsertRange(index, collection) end
---@param item T
---@return System.Int32
function m:LastIndexOf(item) end
---@param item T
---@param index System.Int32
---@return System.Int32
function m:LastIndexOf(item, index) end
---@param item T
---@param index System.Int32
---@param count System.Int32
---@return System.Int32
function m:LastIndexOf(item, index, count) end
---@param item T
---@return System.Boolean
function m:Remove(item) end
---@param match System.Predicate1T
---@return System.Int32
function m:RemoveAll(match) end
---@param index System.Int32
function m:RemoveAt(index) end
---@param index System.Int32
---@param count System.Int32
function m:RemoveRange(index, count) end
function m:Reverse() end
---@param index System.Int32
---@param count System.Int32
function m:Reverse(index, count) end
function m:Sort() end
---@param comparer System.Collections.Generic.IComparer1T
function m:Sort(comparer) end
---@param comparison System.Comparison1T
function m:Sort(comparison) end
---@param index System.Int32
---@param count System.Int32
---@param comparer System.Collections.Generic.IComparer1T
function m:Sort(index, count, comparer) end
---@return T
function m:ToArray() end
function m:TrimExcess() end
---@param match System.Predicate1T
---@return System.Boolean
function m:TrueForAll(match) end
System.Collections.Generic.List1T=m
return m;