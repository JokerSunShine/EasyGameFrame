---@class System.ComponentModel.Int16Converter : System.ComponentModel.BaseNumberConverter
local m = {};

System.ComponentModel.Int16Converter=m
return m;