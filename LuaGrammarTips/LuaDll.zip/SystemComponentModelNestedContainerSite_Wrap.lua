---@class System.ComponentModel.NestedContainerSite
---instance properties
---@field public Component System.ComponentModel.IComponent
---@field public Container System.ComponentModel.IContainer
---@field public DesignMode System.Boolean
---@field public Name System.String
---@field public FullName System.String
local m = {};

---@param service System.Type
---@return System.Object
function m:GetService(service) end
System.ComponentModel.NestedContainerSite=m
return m;