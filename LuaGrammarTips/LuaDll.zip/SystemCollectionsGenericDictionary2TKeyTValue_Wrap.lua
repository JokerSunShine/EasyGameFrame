---@class System.Collections.Generic.Dictionary2TKeyTValue
---instance properties
---@field public Count System.Int32
---@field public Item TValue
---@field public Comparer System.Collections.Generic.IEqualityComparer1TKey
---@field public Keys System.Collections.Generic.Dictionary2KeyCollectionTKeyTValue
---@field public Values System.Collections.Generic.Dictionary2ValueCollectionTKeyTValue
local m = {};

---@param key TKey
---@param value TValue
function m:Add(key, value) end
function m:Clear() end
---@param key TKey
---@return System.Boolean
function m:ContainsKey(key) end
---@param value TValue
---@return System.Boolean
function m:ContainsValue(value) end
---@param info System.Runtime.Serialization.SerializationInfo
---@param context System.Runtime.Serialization.StreamingContext
function m:GetObjectData(info, context) end
---@param sender System.Object
function m:OnDeserialization(sender) end
---@param key TKey
---@return System.Boolean
function m:Remove(key) end
---@param key TKey
---@param value TValue @out
---@return System.Boolean
function m:TryGetValue(key, value) end
---@return System.Collections.Generic.Dictionary2EnumeratorTKeyTValue
function m:GetEnumerator() end
System.Collections.Generic.Dictionary2TKeyTValue=m
return m;