---@class System.CodeDom.CodeParameterDeclarationExpression : System.CodeDom.CodeExpression
---instance properties
---@field public CustomAttributes System.CodeDom.CodeAttributeDeclarationCollection
---@field public Direction System.CodeDom.FieldDirection
---@field public Name System.String
---@field public Type System.CodeDom.CodeTypeReference
local m = {};

System.CodeDom.CodeParameterDeclarationExpression=m
return m;