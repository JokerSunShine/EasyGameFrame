---@class System.BadImageFormatException : System.SystemException
---instance properties
---@field public Message System.String
---@field public FileName System.String
---@field public FusionLog System.String
local m = {};

---@param info System.Runtime.Serialization.SerializationInfo
---@param context System.Runtime.Serialization.StreamingContext
function m:GetObjectData(info, context) end
---@return System.String
function m:ToString() end
System.BadImageFormatException=m
return m;