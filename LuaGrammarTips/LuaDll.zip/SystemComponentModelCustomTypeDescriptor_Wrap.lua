---@class System.ComponentModel.CustomTypeDescriptor
local m = {};

---@return System.ComponentModel.AttributeCollection
function m:GetAttributes() end
---@return System.String
function m:GetClassName() end
---@return System.String
function m:GetComponentName() end
---@return System.ComponentModel.TypeConverter
function m:GetConverter() end
---@return System.ComponentModel.EventDescriptor
function m:GetDefaultEvent() end
---@return System.ComponentModel.PropertyDescriptor
function m:GetDefaultProperty() end
---@param editorBaseType System.Type
---@return System.Object
function m:GetEditor(editorBaseType) end
---@return System.ComponentModel.EventDescriptorCollection
function m:GetEvents() end
---@param attributes System.Attribute
---@return System.ComponentModel.EventDescriptorCollection
function m:GetEvents(attributes) end
---@return System.ComponentModel.PropertyDescriptorCollection
function m:GetProperties() end
---@param attributes System.Attribute
---@return System.ComponentModel.PropertyDescriptorCollection
function m:GetProperties(attributes) end
---@param pd System.ComponentModel.PropertyDescriptor
---@return System.Object
function m:GetPropertyOwner(pd) end
System.ComponentModel.CustomTypeDescriptor=m
return m;