---@class System.CodeDom.CodeStatement : System.CodeDom.CodeObject
---instance properties
---@field public LinePragma System.CodeDom.CodeLinePragma
---@field public EndDirectives System.CodeDom.CodeDirectiveCollection
---@field public StartDirectives System.CodeDom.CodeDirectiveCollection
local m = {};

System.CodeDom.CodeStatement=m
return m;