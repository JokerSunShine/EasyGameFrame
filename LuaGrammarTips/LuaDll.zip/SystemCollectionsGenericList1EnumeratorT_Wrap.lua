---@class System.Collections.Generic.List1EnumeratorT : System.ValueType
---instance properties
---@field public Current T
local m = {};

function m:Dispose() end
---@return System.Boolean
function m:MoveNext() end
System.Collections.Generic.List1EnumeratorT=m
return m;