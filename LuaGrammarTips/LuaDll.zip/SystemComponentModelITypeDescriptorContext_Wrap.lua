---@class System.ComponentModel.ITypeDescriptorContext
---instance properties
---@field public Container System.ComponentModel.IContainer
---@field public Instance System.Object
---@field public PropertyDescriptor System.ComponentModel.PropertyDescriptor
local m = {};

function m:OnComponentChanged() end
---@return System.Boolean
function m:OnComponentChanging() end
System.ComponentModel.ITypeDescriptorContext=m
return m;