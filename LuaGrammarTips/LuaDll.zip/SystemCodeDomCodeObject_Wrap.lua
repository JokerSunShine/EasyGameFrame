---@class System.CodeDom.CodeObject
---instance properties
---@field public UserData System.Collections.IDictionary
local m = {};

System.CodeDom.CodeObject=m
return m;