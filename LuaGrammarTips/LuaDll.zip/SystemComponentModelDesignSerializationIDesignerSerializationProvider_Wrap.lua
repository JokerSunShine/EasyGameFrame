---@class System.ComponentModel.Design.Serialization.IDesignerSerializationProvider
local m = {};

---@param manager System.ComponentModel.Design.Serialization.IDesignerSerializationManager
---@param currentSerializer System.Object
---@param objectType System.Type
---@param serializerType System.Type
---@return System.Object
function m:GetSerializer(manager, currentSerializer, objectType, serializerType) end
System.ComponentModel.Design.Serialization.IDesignerSerializationProvider=m
return m;