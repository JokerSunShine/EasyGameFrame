---@class System.Boolean : System.ValueType
---fields
---@field public FalseString System.String
---@field public TrueString System.String
local m = {};
---@param value System.String
---@return System.Boolean
function m.Parse(value) end
---@param value System.String
---@param result System.Boolean @out
---@return System.Boolean
function m.TryParse(value, result) end

---@param obj System.Object
---@return System.Int32
function m:CompareTo(obj) end
---@param obj System.Object
---@return System.Boolean
function m:Equals(obj) end
---@param value System.Boolean
---@return System.Int32
function m:CompareTo(value) end
---@param obj System.Boolean
---@return System.Boolean
function m:Equals(obj) end
---@return System.Int32
function m:GetHashCode() end
---@return System.String
function m:ToString() end
---@return System.TypeCode
function m:GetTypeCode() end
---@param provider System.IFormatProvider
---@return System.String
function m:ToString(provider) end
System.Boolean=m
return m;