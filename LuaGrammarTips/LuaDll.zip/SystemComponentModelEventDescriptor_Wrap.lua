---@class System.ComponentModel.EventDescriptor : System.ComponentModel.MemberDescriptor
---instance properties
---@field public ComponentType System.Type
---@field public EventType System.Type
---@field public IsMulticast System.Boolean
local m = {};

---@param component System.Object
---@param value System.Delegate
function m:AddEventHandler(component, value) end
---@param component System.Object
---@param value System.Delegate
function m:RemoveEventHandler(component, value) end
System.ComponentModel.EventDescriptor=m
return m;