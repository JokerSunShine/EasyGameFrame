---@class System.CodeDom.Compiler.CompilerParameters
---instance properties
---@field public CompilerOptions System.String
---@field public Evidence System.Security.Policy.Evidence
---@field public GenerateExecutable System.Boolean
---@field public GenerateInMemory System.Boolean
---@field public IncludeDebugInformation System.Boolean
---@field public MainClass System.String
---@field public OutputAssembly System.String
---@field public ReferencedAssemblies System.Collections.Specialized.StringCollection
---@field public TempFiles System.CodeDom.Compiler.TempFileCollection
---@field public TreatWarningsAsErrors System.Boolean
---@field public UserToken System.IntPtr
---@field public WarningLevel System.Int32
---@field public Win32Resource System.String
---@field public EmbeddedResources System.Collections.Specialized.StringCollection
---@field public LinkedResources System.Collections.Specialized.StringCollection
local m = {};

System.CodeDom.Compiler.CompilerParameters=m
return m;