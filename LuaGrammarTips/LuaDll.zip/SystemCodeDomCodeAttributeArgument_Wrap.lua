---@class System.CodeDom.CodeAttributeArgument
---instance properties
---@field public Name System.String
---@field public Value System.CodeDom.CodeExpression
local m = {};

System.CodeDom.CodeAttributeArgument=m
return m;