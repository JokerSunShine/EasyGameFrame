---@class System.BitConverter
---fields
---@field public IsLittleEndian System.Boolean
local m = {};
---@param value System.Double
---@return System.Int64
function m.DoubleToInt64Bits(value) end
---@param value System.Int64
---@return System.Double
function m.Int64BitsToDouble(value) end
---@param value System.Boolean
---@return System.Byte
function m.GetBytes(value) end
---@param value System.Char
---@return System.Byte
function m.GetBytes(value) end
---@param value System.Int16
---@return System.Byte
function m.GetBytes(value) end
---@param value System.Int32
---@return System.Byte
function m.GetBytes(value) end
---@param value System.Int64
---@return System.Byte
function m.GetBytes(value) end
---@param value System.UInt16
---@return System.Byte
function m.GetBytes(value) end
---@param value System.UInt32
---@return System.Byte
function m.GetBytes(value) end
---@param value System.UInt64
---@return System.Byte
function m.GetBytes(value) end
---@param value System.Single
---@return System.Byte
function m.GetBytes(value) end
---@param value System.Double
---@return System.Byte
function m.GetBytes(value) end
---@param value System.Byte
---@param startIndex System.Int32
---@return System.Boolean
function m.ToBoolean(value, startIndex) end
---@param value System.Byte
---@param startIndex System.Int32
---@return System.Char
function m.ToChar(value, startIndex) end
---@param value System.Byte
---@param startIndex System.Int32
---@return System.Int16
function m.ToInt16(value, startIndex) end
---@param value System.Byte
---@param startIndex System.Int32
---@return System.Int32
function m.ToInt32(value, startIndex) end
---@param value System.Byte
---@param startIndex System.Int32
---@return System.Int64
function m.ToInt64(value, startIndex) end
---@param value System.Byte
---@param startIndex System.Int32
---@return System.UInt16
function m.ToUInt16(value, startIndex) end
---@param value System.Byte
---@param startIndex System.Int32
---@return System.UInt32
function m.ToUInt32(value, startIndex) end
---@param value System.Byte
---@param startIndex System.Int32
---@return System.UInt64
function m.ToUInt64(value, startIndex) end
---@param value System.Byte
---@param startIndex System.Int32
---@return System.Single
function m.ToSingle(value, startIndex) end
---@param value System.Byte
---@param startIndex System.Int32
---@return System.Double
function m.ToDouble(value, startIndex) end
---@param value System.Byte
---@return System.String
function m.ToString(value) end
---@param value System.Byte
---@param startIndex System.Int32
---@return System.String
function m.ToString(value, startIndex) end
---@param value System.Byte
---@param startIndex System.Int32
---@param length System.Int32
---@return System.String
function m.ToString(value, startIndex, length) end

System.BitConverter=m
return m;