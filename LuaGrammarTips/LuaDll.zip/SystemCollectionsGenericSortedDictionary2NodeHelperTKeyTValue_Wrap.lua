---@class System.Collections.Generic.SortedDictionary2NodeHelperTKeyTValue
---instance fields
---@field public cmp System.Collections.Generic.IComparer1TKey
local m = {};
---@param cmp System.Collections.Generic.IComparer1TKey
---@return System.Collections.Generic.SortedDictionary2NodeHelperTKeyTValue
function m.GetHelper(cmp) end

---@param key TKey
---@param node System.Collections.Generic.RBTreeNode
---@return System.Int32
function m:Compare(key, node) end
---@param key TKey
---@return System.Collections.Generic.RBTreeNode
function m:CreateNode(key) end
System.Collections.Generic.SortedDictionary2NodeHelperTKeyTValue=m
return m;