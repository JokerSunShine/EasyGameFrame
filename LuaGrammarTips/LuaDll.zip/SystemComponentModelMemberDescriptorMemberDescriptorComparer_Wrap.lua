---@class System.ComponentModel.MemberDescriptorMemberDescriptorComparer
local m = {};

---@param x System.Object
---@param y System.Object
---@return System.Int32
function m:Compare(x, y) end
System.ComponentModel.MemberDescriptorMemberDescriptorComparer=m
return m;