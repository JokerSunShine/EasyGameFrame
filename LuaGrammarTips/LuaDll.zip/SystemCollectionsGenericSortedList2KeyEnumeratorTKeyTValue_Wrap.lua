---@class System.Collections.Generic.SortedList2KeyEnumeratorTKeyTValue : System.ValueType
---instance properties
---@field public Current TKey
local m = {};

function m:Dispose() end
---@return System.Boolean
function m:MoveNext() end
System.Collections.Generic.SortedList2KeyEnumeratorTKeyTValue=m
return m;