---@class System.Collections.Generic.HashSet1LinkT : System.ValueType
---instance fields
---@field public HashCode System.Int32
---@field public Next System.Int32
local m = {};

System.Collections.Generic.HashSet1LinkT=m
return m;