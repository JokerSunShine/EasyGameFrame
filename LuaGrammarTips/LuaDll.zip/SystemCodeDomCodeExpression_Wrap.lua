---@class System.CodeDom.CodeExpression : System.CodeDom.CodeObject
local m = {};

System.CodeDom.CodeExpression=m
return m;