---@class System.Collections.SortedListSlot : System.ValueType
local m = {};

System.Collections.SortedListSlot=m
return m;