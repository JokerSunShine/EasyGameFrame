---@class System.ComponentModel.Design.IHelpService
local m = {};

---@param name System.String
---@param value System.String
---@param keywordType System.ComponentModel.Design.HelpKeywordType
function m:AddContextAttribute(name, value, keywordType) end
function m:ClearContextAttributes() end
---@param contextType System.ComponentModel.Design.HelpContextType
---@return System.ComponentModel.Design.IHelpService
function m:CreateLocalContext(contextType) end
---@param name System.String
---@param value System.String
function m:RemoveContextAttribute(name, value) end
---@param localContext System.ComponentModel.Design.IHelpService
function m:RemoveLocalContext(localContext) end
---@param helpKeyword System.String
function m:ShowHelpFromKeyword(helpKeyword) end
---@param helpUrl System.String
function m:ShowHelpFromUrl(helpUrl) end
System.ComponentModel.Design.IHelpService=m
return m;