---@class System.ComponentModel.IDataErrorInfo
---instance properties
---@field public Error System.String
---@field public Item System.String
local m = {};

System.ComponentModel.IDataErrorInfo=m
return m;