---@class System.ComponentModel.IIntellisenseBuilder
---instance properties
---@field public Name System.String
local m = {};

---@param language System.String
---@param value System.String
---@param newValue System.String
---@return System.Boolean
function m:Show(language, value, newValue) end
System.ComponentModel.IIntellisenseBuilder=m
return m;