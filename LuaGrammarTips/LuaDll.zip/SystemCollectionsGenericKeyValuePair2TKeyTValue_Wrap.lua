---@class System.Collections.Generic.KeyValuePair2TKeyTValue : System.ValueType
---instance properties
---@field public Key TKey
---@field public Value TValue
local m = {};

---@return System.String
function m:ToString() end
System.Collections.Generic.KeyValuePair2TKeyTValue=m
return m;