---@class System.CodeDom.FieldDirection
---@field In @0
---@field Out @1
---@field Ref @2
local m = {};
System.CodeDom.FieldDirection=m
return m;