---@class System.ComponentModel.Design.Serialization.INameCreationService
local m = {};

---@param container System.ComponentModel.IContainer
---@param dataType System.Type
---@return System.String
function m:CreateName(container, dataType) end
---@param name System.String
---@return System.Boolean
function m:IsValidName(name) end
---@param name System.String
function m:ValidateName(name) end
System.ComponentModel.Design.Serialization.INameCreationService=m
return m;