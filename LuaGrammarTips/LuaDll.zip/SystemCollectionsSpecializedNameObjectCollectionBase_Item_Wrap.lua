---@class System.Collections.Specialized.NameObjectCollectionBase_Item
---instance fields
---@field public key System.String
---@field public value System.Object
local m = {};

System.Collections.Specialized.NameObjectCollectionBase_Item=m
return m;