---@class System.CodeDom.CodeTypeMember : System.CodeDom.CodeObject
---instance properties
---@field public Attributes System.CodeDom.MemberAttributes
---@field public Comments System.CodeDom.CodeCommentStatementCollection
---@field public CustomAttributes System.CodeDom.CodeAttributeDeclarationCollection
---@field public LinePragma System.CodeDom.CodeLinePragma
---@field public Name System.String
---@field public EndDirectives System.CodeDom.CodeDirectiveCollection
---@field public StartDirectives System.CodeDom.CodeDirectiveCollection
local m = {};

System.CodeDom.CodeTypeMember=m
return m;