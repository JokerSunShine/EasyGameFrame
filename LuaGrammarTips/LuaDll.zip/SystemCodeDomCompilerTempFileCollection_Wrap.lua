---@class System.CodeDom.Compiler.TempFileCollection
---instance properties
---@field public BasePath System.String
---@field public Count System.Int32
---@field public KeepFiles System.Boolean
---@field public TempDir System.String
local m = {};

---@param fileExtension System.String
---@return System.String
function m:AddExtension(fileExtension) end
---@param fileExtension System.String
---@param keepFile System.Boolean
---@return System.String
function m:AddExtension(fileExtension, keepFile) end
---@param fileName System.String
---@param keepFile System.Boolean
function m:AddFile(fileName, keepFile) end
---@param fileNames System.String
---@param start System.Int32
function m:CopyTo(fileNames, start) end
function m:Delete() end
---@return System.Collections.IEnumerator
function m:GetEnumerator() end
System.CodeDom.Compiler.TempFileCollection=m
return m;