---@class System.ArraySegment1T : System.ValueType
---instance properties
---@field public Array T
---@field public Offset System.Int32
---@field public Count System.Int32
local m = {};
---@param a System.ArraySegment1T
---@param b System.ArraySegment1T
---@return System.Boolean
function m.op_Equality(a, b) end
---@param a System.ArraySegment1T
---@param b System.ArraySegment1T
---@return System.Boolean
function m.op_Inequality(a, b) end

---@param obj System.Object
---@return System.Boolean
function m:Equals(obj) end
---@param obj System.ArraySegment1T
---@return System.Boolean
function m:Equals(obj) end
---@return System.Int32
function m:GetHashCode() end
System.ArraySegment1T=m
return m;