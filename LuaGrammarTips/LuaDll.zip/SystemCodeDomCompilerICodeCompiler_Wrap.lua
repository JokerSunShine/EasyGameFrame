---@class System.CodeDom.Compiler.ICodeCompiler
local m = {};

---@param options System.CodeDom.Compiler.CompilerParameters
---@param compilationUnit System.CodeDom.CodeCompileUnit
---@return System.CodeDom.Compiler.CompilerResults
function m:CompileAssemblyFromDom(options, compilationUnit) end
---@param options System.CodeDom.Compiler.CompilerParameters
---@param batch System.CodeDom.CodeCompileUnit
---@return System.CodeDom.Compiler.CompilerResults
function m:CompileAssemblyFromDomBatch(options, batch) end
---@param options System.CodeDom.Compiler.CompilerParameters
---@param fileName System.String
---@return System.CodeDom.Compiler.CompilerResults
function m:CompileAssemblyFromFile(options, fileName) end
---@param options System.CodeDom.Compiler.CompilerParameters
---@param batch System.String
---@return System.CodeDom.Compiler.CompilerResults
function m:CompileAssemblyFromFileBatch(options, batch) end
---@param options System.CodeDom.Compiler.CompilerParameters
---@param source System.String
---@return System.CodeDom.Compiler.CompilerResults
function m:CompileAssemblyFromSource(options, source) end
---@param options System.CodeDom.Compiler.CompilerParameters
---@param batch System.String
---@return System.CodeDom.Compiler.CompilerResults
function m:CompileAssemblyFromSourceBatch(options, batch) end
System.CodeDom.Compiler.ICodeCompiler=m
return m;