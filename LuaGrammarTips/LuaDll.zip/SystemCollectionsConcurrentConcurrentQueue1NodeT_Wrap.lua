---@class System.Collections.Concurrent.ConcurrentQueue1NodeT
---instance fields
---@field public Value T
---@field public Next System.Collections.Concurrent.ConcurrentQueue1NodeT
local m = {};

System.Collections.Concurrent.ConcurrentQueue1NodeT=m
return m;