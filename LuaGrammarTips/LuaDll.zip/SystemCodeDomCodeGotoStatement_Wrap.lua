---@class System.CodeDom.CodeGotoStatement : System.CodeDom.CodeStatement
---instance properties
---@field public Label System.String
local m = {};

System.CodeDom.CodeGotoStatement=m
return m;