---@class System.Collections.Generic.SortedDictionary2ValueCollectionTKeyTValue
---instance properties
---@field public Count System.Int32
local m = {};

---@param array TValue
---@param arrayIndex System.Int32
function m:CopyTo(array, arrayIndex) end
---@return System.Collections.Generic.SortedDictionary2ValueCollectionEnumeratorTKeyTValue
function m:GetEnumerator() end
System.Collections.Generic.SortedDictionary2ValueCollectionTKeyTValue=m
return m;