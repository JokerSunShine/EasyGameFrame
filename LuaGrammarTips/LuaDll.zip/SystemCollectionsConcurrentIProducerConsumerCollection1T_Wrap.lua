---@class System.Collections.Concurrent.IProducerConsumerCollection1T
local m = {};

---@param item T
---@return System.Boolean
function m:TryAdd(item) end
---@param item T @out
---@return System.Boolean
function m:TryTake(item) end
---@return T
function m:ToArray() end
---@param array T
---@param index System.Int32
function m:CopyTo(array, index) end
System.Collections.Concurrent.IProducerConsumerCollection1T=m
return m;