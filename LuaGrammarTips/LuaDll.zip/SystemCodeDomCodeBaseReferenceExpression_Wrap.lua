---@class System.CodeDom.CodeBaseReferenceExpression : System.CodeDom.CodeExpression
local m = {};

System.CodeDom.CodeBaseReferenceExpression=m
return m;