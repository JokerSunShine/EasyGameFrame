---@class System.CodeDom.CodeTypeDelegate : System.CodeDom.CodeTypeDeclaration
---instance properties
---@field public Parameters System.CodeDom.CodeParameterDeclarationExpressionCollection
---@field public ReturnType System.CodeDom.CodeTypeReference
local m = {};

System.CodeDom.CodeTypeDelegate=m
return m;