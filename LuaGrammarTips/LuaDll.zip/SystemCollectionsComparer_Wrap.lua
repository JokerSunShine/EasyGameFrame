---@class System.Collections.Comparer
---fields
---@field public Default System.Collections.Comparer
---@field public DefaultInvariant System.Collections.Comparer
local m = {};

---@param a System.Object
---@param b System.Object
---@return System.Int32
function m:Compare(a, b) end
---@param info System.Runtime.Serialization.SerializationInfo
---@param context System.Runtime.Serialization.StreamingContext
function m:GetObjectData(info, context) end
System.Collections.Comparer=m
return m;