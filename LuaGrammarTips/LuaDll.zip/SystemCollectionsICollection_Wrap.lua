---@class System.Collections.ICollection
---instance properties
---@field public Count System.Int32
---@field public IsSynchronized System.Boolean
---@field public SyncRoot System.Object
local m = {};

---@param array System.Array
---@param index System.Int32
function m:CopyTo(array, index) end
System.Collections.ICollection=m
return m;