---@class System.Collections.Generic.IDictionary2TKeyTValue
---instance properties
---@field public Item TValue
---@field public Keys System.Collections.Generic.ICollection1TKey
---@field public Values System.Collections.Generic.ICollection1TValue
local m = {};

---@param key TKey
---@param value TValue
function m:Add(key, value) end
---@param key TKey
---@return System.Boolean
function m:ContainsKey(key) end
---@param key TKey
---@return System.Boolean
function m:Remove(key) end
---@param key TKey
---@param value TValue @out
---@return System.Boolean
function m:TryGetValue(key, value) end
System.Collections.Generic.IDictionary2TKeyTValue=m
return m;