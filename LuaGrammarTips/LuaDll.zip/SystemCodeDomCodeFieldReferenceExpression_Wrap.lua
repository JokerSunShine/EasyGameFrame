---@class System.CodeDom.CodeFieldReferenceExpression : System.CodeDom.CodeExpression
---instance properties
---@field public FieldName System.String
---@field public TargetObject System.CodeDom.CodeExpression
local m = {};

System.CodeDom.CodeFieldReferenceExpression=m
return m;