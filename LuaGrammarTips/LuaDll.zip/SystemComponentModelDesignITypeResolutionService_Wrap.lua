---@class System.ComponentModel.Design.ITypeResolutionService
local m = {};

---@param name System.Reflection.AssemblyName
---@return System.Reflection.Assembly
function m:GetAssembly(name) end
---@param name System.Reflection.AssemblyName
---@param throwOnError System.Boolean
---@return System.Reflection.Assembly
function m:GetAssembly(name, throwOnError) end
---@param name System.Reflection.AssemblyName
---@return System.String
function m:GetPathOfAssembly(name) end
---@param name System.String
---@return System.Type
function m:GetType(name) end
---@param name System.String
---@param throwOnError System.Boolean
---@return System.Type
function m:GetType(name, throwOnError) end
---@param name System.String
---@param throwOnError System.Boolean
---@param ignoreCase System.Boolean
---@return System.Type
function m:GetType(name, throwOnError, ignoreCase) end
---@param name System.Reflection.AssemblyName
function m:ReferenceAssembly(name) end
System.ComponentModel.Design.ITypeResolutionService=m
return m;