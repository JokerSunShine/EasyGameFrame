---@class System.Collections.Generic.GenericEqualityComparer1T : System.Collections.Generic.EqualityComparer1T
local m = {};

---@param obj T
---@return System.Int32
function m:GetHashCode(obj) end
---@param x T
---@param y T
---@return System.Boolean
function m:Equals(x, y) end
System.Collections.Generic.GenericEqualityComparer1T=m
return m;