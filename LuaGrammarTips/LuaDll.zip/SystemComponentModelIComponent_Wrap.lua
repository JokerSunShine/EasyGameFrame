---@class System.ComponentModel.IComponent
---instance properties
---@field public Site System.ComponentModel.ISite
local m = {};

---@param value System.EventHandler
function m:add_Disposed(value) end
---@param value System.EventHandler
function m:remove_Disposed(value) end
System.ComponentModel.IComponent=m
return m;