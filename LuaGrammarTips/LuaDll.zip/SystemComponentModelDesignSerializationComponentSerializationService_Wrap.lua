---@class System.ComponentModel.Design.Serialization.ComponentSerializationService
local m = {};

---@return System.ComponentModel.Design.Serialization.SerializationStore
function m:CreateStore() end
---@param store System.ComponentModel.Design.Serialization.SerializationStore
---@return System.Collections.ICollection
function m:Deserialize(store) end
---@param store System.ComponentModel.Design.Serialization.SerializationStore
---@param container System.ComponentModel.IContainer
---@return System.Collections.ICollection
function m:Deserialize(store, container) end
---@param stream System.IO.Stream
---@return System.ComponentModel.Design.Serialization.SerializationStore
function m:LoadStore(stream) end
---@param store System.ComponentModel.Design.Serialization.SerializationStore
---@param value System.Object
function m:Serialize(store, value) end
---@param store System.ComponentModel.Design.Serialization.SerializationStore
---@param value System.Object
function m:SerializeAbsolute(store, value) end
---@param store System.ComponentModel.Design.Serialization.SerializationStore
---@param owningObject System.Object
---@param member System.ComponentModel.MemberDescriptor
function m:SerializeMember(store, owningObject, member) end
---@param store System.ComponentModel.Design.Serialization.SerializationStore
---@param owningObject System.Object
---@param member System.ComponentModel.MemberDescriptor
function m:SerializeMemberAbsolute(store, owningObject, member) end
---@param store System.ComponentModel.Design.Serialization.SerializationStore
---@param container System.ComponentModel.IContainer
function m:DeserializeTo(store, container) end
---@param store System.ComponentModel.Design.Serialization.SerializationStore
---@param container System.ComponentModel.IContainer
---@param validateRecycledTypes System.Boolean
function m:DeserializeTo(store, container, validateRecycledTypes) end
---@param store System.ComponentModel.Design.Serialization.SerializationStore
---@param container System.ComponentModel.IContainer
---@param validateRecycledTypes System.Boolean
---@param applyDefaults System.Boolean
function m:DeserializeTo(store, container, validateRecycledTypes, applyDefaults) end
System.ComponentModel.Design.Serialization.ComponentSerializationService=m
return m;