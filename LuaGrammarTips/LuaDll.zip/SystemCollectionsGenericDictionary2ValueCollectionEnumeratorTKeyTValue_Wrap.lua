---@class System.Collections.Generic.Dictionary2ValueCollectionEnumeratorTKeyTValue : System.ValueType
---instance properties
---@field public Current TValue
local m = {};

function m:Dispose() end
---@return System.Boolean
function m:MoveNext() end
System.Collections.Generic.Dictionary2ValueCollectionEnumeratorTKeyTValue=m
return m;