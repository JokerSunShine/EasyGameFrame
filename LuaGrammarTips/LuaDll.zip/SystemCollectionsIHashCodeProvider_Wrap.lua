---@class System.Collections.IHashCodeProvider
local m = {};

---@param obj System.Object
---@return System.Int32
function m:GetHashCode(obj) end
System.Collections.IHashCodeProvider=m
return m;