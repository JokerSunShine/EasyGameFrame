---@class System.Collections.Generic.Stack1EnumeratorT : System.ValueType
---instance properties
---@field public Current T
local m = {};

function m:Dispose() end
---@return System.Boolean
function m:MoveNext() end
System.Collections.Generic.Stack1EnumeratorT=m
return m;