---@class System.Collections.Specialized.CollectionsUtil
local m = {};
---@return System.Collections.Hashtable
function m.CreateCaseInsensitiveHashtable() end
---@param d System.Collections.IDictionary
---@return System.Collections.Hashtable
function m.CreateCaseInsensitiveHashtable(d) end
---@param capacity System.Int32
---@return System.Collections.Hashtable
function m.CreateCaseInsensitiveHashtable(capacity) end
---@return System.Collections.SortedList
function m.CreateCaseInsensitiveSortedList() end

System.Collections.Specialized.CollectionsUtil=m
return m;