---@class System.ComponentModel.DoWorkEventArgs : System.ComponentModel.CancelEventArgs
---instance properties
---@field public Argument System.Object
---@field public Result System.Object
local m = {};

System.ComponentModel.DoWorkEventArgs=m
return m;