---@class System.ComponentModel.ComponentEditor
local m = {};

---@param component System.Object
---@return System.Boolean
function m:EditComponent(component) end
---@param context System.ComponentModel.ITypeDescriptorContext
---@param component System.Object
---@return System.Boolean
function m:EditComponent(context, component) end
System.ComponentModel.ComponentEditor=m
return m;