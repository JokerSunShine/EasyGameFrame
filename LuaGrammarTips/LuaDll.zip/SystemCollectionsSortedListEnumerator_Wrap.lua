---@class System.Collections.SortedListEnumerator
---instance properties
---@field public Entry System.Collections.DictionaryEntry
---@field public Key System.Object
---@field public Value System.Object
---@field public Current System.Object
local m = {};

function m:Reset() end
---@return System.Boolean
function m:MoveNext() end
---@return System.Object
function m:Clone() end
System.Collections.SortedListEnumerator=m
return m;