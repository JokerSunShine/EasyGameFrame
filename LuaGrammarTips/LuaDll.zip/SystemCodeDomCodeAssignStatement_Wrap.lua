---@class System.CodeDom.CodeAssignStatement : System.CodeDom.CodeStatement
---instance properties
---@field public Left System.CodeDom.CodeExpression
---@field public Right System.CodeDom.CodeExpression
local m = {};

System.CodeDom.CodeAssignStatement=m
return m;