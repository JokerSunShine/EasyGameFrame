---@class System.ComponentModel.Design.ITreeDesigner
---instance properties
---@field public Children System.Collections.ICollection
---@field public Parent System.ComponentModel.Design.IDesigner
local m = {};

System.ComponentModel.Design.ITreeDesigner=m
return m;