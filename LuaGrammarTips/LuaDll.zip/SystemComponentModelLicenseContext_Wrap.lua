---@class System.ComponentModel.LicenseContext
---instance properties
---@field public UsageMode System.ComponentModel.LicenseUsageMode
local m = {};

---@param type System.Type
---@param resourceAssembly System.Reflection.Assembly
---@return System.String
function m:GetSavedLicenseKey(type, resourceAssembly) end
---@param type System.Type
---@return System.Object
function m:GetService(type) end
---@param type System.Type
---@param key System.String
function m:SetSavedLicenseKey(type, key) end
System.ComponentModel.LicenseContext=m
return m;