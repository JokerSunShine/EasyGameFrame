---@class System.CodeDom.CodeDirective : System.CodeDom.CodeObject
local m = {};

System.CodeDom.CodeDirective=m
return m;