---@class System.ComponentModel.LicFileLicenseProvider : System.ComponentModel.LicenseProvider
local m = {};

---@param context System.ComponentModel.LicenseContext
---@param type System.Type
---@param instance System.Object
---@param allowExceptions System.Boolean
---@return System.ComponentModel.License
function m:GetLicense(context, type, instance, allowExceptions) end
System.ComponentModel.LicFileLicenseProvider=m
return m;