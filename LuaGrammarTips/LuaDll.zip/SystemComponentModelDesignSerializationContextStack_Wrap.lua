---@class System.ComponentModel.Design.Serialization.ContextStack
---instance properties
---@field public Current System.Object
---@field public Item System.Object
---@field public Item System.Object
local m = {};

---@return System.Object
function m:Pop() end
---@param context System.Object
function m:Push(context) end
---@param context System.Object
function m:Append(context) end
System.ComponentModel.Design.Serialization.ContextStack=m
return m;