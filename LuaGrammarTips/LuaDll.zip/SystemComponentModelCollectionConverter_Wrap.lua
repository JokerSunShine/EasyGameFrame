---@class System.ComponentModel.CollectionConverter : System.ComponentModel.TypeConverter
local m = {};

---@param context System.ComponentModel.ITypeDescriptorContext
---@param culture System.Globalization.CultureInfo
---@param value System.Object
---@param destinationType System.Type
---@return System.Object
function m:ConvertTo(context, culture, value, destinationType) end
---@param context System.ComponentModel.ITypeDescriptorContext
---@param value System.Object
---@param attributes System.Attribute
---@return System.ComponentModel.PropertyDescriptorCollection
function m:GetProperties(context, value, attributes) end
---@param context System.ComponentModel.ITypeDescriptorContext
---@return System.Boolean
function m:GetPropertiesSupported(context) end
System.ComponentModel.CollectionConverter=m
return m;