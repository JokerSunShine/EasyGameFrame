---@class System.ComponentModel.Design.ComponentChangingEventArgs : System.EventArgs
---instance properties
---@field public Component System.Object
---@field public Member System.ComponentModel.MemberDescriptor
local m = {};

System.ComponentModel.Design.ComponentChangingEventArgs=m
return m;