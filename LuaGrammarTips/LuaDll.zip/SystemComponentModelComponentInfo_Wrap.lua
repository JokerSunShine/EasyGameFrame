---@class System.ComponentModel.ComponentInfo : System.ComponentModel.Info
local m = {};

---@return System.ComponentModel.AttributeCollection
function m:GetAttributes() end
---@return System.ComponentModel.EventDescriptorCollection
function m:GetEvents() end
---@return System.ComponentModel.PropertyDescriptorCollection
function m:GetProperties() end
System.ComponentModel.ComponentInfo=m
return m;