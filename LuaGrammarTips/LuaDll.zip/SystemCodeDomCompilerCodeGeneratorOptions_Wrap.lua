---@class System.CodeDom.Compiler.CodeGeneratorOptions
---instance properties
---@field public BlankLinesBetweenMembers System.Boolean
---@field public BracingStyle System.String
---@field public ElseOnClosing System.Boolean
---@field public IndentString System.String
---@field public Item System.Object
---@field public VerbatimOrder System.Boolean
local m = {};

System.CodeDom.Compiler.CodeGeneratorOptions=m
return m;