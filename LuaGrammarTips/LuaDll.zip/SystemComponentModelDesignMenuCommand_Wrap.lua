---@class System.ComponentModel.Design.MenuCommand
---instance properties
---@field public Checked System.Boolean
---@field public CommandID System.ComponentModel.Design.CommandID
---@field public Enabled System.Boolean
---@field public OleStatus System.Int32
---@field public Properties System.Collections.IDictionary
---@field public Supported System.Boolean
---@field public Visible System.Boolean
local m = {};

---@param value System.EventHandler
function m:add_CommandChanged(value) end
---@param value System.EventHandler
function m:remove_CommandChanged(value) end
function m:Invoke() end
---@param arg System.Object
function m:Invoke(arg) end
---@return System.String
function m:ToString() end
System.ComponentModel.Design.MenuCommand=m
return m;