---@class System.CodeDom.CodeRegionDirective : System.CodeDom.CodeDirective
---instance properties
---@field public RegionMode System.CodeDom.CodeRegionMode
---@field public RegionText System.String
local m = {};

System.CodeDom.CodeRegionDirective=m
return m;