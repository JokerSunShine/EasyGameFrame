---@class System.ComponentModel.IRevertibleChangeTracking
local m = {};

function m:RejectChanges() end
System.ComponentModel.IRevertibleChangeTracking=m
return m;