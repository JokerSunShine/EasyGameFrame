---@class System.CodeDom.CodeComment : System.CodeDom.CodeObject
---instance properties
---@field public DocComment System.Boolean
---@field public Text System.String
local m = {};

System.CodeDom.CodeComment=m
return m;