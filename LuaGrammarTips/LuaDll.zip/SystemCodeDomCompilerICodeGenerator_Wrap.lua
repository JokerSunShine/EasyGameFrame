---@class System.CodeDom.Compiler.ICodeGenerator
local m = {};

---@param value System.String
---@return System.String
function m:CreateEscapedIdentifier(value) end
---@param value System.String
---@return System.String
function m:CreateValidIdentifier(value) end
---@param compileUnit System.CodeDom.CodeCompileUnit
---@param output System.IO.TextWriter
---@param options System.CodeDom.Compiler.CodeGeneratorOptions
function m:GenerateCodeFromCompileUnit(compileUnit, output, options) end
---@param expression System.CodeDom.CodeExpression
---@param output System.IO.TextWriter
---@param options System.CodeDom.Compiler.CodeGeneratorOptions
function m:GenerateCodeFromExpression(expression, output, options) end
---@param ns System.CodeDom.CodeNamespace
---@param output System.IO.TextWriter
---@param options System.CodeDom.Compiler.CodeGeneratorOptions
function m:GenerateCodeFromNamespace(ns, output, options) end
---@param statement System.CodeDom.CodeStatement
---@param output System.IO.TextWriter
---@param options System.CodeDom.Compiler.CodeGeneratorOptions
function m:GenerateCodeFromStatement(statement, output, options) end
---@param typeDeclaration System.CodeDom.CodeTypeDeclaration
---@param output System.IO.TextWriter
---@param options System.CodeDom.Compiler.CodeGeneratorOptions
function m:GenerateCodeFromType(typeDeclaration, output, options) end
---@param type System.CodeDom.CodeTypeReference
---@return System.String
function m:GetTypeOutput(type) end
---@param value System.String
---@return System.Boolean
function m:IsValidIdentifier(value) end
---@param supports System.CodeDom.Compiler.GeneratorSupport
---@return System.Boolean
function m:Supports(supports) end
---@param value System.String
function m:ValidateIdentifier(value) end
System.CodeDom.Compiler.ICodeGenerator=m
return m;