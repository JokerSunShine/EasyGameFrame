---@class System.ComponentModel.Design.ViewTechnology
---@field Passthrough @0
---@field WindowsForms @1
---@field Default @2
local m = {};
System.ComponentModel.Design.ViewTechnology=m
return m;