---@class System.ComponentModel.ICustomTypeDescriptor
local m = {};

---@return System.ComponentModel.AttributeCollection
function m:GetAttributes() end
---@return System.String
function m:GetClassName() end
---@return System.String
function m:GetComponentName() end
---@return System.ComponentModel.TypeConverter
function m:GetConverter() end
---@return System.ComponentModel.EventDescriptor
function m:GetDefaultEvent() end
---@return System.ComponentModel.PropertyDescriptor
function m:GetDefaultProperty() end
---@param editorBaseType System.Type
---@return System.Object
function m:GetEditor(editorBaseType) end
---@return System.ComponentModel.EventDescriptorCollection
function m:GetEvents() end
---@param arr System.Attribute
---@return System.ComponentModel.EventDescriptorCollection
function m:GetEvents(arr) end
---@return System.ComponentModel.PropertyDescriptorCollection
function m:GetProperties() end
---@param arr System.Attribute
---@return System.ComponentModel.PropertyDescriptorCollection
function m:GetProperties(arr) end
---@param pd System.ComponentModel.PropertyDescriptor
---@return System.Object
function m:GetPropertyOwner(pd) end
System.ComponentModel.ICustomTypeDescriptor=m
return m;