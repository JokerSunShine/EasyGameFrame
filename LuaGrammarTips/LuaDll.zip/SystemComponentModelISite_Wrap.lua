---@class System.ComponentModel.ISite
---instance properties
---@field public Component System.ComponentModel.IComponent
---@field public Container System.ComponentModel.IContainer
---@field public DesignMode System.Boolean
---@field public Name System.String
local m = {};

System.ComponentModel.ISite=m
return m;