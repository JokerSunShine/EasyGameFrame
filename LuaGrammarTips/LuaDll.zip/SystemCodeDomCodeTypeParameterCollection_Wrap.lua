---@class System.CodeDom.CodeTypeParameterCollection : System.Collections.CollectionBase
---instance properties
---@field public Item System.CodeDom.CodeTypeParameter
local m = {};

---@param value System.CodeDom.CodeTypeParameter
---@return System.Int32
function m:Add(value) end
---@param value System.String
function m:Add(value) end
---@param value System.CodeDom.CodeTypeParameter
function m:AddRange(value) end
---@param value System.CodeDom.CodeTypeParameterCollection
function m:AddRange(value) end
---@param value System.CodeDom.CodeTypeParameter
---@return System.Boolean
function m:Contains(value) end
---@param array System.CodeDom.CodeTypeParameter
---@param index System.Int32
function m:CopyTo(array, index) end
---@param value System.CodeDom.CodeTypeParameter
---@return System.Int32
function m:IndexOf(value) end
---@param index System.Int32
---@param value System.CodeDom.CodeTypeParameter
function m:Insert(index, value) end
---@param value System.CodeDom.CodeTypeParameter
function m:Remove(value) end
System.CodeDom.CodeTypeParameterCollection=m
return m;