---@class System.ActivationContext
---instance properties
---@field public Form System.ActivationContextContextForm
---@field public Identity System.ApplicationIdentity
local m = {};
---@param identity System.ApplicationIdentity
---@return System.ActivationContext
function m.CreatePartialActivationContext(identity) end
---@param identity System.ApplicationIdentity
---@param manifestPaths System.String
---@return System.ActivationContext
function m.CreatePartialActivationContext(identity, manifestPaths) end

function m:Dispose() end
System.ActivationContext=m
return m;