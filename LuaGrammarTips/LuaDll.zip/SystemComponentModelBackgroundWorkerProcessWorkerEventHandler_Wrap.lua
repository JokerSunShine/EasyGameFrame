---@class System.ComponentModel.BackgroundWorkerProcessWorkerEventHandler : System.MulticastDelegate
local m = {};

---@param argument System.Object
---@param async System.ComponentModel.AsyncOperation
---@param callback System.Threading.SendOrPostCallback
function m:Invoke(argument, async, callback) end
---@param argument System.Object
---@param async System.ComponentModel.AsyncOperation
---@param callback System.Threading.SendOrPostCallback
---@param _callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(argument, async, callback, _callback, object) end
---@param result System.IAsyncResult
function m:EndInvoke(result) end
System.ComponentModel.BackgroundWorkerProcessWorkerEventHandler=m
return m;