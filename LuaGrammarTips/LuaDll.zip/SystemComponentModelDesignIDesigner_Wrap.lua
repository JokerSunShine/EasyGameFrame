---@class System.ComponentModel.Design.IDesigner
---instance properties
---@field public Component System.ComponentModel.IComponent
---@field public Verbs System.ComponentModel.Design.DesignerVerbCollection
local m = {};

function m:DoDefaultAction() end
---@param component System.ComponentModel.IComponent
function m:Initialize(component) end
System.ComponentModel.Design.IDesigner=m
return m;