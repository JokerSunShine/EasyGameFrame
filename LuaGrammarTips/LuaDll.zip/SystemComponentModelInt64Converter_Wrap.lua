---@class System.ComponentModel.Int64Converter : System.ComponentModel.BaseNumberConverter
local m = {};

System.ComponentModel.Int64Converter=m
return m;