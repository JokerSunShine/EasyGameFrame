---@class System.ComponentModel.INotifyPropertyChanged
local m = {};

---@param value System.ComponentModel.PropertyChangedEventHandler
function m:add_PropertyChanged(value) end
---@param value System.ComponentModel.PropertyChangedEventHandler
function m:remove_PropertyChanged(value) end
System.ComponentModel.INotifyPropertyChanged=m
return m;