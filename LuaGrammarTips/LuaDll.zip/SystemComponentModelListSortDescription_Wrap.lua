---@class System.ComponentModel.ListSortDescription
---instance properties
---@field public PropertyDescriptor System.ComponentModel.PropertyDescriptor
---@field public SortDirection System.ComponentModel.ListSortDirection
local m = {};

System.ComponentModel.ListSortDescription=m
return m;