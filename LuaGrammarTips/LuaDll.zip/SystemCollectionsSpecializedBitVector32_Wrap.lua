---@class System.Collections.Specialized.BitVector32 : System.ValueType
---instance properties
---@field public Data System.Int32
---@field public Item System.Int32
---@field public Item System.Boolean
local m = {};
---@return System.Int32
function m.CreateMask() end
---@param prev System.Int32
---@return System.Int32
function m.CreateMask(prev) end
---@param maxValue System.Int16
---@return System.Collections.Specialized.BitVector32Section
function m.CreateSection(maxValue) end
---@param maxValue System.Int16
---@param previous System.Collections.Specialized.BitVector32Section
---@return System.Collections.Specialized.BitVector32Section
function m.CreateSection(maxValue, previous) end
---@param value System.Collections.Specialized.BitVector32
---@return System.String
function m.ToString(value) end

---@param o System.Object
---@return System.Boolean
function m:Equals(o) end
---@return System.Int32
function m:GetHashCode() end
---@return System.String
function m:ToString() end
System.Collections.Specialized.BitVector32=m
return m;