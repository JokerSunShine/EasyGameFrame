---@class System.ComponentModel.Design.DesignerTransaction
---instance properties
---@field public Canceled System.Boolean
---@field public Committed System.Boolean
---@field public Description System.String
local m = {};

function m:Cancel() end
function m:Commit() end
System.ComponentModel.Design.DesignerTransaction=m
return m;