---@class System.ComponentModel.CollectionChangeEventArgs : System.EventArgs
---instance properties
---@field public Action System.ComponentModel.CollectionChangeAction
---@field public Element System.Object
local m = {};

System.ComponentModel.CollectionChangeEventArgs=m
return m;