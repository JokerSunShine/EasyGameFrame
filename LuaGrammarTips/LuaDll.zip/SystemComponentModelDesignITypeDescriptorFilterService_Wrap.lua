---@class System.ComponentModel.Design.ITypeDescriptorFilterService
local m = {};

---@param component System.ComponentModel.IComponent
---@param attributes System.Collections.IDictionary
---@return System.Boolean
function m:FilterAttributes(component, attributes) end
---@param component System.ComponentModel.IComponent
---@param events System.Collections.IDictionary
---@return System.Boolean
function m:FilterEvents(component, events) end
---@param component System.ComponentModel.IComponent
---@param properties System.Collections.IDictionary
---@return System.Boolean
function m:FilterProperties(component, properties) end
System.ComponentModel.Design.ITypeDescriptorFilterService=m
return m;