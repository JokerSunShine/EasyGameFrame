---@class System.ApplicationIdentity
---instance properties
---@field public CodeBase System.String
---@field public FullName System.String
local m = {};

---@return System.String
function m:ToString() end
System.ApplicationIdentity=m
return m;