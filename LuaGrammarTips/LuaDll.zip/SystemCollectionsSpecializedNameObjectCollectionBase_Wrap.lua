---@class System.Collections.Specialized.NameObjectCollectionBase
---instance properties
---@field public Keys System.Collections.Specialized.NameObjectCollectionBaseKeysCollection
---@field public Count System.Int32
local m = {};

---@return System.Collections.IEnumerator
function m:GetEnumerator() end
---@param info System.Runtime.Serialization.SerializationInfo
---@param context System.Runtime.Serialization.StreamingContext
function m:GetObjectData(info, context) end
---@param sender System.Object
function m:OnDeserialization(sender) end
System.Collections.Specialized.NameObjectCollectionBase=m
return m;