---@class System.ComponentModel.LicenseManager
---properties
---@field public CurrentContext System.ComponentModel.LicenseContext
---@field public UsageMode System.ComponentModel.LicenseUsageMode
local m = {};
---@param type System.Type
---@param creationContext System.ComponentModel.LicenseContext
---@return System.Object
function m.CreateWithContext(type, creationContext) end
---@param type System.Type
---@param creationContext System.ComponentModel.LicenseContext
---@param args System.Object
---@return System.Object
function m.CreateWithContext(type, creationContext, args) end
---@param type System.Type
---@return System.Boolean
function m.IsLicensed(type) end
---@param type System.Type
---@return System.Boolean
function m.IsValid(type) end
---@param type System.Type
---@param instance System.Object
---@param license System.ComponentModel.License @out
---@return System.Boolean
function m.IsValid(type, instance, license) end
---@param contextUser System.Object
function m.LockContext(contextUser) end
---@param contextUser System.Object
function m.UnlockContext(contextUser) end
---@param type System.Type
function m.Validate(type) end
---@param type System.Type
---@param instance System.Object
---@return System.ComponentModel.License
function m.Validate(type, instance) end

System.ComponentModel.LicenseManager=m
return m;