---@class System.Collections.Generic.Dictionary2KeyCollectionEnumeratorTKeyTValue : System.ValueType
---instance properties
---@field public Current TKey
local m = {};

function m:Dispose() end
---@return System.Boolean
function m:MoveNext() end
System.Collections.Generic.Dictionary2KeyCollectionEnumeratorTKeyTValue=m
return m;