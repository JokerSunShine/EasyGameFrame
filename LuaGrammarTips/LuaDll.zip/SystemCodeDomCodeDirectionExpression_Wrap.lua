---@class System.CodeDom.CodeDirectionExpression : System.CodeDom.CodeExpression
---instance properties
---@field public Direction System.CodeDom.FieldDirection
---@field public Expression System.CodeDom.CodeExpression
local m = {};

System.CodeDom.CodeDirectionExpression=m
return m;