---@class System.Comparison1T : System.MulticastDelegate
local m = {};

---@param x T
---@param y T
---@return System.Int32
function m:Invoke(x, y) end
---@param x T
---@param y T
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(x, y, callback, object) end
---@param result System.IAsyncResult
---@return System.Int32
function m:EndInvoke(result) end
System.Comparison1T=m
return m;