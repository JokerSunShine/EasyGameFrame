---@class System.CodeDom.CodeTypeOfExpression : System.CodeDom.CodeExpression
---instance properties
---@field public Type System.CodeDom.CodeTypeReference
local m = {};

System.CodeDom.CodeTypeOfExpression=m
return m;