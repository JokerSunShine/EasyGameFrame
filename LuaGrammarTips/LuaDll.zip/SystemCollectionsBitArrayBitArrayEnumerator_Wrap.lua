---@class System.Collections.BitArrayBitArrayEnumerator
---instance properties
---@field public Current System.Object
local m = {};

---@return System.Object
function m:Clone() end
---@return System.Boolean
function m:MoveNext() end
function m:Reset() end
System.Collections.BitArrayBitArrayEnumerator=m
return m;