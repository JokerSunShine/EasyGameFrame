---@class System.Collections.ObjectModel.Collection1T
---instance properties
---@field public Count System.Int32
---@field public Item T
local m = {};

---@param item T
function m:Add(item) end
function m:Clear() end
---@param item T
---@return System.Boolean
function m:Contains(item) end
---@param array T
---@param index System.Int32
function m:CopyTo(array, index) end
---@return System.Collections.Generic.IEnumerator1T
function m:GetEnumerator() end
---@param item T
---@return System.Int32
function m:IndexOf(item) end
---@param index System.Int32
---@param item T
function m:Insert(index, item) end
---@param item T
---@return System.Boolean
function m:Remove(item) end
---@param index System.Int32
function m:RemoveAt(index) end
System.Collections.ObjectModel.Collection1T=m
return m;