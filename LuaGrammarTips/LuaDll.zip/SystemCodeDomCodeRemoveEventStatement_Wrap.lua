---@class System.CodeDom.CodeRemoveEventStatement : System.CodeDom.CodeStatement
---instance properties
---@field public Event System.CodeDom.CodeEventReferenceExpression
---@field public Listener System.CodeDom.CodeExpression
local m = {};

System.CodeDom.CodeRemoveEventStatement=m
return m;