---@class System.Collections.Generic.SortedDictionary2KeyCollectionEnumeratorTKeyTValue : System.ValueType
---instance properties
---@field public Current TKey
local m = {};

---@return System.Boolean
function m:MoveNext() end
function m:Dispose() end
System.Collections.Generic.SortedDictionary2KeyCollectionEnumeratorTKeyTValue=m
return m;