---@class System.ComponentModel.Design.IReferenceService
local m = {};

---@param reference System.Object
---@return System.ComponentModel.IComponent
function m:GetComponent(reference) end
---@param reference System.Object
---@return System.String
function m:GetName(reference) end
---@param name System.String
---@return System.Object
function m:GetReference(name) end
---@return System.Object
function m:GetReferences() end
---@param baseType System.Type
---@return System.Object
function m:GetReferences(baseType) end
System.ComponentModel.Design.IReferenceService=m
return m;