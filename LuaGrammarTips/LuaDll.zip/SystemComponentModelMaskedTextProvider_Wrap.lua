---@class System.ComponentModel.MaskedTextProvider
---properties
---@field public DefaultPasswordChar System.Char
---@field public InvalidIndex System.Int32
---instance properties
---@field public AllowPromptAsInput System.Boolean
---@field public AsciiOnly System.Boolean
---@field public AssignedEditPositionCount System.Int32
---@field public AvailableEditPositionCount System.Int32
---@field public Culture System.Globalization.CultureInfo
---@field public EditPositionCount System.Int32
---@field public EditPositions System.Collections.IEnumerator
---@field public IncludeLiterals System.Boolean
---@field public IncludePrompt System.Boolean
---@field public IsPassword System.Boolean
---@field public Item System.Char
---@field public LastAssignedPosition System.Int32
---@field public Length System.Int32
---@field public Mask System.String
---@field public MaskCompleted System.Boolean
---@field public MaskFull System.Boolean
---@field public PasswordChar System.Char
---@field public PromptChar System.Char
---@field public ResetOnPrompt System.Boolean
---@field public ResetOnSpace System.Boolean
---@field public SkipLiterals System.Boolean
local m = {};
---@param hint System.ComponentModel.MaskedTextResultHint
---@return System.Boolean
function m.GetOperationResultFromHint(hint) end
---@param c System.Char
---@return System.Boolean
function m.IsValidInputChar(c) end
---@param c System.Char
---@return System.Boolean
function m.IsValidMaskChar(c) end
---@param c System.Char
---@return System.Boolean
function m.IsValidPasswordChar(c) end

---@param input System.Char
---@return System.Boolean
function m:Add(input) end
---@param input System.String
---@return System.Boolean
function m:Add(input) end
---@param input System.Char
---@param testPosition System.Int32 @out
---@param resultHint System.ComponentModel.MaskedTextResultHint @out
---@return System.Boolean
function m:Add(input, testPosition, resultHint) end
---@param input System.String
---@param testPosition System.Int32 @out
---@param resultHint System.ComponentModel.MaskedTextResultHint @out
---@return System.Boolean
function m:Add(input, testPosition, resultHint) end
function m:Clear() end
---@param resultHint System.ComponentModel.MaskedTextResultHint @out
function m:Clear(resultHint) end
---@return System.Object
function m:Clone() end
---@param position System.Int32
---@param direction System.Boolean
---@return System.Int32
function m:FindAssignedEditPositionFrom(position, direction) end
---@param startPosition System.Int32
---@param endPosition System.Int32
---@param direction System.Boolean
---@return System.Int32
function m:FindAssignedEditPositionInRange(startPosition, endPosition, direction) end
---@param position System.Int32
---@param direction System.Boolean
---@return System.Int32
function m:FindEditPositionFrom(position, direction) end
---@param startPosition System.Int32
---@param endPosition System.Int32
---@param direction System.Boolean
---@return System.Int32
function m:FindEditPositionInRange(startPosition, endPosition, direction) end
---@param position System.Int32
---@param direction System.Boolean
---@return System.Int32
function m:FindNonEditPositionFrom(position, direction) end
---@param startPosition System.Int32
---@param endPosition System.Int32
---@param direction System.Boolean
---@return System.Int32
function m:FindNonEditPositionInRange(startPosition, endPosition, direction) end
---@param position System.Int32
---@param direction System.Boolean
---@return System.Int32
function m:FindUnassignedEditPositionFrom(position, direction) end
---@param startPosition System.Int32
---@param endPosition System.Int32
---@param direction System.Boolean
---@return System.Int32
function m:FindUnassignedEditPositionInRange(startPosition, endPosition, direction) end
---@param input System.Char
---@param position System.Int32
---@return System.Boolean
function m:InsertAt(input, position) end
---@param input System.String
---@param position System.Int32
---@return System.Boolean
function m:InsertAt(input, position) end
---@param input System.Char
---@param position System.Int32
---@param testPosition System.Int32 @out
---@param resultHint System.ComponentModel.MaskedTextResultHint @out
---@return System.Boolean
function m:InsertAt(input, position, testPosition, resultHint) end
---@param input System.String
---@param position System.Int32
---@param testPosition System.Int32 @out
---@param resultHint System.ComponentModel.MaskedTextResultHint @out
---@return System.Boolean
function m:InsertAt(input, position, testPosition, resultHint) end
---@param position System.Int32
---@return System.Boolean
function m:IsAvailablePosition(position) end
---@param position System.Int32
---@return System.Boolean
function m:IsEditPosition(position) end
---@return System.Boolean
function m:Remove() end
---@param testPosition System.Int32 @out
---@param resultHint System.ComponentModel.MaskedTextResultHint @out
---@return System.Boolean
function m:Remove(testPosition, resultHint) end
---@param position System.Int32
---@return System.Boolean
function m:RemoveAt(position) end
---@param startPosition System.Int32
---@param endPosition System.Int32
---@return System.Boolean
function m:RemoveAt(startPosition, endPosition) end
---@param startPosition System.Int32
---@param endPosition System.Int32
---@param testPosition System.Int32 @out
---@param resultHint System.ComponentModel.MaskedTextResultHint @out
---@return System.Boolean
function m:RemoveAt(startPosition, endPosition, testPosition, resultHint) end
---@param input System.Char
---@param position System.Int32
---@return System.Boolean
function m:Replace(input, position) end
---@param input System.String
---@param position System.Int32
---@return System.Boolean
function m:Replace(input, position) end
---@param input System.Char
---@param position System.Int32
---@param testPosition System.Int32 @out
---@param resultHint System.ComponentModel.MaskedTextResultHint @out
---@return System.Boolean
function m:Replace(input, position, testPosition, resultHint) end
---@param input System.String
---@param position System.Int32
---@param testPosition System.Int32 @out
---@param resultHint System.ComponentModel.MaskedTextResultHint @out
---@return System.Boolean
function m:Replace(input, position, testPosition, resultHint) end
---@param input System.Char
---@param startPosition System.Int32
---@param endPosition System.Int32
---@param testPosition System.Int32 @out
---@param resultHint System.ComponentModel.MaskedTextResultHint @out
---@return System.Boolean
function m:Replace(input, startPosition, endPosition, testPosition, resultHint) end
---@param input System.String
---@param startPosition System.Int32
---@param endPosition System.Int32
---@param testPosition System.Int32 @out
---@param resultHint System.ComponentModel.MaskedTextResultHint @out
---@return System.Boolean
function m:Replace(input, startPosition, endPosition, testPosition, resultHint) end
---@param input System.String
---@return System.Boolean
function m:Set(input) end
---@param input System.String
---@param testPosition System.Int32 @out
---@param resultHint System.ComponentModel.MaskedTextResultHint @out
---@return System.Boolean
function m:Set(input, testPosition, resultHint) end
---@return System.String
function m:ToDisplayString() end
---@return System.String
function m:ToString() end
---@param ignorePasswordChar System.Boolean
---@return System.String
function m:ToString(ignorePasswordChar) end
---@param includePrompt System.Boolean
---@param includeLiterals System.Boolean
---@return System.String
function m:ToString(includePrompt, includeLiterals) end
---@param startPosition System.Int32
---@param length System.Int32
---@return System.String
function m:ToString(startPosition, length) end
---@param ignorePasswordChar System.Boolean
---@param startPosition System.Int32
---@param length System.Int32
---@return System.String
function m:ToString(ignorePasswordChar, startPosition, length) end
---@param includePrompt System.Boolean
---@param includeLiterals System.Boolean
---@param startPosition System.Int32
---@param length System.Int32
---@return System.String
function m:ToString(includePrompt, includeLiterals, startPosition, length) end
---@param ignorePasswordChar System.Boolean
---@param includePrompt System.Boolean
---@param includeLiterals System.Boolean
---@param startPosition System.Int32
---@param length System.Int32
---@return System.String
function m:ToString(ignorePasswordChar, includePrompt, includeLiterals, startPosition, length) end
---@param input System.Char
---@param position System.Int32
---@param hint System.ComponentModel.MaskedTextResultHint @out
---@return System.Boolean
function m:VerifyChar(input, position, hint) end
---@param input System.Char
---@param position System.Int32
---@return System.Boolean
function m:VerifyEscapeChar(input, position) end
---@param input System.String
---@return System.Boolean
function m:VerifyString(input) end
---@param input System.String
---@param testPosition System.Int32 @out
---@param resultHint System.ComponentModel.MaskedTextResultHint @out
---@return System.Boolean
function m:VerifyString(input, testPosition, resultHint) end
System.ComponentModel.MaskedTextProvider=m
return m;