---@class System.CodeDom.Compiler.ICodeParser
local m = {};

---@param codeStream System.IO.TextReader
---@return System.CodeDom.CodeCompileUnit
function m:Parse(codeStream) end
System.CodeDom.Compiler.ICodeParser=m
return m;