---@class System.AppDomain : System.MarshalByRefObject
---properties
---@field public CurrentDomain System.AppDomain
---instance properties
---@field public SetupInformation System.AppDomainSetup
---@field public ApplicationTrust System.Security.Policy.ApplicationTrust
---@field public BaseDirectory System.String
---@field public RelativeSearchPath System.String
---@field public DynamicDirectory System.String
---@field public ShadowCopyFiles System.Boolean
---@field public FriendlyName System.String
---@field public Evidence System.Security.Policy.Evidence
---@field public DomainManager System.AppDomainManager
---@field public ActivationContext System.ActivationContext
---@field public ApplicationIdentity System.ApplicationIdentity
---@field public Id System.Int32
local m = {};
---@param friendlyName System.String
---@return System.AppDomain
function m.CreateDomain(friendlyName) end
---@param friendlyName System.String
---@param securityInfo System.Security.Policy.Evidence
---@return System.AppDomain
function m.CreateDomain(friendlyName, securityInfo) end
---@param friendlyName System.String
---@param securityInfo System.Security.Policy.Evidence
---@param info System.AppDomainSetup
---@return System.AppDomain
function m.CreateDomain(friendlyName, securityInfo, info) end
---@param friendlyName System.String
---@param securityInfo System.Security.Policy.Evidence
---@param appBasePath System.String
---@param appRelativeSearchPath System.String
---@param shadowCopyFiles System.Boolean
---@return System.AppDomain
function m.CreateDomain(friendlyName, securityInfo, appBasePath, appRelativeSearchPath, shadowCopyFiles) end
---@param friendlyName System.String
---@param securityInfo System.Security.Policy.Evidence
---@param info System.AppDomainSetup
---@param grantSet System.Security.PermissionSet
---@param fullTrustAssemblies System.Security.Policy.StrongName
---@return System.AppDomain
function m.CreateDomain(friendlyName, securityInfo, info, grantSet, fullTrustAssemblies) end
---@param domain System.AppDomain
function m.Unload(domain) end
---@param friendlyName System.String
---@param securityInfo System.Security.Policy.Evidence
---@param appBasePath System.String
---@param appRelativeSearchPath System.String
---@param shadowCopyFiles System.Boolean
---@param adInit System.AppDomainInitializer
---@param adInitArgs System.String
---@return System.AppDomain
function m.CreateDomain(friendlyName, securityInfo, appBasePath, appRelativeSearchPath, shadowCopyFiles, adInit, adInitArgs) end

---@param value System.AssemblyLoadEventHandler
function m:add_AssemblyLoad(value) end
---@param value System.AssemblyLoadEventHandler
function m:remove_AssemblyLoad(value) end
---@param value System.ResolveEventHandler
function m:add_AssemblyResolve(value) end
---@param value System.ResolveEventHandler
function m:remove_AssemblyResolve(value) end
---@param value System.EventHandler
function m:add_DomainUnload(value) end
---@param value System.EventHandler
function m:remove_DomainUnload(value) end
---@param value System.EventHandler
function m:add_ProcessExit(value) end
---@param value System.EventHandler
function m:remove_ProcessExit(value) end
---@param value System.ResolveEventHandler
function m:add_ResourceResolve(value) end
---@param value System.ResolveEventHandler
function m:remove_ResourceResolve(value) end
---@param value System.ResolveEventHandler
function m:add_TypeResolve(value) end
---@param value System.ResolveEventHandler
function m:remove_TypeResolve(value) end
---@param value System.UnhandledExceptionEventHandler
function m:add_UnhandledException(value) end
---@param value System.UnhandledExceptionEventHandler
function m:remove_UnhandledException(value) end
---@param value System.ResolveEventHandler
function m:add_ReflectionOnlyAssemblyResolve(value) end
---@param value System.ResolveEventHandler
function m:remove_ReflectionOnlyAssemblyResolve(value) end
---@param assemblyName System.String
---@param typeName System.String
---@return System.Runtime.Remoting.ObjectHandle
function m:CreateComInstanceFrom(assemblyName, typeName) end
---@param assemblyFile System.String
---@param typeName System.String
---@param hashValue System.Byte
---@param hashAlgorithm System.Configuration.Assemblies.AssemblyHashAlgorithm
---@return System.Runtime.Remoting.ObjectHandle
function m:CreateComInstanceFrom(assemblyFile, typeName, hashValue, hashAlgorithm) end
---@param assemblyName System.String
---@param typeName System.String
---@return System.Runtime.Remoting.ObjectHandle
function m:CreateInstance(assemblyName, typeName) end
---@param assemblyName System.String
---@param typeName System.String
---@param activationAttributes System.Object
---@return System.Runtime.Remoting.ObjectHandle
function m:CreateInstance(assemblyName, typeName, activationAttributes) end
---@param assemblyName System.String
---@param typeName System.String
---@param ignoreCase System.Boolean
---@param bindingAttr System.Reflection.BindingFlags
---@param binder System.Reflection.Binder
---@param args System.Object
---@param culture System.Globalization.CultureInfo
---@param activationAttributes System.Object
---@param securityAttributes System.Security.Policy.Evidence
---@return System.Runtime.Remoting.ObjectHandle
function m:CreateInstance(assemblyName, typeName, ignoreCase, bindingAttr, binder, args, culture, activationAttributes, securityAttributes) end
---@param assemblyName System.String
---@param typeName System.String
---@return System.Object
function m:CreateInstanceAndUnwrap(assemblyName, typeName) end
---@param assemblyName System.String
---@param typeName System.String
---@param activationAttributes System.Object
---@return System.Object
function m:CreateInstanceAndUnwrap(assemblyName, typeName, activationAttributes) end
---@param assemblyName System.String
---@param typeName System.String
---@param ignoreCase System.Boolean
---@param bindingAttr System.Reflection.BindingFlags
---@param binder System.Reflection.Binder
---@param args System.Object
---@param culture System.Globalization.CultureInfo
---@param activationAttributes System.Object
---@param securityAttributes System.Security.Policy.Evidence
---@return System.Object
function m:CreateInstanceAndUnwrap(assemblyName, typeName, ignoreCase, bindingAttr, binder, args, culture, activationAttributes, securityAttributes) end
---@param assemblyFile System.String
---@param typeName System.String
---@return System.Runtime.Remoting.ObjectHandle
function m:CreateInstanceFrom(assemblyFile, typeName) end
---@param assemblyFile System.String
---@param typeName System.String
---@param activationAttributes System.Object
---@return System.Runtime.Remoting.ObjectHandle
function m:CreateInstanceFrom(assemblyFile, typeName, activationAttributes) end
---@param assemblyFile System.String
---@param typeName System.String
---@param ignoreCase System.Boolean
---@param bindingAttr System.Reflection.BindingFlags
---@param binder System.Reflection.Binder
---@param args System.Object
---@param culture System.Globalization.CultureInfo
---@param activationAttributes System.Object
---@param securityAttributes System.Security.Policy.Evidence
---@return System.Runtime.Remoting.ObjectHandle
function m:CreateInstanceFrom(assemblyFile, typeName, ignoreCase, bindingAttr, binder, args, culture, activationAttributes, securityAttributes) end
---@param assemblyName System.String
---@param typeName System.String
---@return System.Object
function m:CreateInstanceFromAndUnwrap(assemblyName, typeName) end
---@param assemblyName System.String
---@param typeName System.String
---@param activationAttributes System.Object
---@return System.Object
function m:CreateInstanceFromAndUnwrap(assemblyName, typeName, activationAttributes) end
---@param assemblyName System.String
---@param typeName System.String
---@param ignoreCase System.Boolean
---@param bindingAttr System.Reflection.BindingFlags
---@param binder System.Reflection.Binder
---@param args System.Object
---@param culture System.Globalization.CultureInfo
---@param activationAttributes System.Object
---@param securityAttributes System.Security.Policy.Evidence
---@return System.Object
function m:CreateInstanceFromAndUnwrap(assemblyName, typeName, ignoreCase, bindingAttr, binder, args, culture, activationAttributes, securityAttributes) end
---@param name System.Reflection.AssemblyName
---@param access System.Reflection.Emit.AssemblyBuilderAccess
---@return System.Reflection.Emit.AssemblyBuilder
function m:DefineDynamicAssembly(name, access) end
---@param name System.Reflection.AssemblyName
---@param access System.Reflection.Emit.AssemblyBuilderAccess
---@param evidence System.Security.Policy.Evidence
---@return System.Reflection.Emit.AssemblyBuilder
function m:DefineDynamicAssembly(name, access, evidence) end
---@param name System.Reflection.AssemblyName
---@param access System.Reflection.Emit.AssemblyBuilderAccess
---@param dir System.String
---@return System.Reflection.Emit.AssemblyBuilder
function m:DefineDynamicAssembly(name, access, dir) end
---@param name System.Reflection.AssemblyName
---@param access System.Reflection.Emit.AssemblyBuilderAccess
---@param dir System.String
---@param evidence System.Security.Policy.Evidence
---@return System.Reflection.Emit.AssemblyBuilder
function m:DefineDynamicAssembly(name, access, dir, evidence) end
---@param name System.Reflection.AssemblyName
---@param access System.Reflection.Emit.AssemblyBuilderAccess
---@param requiredPermissions System.Security.PermissionSet
---@param optionalPermissions System.Security.PermissionSet
---@param refusedPermissions System.Security.PermissionSet
---@return System.Reflection.Emit.AssemblyBuilder
function m:DefineDynamicAssembly(name, access, requiredPermissions, optionalPermissions, refusedPermissions) end
---@param name System.Reflection.AssemblyName
---@param access System.Reflection.Emit.AssemblyBuilderAccess
---@param evidence System.Security.Policy.Evidence
---@param requiredPermissions System.Security.PermissionSet
---@param optionalPermissions System.Security.PermissionSet
---@param refusedPermissions System.Security.PermissionSet
---@return System.Reflection.Emit.AssemblyBuilder
function m:DefineDynamicAssembly(name, access, evidence, requiredPermissions, optionalPermissions, refusedPermissions) end
---@param name System.Reflection.AssemblyName
---@param access System.Reflection.Emit.AssemblyBuilderAccess
---@param dir System.String
---@param requiredPermissions System.Security.PermissionSet
---@param optionalPermissions System.Security.PermissionSet
---@param refusedPermissions System.Security.PermissionSet
---@return System.Reflection.Emit.AssemblyBuilder
function m:DefineDynamicAssembly(name, access, dir, requiredPermissions, optionalPermissions, refusedPermissions) end
---@param name System.Reflection.AssemblyName
---@param access System.Reflection.Emit.AssemblyBuilderAccess
---@param dir System.String
---@param evidence System.Security.Policy.Evidence
---@param requiredPermissions System.Security.PermissionSet
---@param optionalPermissions System.Security.PermissionSet
---@param refusedPermissions System.Security.PermissionSet
---@return System.Reflection.Emit.AssemblyBuilder
function m:DefineDynamicAssembly(name, access, dir, evidence, requiredPermissions, optionalPermissions, refusedPermissions) end
---@param name System.Reflection.AssemblyName
---@param access System.Reflection.Emit.AssemblyBuilderAccess
---@param dir System.String
---@param evidence System.Security.Policy.Evidence
---@param requiredPermissions System.Security.PermissionSet
---@param optionalPermissions System.Security.PermissionSet
---@param refusedPermissions System.Security.PermissionSet
---@param isSynchronized System.Boolean
---@return System.Reflection.Emit.AssemblyBuilder
function m:DefineDynamicAssembly(name, access, dir, evidence, requiredPermissions, optionalPermissions, refusedPermissions, isSynchronized) end
---@param name System.Reflection.AssemblyName
---@param access System.Reflection.Emit.AssemblyBuilderAccess
---@param dir System.String
---@param evidence System.Security.Policy.Evidence
---@param requiredPermissions System.Security.PermissionSet
---@param optionalPermissions System.Security.PermissionSet
---@param refusedPermissions System.Security.PermissionSet
---@param isSynchronized System.Boolean
---@param assemblyAttributes System.Collections.Generic.IEnumerable1System.Reflection.Emit.CustomAttributeBuilder
---@return System.Reflection.Emit.AssemblyBuilder
function m:DefineDynamicAssembly(name, access, dir, evidence, requiredPermissions, optionalPermissions, refusedPermissions, isSynchronized, assemblyAttributes) end
---@param name System.Reflection.AssemblyName
---@param access System.Reflection.Emit.AssemblyBuilderAccess
---@param assemblyAttributes System.Collections.Generic.IEnumerable1System.Reflection.Emit.CustomAttributeBuilder
---@return System.Reflection.Emit.AssemblyBuilder
function m:DefineDynamicAssembly(name, access, assemblyAttributes) end
---@param callBackDelegate System.CrossAppDomainDelegate
function m:DoCallBack(callBackDelegate) end
---@param assemblyFile System.String
---@return System.Int32
function m:ExecuteAssembly(assemblyFile) end
---@param assemblyFile System.String
---@param assemblySecurity System.Security.Policy.Evidence
---@return System.Int32
function m:ExecuteAssembly(assemblyFile, assemblySecurity) end
---@param assemblyFile System.String
---@param assemblySecurity System.Security.Policy.Evidence
---@param args System.String
---@return System.Int32
function m:ExecuteAssembly(assemblyFile, assemblySecurity, args) end
---@param assemblyFile System.String
---@param assemblySecurity System.Security.Policy.Evidence
---@param args System.String
---@param hashValue System.Byte
---@param hashAlgorithm System.Configuration.Assemblies.AssemblyHashAlgorithm
---@return System.Int32
function m:ExecuteAssembly(assemblyFile, assemblySecurity, args, hashValue, hashAlgorithm) end
---@return System.Reflection.Assembly
function m:GetAssemblies() end
---@param name System.String
---@return System.Object
function m:GetData(name) end
---@return System.Type
function m:GetType() end
---@return System.Object
function m:InitializeLifetimeService() end
---@param assemblyRef System.Reflection.AssemblyName
---@return System.Reflection.Assembly
function m:Load(assemblyRef) end
---@param assemblyRef System.Reflection.AssemblyName
---@param assemblySecurity System.Security.Policy.Evidence
---@return System.Reflection.Assembly
function m:Load(assemblyRef, assemblySecurity) end
---@param assemblyString System.String
---@return System.Reflection.Assembly
function m:Load(assemblyString) end
---@param assemblyString System.String
---@param assemblySecurity System.Security.Policy.Evidence
---@return System.Reflection.Assembly
function m:Load(assemblyString, assemblySecurity) end
---@param rawAssembly System.Byte
---@return System.Reflection.Assembly
function m:Load(rawAssembly) end
---@param rawAssembly System.Byte
---@param rawSymbolStore System.Byte
---@return System.Reflection.Assembly
function m:Load(rawAssembly, rawSymbolStore) end
---@param rawAssembly System.Byte
---@param rawSymbolStore System.Byte
---@param securityEvidence System.Security.Policy.Evidence
---@return System.Reflection.Assembly
function m:Load(rawAssembly, rawSymbolStore, securityEvidence) end
---@param domainPolicy System.Security.Policy.PolicyLevel
function m:SetAppDomainPolicy(domainPolicy) end
---@param policy System.Security.Principal.PrincipalPolicy
function m:SetPrincipalPolicy(policy) end
---@param principal System.Security.Principal.IPrincipal
function m:SetThreadPrincipal(principal) end
---@return System.Boolean
function m:IsFinalizingForUnload() end
---@param name System.String
---@param data System.Object
function m:SetData(name, data) end
---@param name System.String
---@param data System.Object
---@param permission System.Security.IPermission
function m:SetData(name, data, permission) end
---@return System.String
function m:ToString() end
---@param assemblyName System.String
---@return System.String
function m:ApplyPolicy(assemblyName) end
---@param assemblyName System.String
---@return System.Int32
function m:ExecuteAssemblyByName(assemblyName) end
---@param assemblyName System.String
---@param assemblySecurity System.Security.Policy.Evidence
---@return System.Int32
function m:ExecuteAssemblyByName(assemblyName, assemblySecurity) end
---@param assemblyName System.String
---@param assemblySecurity System.Security.Policy.Evidence
---@param args System.String
---@return System.Int32
function m:ExecuteAssemblyByName(assemblyName, assemblySecurity, args) end
---@param assemblyName System.Reflection.AssemblyName
---@param assemblySecurity System.Security.Policy.Evidence
---@param args System.String
---@return System.Int32
function m:ExecuteAssemblyByName(assemblyName, assemblySecurity, args) end
---@return System.Boolean
function m:IsDefaultAppDomain() end
---@return System.Reflection.Assembly
function m:ReflectionOnlyGetAssemblies() end
System.AppDomain=m
return m;