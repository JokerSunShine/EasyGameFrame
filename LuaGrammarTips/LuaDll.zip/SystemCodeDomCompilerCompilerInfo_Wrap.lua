---@class System.CodeDom.Compiler.CompilerInfo
---instance properties
---@field public CodeDomProviderType System.Type
---@field public IsCodeDomProviderTypeValid System.Boolean
local m = {};

---@return System.CodeDom.Compiler.CompilerParameters
function m:CreateDefaultCompilerParameters() end
---@return System.CodeDom.Compiler.CodeDomProvider
function m:CreateProvider() end
---@param o System.Object
---@return System.Boolean
function m:Equals(o) end
---@return System.Int32
function m:GetHashCode() end
---@return System.String
function m:GetExtensions() end
---@return System.String
function m:GetLanguages() end
System.CodeDom.Compiler.CompilerInfo=m
return m;