---@class System.CodeDom.CodeEntryPointMethod : System.CodeDom.CodeMemberMethod
local m = {};

System.CodeDom.CodeEntryPointMethod=m
return m;