---@class System.ComponentModel.Design.DesigntimeLicenseContextSerializer
local m = {};
---@param o System.IO.Stream
---@param cryptoKey System.String
---@param context System.ComponentModel.Design.DesigntimeLicenseContext
function m.Serialize(o, cryptoKey, context) end

System.ComponentModel.Design.DesigntimeLicenseContextSerializer=m
return m;