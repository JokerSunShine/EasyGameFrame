---@class System.ComponentModel.Design.IDesignerOptionService
local m = {};

---@param pageName System.String
---@param valueName System.String
---@return System.Object
function m:GetOptionValue(pageName, valueName) end
---@param pageName System.String
---@param valueName System.String
---@param value System.Object
function m:SetOptionValue(pageName, valueName, value) end
System.ComponentModel.Design.IDesignerOptionService=m
return m;