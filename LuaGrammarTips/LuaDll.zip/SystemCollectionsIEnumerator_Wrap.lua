---@class System.Collections.IEnumerator
---instance properties
---@field public Current System.Object
local m = {};

---@return System.Boolean
function m:MoveNext() end
function m:Reset() end
System.Collections.IEnumerator=m
return m;