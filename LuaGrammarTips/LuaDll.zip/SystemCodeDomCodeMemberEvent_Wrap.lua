---@class System.CodeDom.CodeMemberEvent : System.CodeDom.CodeTypeMember
---instance properties
---@field public ImplementationTypes System.CodeDom.CodeTypeReferenceCollection
---@field public PrivateImplementationType System.CodeDom.CodeTypeReference
---@field public Type System.CodeDom.CodeTypeReference
local m = {};

System.CodeDom.CodeMemberEvent=m
return m;