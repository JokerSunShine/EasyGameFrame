---@class System.Collections.Generic.SortedDictionary2EnumeratorTKeyTValue : System.ValueType
---instance properties
---@field public Current System.Collections.Generic.KeyValuePair2TKeyTValue
local m = {};

---@return System.Boolean
function m:MoveNext() end
function m:Dispose() end
System.Collections.Generic.SortedDictionary2EnumeratorTKeyTValue=m
return m;