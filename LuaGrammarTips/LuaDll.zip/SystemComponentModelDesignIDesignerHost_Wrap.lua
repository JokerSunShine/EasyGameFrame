---@class System.ComponentModel.Design.IDesignerHost
---instance properties
---@field public Container System.ComponentModel.IContainer
---@field public InTransaction System.Boolean
---@field public Loading System.Boolean
---@field public RootComponent System.ComponentModel.IComponent
---@field public RootComponentClassName System.String
---@field public TransactionDescription System.String
local m = {};

---@param value System.EventHandler
function m:add_Activated(value) end
---@param value System.EventHandler
function m:remove_Activated(value) end
---@param value System.EventHandler
function m:add_Deactivated(value) end
---@param value System.EventHandler
function m:remove_Deactivated(value) end
---@param value System.EventHandler
function m:add_LoadComplete(value) end
---@param value System.EventHandler
function m:remove_LoadComplete(value) end
---@param value System.ComponentModel.Design.DesignerTransactionCloseEventHandler
function m:add_TransactionClosed(value) end
---@param value System.ComponentModel.Design.DesignerTransactionCloseEventHandler
function m:remove_TransactionClosed(value) end
---@param value System.ComponentModel.Design.DesignerTransactionCloseEventHandler
function m:add_TransactionClosing(value) end
---@param value System.ComponentModel.Design.DesignerTransactionCloseEventHandler
function m:remove_TransactionClosing(value) end
---@param value System.EventHandler
function m:add_TransactionOpened(value) end
---@param value System.EventHandler
function m:remove_TransactionOpened(value) end
---@param value System.EventHandler
function m:add_TransactionOpening(value) end
---@param value System.EventHandler
function m:remove_TransactionOpening(value) end
function m:Activate() end
---@param componentClass System.Type
---@return System.ComponentModel.IComponent
function m:CreateComponent(componentClass) end
---@param componentClass System.Type
---@param name System.String
---@return System.ComponentModel.IComponent
function m:CreateComponent(componentClass, name) end
---@return System.ComponentModel.Design.DesignerTransaction
function m:CreateTransaction() end
---@param description System.String
---@return System.ComponentModel.Design.DesignerTransaction
function m:CreateTransaction(description) end
---@param component System.ComponentModel.IComponent
function m:DestroyComponent(component) end
---@param component System.ComponentModel.IComponent
---@return System.ComponentModel.Design.IDesigner
function m:GetDesigner(component) end
---@param typeName System.String
---@return System.Type
function m:GetType(typeName) end
System.ComponentModel.Design.IDesignerHost=m
return m;