---@class System.ComponentModel.ContainerFilterService
local m = {};

---@param components System.ComponentModel.ComponentCollection
---@return System.ComponentModel.ComponentCollection
function m:FilterComponents(components) end
System.ComponentModel.ContainerFilterService=m
return m;