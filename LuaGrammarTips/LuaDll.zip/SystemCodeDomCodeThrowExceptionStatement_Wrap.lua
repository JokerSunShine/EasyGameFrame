---@class System.CodeDom.CodeThrowExceptionStatement : System.CodeDom.CodeStatement
---instance properties
---@field public ToThrow System.CodeDom.CodeExpression
local m = {};

System.CodeDom.CodeThrowExceptionStatement=m
return m;