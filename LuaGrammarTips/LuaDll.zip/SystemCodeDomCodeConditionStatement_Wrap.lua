---@class System.CodeDom.CodeConditionStatement : System.CodeDom.CodeStatement
---instance properties
---@field public Condition System.CodeDom.CodeExpression
---@field public FalseStatements System.CodeDom.CodeStatementCollection
---@field public TrueStatements System.CodeDom.CodeStatementCollection
local m = {};

System.CodeDom.CodeConditionStatement=m
return m;