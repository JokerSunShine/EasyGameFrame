---@class System.CodeDom.CodeTypeReference : System.CodeDom.CodeObject
---instance properties
---@field public ArrayElementType System.CodeDom.CodeTypeReference
---@field public ArrayRank System.Int32
---@field public BaseType System.String
---@field public Options System.CodeDom.CodeTypeReferenceOptions
---@field public TypeArguments System.CodeDom.CodeTypeReferenceCollection
local m = {};

System.CodeDom.CodeTypeReference=m
return m;