---@class System.ComponentModel.NestedContainer : System.ComponentModel.Container
---instance properties
---@field public Owner System.ComponentModel.IComponent
local m = {};

System.ComponentModel.NestedContainer=m
return m;