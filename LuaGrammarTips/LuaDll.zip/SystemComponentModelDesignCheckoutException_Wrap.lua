---@class System.ComponentModel.Design.CheckoutException : System.Runtime.InteropServices.ExternalException
---fields
---@field public Canceled System.ComponentModel.Design.CheckoutException
local m = {};

System.ComponentModel.Design.CheckoutException=m
return m;