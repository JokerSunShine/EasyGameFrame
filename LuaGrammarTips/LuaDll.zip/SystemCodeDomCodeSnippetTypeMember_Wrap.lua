---@class System.CodeDom.CodeSnippetTypeMember : System.CodeDom.CodeTypeMember
---instance properties
---@field public Text System.String
local m = {};

System.CodeDom.CodeSnippetTypeMember=m
return m;