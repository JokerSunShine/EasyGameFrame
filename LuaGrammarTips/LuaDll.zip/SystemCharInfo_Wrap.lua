---@class System.CharInfo : System.ValueType
---instance fields
---@field public Character System.Char
---@field public Attributes System.Int16
local m = {};

System.CharInfo=m
return m;