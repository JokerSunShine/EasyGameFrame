---@class System.ComponentModel.Design.IMenuCommandService
---instance properties
---@field public Verbs System.ComponentModel.Design.DesignerVerbCollection
local m = {};

---@param command System.ComponentModel.Design.MenuCommand
function m:AddCommand(command) end
---@param verb System.ComponentModel.Design.DesignerVerb
function m:AddVerb(verb) end
---@param commandID System.ComponentModel.Design.CommandID
---@return System.ComponentModel.Design.MenuCommand
function m:FindCommand(commandID) end
---@param commandID System.ComponentModel.Design.CommandID
---@return System.Boolean
function m:GlobalInvoke(commandID) end
---@param command System.ComponentModel.Design.MenuCommand
function m:RemoveCommand(command) end
---@param verb System.ComponentModel.Design.DesignerVerb
function m:RemoveVerb(verb) end
---@param menuID System.ComponentModel.Design.CommandID
---@param x System.Int32
---@param y System.Int32
function m:ShowContextMenu(menuID, x, y) end
System.ComponentModel.Design.IMenuCommandService=m
return m;