---@class System.ComponentModel.ContainerDefaultSite
---instance properties
---@field public Component System.ComponentModel.IComponent
---@field public Container System.ComponentModel.IContainer
---@field public DesignMode System.Boolean
---@field public Name System.String
local m = {};

---@param t System.Type
---@return System.Object
function m:GetService(t) end
System.ComponentModel.ContainerDefaultSite=m
return m;