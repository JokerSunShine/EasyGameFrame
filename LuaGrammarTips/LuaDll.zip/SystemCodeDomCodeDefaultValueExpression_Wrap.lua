---@class System.CodeDom.CodeDefaultValueExpression : System.CodeDom.CodeExpression
---instance properties
---@field public Type System.CodeDom.CodeTypeReference
local m = {};

System.CodeDom.CodeDefaultValueExpression=m
return m;