---@class System.ComponentModel.MaskedTextProviderEditPosition
---instance fields
---@field public Parent System.ComponentModel.MaskedTextProvider
---@field public Type System.ComponentModel.MaskedTextProviderEditType
---@field public State System.ComponentModel.MaskedTextProviderEditState
---@field public MaskCharacter System.Char
---@field public input System.Char
---instance properties
---@field public Input System.Char
---@field public FilledIn System.Boolean
---@field public Required System.Boolean
---@field public Editable System.Boolean
---@field public Visible System.Boolean
---@field public Text System.String
local m = {};

function m:Reset() end
---@param c System.Char
---@return System.Boolean
function m:IsAscii(c) end
---@param c System.Char
---@param resultHint System.ComponentModel.MaskedTextResultHint @out
---@param only_test System.Boolean
---@return System.Boolean
function m:Match(c, resultHint, only_test) end
System.ComponentModel.MaskedTextProviderEditPosition=m
return m;