---@class System.CodeDom.Compiler.CompilerProviderOptionsCollection : System.Configuration.ConfigurationElementCollection
---instance properties
---@field public AllKeys System.String
---@field public ProviderOptions System.Collections.Generic.Dictionary2System.StringSystem.String
---@field public Item System.CodeDom.Compiler.CompilerProviderOption
---@field public Item System.CodeDom.Compiler.CompilerProviderOption
local m = {};

---@param index System.Int32
---@return System.CodeDom.Compiler.CompilerProviderOption
function m:Get(index) end
---@param name System.String
---@return System.CodeDom.Compiler.CompilerProviderOption
function m:Get(name) end
---@param index System.Int32
---@return System.String
function m:GetKey(index) end
System.CodeDom.Compiler.CompilerProviderOptionsCollection=m
return m;