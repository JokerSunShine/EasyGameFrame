---@class System.Collections.Generic.RBTreeINodeHelper1T
local m = {};

---@param key T
---@param node System.Collections.Generic.RBTreeNode
---@return System.Int32
function m:Compare(key, node) end
---@param key T
---@return System.Collections.Generic.RBTreeNode
function m:CreateNode(key) end
System.Collections.Generic.RBTreeINodeHelper1T=m
return m;