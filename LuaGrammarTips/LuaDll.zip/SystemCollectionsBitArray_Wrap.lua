---@class System.Collections.BitArray
---instance properties
---@field public Count System.Int32
---@field public IsReadOnly System.Boolean
---@field public IsSynchronized System.Boolean
---@field public Item System.Boolean
---@field public Length System.Int32
---@field public SyncRoot System.Object
local m = {};

---@return System.Object
function m:Clone() end
---@param array System.Array
---@param index System.Int32
function m:CopyTo(array, index) end
---@return System.Collections.BitArray
function m:Not() end
---@param value System.Collections.BitArray
---@return System.Collections.BitArray
function m:And(value) end
---@param value System.Collections.BitArray
---@return System.Collections.BitArray
function m:Or(value) end
---@param value System.Collections.BitArray
---@return System.Collections.BitArray
function m:Xor(value) end
---@param index System.Int32
---@return System.Boolean
function m:Get(index) end
---@param index System.Int32
---@param value System.Boolean
function m:Set(index, value) end
---@param value System.Boolean
function m:SetAll(value) end
---@return System.Collections.IEnumerator
function m:GetEnumerator() end
System.Collections.BitArray=m
return m;