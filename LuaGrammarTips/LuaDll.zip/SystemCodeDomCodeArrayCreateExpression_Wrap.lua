---@class System.CodeDom.CodeArrayCreateExpression : System.CodeDom.CodeExpression
---instance properties
---@field public CreateType System.CodeDom.CodeTypeReference
---@field public Initializers System.CodeDom.CodeExpressionCollection
---@field public SizeExpression System.CodeDom.CodeExpression
---@field public Size System.Int32
local m = {};

System.CodeDom.CodeArrayCreateExpression=m
return m;