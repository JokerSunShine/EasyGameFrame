---@class System.ComponentModel.LicenseException : System.SystemException
---instance properties
---@field public LicensedType System.Type
local m = {};

---@param info System.Runtime.Serialization.SerializationInfo
---@param context System.Runtime.Serialization.StreamingContext
function m:GetObjectData(info, context) end
System.ComponentModel.LicenseException=m
return m;