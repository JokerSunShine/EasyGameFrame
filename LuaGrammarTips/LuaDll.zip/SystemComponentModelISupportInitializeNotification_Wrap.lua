---@class System.ComponentModel.ISupportInitializeNotification
---instance properties
---@field public IsInitialized System.Boolean
local m = {};

---@param value System.EventHandler
function m:add_Initialized(value) end
---@param value System.EventHandler
function m:remove_Initialized(value) end
System.ComponentModel.ISupportInitializeNotification=m
return m;