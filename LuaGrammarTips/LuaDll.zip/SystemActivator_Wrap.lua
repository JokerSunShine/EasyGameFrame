---@class System.Activator
local m = {};
---@param assemblyName System.String
---@param typeName System.String
---@return System.Runtime.Remoting.ObjectHandle
function m.CreateComInstanceFrom(assemblyName, typeName) end
---@param assemblyName System.String
---@param typeName System.String
---@param hashValue System.Byte
---@param hashAlgorithm System.Configuration.Assemblies.AssemblyHashAlgorithm
---@return System.Runtime.Remoting.ObjectHandle
function m.CreateComInstanceFrom(assemblyName, typeName, hashValue, hashAlgorithm) end
---@param assemblyFile System.String
---@param typeName System.String
---@return System.Runtime.Remoting.ObjectHandle
function m.CreateInstanceFrom(assemblyFile, typeName) end
---@param assemblyFile System.String
---@param typeName System.String
---@param activationAttributes System.Object
---@return System.Runtime.Remoting.ObjectHandle
function m.CreateInstanceFrom(assemblyFile, typeName, activationAttributes) end
---@param assemblyFile System.String
---@param typeName System.String
---@param ignoreCase System.Boolean
---@param bindingAttr System.Reflection.BindingFlags
---@param binder System.Reflection.Binder
---@param args System.Object
---@param culture System.Globalization.CultureInfo
---@param activationAttributes System.Object
---@param securityInfo System.Security.Policy.Evidence
---@return System.Runtime.Remoting.ObjectHandle
function m.CreateInstanceFrom(assemblyFile, typeName, ignoreCase, bindingAttr, binder, args, culture, activationAttributes, securityInfo) end
---@param assemblyName System.String
---@param typeName System.String
---@return System.Runtime.Remoting.ObjectHandle
function m.CreateInstance(assemblyName, typeName) end
---@param assemblyName System.String
---@param typeName System.String
---@param activationAttributes System.Object
---@return System.Runtime.Remoting.ObjectHandle
function m.CreateInstance(assemblyName, typeName, activationAttributes) end
---@param assemblyName System.String
---@param typeName System.String
---@param ignoreCase System.Boolean
---@param bindingAttr System.Reflection.BindingFlags
---@param binder System.Reflection.Binder
---@param args System.Object
---@param culture System.Globalization.CultureInfo
---@param activationAttributes System.Object
---@param securityInfo System.Security.Policy.Evidence
---@return System.Runtime.Remoting.ObjectHandle
function m.CreateInstance(assemblyName, typeName, ignoreCase, bindingAttr, binder, args, culture, activationAttributes, securityInfo) end
---@param activationContext System.ActivationContext
---@return System.Runtime.Remoting.ObjectHandle
function m.CreateInstance(activationContext) end
---@param activationContext System.ActivationContext
---@param activationCustomData System.String
---@return System.Runtime.Remoting.ObjectHandle
function m.CreateInstance(activationContext, activationCustomData) end
---@param domain System.AppDomain
---@param assemblyFile System.String
---@param typeName System.String
---@return System.Runtime.Remoting.ObjectHandle
function m.CreateInstanceFrom(domain, assemblyFile, typeName) end
---@param domain System.AppDomain
---@param assemblyFile System.String
---@param typeName System.String
---@param ignoreCase System.Boolean
---@param bindingAttr System.Reflection.BindingFlags
---@param binder System.Reflection.Binder
---@param args System.Object
---@param culture System.Globalization.CultureInfo
---@param activationAttributes System.Object
---@param securityAttributes System.Security.Policy.Evidence
---@return System.Runtime.Remoting.ObjectHandle
function m.CreateInstanceFrom(domain, assemblyFile, typeName, ignoreCase, bindingAttr, binder, args, culture, activationAttributes, securityAttributes) end
---@param domain System.AppDomain
---@param assemblyName System.String
---@param typeName System.String
---@return System.Runtime.Remoting.ObjectHandle
function m.CreateInstance(domain, assemblyName, typeName) end
---@param domain System.AppDomain
---@param assemblyName System.String
---@param typeName System.String
---@param ignoreCase System.Boolean
---@param bindingAttr System.Reflection.BindingFlags
---@param binder System.Reflection.Binder
---@param args System.Object
---@param culture System.Globalization.CultureInfo
---@param activationAttributes System.Object
---@param securityAttributes System.Security.Policy.Evidence
---@return System.Runtime.Remoting.ObjectHandle
function m.CreateInstance(domain, assemblyName, typeName, ignoreCase, bindingAttr, binder, args, culture, activationAttributes, securityAttributes) end
---@param type System.Type
---@return System.Object
function m.CreateInstance(type) end
---@param type System.Type
---@param args System.Object
---@return System.Object
function m.CreateInstance(type, args) end
---@param type System.Type
---@param args System.Object
---@param activationAttributes System.Object
---@return System.Object
function m.CreateInstance(type, args, activationAttributes) end
---@param type System.Type
---@param bindingAttr System.Reflection.BindingFlags
---@param binder System.Reflection.Binder
---@param args System.Object
---@param culture System.Globalization.CultureInfo
---@return System.Object
function m.CreateInstance(type, bindingAttr, binder, args, culture) end
---@param type System.Type
---@param bindingAttr System.Reflection.BindingFlags
---@param binder System.Reflection.Binder
---@param args System.Object
---@param culture System.Globalization.CultureInfo
---@param activationAttributes System.Object
---@return System.Object
function m.CreateInstance(type, bindingAttr, binder, args, culture, activationAttributes) end
---@param type System.Type
---@param nonPublic System.Boolean
---@return System.Object
function m.CreateInstance(type, nonPublic) end
---@param type System.Type
---@param url System.String
---@return System.Object
function m.GetObject(type, url) end
---@param type System.Type
---@param url System.String
---@param state System.Object
---@return System.Object
function m.GetObject(type, url, state) end

System.Activator=m
return m;