---@class System.CodeDom.CodeMemberMethod : System.CodeDom.CodeTypeMember
---instance properties
---@field public ImplementationTypes System.CodeDom.CodeTypeReferenceCollection
---@field public Parameters System.CodeDom.CodeParameterDeclarationExpressionCollection
---@field public PrivateImplementationType System.CodeDom.CodeTypeReference
---@field public ReturnType System.CodeDom.CodeTypeReference
---@field public Statements System.CodeDom.CodeStatementCollection
---@field public ReturnTypeCustomAttributes System.CodeDom.CodeAttributeDeclarationCollection
---@field public TypeParameters System.CodeDom.CodeTypeParameterCollection
local m = {};

---@param value System.EventHandler
function m:add_PopulateImplementationTypes(value) end
---@param value System.EventHandler
function m:remove_PopulateImplementationTypes(value) end
---@param value System.EventHandler
function m:add_PopulateParameters(value) end
---@param value System.EventHandler
function m:remove_PopulateParameters(value) end
---@param value System.EventHandler
function m:add_PopulateStatements(value) end
---@param value System.EventHandler
function m:remove_PopulateStatements(value) end
System.CodeDom.CodeMemberMethod=m
return m;