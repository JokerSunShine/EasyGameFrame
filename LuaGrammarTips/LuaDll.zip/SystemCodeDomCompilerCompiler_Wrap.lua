---@class System.CodeDom.Compiler.Compiler : System.Configuration.ConfigurationElement
---instance properties
---@field public CompilerOptions System.String
---@field public Extension System.String
---@field public Language System.String
---@field public Type System.String
---@field public WarningLevel System.Int32
---@field public ProviderOptions System.CodeDom.Compiler.CompilerProviderOptionsCollection
---@field public ProviderOptionsDictionary System.Collections.Generic.Dictionary2System.StringSystem.String
local m = {};

System.CodeDom.Compiler.Compiler=m
return m;