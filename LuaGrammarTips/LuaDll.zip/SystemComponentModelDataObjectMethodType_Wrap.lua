---@class System.ComponentModel.DataObjectMethodType
---@field Fill @0
---@field Select @1
---@field Update @2
---@field Insert @3
---@field Delete @4
local m = {};
System.ComponentModel.DataObjectMethodType=m
return m;