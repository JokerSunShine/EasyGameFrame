---@class System.Collections.Specialized.NameObjectCollectionBase_KeysEnumerator
---instance properties
---@field public Current System.Object
local m = {};

---@return System.Boolean
function m:MoveNext() end
function m:Reset() end
System.Collections.Specialized.NameObjectCollectionBase_KeysEnumerator=m
return m;