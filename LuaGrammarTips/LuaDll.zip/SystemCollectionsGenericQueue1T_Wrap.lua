---@class System.Collections.Generic.Queue1T
---instance properties
---@field public Count System.Int32
local m = {};

function m:Clear() end
---@param item T
---@return System.Boolean
function m:Contains(item) end
---@param array T
---@param idx System.Int32
function m:CopyTo(array, idx) end
---@return T
function m:Dequeue() end
---@return T
function m:Peek() end
---@param item T
function m:Enqueue(item) end
---@return T
function m:ToArray() end
function m:TrimExcess() end
---@return System.Collections.Generic.Queue1EnumeratorT
function m:GetEnumerator() end
System.Collections.Generic.Queue1T=m
return m;