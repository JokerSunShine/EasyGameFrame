---@class System.ComponentModel.Design.IDesignerFilter
local m = {};

---@param attributes System.Collections.IDictionary
function m:PostFilterAttributes(attributes) end
---@param events System.Collections.IDictionary
function m:PostFilterEvents(events) end
---@param properties System.Collections.IDictionary
function m:PostFilterProperties(properties) end
---@param attributes System.Collections.IDictionary
function m:PreFilterAttributes(attributes) end
---@param events System.Collections.IDictionary
function m:PreFilterEvents(events) end
---@param properties System.Collections.IDictionary
function m:PreFilterProperties(properties) end
System.ComponentModel.Design.IDesignerFilter=m
return m;