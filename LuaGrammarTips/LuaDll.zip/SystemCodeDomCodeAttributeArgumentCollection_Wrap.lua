---@class System.CodeDom.CodeAttributeArgumentCollection : System.Collections.CollectionBase
---instance properties
---@field public Item System.CodeDom.CodeAttributeArgument
local m = {};

---@param value System.CodeDom.CodeAttributeArgument
---@return System.Int32
function m:Add(value) end
---@param value System.CodeDom.CodeAttributeArgument
function m:AddRange(value) end
---@param value System.CodeDom.CodeAttributeArgumentCollection
function m:AddRange(value) end
---@param value System.CodeDom.CodeAttributeArgument
---@return System.Boolean
function m:Contains(value) end
---@param array System.CodeDom.CodeAttributeArgument
---@param index System.Int32
function m:CopyTo(array, index) end
---@param value System.CodeDom.CodeAttributeArgument
---@return System.Int32
function m:IndexOf(value) end
---@param index System.Int32
---@param value System.CodeDom.CodeAttributeArgument
function m:Insert(index, value) end
---@param value System.CodeDom.CodeAttributeArgument
function m:Remove(value) end
System.CodeDom.CodeAttributeArgumentCollection=m
return m;