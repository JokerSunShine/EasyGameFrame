---@class System.ComponentModel.DoubleConverter : System.ComponentModel.BaseNumberConverter
local m = {};

System.ComponentModel.DoubleConverter=m
return m;