---@class System.ComponentModel.IExtenderProvider
local m = {};

---@param extendee System.Object
---@return System.Boolean
function m:CanExtend(extendee) end
System.ComponentModel.IExtenderProvider=m
return m;