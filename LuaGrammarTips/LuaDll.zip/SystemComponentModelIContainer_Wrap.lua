---@class System.ComponentModel.IContainer
---instance properties
---@field public Components System.ComponentModel.ComponentCollection
local m = {};

---@param component System.ComponentModel.IComponent
function m:Add(component) end
---@param component System.ComponentModel.IComponent
---@param name System.String
function m:Add(component, name) end
---@param component System.ComponentModel.IComponent
function m:Remove(component) end
System.ComponentModel.IContainer=m
return m;