---@class System.Action3T1T2T3 : System.MulticastDelegate
local m = {};

---@param arg1 T1
---@param arg2 T2
---@param arg3 T3
function m:Invoke(arg1, arg2, arg3) end
---@param arg1 T1
---@param arg2 T2
---@param arg3 T3
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(arg1, arg2, arg3, callback, object) end
---@param result System.IAsyncResult
function m:EndInvoke(result) end
System.Action3T1T2T3=m
return m;