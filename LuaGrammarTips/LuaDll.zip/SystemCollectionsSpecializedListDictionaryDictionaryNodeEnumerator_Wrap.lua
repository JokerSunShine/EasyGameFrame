---@class System.Collections.Specialized.ListDictionaryDictionaryNodeEnumerator
---instance properties
---@field public Current System.Object
---@field public Entry System.Collections.DictionaryEntry
---@field public Key System.Object
---@field public Value System.Object
local m = {};

---@return System.Boolean
function m:MoveNext() end
function m:Reset() end
System.Collections.Specialized.ListDictionaryDictionaryNodeEnumerator=m
return m;