---@class System.ComponentModel.Design.Serialization.MemberRelationship : System.ValueType
---fields
---@field public Empty System.ComponentModel.Design.Serialization.MemberRelationship
---instance properties
---@field public IsEmpty System.Boolean
---@field public Owner System.Object
---@field public Member System.ComponentModel.MemberDescriptor
local m = {};
---@param left System.ComponentModel.Design.Serialization.MemberRelationship
---@param right System.ComponentModel.Design.Serialization.MemberRelationship
---@return System.Boolean
function m.op_Equality(left, right) end
---@param left System.ComponentModel.Design.Serialization.MemberRelationship
---@param right System.ComponentModel.Design.Serialization.MemberRelationship
---@return System.Boolean
function m.op_Inequality(left, right) end

---@return System.Int32
function m:GetHashCode() end
---@param o System.Object
---@return System.Boolean
function m:Equals(o) end
System.ComponentModel.Design.Serialization.MemberRelationship=m
return m;