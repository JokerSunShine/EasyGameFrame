---@class System.ComponentModel.Design.RuntimeLicenseContext : System.ComponentModel.LicenseContext
local m = {};

---@param type System.Type
---@param resourceAssembly System.Reflection.Assembly
---@return System.String
function m:GetSavedLicenseKey(type, resourceAssembly) end
---@param type System.Type
---@param key System.String
function m:SetSavedLicenseKey(type, key) end
System.ComponentModel.Design.RuntimeLicenseContext=m
return m;