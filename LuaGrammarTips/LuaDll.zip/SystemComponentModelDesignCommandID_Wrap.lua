---@class System.ComponentModel.Design.CommandID
---instance properties
---@field public Guid System.Guid
---@field public ID System.Int32
local m = {};

---@param obj System.Object
---@return System.Boolean
function m:Equals(obj) end
---@return System.Int32
function m:GetHashCode() end
---@return System.String
function m:ToString() end
System.ComponentModel.Design.CommandID=m
return m;