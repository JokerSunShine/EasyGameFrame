---@class System.CodeDom.CodeAttributeDeclarationCollection : System.Collections.CollectionBase
---instance properties
---@field public Item System.CodeDom.CodeAttributeDeclaration
local m = {};

---@param value System.CodeDom.CodeAttributeDeclaration
---@return System.Int32
function m:Add(value) end
---@param value System.CodeDom.CodeAttributeDeclaration
function m:AddRange(value) end
---@param value System.CodeDom.CodeAttributeDeclarationCollection
function m:AddRange(value) end
---@param value System.CodeDom.CodeAttributeDeclaration
---@return System.Boolean
function m:Contains(value) end
---@param array System.CodeDom.CodeAttributeDeclaration
---@param index System.Int32
function m:CopyTo(array, index) end
---@param value System.CodeDom.CodeAttributeDeclaration
---@return System.Int32
function m:IndexOf(value) end
---@param index System.Int32
---@param value System.CodeDom.CodeAttributeDeclaration
function m:Insert(index, value) end
---@param value System.CodeDom.CodeAttributeDeclaration
function m:Remove(value) end
System.CodeDom.CodeAttributeDeclarationCollection=m
return m;