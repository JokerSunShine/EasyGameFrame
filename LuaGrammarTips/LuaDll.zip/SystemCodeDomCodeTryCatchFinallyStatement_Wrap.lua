---@class System.CodeDom.CodeTryCatchFinallyStatement : System.CodeDom.CodeStatement
---instance properties
---@field public FinallyStatements System.CodeDom.CodeStatementCollection
---@field public TryStatements System.CodeDom.CodeStatementCollection
---@field public CatchClauses System.CodeDom.CodeCatchClauseCollection
local m = {};

System.CodeDom.CodeTryCatchFinallyStatement=m
return m;