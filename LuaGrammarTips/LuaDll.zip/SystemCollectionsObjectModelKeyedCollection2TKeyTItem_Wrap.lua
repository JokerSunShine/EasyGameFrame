---@class System.Collections.ObjectModel.KeyedCollection2TKeyTItem : System.Collections.ObjectModel.Collection1TItem
---instance properties
---@field public Comparer System.Collections.Generic.IEqualityComparer1TKey
---@field public Item TItem
local m = {};

---@param key TKey
---@return System.Boolean
function m:Contains(key) end
---@param key TKey
---@return System.Boolean
function m:Remove(key) end
System.Collections.ObjectModel.KeyedCollection2TKeyTItem=m
return m;