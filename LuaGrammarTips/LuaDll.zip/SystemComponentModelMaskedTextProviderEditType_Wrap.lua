---@class System.ComponentModel.MaskedTextProviderEditType
---@field DigitRequired @0
---@field DigitOrSpaceOptional @1
---@field DigitOrSpaceOptional_Blank @2
---@field LetterRequired @3
---@field LetterOptional @4
---@field CharacterRequired @5
---@field CharacterOptional @6
---@field AlphanumericRequired @7
---@field AlphanumericOptional @8
---@field DecimalPlaceholder @9
---@field ThousandsPlaceholder @10
---@field TimeSeparator @11
---@field DateSeparator @12
---@field CurrencySymbol @13
---@field Literal @14
local m = {};
System.ComponentModel.MaskedTextProviderEditType=m
return m;