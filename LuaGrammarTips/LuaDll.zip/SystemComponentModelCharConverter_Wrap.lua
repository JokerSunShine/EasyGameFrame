---@class System.ComponentModel.CharConverter : System.ComponentModel.TypeConverter
local m = {};

---@param context System.ComponentModel.ITypeDescriptorContext
---@param sourceType System.Type
---@return System.Boolean
function m:CanConvertFrom(context, sourceType) end
---@param context System.ComponentModel.ITypeDescriptorContext
---@param culture System.Globalization.CultureInfo
---@param value System.Object
---@return System.Object
function m:ConvertFrom(context, culture, value) end
---@param context System.ComponentModel.ITypeDescriptorContext
---@param culture System.Globalization.CultureInfo
---@param value System.Object
---@param destinationType System.Type
---@return System.Object
function m:ConvertTo(context, culture, value, destinationType) end
System.ComponentModel.CharConverter=m
return m;