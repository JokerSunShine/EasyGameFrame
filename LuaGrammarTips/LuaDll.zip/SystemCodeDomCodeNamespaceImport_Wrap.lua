---@class System.CodeDom.CodeNamespaceImport : System.CodeDom.CodeObject
---instance properties
---@field public LinePragma System.CodeDom.CodeLinePragma
---@field public Namespace System.String
local m = {};

System.CodeDom.CodeNamespaceImport=m
return m;