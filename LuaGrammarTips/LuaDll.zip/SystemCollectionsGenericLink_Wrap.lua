---@class System.Collections.Generic.Link : System.ValueType
---instance fields
---@field public HashCode System.Int32
---@field public Next System.Int32
local m = {};

System.Collections.Generic.Link=m
return m;