---@class System.Collections.Specialized.ProcessStringDictionary : System.Collections.Specialized.StringDictionary
---instance properties
---@field public Count System.Int32
---@field public IsSynchronized System.Boolean
---@field public Item System.String
---@field public Keys System.Collections.ICollection
---@field public Values System.Collections.ICollection
---@field public SyncRoot System.Object
local m = {};

---@param key System.String
---@param value System.String
function m:Add(key, value) end
function m:Clear() end
---@param key System.String
---@return System.Boolean
function m:ContainsKey(key) end
---@param value System.String
---@return System.Boolean
function m:ContainsValue(value) end
---@param array System.Array
---@param index System.Int32
function m:CopyTo(array, index) end
---@return System.Collections.IEnumerator
function m:GetEnumerator() end
---@param key System.String
function m:Remove(key) end
System.Collections.Specialized.ProcessStringDictionary=m
return m;