---@class System.ComponentModel.EventDescriptorCollection
---fields
---@field public Empty System.ComponentModel.EventDescriptorCollection
---instance properties
---@field public Count System.Int32
---@field public Item System.ComponentModel.EventDescriptor
---@field public Item System.ComponentModel.EventDescriptor
local m = {};

---@param value System.ComponentModel.EventDescriptor
---@return System.Int32
function m:Add(value) end
function m:Clear() end
---@param value System.ComponentModel.EventDescriptor
---@return System.Boolean
function m:Contains(value) end
---@param name System.String
---@param ignoreCase System.Boolean
---@return System.ComponentModel.EventDescriptor
function m:Find(name, ignoreCase) end
---@return System.Collections.IEnumerator
function m:GetEnumerator() end
---@param value System.ComponentModel.EventDescriptor
---@return System.Int32
function m:IndexOf(value) end
---@param index System.Int32
---@param value System.ComponentModel.EventDescriptor
function m:Insert(index, value) end
---@param value System.ComponentModel.EventDescriptor
function m:Remove(value) end
---@param index System.Int32
function m:RemoveAt(index) end
---@return System.ComponentModel.EventDescriptorCollection
function m:Sort() end
---@param comparer System.Collections.IComparer
---@return System.ComponentModel.EventDescriptorCollection
function m:Sort(comparer) end
---@param order System.String
---@return System.ComponentModel.EventDescriptorCollection
function m:Sort(order) end
---@param order System.String
---@param comparer System.Collections.IComparer
---@return System.ComponentModel.EventDescriptorCollection
function m:Sort(order, comparer) end
System.ComponentModel.EventDescriptorCollection=m
return m;