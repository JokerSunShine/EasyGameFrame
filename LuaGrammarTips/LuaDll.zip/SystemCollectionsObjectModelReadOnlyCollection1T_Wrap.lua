---@class System.Collections.ObjectModel.ReadOnlyCollection1T
---instance properties
---@field public Count System.Int32
---@field public Item T
local m = {};

---@param value T
---@return System.Boolean
function m:Contains(value) end
---@param array T
---@param index System.Int32
function m:CopyTo(array, index) end
---@return System.Collections.Generic.IEnumerator1T
function m:GetEnumerator() end
---@param value T
---@return System.Int32
function m:IndexOf(value) end
System.Collections.ObjectModel.ReadOnlyCollection1T=m
return m;