---@class System.ComponentModel.BindingDirection
---@field OneWay @0
---@field TwoWay @1
local m = {};
System.ComponentModel.BindingDirection=m
return m;