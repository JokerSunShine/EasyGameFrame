---@class System.ComponentModel.Design.Serialization.MemberRelationshipServiceMemberRelationshipWeakEntry
---instance properties
---@field public Owner System.Object
---@field public Member System.ComponentModel.MemberDescriptor
local m = {};
---@param left System.ComponentModel.Design.Serialization.MemberRelationshipServiceMemberRelationshipWeakEntry
---@param right System.ComponentModel.Design.Serialization.MemberRelationshipServiceMemberRelationshipWeakEntry
---@return System.Boolean
function m.op_Equality(left, right) end
---@param left System.ComponentModel.Design.Serialization.MemberRelationshipServiceMemberRelationshipWeakEntry
---@param right System.ComponentModel.Design.Serialization.MemberRelationshipServiceMemberRelationshipWeakEntry
---@return System.Boolean
function m.op_Inequality(left, right) end

---@return System.Int32
function m:GetHashCode() end
---@param o System.Object
---@return System.Boolean
function m:Equals(o) end
System.ComponentModel.Design.Serialization.MemberRelationshipServiceMemberRelationshipWeakEntry=m
return m;