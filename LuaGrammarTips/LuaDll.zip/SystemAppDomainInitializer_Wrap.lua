---@class System.AppDomainInitializer : System.MulticastDelegate
local m = {};

---@param args System.String
function m:Invoke(args) end
---@param args System.String
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(args, callback, object) end
---@param result System.IAsyncResult
function m:EndInvoke(result) end
System.AppDomainInitializer=m
return m;