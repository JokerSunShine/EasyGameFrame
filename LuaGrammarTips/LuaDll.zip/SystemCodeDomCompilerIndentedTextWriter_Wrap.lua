---@class System.CodeDom.Compiler.IndentedTextWriter : System.IO.TextWriter
---fields
---@field public DefaultTabString System.String
---instance properties
---@field public Encoding System.Text.Encoding
---@field public Indent System.Int32
---@field public InnerWriter System.IO.TextWriter
---@field public NewLine System.String
local m = {};

function m:Close() end
function m:Flush() end
---@param value System.Boolean
function m:Write(value) end
---@param value System.Char
function m:Write(value) end
---@param value System.Char
function m:Write(value) end
---@param value System.Double
function m:Write(value) end
---@param value System.Int32
function m:Write(value) end
---@param value System.Int64
function m:Write(value) end
---@param value System.Object
function m:Write(value) end
---@param value System.Single
function m:Write(value) end
---@param value System.String
function m:Write(value) end
---@param format System.String
---@param arg System.Object
function m:Write(format, arg) end
---@param format System.String
---@param args System.Object
function m:Write(format, args) end
---@param buffer System.Char
---@param index System.Int32
---@param count System.Int32
function m:Write(buffer, index, count) end
---@param format System.String
---@param arg0 System.Object
---@param arg1 System.Object
function m:Write(format, arg0, arg1) end
function m:WriteLine() end
---@param value System.Boolean
function m:WriteLine(value) end
---@param value System.Char
function m:WriteLine(value) end
---@param value System.Char
function m:WriteLine(value) end
---@param value System.Double
function m:WriteLine(value) end
---@param value System.Int32
function m:WriteLine(value) end
---@param value System.Int64
function m:WriteLine(value) end
---@param value System.Object
function m:WriteLine(value) end
---@param value System.Single
function m:WriteLine(value) end
---@param value System.String
function m:WriteLine(value) end
---@param value System.UInt32
function m:WriteLine(value) end
---@param format System.String
---@param arg System.Object
function m:WriteLine(format, arg) end
---@param format System.String
---@param args System.Object
function m:WriteLine(format, args) end
---@param buffer System.Char
---@param index System.Int32
---@param count System.Int32
function m:WriteLine(buffer, index, count) end
---@param format System.String
---@param arg0 System.Object
---@param arg1 System.Object
function m:WriteLine(format, arg0, arg1) end
---@param value System.String
function m:WriteLineNoTabs(value) end
System.CodeDom.Compiler.IndentedTextWriter=m
return m;