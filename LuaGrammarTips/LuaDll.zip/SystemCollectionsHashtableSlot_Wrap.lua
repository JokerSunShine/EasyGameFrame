---@class System.Collections.HashtableSlot : System.ValueType
local m = {};

System.Collections.HashtableSlot=m
return m;