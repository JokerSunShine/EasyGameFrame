---@class System.CodeDom.Compiler.CodeDomProvider : System.ComponentModel.Component
---instance properties
---@field public FileExtension System.String
---@field public LanguageOptions System.CodeDom.Compiler.LanguageOptions
local m = {};
---@param language System.String
---@return System.CodeDom.Compiler.CodeDomProvider
function m.CreateProvider(language) end
---@return System.CodeDom.Compiler.CompilerInfo
function m.GetAllCompilerInfo() end
---@param language System.String
---@return System.CodeDom.Compiler.CompilerInfo
function m.GetCompilerInfo(language) end
---@param extension System.String
---@return System.String
function m.GetLanguageFromExtension(extension) end
---@param extension System.String
---@return System.Boolean
function m.IsDefinedExtension(extension) end
---@param language System.String
---@return System.Boolean
function m.IsDefinedLanguage(language) end

---@param fileName System.String
---@return System.CodeDom.Compiler.ICodeGenerator
function m:CreateGenerator(fileName) end
---@param output System.IO.TextWriter
---@return System.CodeDom.Compiler.ICodeGenerator
function m:CreateGenerator(output) end
---@param type System.Type
---@return System.ComponentModel.TypeConverter
function m:GetConverter(type) end
---@param options System.CodeDom.Compiler.CompilerParameters
---@param compilationUnits System.CodeDom.CodeCompileUnit
---@return System.CodeDom.Compiler.CompilerResults
function m:CompileAssemblyFromDom(options, compilationUnits) end
---@param options System.CodeDom.Compiler.CompilerParameters
---@param fileNames System.String
---@return System.CodeDom.Compiler.CompilerResults
function m:CompileAssemblyFromFile(options, fileNames) end
---@param options System.CodeDom.Compiler.CompilerParameters
---@param fileNames System.String
---@return System.CodeDom.Compiler.CompilerResults
function m:CompileAssemblyFromSource(options, fileNames) end
---@param value System.String
---@return System.String
function m:CreateEscapedIdentifier(value) end
---@param value System.String
---@return System.String
function m:CreateValidIdentifier(value) end
---@param compileUnit System.CodeDom.CodeCompileUnit
---@param writer System.IO.TextWriter
---@param options System.CodeDom.Compiler.CodeGeneratorOptions
function m:GenerateCodeFromCompileUnit(compileUnit, writer, options) end
---@param expression System.CodeDom.CodeExpression
---@param writer System.IO.TextWriter
---@param options System.CodeDom.Compiler.CodeGeneratorOptions
function m:GenerateCodeFromExpression(expression, writer, options) end
---@param member System.CodeDom.CodeTypeMember
---@param writer System.IO.TextWriter
---@param options System.CodeDom.Compiler.CodeGeneratorOptions
function m:GenerateCodeFromMember(member, writer, options) end
---@param codeNamespace System.CodeDom.CodeNamespace
---@param writer System.IO.TextWriter
---@param options System.CodeDom.Compiler.CodeGeneratorOptions
function m:GenerateCodeFromNamespace(codeNamespace, writer, options) end
---@param statement System.CodeDom.CodeStatement
---@param writer System.IO.TextWriter
---@param options System.CodeDom.Compiler.CodeGeneratorOptions
function m:GenerateCodeFromStatement(statement, writer, options) end
---@param codeType System.CodeDom.CodeTypeDeclaration
---@param writer System.IO.TextWriter
---@param options System.CodeDom.Compiler.CodeGeneratorOptions
function m:GenerateCodeFromType(codeType, writer, options) end
---@param type System.CodeDom.CodeTypeReference
---@return System.String
function m:GetTypeOutput(type) end
---@param value System.String
---@return System.Boolean
function m:IsValidIdentifier(value) end
---@param codeStream System.IO.TextReader
---@return System.CodeDom.CodeCompileUnit
function m:Parse(codeStream) end
---@param supports System.CodeDom.Compiler.GeneratorSupport
---@return System.Boolean
function m:Supports(supports) end
System.CodeDom.Compiler.CodeDomProvider=m
return m;