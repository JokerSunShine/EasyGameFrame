---@class System.ComponentModel.MaskedTextResultHint
---@field Unknown @0
---@field CharacterEscaped @1
---@field NoEffect @2
---@field SideEffect @3
---@field Success @4
---@field PositionOutOfRange @-55
---@field NonEditPosition @-54
---@field UnavailableEditPosition @-53
---@field PromptCharNotAllowed @-52
---@field InvalidInput @-51
---@field SignedDigitExpected @-5
---@field LetterExpected @-4
---@field DigitExpected @-3
---@field AlphanumericCharacterExpected @-2
---@field AsciiCharacterExpected @-1
local m = {};
System.ComponentModel.MaskedTextResultHint=m
return m;