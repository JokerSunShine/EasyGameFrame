---@class System.Collections.Generic.SortedDictionary2ValueCollectionEnumeratorTKeyTValue : System.ValueType
---instance properties
---@field public Current TValue
local m = {};

---@return System.Boolean
function m:MoveNext() end
function m:Dispose() end
System.Collections.Generic.SortedDictionary2ValueCollectionEnumeratorTKeyTValue=m
return m;