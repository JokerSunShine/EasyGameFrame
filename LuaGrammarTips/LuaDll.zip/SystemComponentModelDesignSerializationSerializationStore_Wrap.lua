---@class System.ComponentModel.Design.Serialization.SerializationStore
---instance properties
---@field public Errors System.Collections.ICollection
local m = {};

function m:Close() end
---@param stream System.IO.Stream
function m:Save(stream) end
System.ComponentModel.Design.Serialization.SerializationStore=m
return m;