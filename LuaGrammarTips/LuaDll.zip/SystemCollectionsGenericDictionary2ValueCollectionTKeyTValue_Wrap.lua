---@class System.Collections.Generic.Dictionary2ValueCollectionTKeyTValue
---instance properties
---@field public Count System.Int32
local m = {};

---@param array TValue
---@param index System.Int32
function m:CopyTo(array, index) end
---@return System.Collections.Generic.Dictionary2ValueCollectionEnumeratorTKeyTValue
function m:GetEnumerator() end
System.Collections.Generic.Dictionary2ValueCollectionTKeyTValue=m
return m;