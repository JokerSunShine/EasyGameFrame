---@class System.CodeDom.CodeMethodReturnStatement : System.CodeDom.CodeStatement
---instance properties
---@field public Expression System.CodeDom.CodeExpression
local m = {};

System.CodeDom.CodeMethodReturnStatement=m
return m;