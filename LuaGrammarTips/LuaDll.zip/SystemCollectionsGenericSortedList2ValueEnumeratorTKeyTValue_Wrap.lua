---@class System.Collections.Generic.SortedList2ValueEnumeratorTKeyTValue : System.ValueType
---instance properties
---@field public Current TValue
local m = {};

function m:Dispose() end
---@return System.Boolean
function m:MoveNext() end
System.Collections.Generic.SortedList2ValueEnumeratorTKeyTValue=m
return m;