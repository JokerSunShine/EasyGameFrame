---@class System.ComponentModel.Design.IEventBindingService
local m = {};

---@param component System.ComponentModel.IComponent
---@param e System.ComponentModel.EventDescriptor
---@return System.String
function m:CreateUniqueMethodName(component, e) end
---@param e System.ComponentModel.EventDescriptor
---@return System.Collections.ICollection
function m:GetCompatibleMethods(e) end
---@param property System.ComponentModel.PropertyDescriptor
---@return System.ComponentModel.EventDescriptor
function m:GetEvent(property) end
---@param events System.ComponentModel.EventDescriptorCollection
---@return System.ComponentModel.PropertyDescriptorCollection
function m:GetEventProperties(events) end
---@param e System.ComponentModel.EventDescriptor
---@return System.ComponentModel.PropertyDescriptor
function m:GetEventProperty(e) end
---@return System.Boolean
function m:ShowCode() end
---@param lineNumber System.Int32
---@return System.Boolean
function m:ShowCode(lineNumber) end
---@param component System.ComponentModel.IComponent
---@param e System.ComponentModel.EventDescriptor
---@return System.Boolean
function m:ShowCode(component, e) end
System.ComponentModel.Design.IEventBindingService=m
return m;