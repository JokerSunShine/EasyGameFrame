---@class System.Collections.Specialized.NameValueCollection : System.Collections.Specialized.NameObjectCollectionBase
---instance properties
---@field public AllKeys System.String
---@field public Item System.String
---@field public Item System.String
local m = {};

---@param c System.Collections.Specialized.NameValueCollection
function m:Add(c) end
---@param name System.String
---@param val System.String
function m:Add(name, val) end
function m:Clear() end
---@param dest System.Array
---@param index System.Int32
function m:CopyTo(dest, index) end
---@param index System.Int32
---@return System.String
function m:Get(index) end
---@param name System.String
---@return System.String
function m:Get(name) end
---@param index System.Int32
---@return System.String
function m:GetKey(index) end
---@param index System.Int32
---@return System.String
function m:GetValues(index) end
---@param name System.String
---@return System.String
function m:GetValues(name) end
---@return System.Boolean
function m:HasKeys() end
---@param name System.String
function m:Remove(name) end
---@param name System.String
---@param value System.String
function m:Set(name, value) end
System.Collections.Specialized.NameValueCollection=m
return m;