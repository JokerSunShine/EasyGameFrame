---@class System.Collections.Generic.CollectionDebuggerView1T
---instance properties
---@field public Items T
local m = {};

System.Collections.Generic.CollectionDebuggerView1T=m
return m;