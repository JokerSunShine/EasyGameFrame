---@class System.CodeDom.CodeIndexerExpression : System.CodeDom.CodeExpression
---instance properties
---@field public Indices System.CodeDom.CodeExpressionCollection
---@field public TargetObject System.CodeDom.CodeExpression
local m = {};

System.CodeDom.CodeIndexerExpression=m
return m;