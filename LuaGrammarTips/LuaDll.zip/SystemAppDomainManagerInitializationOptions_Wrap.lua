---@class System.AppDomainManagerInitializationOptions
---@field None @0
---@field RegisterWithHost @1
local m = {};
System.AppDomainManagerInitializationOptions=m
return m;