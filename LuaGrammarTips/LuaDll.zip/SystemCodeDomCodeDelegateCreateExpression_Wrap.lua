---@class System.CodeDom.CodeDelegateCreateExpression : System.CodeDom.CodeExpression
---instance properties
---@field public DelegateType System.CodeDom.CodeTypeReference
---@field public MethodName System.String
---@field public TargetObject System.CodeDom.CodeExpression
local m = {};

System.CodeDom.CodeDelegateCreateExpression=m
return m;