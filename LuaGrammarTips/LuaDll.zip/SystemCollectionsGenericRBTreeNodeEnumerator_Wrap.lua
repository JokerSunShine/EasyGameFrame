---@class System.Collections.Generic.RBTreeNodeEnumerator : System.ValueType
---instance properties
---@field public Current System.Collections.Generic.RBTreeNode
local m = {};

function m:Reset() end
---@return System.Boolean
function m:MoveNext() end
function m:Dispose() end
System.Collections.Generic.RBTreeNodeEnumerator=m
return m;