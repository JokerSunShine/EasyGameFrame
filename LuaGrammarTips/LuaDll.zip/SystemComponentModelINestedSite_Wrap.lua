---@class System.ComponentModel.INestedSite
---instance properties
---@field public FullName System.String
local m = {};

System.ComponentModel.INestedSite=m
return m;