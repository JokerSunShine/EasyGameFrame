---@class System.ComponentModel.IRaiseItemChangedEvents
---instance properties
---@field public RaisesItemChangedEvents System.Boolean
local m = {};

System.ComponentModel.IRaiseItemChangedEvents=m
return m;