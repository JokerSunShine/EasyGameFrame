---@class bagV2.RafflePreyTreasureBag
---instance properties
---@field public lid System.Int64
---@field public lidSpecified System.Boolean
local m = {};

bagV2.RafflePreyTreasureBag=m
return m;