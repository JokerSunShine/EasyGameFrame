---@class DataStructTreeBTreeBTreeBtreeNode1T : DataStructTreeBTreeBaseBTreeNodeBase1T
local m = {};
---@param data T
---@return DataStructTreeBTreeBaseBTreeNodeBase1T
function m:FindNode(data) end
---@param traversaList CommonOneWayChainListOneWayChainList1T
---@param action SystemAction1T @default_value:
function m:Traversal(traversaList, action) end
---@param data T
function m:InserData(data) end
---@param order SystemInt32
---@param isLeaf SystemBoolean
---@param compareFunc SystemFunc3TTSystemInt32
---@param tree DataStructTreeBTreeBaseBTreeBase1T
---@param count SystemInt32 @default_value:0
---@return DataStructTreeBTreeBaseBTreeNodeBase1T
function m:GetNewTreeNoe(order, isLeaf, compareFunc, tree, count) end
---@param data T
function m:DeleteData(data) end
---@param node DataStructTreeBTreeBTreeBtreeNode1T
---@return T
function m:FindPreDecessor(node) end
---@param node DataStructTreeBTreeBTreeBtreeNode1T
---@return T
function m:FindSuccessor(node) end
---@return SystemBoolean
function m:IsMinCount() end
---@return SystemBoolean
function m:IsMaxCount() end
DataStructTreeBTreeBTreeBtreeNode1T=m
return m;