---@class ICSharpCodeNRefactoryAstStatementWithEmbeddedStatement : ICSharpCodeNRefactoryAstStatement
---instance properties
---@field public EmbeddedStatement ICSharpCodeNRefactoryAstStatement
local m = {};
ICSharpCodeNRefactoryAstStatementWithEmbeddedStatement=m
return m;