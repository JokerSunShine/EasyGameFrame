---@class bagV2.ResUseItem
---instance properties
---@field public itemId System.Int32
---@field public cdTime System.Int64
---@field public cdTimeSpecified System.Boolean
local m = {};

bagV2.ResUseItem=m
return m;