---@class ExCSS.Model.TextBlocks.SymbolBlock : ExCSS.Model.TextBlocks.Block
local m = {};
---@return System.String
function m:ToString() end
ExCSS.Model.TextBlocks.SymbolBlock=m
return m;