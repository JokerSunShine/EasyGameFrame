---@class CommonTrieSearchTrieNode
---instance properties
---@field public Occurances SystemInt32
local m = {};
---@param key SystemChar
---@return CommonTrieSearchTrieNode
function m:AddChild(key) end
---@param c SystemChar
---@return CommonTrieSearchTrieNode
function m:GetChildNode(c) end
function m:AddCount() end
function m:ResetCount() end
---@param key SystemChar
function m:RemoveNode(key) end
---@return CommonTrieSearchTrieNode
function m:GetTrieNodeArray() end
---@return SystemString
function m:GetString() end
---@return SystemBoolean
function m:HaveChildNode() end
CommonTrieSearchTrieNode=m
return m;