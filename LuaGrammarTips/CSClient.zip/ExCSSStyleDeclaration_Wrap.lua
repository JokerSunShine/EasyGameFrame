---@class ExCSSStyleDeclaration
---instance properties
---@field public Value SystemString
---@field public ParentRule ExCSSRuleSet
---@field public Item ExCSSProperty
---@field public Properties SystemCollectionsGenericList1ExCSSProperty
---@field public Count SystemInt32
---@field public IsReadOnly SystemBoolean
local m = {};
---@param item ExCSSProperty
function m:Add(item) end
function m:Clear() end
---@param item ExCSSProperty
---@return SystemBoolean
function m:Contains(item) end
---@param array ExCSSProperty
---@param arrayIndex SystemInt32
function m:CopyTo(array, arrayIndex) end
---@param item ExCSSProperty
---@return SystemBoolean
function m:Remove(item) end
---@param item ExCSSProperty
---@return SystemInt32
function m:IndexOf(item) end
---@param index SystemInt32
---@param item ExCSSProperty
function m:Insert(index, item) end
---@param index SystemInt32
function m:RemoveAt(index) end
---@return SystemString
function m:ToString() end
---@param friendlyFormat SystemBoolean
---@param indentation SystemInt32 @default_value:0
---@return SystemString
function m:ToString(friendlyFormat, indentation) end
---@return SystemCollectionsGenericIEnumerator1ExCSSProperty
function m:GetEnumerator() end
ExCSSStyleDeclaration=m
return m;