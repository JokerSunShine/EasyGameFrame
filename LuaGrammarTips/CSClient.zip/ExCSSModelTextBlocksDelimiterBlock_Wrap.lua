---@class ExCSSModelTextBlocksDelimiterBlock : ExCSSModelTextBlocksCharacterBlock
local m = {};
---@return SystemString
function m:ToString() end
ExCSSModelTextBlocksDelimiterBlock=m
return m;