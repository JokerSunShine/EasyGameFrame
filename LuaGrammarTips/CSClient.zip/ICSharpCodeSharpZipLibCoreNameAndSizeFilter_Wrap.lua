---@class ICSharpCodeSharpZipLibCoreNameAndSizeFilter : ICSharpCodeSharpZipLibCorePathFilter
---instance properties
---@field public MinSize SystemInt64
---@field public MaxSize SystemInt64
local m = {};
---@param fileName SystemString
---@return SystemBoolean
function m:IsMatch(fileName) end
ICSharpCodeSharpZipLibCoreNameAndSizeFilter=m
return m;