---@class auctionV2.GuessYouLikeResponse
---instance properties
---@field public itemType System.Int32
---@field public itemTypeSpecified System.Boolean
---@field public items System.Collections.Generic.List1auctionV2.AuctionItemInfo
---@field public totalPage System.Int32
---@field public totalPageSpecified System.Boolean
---@field public page System.Int32
---@field public pageSpecified System.Boolean
---@field public countPerPage System.Int32
---@field public countPerPageSpecified System.Boolean
---@field public pageNumber System.Int32
---@field public pageNumberSpecified System.Boolean
local m = {};

auctionV2.GuessYouLikeResponse=m
return m;