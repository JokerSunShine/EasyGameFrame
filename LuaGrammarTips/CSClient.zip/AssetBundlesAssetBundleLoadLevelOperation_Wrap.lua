---@class AssetBundles.AssetBundleLoadLevelOperation : AssetBundles.AssetBundleLoadOperation
local m = {};

---@return System.Boolean
function m:Update() end
---@return System.Boolean
function m:IsDone() end
AssetBundles.AssetBundleLoadLevelOperation=m
return m;