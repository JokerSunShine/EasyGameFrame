---@class DataStructGraphBaseEdge
---instance fields
---@field public start SystemInt32
---@field public end SystemInt32
---@field public len SystemInt32
local m = {};
DataStructGraphBaseEdge=m
return m;