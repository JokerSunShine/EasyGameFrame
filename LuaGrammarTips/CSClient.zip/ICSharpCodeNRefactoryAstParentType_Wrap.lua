---@class ICSharpCodeNRefactoryAstParentType
---@field ClassOrStruct @0
---@field InterfaceOrEnum @1
---@field Namespace @2
---@field Unknown @3
ICSharpCodeNRefactoryAstParentType=m
return m;