---@class ExCSS.Model.TextBlocks.Block
local m = {};
ExCSS.Model.TextBlocks.Block=m
return m;