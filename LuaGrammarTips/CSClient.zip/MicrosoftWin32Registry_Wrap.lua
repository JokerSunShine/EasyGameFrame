---@class MicrosoftWin32Registry
---fields
---@field public ClassesRoot MicrosoftWin32RegistryKey
---@field public CurrentConfig MicrosoftWin32RegistryKey
---@field public CurrentUser MicrosoftWin32RegistryKey
---@field public LocalMachine MicrosoftWin32RegistryKey
---@field public PerformanceData MicrosoftWin32RegistryKey
---@field public Users MicrosoftWin32RegistryKey
local m = {};
---@param keyName SystemString
---@param valueName SystemString
---@param value SystemObject
function m.SetValue(keyName, valueName, value) end
---@param keyName SystemString
---@param valueName SystemString
---@param value SystemObject
---@param valueKind MicrosoftWin32RegistryValueKind
function m.SetValue(keyName, valueName, value, valueKind) end
---@param keyName SystemString
---@param valueName SystemString
---@param defaultValue SystemObject
---@return SystemObject
function m.GetValue(keyName, valueName, defaultValue) end
MicrosoftWin32Registry=m
return m;