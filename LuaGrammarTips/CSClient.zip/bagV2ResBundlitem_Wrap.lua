---@class bagV2.ResBundlitem
---instance properties
---@field public itemId System.Collections.Generic.List1System.Int32
local m = {};

bagV2.ResBundlitem=m
return m;