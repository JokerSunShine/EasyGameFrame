---@class ExCSSAggregateSelectorList : ExCSSSelectorList
---instance fields
---@field public Delimiter SystemString
local m = {};
---@param friendlyFormat SystemBoolean
---@param indentation SystemInt32 @default_value:0
---@return SystemString
function m:ToString(friendlyFormat, indentation) end
ExCSSAggregateSelectorList=m
return m;