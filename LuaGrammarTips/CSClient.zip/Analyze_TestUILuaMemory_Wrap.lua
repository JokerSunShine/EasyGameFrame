---@class Analyze_TestUILuaMemory : Analyze_TestLuaMemoryBase
---fields
---@field public actionTest System.Action
---instance properties
---@field public AnalyzeResultDirPath System.String
---@field public OpenPanelCounter System.Int32
---@field public CurrentTestingPanelName System.String
---@field public CurrentState Analyze_TestUILuaMemoryState
local m = {};

---@param panelName System.String
function m:StartTestPanel(panelName) end
Analyze_TestUILuaMemory=m
return m;