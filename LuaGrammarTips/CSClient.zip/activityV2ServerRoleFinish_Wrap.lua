---@class activityV2.ServerRoleFinish
---instance properties
---@field public roleId System.Int64
---@field public roleIdSpecified System.Boolean
---@field public name System.String
---@field public nameSpecified System.Boolean
---@field public sex System.Int32
---@field public sexSpecified System.Boolean
---@field public carrer System.Int32
---@field public carrerSpecified System.Boolean
local m = {};

activityV2.ServerRoleFinish=m
return m;