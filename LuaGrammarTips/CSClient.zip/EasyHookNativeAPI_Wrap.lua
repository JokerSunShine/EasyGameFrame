---@class EasyHookNativeAPI
---fields
---@field public MAX_HOOK_COUNT SystemInt32
---@field public MAX_ACE_COUNT SystemInt32
---@field public Is64Bit SystemBoolean
---@field public STATUS_SUCCESS SystemInt32
---@field public STATUS_INVALID_PARAMETER SystemInt32
---@field public STATUS_INVALID_PARAMETER_1 SystemInt32
---@field public STATUS_INVALID_PARAMETER_2 SystemInt32
---@field public STATUS_INVALID_PARAMETER_3 SystemInt32
---@field public STATUS_INVALID_PARAMETER_4 SystemInt32
---@field public STATUS_INVALID_PARAMETER_5 SystemInt32
---@field public STATUS_NOT_SUPPORTED SystemInt32
---@field public STATUS_INTERNAL_ERROR SystemInt32
---@field public STATUS_INSUFFICIENT_RESOURCES SystemInt32
---@field public STATUS_BUFFER_TOO_SMALL SystemInt32
---@field public STATUS_NO_MEMORY SystemInt32
---@field public STATUS_WOW_ASSERTION SystemInt32
---@field public STATUS_ACCESS_DENIED SystemInt32
---@field public EASYHOOK_INJECT_DEFAULT SystemInt32
---@field public EASYHOOK_INJECT_MANAGED SystemInt32
local m = {};
---@return SystemInt32
function m.GetCurrentThreadId() end
---@param InHandle SystemIntPtr
function m.CloseHandle(InHandle) end
---@return SystemInt32
function m.GetCurrentProcessId() end
---@param InModule SystemIntPtr
---@param InProcName SystemString
---@return SystemIntPtr
function m.GetProcAddress(InModule, InProcName) end
---@param InPath SystemString
---@return SystemIntPtr
function m.LoadLibrary(InPath) end
---@param InPath SystemString
---@return SystemIntPtr
function m.GetModuleHandle(InPath) end
---@param InFramesToSkip SystemInt32
---@param InFramesToCapture SystemInt32
---@param OutBackTrace SystemIntPtr
---@param OutBackTraceHash SystemIntPtr
---@return SystemInt16
function m.RtlCaptureStackBackTrace(InFramesToSkip, InFramesToCapture, OutBackTrace, OutBackTraceHash) end
---@return SystemInt32
function m.RtlGetLastError() end
---@return SystemString
function m.RtlGetLastErrorString() end
function m.LhUninstallAllHooks() end
---@param InEntryPoint SystemIntPtr
---@param InHookProc SystemIntPtr
---@param InCallback SystemIntPtr
---@param OutHandle SystemIntPtr
function m.LhInstallHook(InEntryPoint, InHookProc, InCallback, OutHandle) end
---@param RefHandle SystemIntPtr
function m.LhUninstallHook(RefHandle) end
function m.LhWaitForPendingRemovals() end
---@param InHandle SystemIntPtr
---@param InThreadID SystemInt32
---@param OutResult SystemBoolean @out
function m.LhIsThreadIntercepted(InHandle, InThreadID, OutResult) end
---@param InThreadIdList SystemInt32
---@param InThreadCount SystemInt32
---@param InHandle SystemIntPtr
function m.LhSetInclusiveACL(InThreadIdList, InThreadCount, InHandle) end
---@param InThreadIdList SystemInt32
---@param InThreadCount SystemInt32
---@param InHandle SystemIntPtr
function m.LhSetExclusiveACL(InThreadIdList, InThreadCount, InHandle) end
---@param InThreadIdList SystemInt32
---@param InThreadCount SystemInt32
function m.LhSetGlobalInclusiveACL(InThreadIdList, InThreadCount) end
---@param InThreadIdList SystemInt32
---@param InThreadCount SystemInt32
function m.LhSetGlobalExclusiveACL(InThreadIdList, InThreadCount) end
---@param OutValue SystemIntPtr @out
function m.LhBarrierGetCallingModule(OutValue) end
---@param OutValue SystemIntPtr @out
function m.LhBarrierGetCallback(OutValue) end
---@param OutValue SystemIntPtr @out
function m.LhBarrierGetReturnAddress(OutValue) end
---@param OutValue SystemIntPtr @out
function m.LhBarrierGetAddressOfReturnAddress(OutValue) end
---@param OutBackup SystemIntPtr @out
function m.LhBarrierBeginStackTrace(OutBackup) end
---@param OutBackup SystemIntPtr
function m.LhBarrierEndStackTrace(OutBackup) end
---@param handle SystemIntPtr
---@param address SystemIntPtr @out
function m.LhGetHookBypassAddress(handle, address) end
function m.DbgAttachDebugger() end
---@param InThreadHandle SystemIntPtr
---@param OutThreadId SystemInt32 @out
function m.DbgGetThreadIdByHandle(InThreadHandle, OutThreadId) end
---@param InProcessHandle SystemIntPtr
---@param OutProcessId SystemInt32 @out
function m.DbgGetProcessIdByHandle(InProcessHandle, OutProcessId) end
---@param InNamedHandle SystemIntPtr
---@param OutNameBuffer SystemIntPtr
---@param InBufferSize SystemInt32
---@param OutRequiredSize SystemInt32 @out
function m.DbgHandleToObjectName(InNamedHandle, OutNameBuffer, InBufferSize, OutRequiredSize) end
---@param InTargetPID SystemInt32
---@param InWakeUpTID SystemInt32
---@param InInjectionOptions SystemInt32
---@param InLibraryPath_x86 SystemString
---@param InLibraryPath_x64 SystemString
---@param InPassThruBuffer SystemIntPtr
---@param InPassThruSize SystemInt32
---@return SystemInt32
function m.RhInjectLibraryEx(InTargetPID, InWakeUpTID, InInjectionOptions, InLibraryPath_x86, InLibraryPath_x64, InPassThruBuffer, InPassThruSize) end
---@param InTargetPID SystemInt32
---@param InWakeUpTID SystemInt32
---@param InInjectionOptions SystemInt32
---@param InLibraryPath_x86 SystemString
---@param InLibraryPath_x64 SystemString
---@param InPassThruBuffer SystemIntPtr
---@param InPassThruSize SystemInt32
function m.RhInjectLibrary(InTargetPID, InWakeUpTID, InInjectionOptions, InLibraryPath_x86, InLibraryPath_x64, InPassThruBuffer, InPassThruSize) end
---@param InEXEPath SystemString
---@param InCommandLine SystemString
---@param InProcessCreationFlags SystemInt32
---@param OutProcessId SystemInt32 @out
---@param OutThreadId SystemInt32 @out
function m.RtlCreateSuspendedProcess(InEXEPath, InCommandLine, InProcessCreationFlags, OutProcessId, OutThreadId) end
---@param InProcessId SystemInt32
---@param OutResult SystemBoolean @out
function m.RhIsX64Process(InProcessId, OutResult) end
---@return SystemBoolean
function m.RhIsAdministrator() end
---@param InProcessId SystemInt32
---@param OutToken SystemIntPtr @out
function m.RhGetProcessToken(InProcessId, OutToken) end
function m.RhWakeUpProcess() end
---@param InServiceName SystemString
---@param InExePath SystemString
---@param InChannelName SystemString
function m.RtlInstallService(InServiceName, InExePath, InChannelName) end
---@param InDriverPath SystemString
---@param InDriverName SystemString
function m.RhInstallDriver(InDriverPath, InDriverName) end
function m.RhInstallSupportDriver() end
---@return SystemBoolean
function m.RhIsX64System() end
---@param InAssemblyPaths SystemString
---@param InDescription SystemString
---@param InUniqueID SystemString
function m.GacInstallAssemblies(InAssemblyPaths, InDescription, InUniqueID) end
---@param InAssemblyNames SystemString
---@param InDescription SystemString
---@param InUniqueID SystemString
function m.GacUninstallAssemblies(InAssemblyNames, InDescription, InUniqueID) end
EasyHookNativeAPI=m
return m;