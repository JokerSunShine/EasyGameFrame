---@class ICSharpCode.NRefactory.PrettyPrinter.SpecialNodesInserter
local m = {};
---@param specials System.Collections.Generic.IEnumerable`1[ICSharpCode.NRefactory.ISpecial]
---@param outputVisitor ICSharpCode.NRefactory.PrettyPrinter.IOutputAstVisitor
---@return ICSharpCode.NRefactory.PrettyPrinter.SpecialNodesInserter
function m.Install(specials, outputVisitor) end
---@param node ICSharpCode.NRefactory.Ast.INode
function m:AcceptNodeStart(node) end
---@param node ICSharpCode.NRefactory.Ast.INode
function m:AcceptNodeEnd(node) end
---@param loc ICSharpCode.NRefactory.Location
function m:AcceptPoint(loc) end
function m:Finish() end
ICSharpCode.NRefactory.PrettyPrinter.SpecialNodesInserter=m
return m;