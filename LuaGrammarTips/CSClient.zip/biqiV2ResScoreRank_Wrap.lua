---@class biqiV2.ResScoreRank
---instance properties
---@field public scoreList System.Collections.Generic.List1biqiV2.ScoreRankInfo
local m = {};

biqiV2.ResScoreRank=m
return m;