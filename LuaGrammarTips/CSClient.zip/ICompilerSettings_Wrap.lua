---@class ICompilerSettings
---instance properties
---@field public LibPaths SystemString
---@field public CompilerPath SystemString
---@field public LinkerPath SystemString
---@field public MachineSpecification SystemString
local m = {};
ICompilerSettings=m
return m;