---@class ICompilerSettings
---instance properties
---@field public LibPaths System.String[]
---@field public CompilerPath System.String
---@field public LinkerPath System.String
---@field public MachineSpecification System.String
local m = {};
ICompilerSettings=m
return m;