---@class ExCSSDirectionMode
---@field LeftToRight @0
---@field RightToLeft @1
ExCSSDirectionMode=m
return m;