---@class ExCSS.Model.TextBlocks.RangeBlock : ExCSS.Model.TextBlocks.Block
local m = {};
---@return System.String
function m:ToString() end
ExCSS.Model.TextBlocks.RangeBlock=m
return m;