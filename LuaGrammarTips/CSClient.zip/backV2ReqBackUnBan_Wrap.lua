---@class backV2.ReqBackUnBan
---instance properties
---@field public banType System.Int32
---@field public banTypeSpecified System.Boolean
---@field public uid System.String
---@field public uidSpecified System.Boolean
local m = {};

backV2.ReqBackUnBan=m
return m;