---@class AutomaticTeamState
---@field ALLHAVETEAMS @1
---@field ALLNOTHAVETEAMS @2
---@field OTHERHASTEAM @3
---@field MEHAVETEAM @4
---@field JOIN_OR_CHANGEPKMODEL @20
---@field JOIN_OR_FIGHT @21
---@field JOIN_REFUSE_CHANGEPKMODEL @22
---@field JOIN_REFUSE_FIGHT @23
---@field NON @99
local m = {};
AutomaticTeamState=m
return m;