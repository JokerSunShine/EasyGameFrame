---@class ExCSSEqualSign : ExCSSTerm
local m = {};
---@return SystemString
function m:ToString() end
ExCSSEqualSign=m
return m;