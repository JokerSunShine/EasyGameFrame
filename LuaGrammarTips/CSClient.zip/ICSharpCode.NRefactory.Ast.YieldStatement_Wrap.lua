---@class ICSharpCode.NRefactory.Ast.YieldStatement : ICSharpCode.NRefactory.Ast.Statement
---instance properties
---@field public Statement ICSharpCode.NRefactory.Ast.Statement
---@field public IsYieldBreak System.Boolean
---@field public IsYieldReturn System.Boolean
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.YieldStatement=m
return m;