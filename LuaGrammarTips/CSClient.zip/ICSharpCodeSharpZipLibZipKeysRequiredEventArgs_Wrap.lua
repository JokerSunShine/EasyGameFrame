---@class ICSharpCodeSharpZipLibZipKeysRequiredEventArgs : SystemEventArgs
---instance properties
---@field public FileName SystemString
---@field public Key SystemByte
local m = {};
ICSharpCodeSharpZipLibZipKeysRequiredEventArgs=m
return m;