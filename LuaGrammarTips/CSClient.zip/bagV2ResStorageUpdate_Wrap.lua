---@class bagV2.ResStorageUpdate
---instance properties
---@field public item bagV2.BagItemInfo
---@field public operate System.Int32
---@field public operateSpecified System.Boolean
local m = {};

bagV2.ResStorageUpdate=m
return m;