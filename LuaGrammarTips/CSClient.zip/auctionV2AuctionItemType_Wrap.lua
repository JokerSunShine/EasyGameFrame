---@class auctionV2.AuctionItemType
---@field THADED_PRODUCTS @1
---@field SALF_PRODUCTS @2
---@field BUY_PRODUCTS @3
---@field SMELT @4
local m = {};
auctionV2.AuctionItemType=m
return m;