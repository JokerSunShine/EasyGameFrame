---@class arenaV2.ResHistoryHighestRank
---instance properties
---@field public highestRank System.Int32
---@field public highestRankSpecified System.Boolean
local m = {};

arenaV2.ResHistoryHighestRank=m
return m;