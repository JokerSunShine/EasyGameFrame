---@class Consts
---fields
---@field public AssemblyName SystemString
---@field public PublicKey SystemString
local m = {};
Consts=m
return m;