---@class ICSharpCode.NRefactory.Ast.QueryExpressionFromOrJoinClause : ICSharpCode.NRefactory.Ast.QueryExpressionClause
---instance properties
---@field public Type ICSharpCode.NRefactory.Ast.TypeReference
---@field public Identifier System.String
---@field public InExpression ICSharpCode.NRefactory.Ast.Expression
local m = {};
ICSharpCode.NRefactory.Ast.QueryExpressionFromOrJoinClause=m
return m;