---@class activityV2.ResCrazyHappyChangeInfo
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public crazyHappyInfo System.Collections.Generic.List1activityV2.CrazyHappyInfo
---@field public crazyHappyValue System.Int32
---@field public crazyHappyValueSpecified System.Boolean
local m = {};

activityV2.ResCrazyHappyChangeInfo=m
return m;