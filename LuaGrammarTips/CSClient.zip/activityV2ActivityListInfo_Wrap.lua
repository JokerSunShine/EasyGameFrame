---@class activityV2.ActivityListInfo
---instance properties
---@field public activityDataInfo System.Collections.Generic.List1activityV2.ActivityDataInfo
---@field public registerNum System.Int32
---@field public registerNumSpecified System.Boolean
local m = {};

activityV2.ActivityListInfo=m
return m;