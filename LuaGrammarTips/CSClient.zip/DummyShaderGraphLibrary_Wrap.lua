---@class DummyShaderGraphLibrary
local m = {};
DummyShaderGraphLibrary=m
return m;