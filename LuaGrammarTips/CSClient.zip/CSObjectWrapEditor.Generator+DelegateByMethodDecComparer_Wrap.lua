---@class CSObjectWrapEditor.Generator+DelegateByMethodDecComparer
local m = {};
---@param x System.Type
---@param y System.Type
---@return System.Boolean
function m:Equals(x, y) end
---@param obj System.Type
---@return System.Int32
function m:GetHashCode(obj) end
CSObjectWrapEditor.Generator+DelegateByMethodDecComparer=m
return m;