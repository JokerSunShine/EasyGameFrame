---@class artifactV2.ReqArtifactUp
---instance properties
---@field public type System.Int32
---@field public typeSpecified System.Boolean
---@field public fragmentType System.Int32
---@field public fragmentTypeSpecified System.Boolean
local m = {};

artifactV2.ReqArtifactUp=m
return m;