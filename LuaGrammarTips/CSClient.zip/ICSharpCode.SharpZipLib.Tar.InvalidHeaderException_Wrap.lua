---@class ICSharpCode.SharpZipLib.Tar.InvalidHeaderException : ICSharpCode.SharpZipLib.Tar.TarException
local m = {};
ICSharpCode.SharpZipLib.Tar.InvalidHeaderException=m
return m;