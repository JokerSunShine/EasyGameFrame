awakeV2 = {};
