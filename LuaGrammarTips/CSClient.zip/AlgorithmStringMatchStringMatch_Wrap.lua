---@class AlgorithmStringMatchStringMatch
local m = {};
---@param s SystemString
---@param patten SystemString
---@return SystemInt32
function m.BruteForce(s, patten) end
---@param s SystemString
---@param patten SystemString
---@return SystemInt32
function m.BMMatch(s, patten) end
---@param s SystemString
---@param patten SystemString
---@return SystemInt32
function m.KMPMatch(s, patten) end
AlgorithmStringMatchStringMatch=m
return m;