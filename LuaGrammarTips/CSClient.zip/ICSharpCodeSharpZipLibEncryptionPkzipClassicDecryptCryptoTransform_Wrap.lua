---@class ICSharpCodeSharpZipLibEncryptionPkzipClassicDecryptCryptoTransform : ICSharpCodeSharpZipLibEncryptionPkzipClassicCryptoBase
---instance properties
---@field public CanReuseTransform SystemBoolean
---@field public InputBlockSize SystemInt32
---@field public OutputBlockSize SystemInt32
---@field public CanTransformMultipleBlocks SystemBoolean
local m = {};
---@param inputBuffer SystemByte
---@param inputOffset SystemInt32
---@param inputCount SystemInt32
---@return SystemByte
function m:TransformFinalBlock(inputBuffer, inputOffset, inputCount) end
---@param inputBuffer SystemByte
---@param inputOffset SystemInt32
---@param inputCount SystemInt32
---@param outputBuffer SystemByte
---@param outputOffset SystemInt32
---@return SystemInt32
function m:TransformBlock(inputBuffer, inputOffset, inputCount, outputBuffer, outputOffset) end
function m:Dispose() end
ICSharpCodeSharpZipLibEncryptionPkzipClassicDecryptCryptoTransform=m
return m;