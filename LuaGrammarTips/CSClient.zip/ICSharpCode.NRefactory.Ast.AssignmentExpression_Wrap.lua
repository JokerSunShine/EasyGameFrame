---@class ICSharpCode.NRefactory.Ast.AssignmentExpression : ICSharpCode.NRefactory.Ast.Expression
---instance properties
---@field public Left ICSharpCode.NRefactory.Ast.Expression
---@field public Op ICSharpCode.NRefactory.Ast.AssignmentOperatorType
---@field public Right ICSharpCode.NRefactory.Ast.Expression
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.AssignmentExpression=m
return m;