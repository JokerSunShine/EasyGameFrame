---@class ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputBuffer
---instance properties
---@field public RawLength System.Int32
---@field public RawData System.Byte[]
---@field public ClearTextLength System.Int32
---@field public ClearText System.Byte[]
---@field public Available System.Int32
---@field public CryptoTransform System.Security.Cryptography.ICryptoTransform
local m = {};
---@param inflater ICSharpCode.SharpZipLib.Zip.Compression.Inflater
function m:SetInflaterInput(inflater) end
function m:Fill() end
---@param buffer System.Byte[]
---@return System.Int32
function m:ReadRawBuffer(buffer) end
---@param outBuffer System.Byte[]
---@param offset System.Int32
---@param length System.Int32
---@return System.Int32
function m:ReadRawBuffer(outBuffer, offset, length) end
---@param outBuffer System.Byte[]
---@param offset System.Int32
---@param length System.Int32
---@return System.Int32
function m:ReadClearTextBuffer(outBuffer, offset, length) end
---@return System.Int32
function m:ReadLeByte() end
---@return System.Int32
function m:ReadLeShort() end
---@return System.Int32
function m:ReadLeInt() end
---@return System.Int64
function m:ReadLeLong() end
ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputBuffer=m
return m;