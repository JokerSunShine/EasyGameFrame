---@class ExCSS.NthChildSelector : ExCSS.BaseSelector
---instance fields
---@field public Step System.Int32
---@field public Offset System.Int32
local m = {};
---@param friendlyFormat System.Boolean
---@param indentation System.Int32 @default_value:0
---@return System.String
function m:ToString(friendlyFormat, indentation) end
ExCSS.NthChildSelector=m
return m;