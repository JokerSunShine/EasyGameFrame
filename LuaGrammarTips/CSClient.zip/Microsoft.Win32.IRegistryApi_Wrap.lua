---@class Microsoft.Win32.IRegistryApi
local m = {};
---@param rkey Microsoft.Win32.RegistryKey
---@param keyname System.String
---@return Microsoft.Win32.RegistryKey
function m:CreateSubKey(rkey, keyname) end
---@param hKey Microsoft.Win32.RegistryHive
---@param machineName System.String
---@return Microsoft.Win32.RegistryKey
function m:OpenRemoteBaseKey(hKey, machineName) end
---@param rkey Microsoft.Win32.RegistryKey
---@param keyname System.String
---@param writtable System.Boolean
---@return Microsoft.Win32.RegistryKey
function m:OpenSubKey(rkey, keyname, writtable) end
---@param rkey Microsoft.Win32.RegistryKey
function m:Flush(rkey) end
---@param rkey Microsoft.Win32.RegistryKey
function m:Close(rkey) end
---@param rkey Microsoft.Win32.RegistryKey
---@param name System.String
---@param default_value System.Object
---@param options Microsoft.Win32.RegistryValueOptions
---@return System.Object
function m:GetValue(rkey, name, default_value, options) end
---@param rkey Microsoft.Win32.RegistryKey
---@param name System.String
---@return Microsoft.Win32.RegistryValueKind
function m:GetValueKind(rkey, name) end
---@param rkey Microsoft.Win32.RegistryKey
---@param name System.String
---@param value System.Object
function m:SetValue(rkey, name, value) end
---@param rkey Microsoft.Win32.RegistryKey
---@return System.Int32
function m:SubKeyCount(rkey) end
---@param rkey Microsoft.Win32.RegistryKey
---@return System.Int32
function m:ValueCount(rkey) end
---@param rkey Microsoft.Win32.RegistryKey
---@param value System.String
---@param throw_if_missing System.Boolean
function m:DeleteValue(rkey, value, throw_if_missing) end
---@param rkey Microsoft.Win32.RegistryKey
---@param keyName System.String
---@param throw_if_missing System.Boolean
function m:DeleteKey(rkey, keyName, throw_if_missing) end
---@param rkey Microsoft.Win32.RegistryKey
---@return System.String[]
function m:GetSubKeyNames(rkey) end
---@param rkey Microsoft.Win32.RegistryKey
---@return System.String[]
function m:GetValueNames(rkey) end
---@param rkey Microsoft.Win32.RegistryKey
---@return System.String
function m:ToString(rkey) end
---@param rkey Microsoft.Win32.RegistryKey
---@param name System.String
---@param value System.Object
---@param valueKind Microsoft.Win32.RegistryValueKind
function m:SetValue(rkey, name, value, valueKind) end
---@param rkey Microsoft.Win32.RegistryKey
---@param keyname System.String
---@param options Microsoft.Win32.RegistryOptions
---@return Microsoft.Win32.RegistryKey
function m:CreateSubKey(rkey, keyname, options) end
---@param handle Microsoft.Win32.SafeHandles.SafeRegistryHandle
---@return Microsoft.Win32.RegistryKey
function m:FromHandle(handle) end
---@param key Microsoft.Win32.RegistryKey
---@return System.IntPtr
function m:GetHandle(key) end
Microsoft.Win32.IRegistryApi=m
return m;