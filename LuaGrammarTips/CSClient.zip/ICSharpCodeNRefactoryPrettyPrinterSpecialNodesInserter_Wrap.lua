---@class ICSharpCodeNRefactoryPrettyPrinterSpecialNodesInserter
local m = {};
---@param specials SystemCollectionsGenericIEnumerable1ICSharpCodeNRefactoryISpecial
---@param outputVisitor ICSharpCodeNRefactoryPrettyPrinterIOutputAstVisitor
---@return ICSharpCodeNRefactoryPrettyPrinterSpecialNodesInserter
function m.Install(specials, outputVisitor) end
---@param node ICSharpCodeNRefactoryAstINode
function m:AcceptNodeStart(node) end
---@param node ICSharpCodeNRefactoryAstINode
function m:AcceptNodeEnd(node) end
---@param loc ICSharpCodeNRefactoryLocation
function m:AcceptPoint(loc) end
function m:Finish() end
ICSharpCodeNRefactoryPrettyPrinterSpecialNodesInserter=m
return m;