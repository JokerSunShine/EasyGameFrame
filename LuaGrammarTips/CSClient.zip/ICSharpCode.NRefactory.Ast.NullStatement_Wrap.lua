---@class ICSharpCode.NRefactory.Ast.NullStatement : ICSharpCode.NRefactory.Ast.Statement
---fields
---@field public Instance ICSharpCode.NRefactory.Ast.NullStatement
---instance properties
---@field public IsNull System.Boolean
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.NullStatement=m
return m;