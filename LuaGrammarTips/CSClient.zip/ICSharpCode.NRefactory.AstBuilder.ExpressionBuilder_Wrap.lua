---@class ICSharpCode.NRefactory.AstBuilder.ExpressionBuilder
local m = {};
---@param identifier System.String
---@return ICSharpCode.NRefactory.Ast.IdentifierExpression
function m.Identifier(identifier) end
---@param targetObject ICSharpCode.NRefactory.Ast.Expression
---@param memberName System.String
---@return ICSharpCode.NRefactory.Ast.MemberReferenceExpression
function m.Member(targetObject, memberName) end
---@param callTarget ICSharpCode.NRefactory.Ast.Expression
---@param methodName System.String
---@param arguments ICSharpCode.NRefactory.Ast.Expression[]
---@return ICSharpCode.NRefactory.Ast.InvocationExpression
function m.Call(callTarget, methodName, arguments) end
---@param callTarget ICSharpCode.NRefactory.Ast.Expression
---@param arguments ICSharpCode.NRefactory.Ast.Expression[]
---@return ICSharpCode.NRefactory.Ast.InvocationExpression
function m.Call(callTarget, arguments) end
---@param createType ICSharpCode.NRefactory.Ast.TypeReference
---@param arguments ICSharpCode.NRefactory.Ast.Expression[]
---@return ICSharpCode.NRefactory.Ast.ObjectCreateExpression
function m.New(createType, arguments) end
---@param type ICSharpCode.NRefactory.Ast.TypeReference
---@return ICSharpCode.NRefactory.Ast.Expression
function m.CreateDefaultValueForType(type) end
---@param left ICSharpCode.NRefactory.Ast.Expression
---@param op ICSharpCode.NRefactory.Ast.BinaryOperatorType
---@param right ICSharpCode.NRefactory.Ast.Expression
---@return ICSharpCode.NRefactory.Ast.BinaryOperatorExpression
function m.Operator(left, op, right) end
ICSharpCode.NRefactory.AstBuilder.ExpressionBuilder=m
return m;