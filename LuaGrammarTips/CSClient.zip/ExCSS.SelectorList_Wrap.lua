---@class ExCSS.SelectorList : ExCSS.BaseSelector
---instance properties
---@field public Length System.Int32
---@field public Item ExCSS.BaseSelector
local m = {};
---@param selector ExCSS.BaseSelector
---@return ExCSS.SelectorList
function m:AppendSelector(selector) end
---@param selector ExCSS.SimpleSelector
---@return ExCSS.SelectorList
function m:RemoveSelector(selector) end
---@return ExCSS.SelectorList
function m:ClearSelectors() end
---@return System.Collections.Generic.IEnumerator`1[ExCSS.BaseSelector]
function m:GetEnumerator() end
---@param friendlyFormat System.Boolean
---@param indentation System.Int32 @default_value:0
---@return System.String
function m:ToString(friendlyFormat, indentation) end
ExCSS.SelectorList=m
return m;