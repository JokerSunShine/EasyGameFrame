---@class ICSharpCodeSharpZipLibTarProgressMessageHandler : SystemMulticastDelegate
local m = {};
---@param archive ICSharpCodeSharpZipLibTarTarArchive
---@param entry ICSharpCodeSharpZipLibTarTarEntry
---@param message SystemString
function m:Invoke(archive, entry, message) end
---@param archive ICSharpCodeSharpZipLibTarTarArchive
---@param entry ICSharpCodeSharpZipLibTarTarEntry
---@param message SystemString
---@param callback SystemAsyncCallback
---@param object SystemObject
---@return SystemIAsyncResult
function m:BeginInvoke(archive, entry, message, callback, object) end
---@param result SystemIAsyncResult
function m:EndInvoke(result) end
ICSharpCodeSharpZipLibTarProgressMessageHandler=m
return m;