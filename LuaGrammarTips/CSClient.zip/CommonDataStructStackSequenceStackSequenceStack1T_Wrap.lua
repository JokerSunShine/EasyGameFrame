---@class CommonDataStructStackSequenceStackSequenceStack1T
---instance properties
---@field public Count SystemInt32
local m = {};
---@param item T
---@return SystemBoolean
function m:Push(item) end
---@return T
function m:Pop() end
CommonDataStructStackSequenceStackSequenceStack1T=m
return m;