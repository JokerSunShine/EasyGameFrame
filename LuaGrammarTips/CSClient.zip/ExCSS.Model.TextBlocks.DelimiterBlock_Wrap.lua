---@class ExCSS.Model.TextBlocks.DelimiterBlock : ExCSS.Model.TextBlocks.CharacterBlock
local m = {};
---@return System.String
function m:ToString() end
ExCSS.Model.TextBlocks.DelimiterBlock=m
return m;