---@class CSObjectWrapEditor.XLuaTemplates : System.ValueType
---instance fields
---@field public LuaClassWrap CSObjectWrapEditor.XLuaTemplate
---@field public LuaDelegateBridge CSObjectWrapEditor.XLuaTemplate
---@field public LuaDelegateWrap CSObjectWrapEditor.XLuaTemplate
---@field public LuaEnumWrap CSObjectWrapEditor.XLuaTemplate
---@field public LuaInterfaceBridge CSObjectWrapEditor.XLuaTemplate
---@field public LuaRegister CSObjectWrapEditor.XLuaTemplate
---@field public LuaWrapPusher CSObjectWrapEditor.XLuaTemplate
---@field public PackUnpack CSObjectWrapEditor.XLuaTemplate
---@field public TemplateCommon CSObjectWrapEditor.XLuaTemplate
local m = {};
CSObjectWrapEditor.XLuaTemplates=m
return m;