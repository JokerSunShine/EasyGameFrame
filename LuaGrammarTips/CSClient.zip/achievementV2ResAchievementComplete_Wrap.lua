---@class achievementV2.ResAchievementComplete
---instance properties
---@field public achievementInfo achievementV2.AchievementInfo
local m = {};

achievementV2.ResAchievementComplete=m
return m;