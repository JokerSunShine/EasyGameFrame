---@class CSObjectWrapEditor.Generator
---fields
---@field public LuaCallCSharp System.Collections.Generic.List`1[System.Type]
---@field public CSharpCallLua System.Collections.Generic.List`1[System.Type]
---@field public BlackList System.Collections.Generic.List`1[System.Collections.Generic.List`1[System.String]]
---@field public GCOptimizeList System.Collections.Generic.List`1[System.Type]
---@field public AdditionalProperties System.Collections.Generic.Dictionary`2[System.Type,System.Collections.Generic.List`1[System.String]]
---@field public ReflectionUse System.Collections.Generic.List`1[System.Type]
---@field public HotfixCfg System.Collections.Generic.Dictionary`2[System.Type,XLua.HotfixFlag]
---@field public OptimizeCfg System.Collections.Generic.Dictionary`2[System.Type,XLua.OptimizeFlag]
---@field public DoNotGen System.Collections.Generic.Dictionary`2[System.Type,System.Collections.Generic.HashSet`1[System.String]]
---@field public assemblyList System.Collections.Generic.List`1[System.String]
---@field public memberFilters System.Collections.Generic.List`1[System.Func`2[System.Reflection.MemberInfo,System.Boolean]]
local m = {};
---@param hotfix_check_types System.Collections.Generic.IEnumerable`1[System.Type]
function m.GenDelegateBridges(hotfix_check_types) end
function m.GenEnumWraps() end
---@param minimum System.Boolean @default_value:False
function m.GenLuaRegister(minimum) end
---@param type System.Type
---@param cb System.Action`1[System.Type]
function m.AllSubStruct(type, cb) end
---@param types System.Collections.Generic.IEnumerable`1[System.Type]
---@param save_path System.String
function m.GenPackUnpack(types, save_path) end
---@param check_types System.Collections.Generic.IEnumerable`1[System.Type]
function m.GetGenConfig(check_types) end
---@param wraps System.Collections.Generic.IEnumerable`1[System.Type]
---@param gc_optimze_list System.Collections.Generic.IEnumerable`1[System.Type]
---@param itf_bridges System.Collections.Generic.IEnumerable`1[System.Type]
---@param save_path System.String
function m.Gen(wraps, gc_optimze_list, itf_bridges, save_path) end
---@param minimum System.Boolean @default_value:False
function m.GenCodeForClass(minimum) end
function m.GenAll() end
function m.GenUsingCLI() end
function m.ClearAll() end
---@param template_src System.String
---@param get_tasks CSObjectWrapEditor.Generator+GetTasks
function m.CustomGen(template_src, get_tasks) end
---@param target UnityEditor.BuildTarget
---@param pathToBuiltProject System.String
function m.CheckGenrate(target, pathToBuiltProject) end
CSObjectWrapEditor.Generator=m
return m;