---@class ICSharpCodeSharpZipLibCoreIScanFilter
local m = {};
---@param name SystemString
---@return SystemBoolean
function m:IsMatch(name) end
ICSharpCodeSharpZipLibCoreIScanFilter=m
return m;