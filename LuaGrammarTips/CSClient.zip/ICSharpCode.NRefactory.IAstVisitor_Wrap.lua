---@class ICSharpCode.NRefactory.IAstVisitor
local m = {};
---@param addHandlerStatement ICSharpCode.NRefactory.Ast.AddHandlerStatement
---@param data System.Object
---@return System.Object
function m:VisitAddHandlerStatement(addHandlerStatement, data) end
---@param addressOfExpression ICSharpCode.NRefactory.Ast.AddressOfExpression
---@param data System.Object
---@return System.Object
function m:VisitAddressOfExpression(addressOfExpression, data) end
---@param anonymousMethodExpression ICSharpCode.NRefactory.Ast.AnonymousMethodExpression
---@param data System.Object
---@return System.Object
function m:VisitAnonymousMethodExpression(anonymousMethodExpression, data) end
---@param arrayCreateExpression ICSharpCode.NRefactory.Ast.ArrayCreateExpression
---@param data System.Object
---@return System.Object
function m:VisitArrayCreateExpression(arrayCreateExpression, data) end
---@param assignmentExpression ICSharpCode.NRefactory.Ast.AssignmentExpression
---@param data System.Object
---@return System.Object
function m:VisitAssignmentExpression(assignmentExpression, data) end
---@param attribute ICSharpCode.NRefactory.Ast.Attribute
---@param data System.Object
---@return System.Object
function m:VisitAttribute(attribute, data) end
---@param attributeSection ICSharpCode.NRefactory.Ast.AttributeSection
---@param data System.Object
---@return System.Object
function m:VisitAttributeSection(attributeSection, data) end
---@param baseReferenceExpression ICSharpCode.NRefactory.Ast.BaseReferenceExpression
---@param data System.Object
---@return System.Object
function m:VisitBaseReferenceExpression(baseReferenceExpression, data) end
---@param binaryOperatorExpression ICSharpCode.NRefactory.Ast.BinaryOperatorExpression
---@param data System.Object
---@return System.Object
function m:VisitBinaryOperatorExpression(binaryOperatorExpression, data) end
---@param blockStatement ICSharpCode.NRefactory.Ast.BlockStatement
---@param data System.Object
---@return System.Object
function m:VisitBlockStatement(blockStatement, data) end
---@param breakStatement ICSharpCode.NRefactory.Ast.BreakStatement
---@param data System.Object
---@return System.Object
function m:VisitBreakStatement(breakStatement, data) end
---@param caseLabel ICSharpCode.NRefactory.Ast.CaseLabel
---@param data System.Object
---@return System.Object
function m:VisitCaseLabel(caseLabel, data) end
---@param castExpression ICSharpCode.NRefactory.Ast.CastExpression
---@param data System.Object
---@return System.Object
function m:VisitCastExpression(castExpression, data) end
---@param catchClause ICSharpCode.NRefactory.Ast.CatchClause
---@param data System.Object
---@return System.Object
function m:VisitCatchClause(catchClause, data) end
---@param checkedExpression ICSharpCode.NRefactory.Ast.CheckedExpression
---@param data System.Object
---@return System.Object
function m:VisitCheckedExpression(checkedExpression, data) end
---@param checkedStatement ICSharpCode.NRefactory.Ast.CheckedStatement
---@param data System.Object
---@return System.Object
function m:VisitCheckedStatement(checkedStatement, data) end
---@param classReferenceExpression ICSharpCode.NRefactory.Ast.ClassReferenceExpression
---@param data System.Object
---@return System.Object
function m:VisitClassReferenceExpression(classReferenceExpression, data) end
---@param collectionInitializerExpression ICSharpCode.NRefactory.Ast.CollectionInitializerExpression
---@param data System.Object
---@return System.Object
function m:VisitCollectionInitializerExpression(collectionInitializerExpression, data) end
---@param compilationUnit ICSharpCode.NRefactory.Ast.CompilationUnit
---@param data System.Object
---@return System.Object
function m:VisitCompilationUnit(compilationUnit, data) end
---@param conditionalExpression ICSharpCode.NRefactory.Ast.ConditionalExpression
---@param data System.Object
---@return System.Object
function m:VisitConditionalExpression(conditionalExpression, data) end
---@param constructorDeclaration ICSharpCode.NRefactory.Ast.ConstructorDeclaration
---@param data System.Object
---@return System.Object
function m:VisitConstructorDeclaration(constructorDeclaration, data) end
---@param constructorInitializer ICSharpCode.NRefactory.Ast.ConstructorInitializer
---@param data System.Object
---@return System.Object
function m:VisitConstructorInitializer(constructorInitializer, data) end
---@param continueStatement ICSharpCode.NRefactory.Ast.ContinueStatement
---@param data System.Object
---@return System.Object
function m:VisitContinueStatement(continueStatement, data) end
---@param declareDeclaration ICSharpCode.NRefactory.Ast.DeclareDeclaration
---@param data System.Object
---@return System.Object
function m:VisitDeclareDeclaration(declareDeclaration, data) end
---@param defaultValueExpression ICSharpCode.NRefactory.Ast.DefaultValueExpression
---@param data System.Object
---@return System.Object
function m:VisitDefaultValueExpression(defaultValueExpression, data) end
---@param delegateDeclaration ICSharpCode.NRefactory.Ast.DelegateDeclaration
---@param data System.Object
---@return System.Object
function m:VisitDelegateDeclaration(delegateDeclaration, data) end
---@param destructorDeclaration ICSharpCode.NRefactory.Ast.DestructorDeclaration
---@param data System.Object
---@return System.Object
function m:VisitDestructorDeclaration(destructorDeclaration, data) end
---@param directionExpression ICSharpCode.NRefactory.Ast.DirectionExpression
---@param data System.Object
---@return System.Object
function m:VisitDirectionExpression(directionExpression, data) end
---@param doLoopStatement ICSharpCode.NRefactory.Ast.DoLoopStatement
---@param data System.Object
---@return System.Object
function m:VisitDoLoopStatement(doLoopStatement, data) end
---@param elseIfSection ICSharpCode.NRefactory.Ast.ElseIfSection
---@param data System.Object
---@return System.Object
function m:VisitElseIfSection(elseIfSection, data) end
---@param emptyStatement ICSharpCode.NRefactory.Ast.EmptyStatement
---@param data System.Object
---@return System.Object
function m:VisitEmptyStatement(emptyStatement, data) end
---@param endStatement ICSharpCode.NRefactory.Ast.EndStatement
---@param data System.Object
---@return System.Object
function m:VisitEndStatement(endStatement, data) end
---@param eraseStatement ICSharpCode.NRefactory.Ast.EraseStatement
---@param data System.Object
---@return System.Object
function m:VisitEraseStatement(eraseStatement, data) end
---@param errorStatement ICSharpCode.NRefactory.Ast.ErrorStatement
---@param data System.Object
---@return System.Object
function m:VisitErrorStatement(errorStatement, data) end
---@param eventAddRegion ICSharpCode.NRefactory.Ast.EventAddRegion
---@param data System.Object
---@return System.Object
function m:VisitEventAddRegion(eventAddRegion, data) end
---@param eventDeclaration ICSharpCode.NRefactory.Ast.EventDeclaration
---@param data System.Object
---@return System.Object
function m:VisitEventDeclaration(eventDeclaration, data) end
---@param eventRaiseRegion ICSharpCode.NRefactory.Ast.EventRaiseRegion
---@param data System.Object
---@return System.Object
function m:VisitEventRaiseRegion(eventRaiseRegion, data) end
---@param eventRemoveRegion ICSharpCode.NRefactory.Ast.EventRemoveRegion
---@param data System.Object
---@return System.Object
function m:VisitEventRemoveRegion(eventRemoveRegion, data) end
---@param exitStatement ICSharpCode.NRefactory.Ast.ExitStatement
---@param data System.Object
---@return System.Object
function m:VisitExitStatement(exitStatement, data) end
---@param expressionRangeVariable ICSharpCode.NRefactory.Ast.ExpressionRangeVariable
---@param data System.Object
---@return System.Object
function m:VisitExpressionRangeVariable(expressionRangeVariable, data) end
---@param expressionStatement ICSharpCode.NRefactory.Ast.ExpressionStatement
---@param data System.Object
---@return System.Object
function m:VisitExpressionStatement(expressionStatement, data) end
---@param externAliasDirective ICSharpCode.NRefactory.Ast.ExternAliasDirective
---@param data System.Object
---@return System.Object
function m:VisitExternAliasDirective(externAliasDirective, data) end
---@param fieldDeclaration ICSharpCode.NRefactory.Ast.FieldDeclaration
---@param data System.Object
---@return System.Object
function m:VisitFieldDeclaration(fieldDeclaration, data) end
---@param fixedStatement ICSharpCode.NRefactory.Ast.FixedStatement
---@param data System.Object
---@return System.Object
function m:VisitFixedStatement(fixedStatement, data) end
---@param foreachStatement ICSharpCode.NRefactory.Ast.ForeachStatement
---@param data System.Object
---@return System.Object
function m:VisitForeachStatement(foreachStatement, data) end
---@param forNextStatement ICSharpCode.NRefactory.Ast.ForNextStatement
---@param data System.Object
---@return System.Object
function m:VisitForNextStatement(forNextStatement, data) end
---@param forStatement ICSharpCode.NRefactory.Ast.ForStatement
---@param data System.Object
---@return System.Object
function m:VisitForStatement(forStatement, data) end
---@param gotoCaseStatement ICSharpCode.NRefactory.Ast.GotoCaseStatement
---@param data System.Object
---@return System.Object
function m:VisitGotoCaseStatement(gotoCaseStatement, data) end
---@param gotoStatement ICSharpCode.NRefactory.Ast.GotoStatement
---@param data System.Object
---@return System.Object
function m:VisitGotoStatement(gotoStatement, data) end
---@param identifierExpression ICSharpCode.NRefactory.Ast.IdentifierExpression
---@param data System.Object
---@return System.Object
function m:VisitIdentifierExpression(identifierExpression, data) end
---@param ifElseStatement ICSharpCode.NRefactory.Ast.IfElseStatement
---@param data System.Object
---@return System.Object
function m:VisitIfElseStatement(ifElseStatement, data) end
---@param indexerDeclaration ICSharpCode.NRefactory.Ast.IndexerDeclaration
---@param data System.Object
---@return System.Object
function m:VisitIndexerDeclaration(indexerDeclaration, data) end
---@param indexerExpression ICSharpCode.NRefactory.Ast.IndexerExpression
---@param data System.Object
---@return System.Object
function m:VisitIndexerExpression(indexerExpression, data) end
---@param innerClassTypeReference ICSharpCode.NRefactory.Ast.InnerClassTypeReference
---@param data System.Object
---@return System.Object
function m:VisitInnerClassTypeReference(innerClassTypeReference, data) end
---@param interfaceImplementation ICSharpCode.NRefactory.Ast.InterfaceImplementation
---@param data System.Object
---@return System.Object
function m:VisitInterfaceImplementation(interfaceImplementation, data) end
---@param invocationExpression ICSharpCode.NRefactory.Ast.InvocationExpression
---@param data System.Object
---@return System.Object
function m:VisitInvocationExpression(invocationExpression, data) end
---@param labelStatement ICSharpCode.NRefactory.Ast.LabelStatement
---@param data System.Object
---@return System.Object
function m:VisitLabelStatement(labelStatement, data) end
---@param lambdaExpression ICSharpCode.NRefactory.Ast.LambdaExpression
---@param data System.Object
---@return System.Object
function m:VisitLambdaExpression(lambdaExpression, data) end
---@param localVariableDeclaration ICSharpCode.NRefactory.Ast.LocalVariableDeclaration
---@param data System.Object
---@return System.Object
function m:VisitLocalVariableDeclaration(localVariableDeclaration, data) end
---@param lockStatement ICSharpCode.NRefactory.Ast.LockStatement
---@param data System.Object
---@return System.Object
function m:VisitLockStatement(lockStatement, data) end
---@param memberReferenceExpression ICSharpCode.NRefactory.Ast.MemberReferenceExpression
---@param data System.Object
---@return System.Object
function m:VisitMemberReferenceExpression(memberReferenceExpression, data) end
---@param methodDeclaration ICSharpCode.NRefactory.Ast.MethodDeclaration
---@param data System.Object
---@return System.Object
function m:VisitMethodDeclaration(methodDeclaration, data) end
---@param namedArgumentExpression ICSharpCode.NRefactory.Ast.NamedArgumentExpression
---@param data System.Object
---@return System.Object
function m:VisitNamedArgumentExpression(namedArgumentExpression, data) end
---@param namespaceDeclaration ICSharpCode.NRefactory.Ast.NamespaceDeclaration
---@param data System.Object
---@return System.Object
function m:VisitNamespaceDeclaration(namespaceDeclaration, data) end
---@param objectCreateExpression ICSharpCode.NRefactory.Ast.ObjectCreateExpression
---@param data System.Object
---@return System.Object
function m:VisitObjectCreateExpression(objectCreateExpression, data) end
---@param onErrorStatement ICSharpCode.NRefactory.Ast.OnErrorStatement
---@param data System.Object
---@return System.Object
function m:VisitOnErrorStatement(onErrorStatement, data) end
---@param operatorDeclaration ICSharpCode.NRefactory.Ast.OperatorDeclaration
---@param data System.Object
---@return System.Object
function m:VisitOperatorDeclaration(operatorDeclaration, data) end
---@param optionDeclaration ICSharpCode.NRefactory.Ast.OptionDeclaration
---@param data System.Object
---@return System.Object
function m:VisitOptionDeclaration(optionDeclaration, data) end
---@param parameterDeclarationExpression ICSharpCode.NRefactory.Ast.ParameterDeclarationExpression
---@param data System.Object
---@return System.Object
function m:VisitParameterDeclarationExpression(parameterDeclarationExpression, data) end
---@param parenthesizedExpression ICSharpCode.NRefactory.Ast.ParenthesizedExpression
---@param data System.Object
---@return System.Object
function m:VisitParenthesizedExpression(parenthesizedExpression, data) end
---@param pointerReferenceExpression ICSharpCode.NRefactory.Ast.PointerReferenceExpression
---@param data System.Object
---@return System.Object
function m:VisitPointerReferenceExpression(pointerReferenceExpression, data) end
---@param primitiveExpression ICSharpCode.NRefactory.Ast.PrimitiveExpression
---@param data System.Object
---@return System.Object
function m:VisitPrimitiveExpression(primitiveExpression, data) end
---@param propertyDeclaration ICSharpCode.NRefactory.Ast.PropertyDeclaration
---@param data System.Object
---@return System.Object
function m:VisitPropertyDeclaration(propertyDeclaration, data) end
---@param propertyGetRegion ICSharpCode.NRefactory.Ast.PropertyGetRegion
---@param data System.Object
---@return System.Object
function m:VisitPropertyGetRegion(propertyGetRegion, data) end
---@param propertySetRegion ICSharpCode.NRefactory.Ast.PropertySetRegion
---@param data System.Object
---@return System.Object
function m:VisitPropertySetRegion(propertySetRegion, data) end
---@param queryExpression ICSharpCode.NRefactory.Ast.QueryExpression
---@param data System.Object
---@return System.Object
function m:VisitQueryExpression(queryExpression, data) end
---@param queryExpressionAggregateClause ICSharpCode.NRefactory.Ast.QueryExpressionAggregateClause
---@param data System.Object
---@return System.Object
function m:VisitQueryExpressionAggregateClause(queryExpressionAggregateClause, data) end
---@param queryExpressionDistinctClause ICSharpCode.NRefactory.Ast.QueryExpressionDistinctClause
---@param data System.Object
---@return System.Object
function m:VisitQueryExpressionDistinctClause(queryExpressionDistinctClause, data) end
---@param queryExpressionFromClause ICSharpCode.NRefactory.Ast.QueryExpressionFromClause
---@param data System.Object
---@return System.Object
function m:VisitQueryExpressionFromClause(queryExpressionFromClause, data) end
---@param queryExpressionGroupClause ICSharpCode.NRefactory.Ast.QueryExpressionGroupClause
---@param data System.Object
---@return System.Object
function m:VisitQueryExpressionGroupClause(queryExpressionGroupClause, data) end
---@param queryExpressionGroupJoinVBClause ICSharpCode.NRefactory.Ast.QueryExpressionGroupJoinVBClause
---@param data System.Object
---@return System.Object
function m:VisitQueryExpressionGroupJoinVBClause(queryExpressionGroupJoinVBClause, data) end
---@param queryExpressionGroupVBClause ICSharpCode.NRefactory.Ast.QueryExpressionGroupVBClause
---@param data System.Object
---@return System.Object
function m:VisitQueryExpressionGroupVBClause(queryExpressionGroupVBClause, data) end
---@param queryExpressionJoinClause ICSharpCode.NRefactory.Ast.QueryExpressionJoinClause
---@param data System.Object
---@return System.Object
function m:VisitQueryExpressionJoinClause(queryExpressionJoinClause, data) end
---@param queryExpressionJoinConditionVB ICSharpCode.NRefactory.Ast.QueryExpressionJoinConditionVB
---@param data System.Object
---@return System.Object
function m:VisitQueryExpressionJoinConditionVB(queryExpressionJoinConditionVB, data) end
---@param queryExpressionJoinVBClause ICSharpCode.NRefactory.Ast.QueryExpressionJoinVBClause
---@param data System.Object
---@return System.Object
function m:VisitQueryExpressionJoinVBClause(queryExpressionJoinVBClause, data) end
---@param queryExpressionLetClause ICSharpCode.NRefactory.Ast.QueryExpressionLetClause
---@param data System.Object
---@return System.Object
function m:VisitQueryExpressionLetClause(queryExpressionLetClause, data) end
---@param queryExpressionLetVBClause ICSharpCode.NRefactory.Ast.QueryExpressionLetVBClause
---@param data System.Object
---@return System.Object
function m:VisitQueryExpressionLetVBClause(queryExpressionLetVBClause, data) end
---@param queryExpressionOrderClause ICSharpCode.NRefactory.Ast.QueryExpressionOrderClause
---@param data System.Object
---@return System.Object
function m:VisitQueryExpressionOrderClause(queryExpressionOrderClause, data) end
---@param queryExpressionOrdering ICSharpCode.NRefactory.Ast.QueryExpressionOrdering
---@param data System.Object
---@return System.Object
function m:VisitQueryExpressionOrdering(queryExpressionOrdering, data) end
---@param queryExpressionPartitionVBClause ICSharpCode.NRefactory.Ast.QueryExpressionPartitionVBClause
---@param data System.Object
---@return System.Object
function m:VisitQueryExpressionPartitionVBClause(queryExpressionPartitionVBClause, data) end
---@param queryExpressionSelectClause ICSharpCode.NRefactory.Ast.QueryExpressionSelectClause
---@param data System.Object
---@return System.Object
function m:VisitQueryExpressionSelectClause(queryExpressionSelectClause, data) end
---@param queryExpressionSelectVBClause ICSharpCode.NRefactory.Ast.QueryExpressionSelectVBClause
---@param data System.Object
---@return System.Object
function m:VisitQueryExpressionSelectVBClause(queryExpressionSelectVBClause, data) end
---@param queryExpressionWhereClause ICSharpCode.NRefactory.Ast.QueryExpressionWhereClause
---@param data System.Object
---@return System.Object
function m:VisitQueryExpressionWhereClause(queryExpressionWhereClause, data) end
---@param raiseEventStatement ICSharpCode.NRefactory.Ast.RaiseEventStatement
---@param data System.Object
---@return System.Object
function m:VisitRaiseEventStatement(raiseEventStatement, data) end
---@param reDimStatement ICSharpCode.NRefactory.Ast.ReDimStatement
---@param data System.Object
---@return System.Object
function m:VisitReDimStatement(reDimStatement, data) end
---@param removeHandlerStatement ICSharpCode.NRefactory.Ast.RemoveHandlerStatement
---@param data System.Object
---@return System.Object
function m:VisitRemoveHandlerStatement(removeHandlerStatement, data) end
---@param resumeStatement ICSharpCode.NRefactory.Ast.ResumeStatement
---@param data System.Object
---@return System.Object
function m:VisitResumeStatement(resumeStatement, data) end
---@param returnStatement ICSharpCode.NRefactory.Ast.ReturnStatement
---@param data System.Object
---@return System.Object
function m:VisitReturnStatement(returnStatement, data) end
---@param sizeOfExpression ICSharpCode.NRefactory.Ast.SizeOfExpression
---@param data System.Object
---@return System.Object
function m:VisitSizeOfExpression(sizeOfExpression, data) end
---@param stackAllocExpression ICSharpCode.NRefactory.Ast.StackAllocExpression
---@param data System.Object
---@return System.Object
function m:VisitStackAllocExpression(stackAllocExpression, data) end
---@param stopStatement ICSharpCode.NRefactory.Ast.StopStatement
---@param data System.Object
---@return System.Object
function m:VisitStopStatement(stopStatement, data) end
---@param switchSection ICSharpCode.NRefactory.Ast.SwitchSection
---@param data System.Object
---@return System.Object
function m:VisitSwitchSection(switchSection, data) end
---@param switchStatement ICSharpCode.NRefactory.Ast.SwitchStatement
---@param data System.Object
---@return System.Object
function m:VisitSwitchStatement(switchStatement, data) end
---@param templateDefinition ICSharpCode.NRefactory.Ast.TemplateDefinition
---@param data System.Object
---@return System.Object
function m:VisitTemplateDefinition(templateDefinition, data) end
---@param thisReferenceExpression ICSharpCode.NRefactory.Ast.ThisReferenceExpression
---@param data System.Object
---@return System.Object
function m:VisitThisReferenceExpression(thisReferenceExpression, data) end
---@param throwStatement ICSharpCode.NRefactory.Ast.ThrowStatement
---@param data System.Object
---@return System.Object
function m:VisitThrowStatement(throwStatement, data) end
---@param tryCatchStatement ICSharpCode.NRefactory.Ast.TryCatchStatement
---@param data System.Object
---@return System.Object
function m:VisitTryCatchStatement(tryCatchStatement, data) end
---@param typeDeclaration ICSharpCode.NRefactory.Ast.TypeDeclaration
---@param data System.Object
---@return System.Object
function m:VisitTypeDeclaration(typeDeclaration, data) end
---@param typeOfExpression ICSharpCode.NRefactory.Ast.TypeOfExpression
---@param data System.Object
---@return System.Object
function m:VisitTypeOfExpression(typeOfExpression, data) end
---@param typeOfIsExpression ICSharpCode.NRefactory.Ast.TypeOfIsExpression
---@param data System.Object
---@return System.Object
function m:VisitTypeOfIsExpression(typeOfIsExpression, data) end
---@param typeReference ICSharpCode.NRefactory.Ast.TypeReference
---@param data System.Object
---@return System.Object
function m:VisitTypeReference(typeReference, data) end
---@param typeReferenceExpression ICSharpCode.NRefactory.Ast.TypeReferenceExpression
---@param data System.Object
---@return System.Object
function m:VisitTypeReferenceExpression(typeReferenceExpression, data) end
---@param unaryOperatorExpression ICSharpCode.NRefactory.Ast.UnaryOperatorExpression
---@param data System.Object
---@return System.Object
function m:VisitUnaryOperatorExpression(unaryOperatorExpression, data) end
---@param uncheckedExpression ICSharpCode.NRefactory.Ast.UncheckedExpression
---@param data System.Object
---@return System.Object
function m:VisitUncheckedExpression(uncheckedExpression, data) end
---@param uncheckedStatement ICSharpCode.NRefactory.Ast.UncheckedStatement
---@param data System.Object
---@return System.Object
function m:VisitUncheckedStatement(uncheckedStatement, data) end
---@param unsafeStatement ICSharpCode.NRefactory.Ast.UnsafeStatement
---@param data System.Object
---@return System.Object
function m:VisitUnsafeStatement(unsafeStatement, data) end
---@param using ICSharpCode.NRefactory.Ast.Using
---@param data System.Object
---@return System.Object
function m:VisitUsing(using, data) end
---@param usingDeclaration ICSharpCode.NRefactory.Ast.UsingDeclaration
---@param data System.Object
---@return System.Object
function m:VisitUsingDeclaration(usingDeclaration, data) end
---@param usingStatement ICSharpCode.NRefactory.Ast.UsingStatement
---@param data System.Object
---@return System.Object
function m:VisitUsingStatement(usingStatement, data) end
---@param variableDeclaration ICSharpCode.NRefactory.Ast.VariableDeclaration
---@param data System.Object
---@return System.Object
function m:VisitVariableDeclaration(variableDeclaration, data) end
---@param withStatement ICSharpCode.NRefactory.Ast.WithStatement
---@param data System.Object
---@return System.Object
function m:VisitWithStatement(withStatement, data) end
---@param yieldStatement ICSharpCode.NRefactory.Ast.YieldStatement
---@param data System.Object
---@return System.Object
function m:VisitYieldStatement(yieldStatement, data) end
ICSharpCode.NRefactory.IAstVisitor=m
return m;