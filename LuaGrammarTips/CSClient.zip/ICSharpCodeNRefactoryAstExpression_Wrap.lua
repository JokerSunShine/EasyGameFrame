---@class ICSharpCodeNRefactoryAstExpression : ICSharpCodeNRefactoryAstAbstractNode
---properties
---@field public Null ICSharpCodeNRefactoryAstExpression
---instance properties
---@field public IsNull SystemBoolean
local m = {};
---@param expression ICSharpCodeNRefactoryAstExpression
---@return ICSharpCodeNRefactoryAstExpression
function m.CheckNull(expression) end
---@param expr ICSharpCodeNRefactoryAstExpression
---@param value SystemInt32
---@return ICSharpCodeNRefactoryAstExpression
function m.AddInteger(expr, value) end
ICSharpCodeNRefactoryAstExpression=m
return m;