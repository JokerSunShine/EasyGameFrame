---@class ICSharpCode.NRefactory.Ast.ReDimStatement : ICSharpCode.NRefactory.Ast.Statement
---instance properties
---@field public ReDimClauses System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.InvocationExpression]
---@field public IsPreserve System.Boolean
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.ReDimStatement=m
return m;