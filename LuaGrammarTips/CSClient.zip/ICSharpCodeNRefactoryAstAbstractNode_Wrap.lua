---@class ICSharpCodeNRefactoryAstAbstractNode
---instance properties
---@field public Parent ICSharpCodeNRefactoryAstINode
---@field public StartLocation ICSharpCodeNRefactoryLocation
---@field public EndLocation ICSharpCodeNRefactoryLocation
---@field public UserData SystemObject
---@field public Children SystemCollectionsGenericList1ICSharpCodeNRefactoryAstINode
local m = {};
---@param collection SystemCollectionsICollection
---@return SystemString
function m.GetCollectionString(collection) end
---@param childNode ICSharpCodeNRefactoryAstINode
function m:AddChild(childNode) end
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptChildren(visitor, data) end
ICSharpCodeNRefactoryAstAbstractNode=m
return m;