---@class backV2.ReqStopAnnounce
---instance properties
---@field public uniqueId System.Int32
---@field public uniqueIdSpecified System.Boolean
local m = {};

backV2.ReqStopAnnounce=m
return m;