---@class ICSharpCode.NRefactory.Ast.Statement : ICSharpCode.NRefactory.Ast.AbstractNode
---properties
---@field public Null ICSharpCode.NRefactory.Ast.Statement
---instance properties
---@field public IsNull System.Boolean
local m = {};
---@param statement ICSharpCode.NRefactory.Ast.Statement
---@return ICSharpCode.NRefactory.Ast.Statement
function m.CheckNull(statement) end
ICSharpCode.NRefactory.Ast.Statement=m
return m;