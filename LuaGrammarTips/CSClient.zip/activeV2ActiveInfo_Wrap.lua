---@class activeV2.ActiveInfo
---instance properties
---@field public activeNumber System.Int32
---@field public activeNumberSpecified System.Boolean
---@field public activeProgress System.Collections.Generic.List1activeV2.ActiveItem
---@field public reward System.Int64
---@field public rewardSpecified System.Boolean
---@field public firstRandomIndex System.Collections.Generic.List1System.Int32
local m = {};

activeV2.ActiveInfo=m
return m;