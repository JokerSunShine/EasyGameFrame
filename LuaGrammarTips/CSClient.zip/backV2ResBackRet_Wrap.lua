---@class backV2.ResBackRet
---instance properties
---@field public ret System.String
---@field public retSpecified System.Boolean
local m = {};

backV2.ResBackRet=m
return m;