---@class ICSharpCode.SharpZipLib.Zip.ZipFile+ZipEntryEnumeration
---instance properties
---@field public Current System.Object
local m = {};
function m:Reset() end
---@return System.Boolean
function m:MoveNext() end
ICSharpCode.SharpZipLib.Zip.ZipFile+ZipEntryEnumeration=m
return m;