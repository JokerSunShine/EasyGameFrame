---@class ICSharpCode.SharpZipLib.SharpZipBaseException : System.ApplicationException
local m = {};
ICSharpCode.SharpZipLib.SharpZipBaseException=m
return m;