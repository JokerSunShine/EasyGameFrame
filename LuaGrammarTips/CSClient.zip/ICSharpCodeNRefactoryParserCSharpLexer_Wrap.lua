---@class ICSharpCodeNRefactoryParserCSharpLexer : ICSharpCodeNRefactoryParserAbstractLexer
---instance properties
---@field public ConditionalCompilationSymbols SystemCollectionsGenericIDictionary2SystemStringSystemObject
local m = {};
---@param targetToken SystemInt32
function m:SkipCurrentBlock(targetToken) end
---@param symbols SystemString
function m:SetConditionalCompilationSymbols(symbols) end
ICSharpCodeNRefactoryParserCSharpLexer=m
return m;