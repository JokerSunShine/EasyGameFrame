---@class ICSharpCode.NRefactory.Ast.TypeReference : ICSharpCode.NRefactory.Ast.AbstractNode
---fields
---@field public StructConstraint ICSharpCode.NRefactory.Ast.TypeReference
---@field public ClassConstraint ICSharpCode.NRefactory.Ast.TypeReference
---@field public NewConstraint ICSharpCode.NRefactory.Ast.TypeReference
---properties
---@field public PrimitiveTypesCSharp System.Collections.Generic.IDictionary`2[System.String,System.String]
---@field public PrimitiveTypesVB System.Collections.Generic.IDictionary`2[System.String,System.String]
---@field public PrimitiveTypesCSharpReverse System.Collections.Generic.IDictionary`2[System.String,System.String]
---@field public PrimitiveTypesVBReverse System.Collections.Generic.IDictionary`2[System.String,System.String]
---@field public Null ICSharpCode.NRefactory.Ast.TypeReference
---instance properties
---@field public Type System.String
---@field public PointerNestingLevel System.Int32
---@field public RankSpecifier System.Int32[]
---@field public GenericTypes System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.TypeReference]
---@field public IsArrayType System.Boolean
---@field public IsNull System.Boolean
---@field public IsGlobal System.Boolean
---@field public IsKeyword System.Boolean
local m = {};
---@param tr ICSharpCode.NRefactory.Ast.TypeReference&
---@return System.String
function m.StripLastIdentifierFromType(tr) end
---@param typeReference ICSharpCode.NRefactory.Ast.TypeReference
---@return ICSharpCode.NRefactory.Ast.TypeReference
function m.CheckNull(typeReference) end
---@param a ICSharpCode.NRefactory.Ast.TypeReference
---@param b ICSharpCode.NRefactory.Ast.TypeReference
---@return System.Boolean
function m.AreEqualReferences(a, b) end
---@return ICSharpCode.NRefactory.Ast.TypeReference
function m:Clone() end
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.TypeReference=m
return m;