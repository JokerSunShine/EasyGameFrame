---@class AnimatedAlpha : UnityEngine.MonoBehaviour
---instance fields
---@field public alpha System.Single
local m = {};

AnimatedAlpha=m
return m;