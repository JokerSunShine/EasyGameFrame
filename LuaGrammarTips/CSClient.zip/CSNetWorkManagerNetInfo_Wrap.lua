---@class CSNetWorkManagerNetInfo : SystemValueType
---instance fields
---@field public msgId SystemInt32
---@field public obj SystemObject
local m = {};
CSNetWorkManagerNetInfo=m
return m;