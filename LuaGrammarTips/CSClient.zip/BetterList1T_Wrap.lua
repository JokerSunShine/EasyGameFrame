---@class BetterList1T
---instance fields
---@field public buffer T
---@field public size System.Int32
---instance properties
---@field public Count System.Int32
---@field public Item T
local m = {};

---@return System.Collections.Generic.IEnumerator1T
function m:GetEnumerator() end
function m:Clear() end
function m:Release() end
---@param item T
function m:Add(item) end
---@param list BetterList1T
function m:AddRange(list) end
function m:Reverse() end
---@param index System.Int32
---@param item T
function m:Insert(index, item) end
---@param item T
---@return System.Boolean
function m:Contains(item) end
---@param item T
---@return System.Int32
function m:IndexOf(item) end
---@param item T
---@return System.Boolean
function m:Remove(item) end
---@param index System.Int32
function m:RemoveAt(index) end
---@return T
function m:Pop() end
---@return T
function m:ToArray() end
---@param comparer BetterList1CompareFuncT
function m:Sort(comparer) end
---@param match System.Predicate1T
---@param list BetterList1T
function m:FindAll(match, list) end
---@param match BetterList1CompareFunc_2T
---@param obj System.Object
---@param list BetterList1T
function m:FindAll(match, obj, list) end
---@param match System.Predicate1T
---@return T
function m:Find(match) end
---@param match BetterList1CompareFunc_2T
---@param obj System.Object
---@return T
function m:Find(match, obj) end
---@param startIndex System.Int32
---@param count System.Int32
---@param list BetterList1T
---@return BetterList1T
function m:GetRange(startIndex, count, list) end
BetterList1T=m
return m;