---@class ICSharpCode.NRefactory.Parser.VB.ParamModifierList
---instance properties
---@field public Modifier ICSharpCode.NRefactory.Ast.ParameterModifiers
---@field public isNone System.Boolean
local m = {};
---@param m ICSharpCode.NRefactory.Ast.ParameterModifiers
function m:Add(m) end
---@param m ICSharpCode.NRefactory.Parser.VB.ParamModifierList
function m:Add(m) end
function m:Check() end
ICSharpCode.NRefactory.Parser.VB.ParamModifierList=m
return m;