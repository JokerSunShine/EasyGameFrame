---@class BossBronPoint
---instance fields
---@field public x System.Int32
---@field public y System.Int32
---@field public showStr System.String
---@field public icon System.String
---@field public color UnityEngine.Color
local m = {};

BossBronPoint=m
return m;