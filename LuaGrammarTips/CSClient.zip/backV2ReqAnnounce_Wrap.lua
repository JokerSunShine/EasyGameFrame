---@class backV2.ReqAnnounce
---instance properties
---@field public announceId System.Int32
---@field public announceIdSpecified System.Boolean
---@field public paramsClient System.Collections.Generic.List1System.String
local m = {};

backV2.ReqAnnounce=m
return m;