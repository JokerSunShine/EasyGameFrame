---@class backV2.ReqFetchMemory
---instance properties
---@field public tableType System.Int32
---@field public tableTypeSpecified System.Boolean
---@field public mid System.Int64
---@field public midSpecified System.Boolean
local m = {};

backV2.ReqFetchMemory=m
return m;