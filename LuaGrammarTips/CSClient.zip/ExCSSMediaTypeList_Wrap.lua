---@class ExCSSMediaTypeList
---instance properties
---@field public Item SystemString
---@field public Count SystemInt32
---@field public MediaType SystemString
local m = {};
---@return SystemString
function m:ToString() end
---@param friendlyFormat SystemBoolean
---@param indentation SystemInt32 @default_value:0
---@return SystemString
function m:ToString(friendlyFormat, indentation) end
---@return SystemCollectionsGenericIEnumerator1SystemString
function m:GetEnumerator() end
ExCSSMediaTypeList=m
return m;