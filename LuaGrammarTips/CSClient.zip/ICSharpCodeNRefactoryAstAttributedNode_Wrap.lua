---@class ICSharpCodeNRefactoryAstAttributedNode : ICSharpCodeNRefactoryAstAbstractNode
---instance properties
---@field public Attributes SystemCollectionsGenericList1ICSharpCodeNRefactoryAstAttributeSection
---@field public Modifier ICSharpCodeNRefactoryAstModifiers
local m = {};
ICSharpCodeNRefactoryAstAttributedNode=m
return m;