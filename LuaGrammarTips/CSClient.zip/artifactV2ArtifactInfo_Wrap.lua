---@class artifactV2.ArtifactInfo
---instance properties
---@field public type System.Int32
---@field public typeSpecified System.Boolean
---@field public bless System.Int32
---@field public blessSpecified System.Boolean
---@field public active System.Boolean
---@field public activeSpecified System.Boolean
---@field public fragments System.Collections.Generic.List1System.Int32
local m = {};

artifactV2.ArtifactInfo=m
return m;