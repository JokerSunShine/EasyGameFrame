---@class ExCSSModelISupportsSelector
---instance properties
---@field public Selector ExCSSBaseSelector
local m = {};
ExCSSModelISupportsSelector=m
return m;