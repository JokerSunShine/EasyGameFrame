---@class ICSharpCodeSharpZipLibCoreFileSystemScanner
---instance fields
---@field public ProcessDirectory ICSharpCodeSharpZipLibCoreProcessDirectoryDelegate
---@field public ProcessFile ICSharpCodeSharpZipLibCoreProcessFileDelegate
---@field public DirectoryFailure ICSharpCodeSharpZipLibCoreDirectoryFailureDelegate
---@field public FileFailure ICSharpCodeSharpZipLibCoreFileFailureDelegate
local m = {};
---@param directory SystemString
---@param e SystemException
function m:OnDirectoryFailure(directory, e) end
---@param file SystemString
---@param e SystemException
function m:OnFileFailure(file, e) end
---@param file SystemString
function m:OnProcessFile(file) end
---@param directory SystemString
---@param hasMatchingFiles SystemBoolean
function m:OnProcessDirectory(directory, hasMatchingFiles) end
---@param directory SystemString
---@param recurse SystemBoolean
function m:Scan(directory, recurse) end
ICSharpCodeSharpZipLibCoreFileSystemScanner=m
return m;