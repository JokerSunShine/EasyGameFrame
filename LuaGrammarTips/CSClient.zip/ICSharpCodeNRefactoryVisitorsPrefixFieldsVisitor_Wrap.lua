---@class ICSharpCodeNRefactoryVisitorsPrefixFieldsVisitor : ICSharpCodeNRefactoryVisitorsAbstractAstVisitor
local m = {};
---@param typeDeclaration ICSharpCodeNRefactoryAstINode
function m:Run(typeDeclaration) end
---@param typeDeclaration ICSharpCodeNRefactoryAstTypeDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitTypeDeclaration(typeDeclaration, data) end
---@param blockStatement ICSharpCodeNRefactoryAstBlockStatement
---@param data SystemObject
---@return SystemObject
function m:VisitBlockStatement(blockStatement, data) end
---@param methodDeclaration ICSharpCodeNRefactoryAstMethodDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitMethodDeclaration(methodDeclaration, data) end
---@param propertyDeclaration ICSharpCodeNRefactoryAstPropertyDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitPropertyDeclaration(propertyDeclaration, data) end
---@param constructorDeclaration ICSharpCodeNRefactoryAstConstructorDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitConstructorDeclaration(constructorDeclaration, data) end
---@param variableDeclaration ICSharpCodeNRefactoryAstVariableDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitVariableDeclaration(variableDeclaration, data) end
---@param parameterDeclarationExpression ICSharpCodeNRefactoryAstParameterDeclarationExpression
---@param data SystemObject
---@return SystemObject
function m:VisitParameterDeclarationExpression(parameterDeclarationExpression, data) end
---@param foreachStatement ICSharpCodeNRefactoryAstForeachStatement
---@param data SystemObject
---@return SystemObject
function m:VisitForeachStatement(foreachStatement, data) end
---@param identifierExpression ICSharpCodeNRefactoryAstIdentifierExpression
---@param data SystemObject
---@return SystemObject
function m:VisitIdentifierExpression(identifierExpression, data) end
---@param fieldReferenceExpression ICSharpCodeNRefactoryAstMemberReferenceExpression
---@param data SystemObject
---@return SystemObject
function m:VisitMemberReferenceExpression(fieldReferenceExpression, data) end
ICSharpCodeNRefactoryVisitorsPrefixFieldsVisitor=m
return m;