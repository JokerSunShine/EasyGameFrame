---@class DropdownSample : UnityEngineMonoBehaviour
local m = {};
function m:OnButtonClick() end
DropdownSample=m
return m;