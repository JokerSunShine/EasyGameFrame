---@class EasyHookInjectionLoaderHostConnectionDataConnectionState
---@field Invalid @0
---@field NoChannel @1
---@field Valid @2147483647
EasyHookInjectionLoaderHostConnectionDataConnectionState=m
return m;