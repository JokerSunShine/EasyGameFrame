---@class ICSharpCode.SharpZipLib.Zip.FastZipEvents
---instance fields
---@field public ProcessDirectory ICSharpCode.SharpZipLib.Core.ProcessDirectoryDelegate
---@field public ProcessFile ICSharpCode.SharpZipLib.Core.ProcessFileDelegate
---@field public DirectoryFailure ICSharpCode.SharpZipLib.Core.DirectoryFailureDelegate
---@field public FileFailure ICSharpCode.SharpZipLib.Core.FileFailureDelegate
local m = {};
---@param directory System.String
---@param e System.Exception
function m:OnDirectoryFailure(directory, e) end
---@param file System.String
---@param e System.Exception
function m:OnFileFailure(file, e) end
---@param file System.String
function m:OnProcessFile(file) end
---@param directory System.String
---@param hasMatchingFiles System.Boolean
function m:OnProcessDirectory(directory, hasMatchingFiles) end
ICSharpCode.SharpZipLib.Zip.FastZipEvents=m
return m;