---@class ExCSS.DirectionMode
---@field LeftToRight @0
---@field RightToLeft @1
ExCSS.DirectionMode=m
return m;