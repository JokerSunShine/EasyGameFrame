---@class Internal.Runtime.Augments.EnvironmentAugments
---fields
---@field public StackTrace System.String
local m = {};
Internal.Runtime.Augments.EnvironmentAugments=m
return m;