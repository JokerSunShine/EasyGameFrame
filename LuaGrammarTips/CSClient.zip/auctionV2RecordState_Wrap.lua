---@class auctionV2.RecordState
---@field CAN_RECEIVE @1
---@field NOT_AVAILABLE @2
---@field HAVE_RECEIVE @3
local m = {};
auctionV2.RecordState=m
return m;