---@class AnimatedColor : UnityEngine.MonoBehaviour
---instance fields
---@field public color UnityEngine.Color
local m = {};

AnimatedColor=m
return m;