---@class artifactV2.ResArtifactActive
---instance properties
---@field public type System.Int32
---@field public typeSpecified System.Boolean
---@field public active System.Boolean
---@field public activeSpecified System.Boolean
---@field public power System.Int32
---@field public powerSpecified System.Boolean
local m = {};

artifactV2.ResArtifactActive=m
return m;