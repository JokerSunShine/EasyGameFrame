---@class ICSharpCodeNRefactoryAstNamedArgumentExpression : ICSharpCodeNRefactoryAstExpression
---instance properties
---@field public Name SystemString
---@field public Expression ICSharpCodeNRefactoryAstExpression
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstNamedArgumentExpression=m
return m;