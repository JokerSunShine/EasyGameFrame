---@class ExCSS.Combinator
---@field Child @0
---@field Descendent @1
---@field AdjacentSibling @2
---@field Sibling @3
---@field Namespace @4
ExCSS.Combinator=m
return m;