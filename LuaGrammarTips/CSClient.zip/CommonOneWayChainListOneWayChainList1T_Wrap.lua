---@class CommonOneWayChainListOneWayChainList1T
---instance properties
---@field public Head CommonOneWayChainListNode1T
---@field public Item T
---@field public Count SystemInt32
local m = {};
---@return SystemInt32
function m:GetLength() end
---@param i SystemInt32
---@return T
function m:GetNodeValue(i) end
---@return SystemBoolean
function m:IsEmpty() end
---@param item T
function m:Append(item) end
---@param item T
---@param i SystemInt32 @default_value:-1
function m:Insert(item, i) end
---@param i SystemInt32
function m:Delete(i) end
function m:Reverse() end
---@return T
function m:GetMiddleValue() end
---@param list CommonOneWayChainListOneWayChainList1T
function m:Merge(list) end
function m:Clear() end
---@return SystemCollectionsIEnumerator
function m:GetEnumerator() end
CommonOneWayChainListOneWayChainList1T=m
return m;