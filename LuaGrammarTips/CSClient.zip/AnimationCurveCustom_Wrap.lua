---@class AnimationCurveCustom : UnityEngine.MonoBehaviour
---instance fields
---@field public CurveList System.Collections.Generic.List1UnityEngine.AnimationCurve
---@field public Normal UnityEngine.AnimationCurve
---@field public SpeedUp UnityEngine.AnimationCurve
---@field public SpeedDown UnityEngine.AnimationCurve
local m = {};

AnimationCurveCustom=m
return m;