---@class ICSharpCodeNRefactoryAstDeclareDeclaration : ICSharpCodeNRefactoryAstParametrizedNode
---instance properties
---@field public Alias SystemString
---@field public Library SystemString
---@field public Charset ICSharpCodeNRefactoryAstCharsetModifier
---@field public TypeReference ICSharpCodeNRefactoryAstTypeReference
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstDeclareDeclaration=m
return m;