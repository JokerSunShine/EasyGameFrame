---@class activityV2.ReqGetFirstKillBossReward
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public cfgId System.Int32
---@field public cfgIdSpecified System.Boolean
local m = {};

activityV2.ReqGetFirstKillBossReward=m
return m;