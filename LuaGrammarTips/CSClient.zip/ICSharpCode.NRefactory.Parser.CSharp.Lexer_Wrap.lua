---@class ICSharpCode.NRefactory.Parser.CSharp.Lexer : ICSharpCode.NRefactory.Parser.AbstractLexer
---instance properties
---@field public ConditionalCompilationSymbols System.Collections.Generic.IDictionary`2[System.String,System.Object]
local m = {};
---@param targetToken System.Int32
function m:SkipCurrentBlock(targetToken) end
---@param symbols System.String
function m:SetConditionalCompilationSymbols(symbols) end
ICSharpCode.NRefactory.Parser.CSharp.Lexer=m
return m;