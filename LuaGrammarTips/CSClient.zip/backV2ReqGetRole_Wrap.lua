---@class backV2.ReqGetRole
---instance properties
---@field public uid System.Int64
---@field public uidSpecified System.Boolean
local m = {};

backV2.ReqGetRole=m
return m;