---@class ExCSS.Comma : ExCSS.Term
local m = {};
---@return System.String
function m:ToString() end
ExCSS.Comma=m
return m;