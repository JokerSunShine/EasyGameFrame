---@class auctionV2.MarketPriceSection
---instance properties
---@field public lid System.Int64
---@field public lidSpecified System.Boolean
---@field public marketPriceSection auctionV2.BaseMarketPriceSection
---@field public otherMarketPriceSection auctionV2.BaseMarketPriceSection
---@field public MarketPriceSectionType System.Int32
---@field public MarketPriceSectionTypeSpecified System.Boolean
---@field public condition auctionV2.BuyProductsCondition
---@field public name System.String
---@field public nameSpecified System.Boolean
local m = {};

auctionV2.MarketPriceSection=m
return m;