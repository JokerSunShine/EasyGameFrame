---@class DataStructTreeBinaryTreePerfectBinaryTreePrefectBinaryTree_Array1T : DataStructTreeBinaryTreeArrayBinaryTreeAbstract1T
---instance properties
---@field public NodeArray T
local m = {};
DataStructTreeBinaryTreePerfectBinaryTreePrefectBinaryTree_Array1T=m
return m;