---@class AcitivityIdType
---@field NONE @0
---@field BUDOUKAI @236
local m = {};
AcitivityIdType=m
return m;