---@class ExCSSPseudoSelectorPrefix
local m = {};
ExCSSPseudoSelectorPrefix=m
return m;