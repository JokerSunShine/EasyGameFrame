---@class auctionV2.AuctionItemLotInfo
---instance properties
---@field public bidderRid System.Int64
---@field public bidderRidSpecified System.Boolean
---@field public bidPrice System.Int64
---@field public bidPriceSpecified System.Boolean
---@field public isPublicity System.Boolean
---@field public isPublicitySpecified System.Boolean
---@field public publicityTime System.Int64
---@field public publicityTimeSpecified System.Boolean
---@field public fixedPrice System.Int32
---@field public fixedPriceSpecified System.Boolean
local m = {};

auctionV2.AuctionItemLotInfo=m
return m;