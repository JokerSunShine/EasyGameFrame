---@class CSObjectWrapEditor.Generator+XluaTypeInfo
---instance fields
---@field public Type System.Type
---@field public FieldInfos System.Collections.Generic.List`1[CSObjectWrapEditor.Generator+XluaFieldInfo]
---@field public FieldGroup System.Collections.Generic.List`1[System.Collections.Generic.List`1[CSObjectWrapEditor.Generator+XluaFieldInfo]]
---@field public IsRoot System.Boolean
local m = {};
CSObjectWrapEditor.Generator+XluaTypeInfo=m
return m;