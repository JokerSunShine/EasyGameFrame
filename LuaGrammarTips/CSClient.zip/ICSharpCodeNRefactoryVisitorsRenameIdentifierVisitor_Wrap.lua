---@class ICSharpCodeNRefactoryVisitorsRenameIdentifierVisitor : ICSharpCodeNRefactoryVisitorsAbstractAstVisitor
local m = {};
---@param identifierExpression ICSharpCodeNRefactoryAstIdentifierExpression
---@param data SystemObject
---@return SystemObject
function m:VisitIdentifierExpression(identifierExpression, data) end
ICSharpCodeNRefactoryVisitorsRenameIdentifierVisitor=m
return m;