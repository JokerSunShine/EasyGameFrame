---@class arenaV2.ResArenaReward
---instance properties
---@field public times System.Int32
---@field public timesSpecified System.Boolean
---@field public rows System.Collections.Generic.List1System.Int32
local m = {};

arenaV2.ResArenaReward=m
return m;