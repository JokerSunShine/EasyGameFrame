---@class ExCSSErrorMessages
local m = {};
ExCSSErrorMessages=m
return m;