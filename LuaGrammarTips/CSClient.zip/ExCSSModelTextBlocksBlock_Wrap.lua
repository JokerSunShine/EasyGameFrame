---@class ExCSSModelTextBlocksBlock
local m = {};
ExCSSModelTextBlocksBlock=m
return m;