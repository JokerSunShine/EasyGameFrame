---@class ICSharpCode.NRefactory.Parser.Errors
---instance fields
---@field public SynErr ICSharpCode.NRefactory.Parser.ErrorCodeProc
---@field public SemErr ICSharpCode.NRefactory.Parser.ErrorCodeProc
---@field public Error ICSharpCode.NRefactory.Parser.ErrorMsgProc
---instance properties
---@field public ErrorOutput System.String
---@field public Count System.Int32
local m = {};
ICSharpCode.NRefactory.Parser.Errors=m
return m;