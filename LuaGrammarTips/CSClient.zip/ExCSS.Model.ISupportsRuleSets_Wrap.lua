---@class ExCSS.Model.ISupportsRuleSets
---instance properties
---@field public RuleSets System.Collections.Generic.List`1[ExCSS.RuleSet]
local m = {};
ExCSS.Model.ISupportsRuleSets=m
return m;