---@class ICSharpCode.SharpZipLib.Zip.ZipInputStream+ReaderDelegate : System.MulticastDelegate
local m = {};
---@param b System.Byte[]
---@param offset System.Int32
---@param length System.Int32
---@return System.Int32
function m:Invoke(b, offset, length) end
---@param b System.Byte[]
---@param offset System.Int32
---@param length System.Int32
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(b, offset, length, callback, object) end
---@param result System.IAsyncResult
---@return System.Int32
function m:EndInvoke(result) end
ICSharpCode.SharpZipLib.Zip.ZipInputStream+ReaderDelegate=m
return m;