---@class ICSharpCode.NRefactory.PrettyPrinter.CSharpOutputVisitor : ICSharpCode.NRefactory.Visitors.NodeTrackingAstVisitor
---instance properties
---@field public Text System.String
---@field public Errors ICSharpCode.NRefactory.Parser.Errors
---@field public Options ICSharpCode.NRefactory.PrettyPrinter.PrettyPrintOptions
---@field public OutputFormatter ICSharpCode.NRefactory.PrettyPrinter.IOutputFormatter
local m = {};
---@param value System.Action`1[ICSharpCode.NRefactory.Ast.INode]
function m:add_BeforeNodeVisit(value) end
---@param value System.Action`1[ICSharpCode.NRefactory.Ast.INode]
function m:remove_BeforeNodeVisit(value) end
---@param value System.Action`1[ICSharpCode.NRefactory.Ast.INode]
function m:add_AfterNodeVisit(value) end
---@param value System.Action`1[ICSharpCode.NRefactory.Ast.INode]
function m:remove_AfterNodeVisit(value) end
---@param compilationUnit ICSharpCode.NRefactory.Ast.CompilationUnit
---@param data System.Object
---@return System.Object
function m:TrackedVisitCompilationUnit(compilationUnit, data) end
---@param typeReference ICSharpCode.NRefactory.Ast.TypeReference
---@param data System.Object
---@return System.Object
function m:TrackedVisitTypeReference(typeReference, data) end
---@param innerClassTypeReference ICSharpCode.NRefactory.Ast.InnerClassTypeReference
---@param data System.Object
---@return System.Object
function m:TrackedVisitInnerClassTypeReference(innerClassTypeReference, data) end
---@param attributeSection ICSharpCode.NRefactory.Ast.AttributeSection
---@param data System.Object
---@return System.Object
function m:TrackedVisitAttributeSection(attributeSection, data) end
---@param attribute ICSharpCode.NRefactory.Ast.Attribute
---@param data System.Object
---@return System.Object
function m:TrackedVisitAttribute(attribute, data) end
---@param namedArgumentExpression ICSharpCode.NRefactory.Ast.NamedArgumentExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitNamedArgumentExpression(namedArgumentExpression, data) end
---@param using ICSharpCode.NRefactory.Ast.Using
---@param data System.Object
---@return System.Object
function m:TrackedVisitUsing(using, data) end
---@param usingDeclaration ICSharpCode.NRefactory.Ast.UsingDeclaration
---@param data System.Object
---@return System.Object
function m:TrackedVisitUsingDeclaration(usingDeclaration, data) end
---@param externAliasDirective ICSharpCode.NRefactory.Ast.ExternAliasDirective
---@param data System.Object
---@return System.Object
function m:TrackedVisitExternAliasDirective(externAliasDirective, data) end
---@param namespaceDeclaration ICSharpCode.NRefactory.Ast.NamespaceDeclaration
---@param data System.Object
---@return System.Object
function m:TrackedVisitNamespaceDeclaration(namespaceDeclaration, data) end
---@param typeDeclaration ICSharpCode.NRefactory.Ast.TypeDeclaration
---@param data System.Object
---@return System.Object
function m:TrackedVisitTypeDeclaration(typeDeclaration, data) end
---@param templateDefinition ICSharpCode.NRefactory.Ast.TemplateDefinition
---@param data System.Object
---@return System.Object
function m:TrackedVisitTemplateDefinition(templateDefinition, data) end
---@param delegateDeclaration ICSharpCode.NRefactory.Ast.DelegateDeclaration
---@param data System.Object
---@return System.Object
function m:TrackedVisitDelegateDeclaration(delegateDeclaration, data) end
---@param optionDeclaration ICSharpCode.NRefactory.Ast.OptionDeclaration
---@param data System.Object
---@return System.Object
function m:TrackedVisitOptionDeclaration(optionDeclaration, data) end
---@param fieldDeclaration ICSharpCode.NRefactory.Ast.FieldDeclaration
---@param data System.Object
---@return System.Object
function m:TrackedVisitFieldDeclaration(fieldDeclaration, data) end
---@param variableDeclaration ICSharpCode.NRefactory.Ast.VariableDeclaration
---@param data System.Object
---@return System.Object
function m:TrackedVisitVariableDeclaration(variableDeclaration, data) end
---@param propertyDeclaration ICSharpCode.NRefactory.Ast.PropertyDeclaration
---@param data System.Object
---@return System.Object
function m:TrackedVisitPropertyDeclaration(propertyDeclaration, data) end
---@param propertyGetRegion ICSharpCode.NRefactory.Ast.PropertyGetRegion
---@param data System.Object
---@return System.Object
function m:TrackedVisitPropertyGetRegion(propertyGetRegion, data) end
---@param propertySetRegion ICSharpCode.NRefactory.Ast.PropertySetRegion
---@param data System.Object
---@return System.Object
function m:TrackedVisitPropertySetRegion(propertySetRegion, data) end
---@param eventDeclaration ICSharpCode.NRefactory.Ast.EventDeclaration
---@param data System.Object
---@return System.Object
function m:TrackedVisitEventDeclaration(eventDeclaration, data) end
---@param eventAddRegion ICSharpCode.NRefactory.Ast.EventAddRegion
---@param data System.Object
---@return System.Object
function m:TrackedVisitEventAddRegion(eventAddRegion, data) end
---@param eventRemoveRegion ICSharpCode.NRefactory.Ast.EventRemoveRegion
---@param data System.Object
---@return System.Object
function m:TrackedVisitEventRemoveRegion(eventRemoveRegion, data) end
---@param eventRaiseRegion ICSharpCode.NRefactory.Ast.EventRaiseRegion
---@param data System.Object
---@return System.Object
function m:TrackedVisitEventRaiseRegion(eventRaiseRegion, data) end
---@param parameterDeclarationExpression ICSharpCode.NRefactory.Ast.ParameterDeclarationExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitParameterDeclarationExpression(parameterDeclarationExpression, data) end
---@param methodDeclaration ICSharpCode.NRefactory.Ast.MethodDeclaration
---@param data System.Object
---@return System.Object
function m:TrackedVisitMethodDeclaration(methodDeclaration, data) end
---@param operatorDeclaration ICSharpCode.NRefactory.Ast.OperatorDeclaration
---@param data System.Object
---@return System.Object
function m:TrackedVisitOperatorDeclaration(operatorDeclaration, data) end
---@param interfaceImplementation ICSharpCode.NRefactory.Ast.InterfaceImplementation
---@param data System.Object
---@return System.Object
function m:TrackedVisitInterfaceImplementation(interfaceImplementation, data) end
---@param constructorDeclaration ICSharpCode.NRefactory.Ast.ConstructorDeclaration
---@param data System.Object
---@return System.Object
function m:TrackedVisitConstructorDeclaration(constructorDeclaration, data) end
---@param constructorInitializer ICSharpCode.NRefactory.Ast.ConstructorInitializer
---@param data System.Object
---@return System.Object
function m:TrackedVisitConstructorInitializer(constructorInitializer, data) end
---@param indexerDeclaration ICSharpCode.NRefactory.Ast.IndexerDeclaration
---@param data System.Object
---@return System.Object
function m:TrackedVisitIndexerDeclaration(indexerDeclaration, data) end
---@param destructorDeclaration ICSharpCode.NRefactory.Ast.DestructorDeclaration
---@param data System.Object
---@return System.Object
function m:TrackedVisitDestructorDeclaration(destructorDeclaration, data) end
---@param declareDeclaration ICSharpCode.NRefactory.Ast.DeclareDeclaration
---@param data System.Object
---@return System.Object
function m:TrackedVisitDeclareDeclaration(declareDeclaration, data) end
---@param blockStatement ICSharpCode.NRefactory.Ast.BlockStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitBlockStatement(blockStatement, data) end
---@param addHandlerStatement ICSharpCode.NRefactory.Ast.AddHandlerStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitAddHandlerStatement(addHandlerStatement, data) end
---@param removeHandlerStatement ICSharpCode.NRefactory.Ast.RemoveHandlerStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitRemoveHandlerStatement(removeHandlerStatement, data) end
---@param raiseEventStatement ICSharpCode.NRefactory.Ast.RaiseEventStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitRaiseEventStatement(raiseEventStatement, data) end
---@param eraseStatement ICSharpCode.NRefactory.Ast.EraseStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitEraseStatement(eraseStatement, data) end
---@param errorStatement ICSharpCode.NRefactory.Ast.ErrorStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitErrorStatement(errorStatement, data) end
---@param onErrorStatement ICSharpCode.NRefactory.Ast.OnErrorStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitOnErrorStatement(onErrorStatement, data) end
---@param reDimStatement ICSharpCode.NRefactory.Ast.ReDimStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitReDimStatement(reDimStatement, data) end
---@param expressionStatement ICSharpCode.NRefactory.Ast.ExpressionStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitExpressionStatement(expressionStatement, data) end
---@param localVariableDeclaration ICSharpCode.NRefactory.Ast.LocalVariableDeclaration
---@param data System.Object
---@return System.Object
function m:TrackedVisitLocalVariableDeclaration(localVariableDeclaration, data) end
---@param emptyStatement ICSharpCode.NRefactory.Ast.EmptyStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitEmptyStatement(emptyStatement, data) end
---@param yieldStatement ICSharpCode.NRefactory.Ast.YieldStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitYieldStatement(yieldStatement, data) end
---@param returnStatement ICSharpCode.NRefactory.Ast.ReturnStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitReturnStatement(returnStatement, data) end
---@param ifElseStatement ICSharpCode.NRefactory.Ast.IfElseStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitIfElseStatement(ifElseStatement, data) end
---@param elseIfSection ICSharpCode.NRefactory.Ast.ElseIfSection
---@param data System.Object
---@return System.Object
function m:TrackedVisitElseIfSection(elseIfSection, data) end
---@param forStatement ICSharpCode.NRefactory.Ast.ForStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitForStatement(forStatement, data) end
---@param labelStatement ICSharpCode.NRefactory.Ast.LabelStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitLabelStatement(labelStatement, data) end
---@param gotoStatement ICSharpCode.NRefactory.Ast.GotoStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitGotoStatement(gotoStatement, data) end
---@param switchStatement ICSharpCode.NRefactory.Ast.SwitchStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitSwitchStatement(switchStatement, data) end
---@param switchSection ICSharpCode.NRefactory.Ast.SwitchSection
---@param data System.Object
---@return System.Object
function m:TrackedVisitSwitchSection(switchSection, data) end
---@param caseLabel ICSharpCode.NRefactory.Ast.CaseLabel
---@param data System.Object
---@return System.Object
function m:TrackedVisitCaseLabel(caseLabel, data) end
---@param breakStatement ICSharpCode.NRefactory.Ast.BreakStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitBreakStatement(breakStatement, data) end
---@param stopStatement ICSharpCode.NRefactory.Ast.StopStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitStopStatement(stopStatement, data) end
---@param resumeStatement ICSharpCode.NRefactory.Ast.ResumeStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitResumeStatement(resumeStatement, data) end
---@param endStatement ICSharpCode.NRefactory.Ast.EndStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitEndStatement(endStatement, data) end
---@param continueStatement ICSharpCode.NRefactory.Ast.ContinueStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitContinueStatement(continueStatement, data) end
---@param gotoCaseStatement ICSharpCode.NRefactory.Ast.GotoCaseStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitGotoCaseStatement(gotoCaseStatement, data) end
---@param doLoopStatement ICSharpCode.NRefactory.Ast.DoLoopStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitDoLoopStatement(doLoopStatement, data) end
---@param foreachStatement ICSharpCode.NRefactory.Ast.ForeachStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitForeachStatement(foreachStatement, data) end
---@param lockStatement ICSharpCode.NRefactory.Ast.LockStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitLockStatement(lockStatement, data) end
---@param usingStatement ICSharpCode.NRefactory.Ast.UsingStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitUsingStatement(usingStatement, data) end
---@param withStatement ICSharpCode.NRefactory.Ast.WithStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitWithStatement(withStatement, data) end
---@param tryCatchStatement ICSharpCode.NRefactory.Ast.TryCatchStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitTryCatchStatement(tryCatchStatement, data) end
---@param catchClause ICSharpCode.NRefactory.Ast.CatchClause
---@param data System.Object
---@return System.Object
function m:TrackedVisitCatchClause(catchClause, data) end
---@param throwStatement ICSharpCode.NRefactory.Ast.ThrowStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitThrowStatement(throwStatement, data) end
---@param fixedStatement ICSharpCode.NRefactory.Ast.FixedStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitFixedStatement(fixedStatement, data) end
---@param unsafeStatement ICSharpCode.NRefactory.Ast.UnsafeStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitUnsafeStatement(unsafeStatement, data) end
---@param checkedStatement ICSharpCode.NRefactory.Ast.CheckedStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitCheckedStatement(checkedStatement, data) end
---@param uncheckedStatement ICSharpCode.NRefactory.Ast.UncheckedStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitUncheckedStatement(uncheckedStatement, data) end
---@param exitStatement ICSharpCode.NRefactory.Ast.ExitStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitExitStatement(exitStatement, data) end
---@param forNextStatement ICSharpCode.NRefactory.Ast.ForNextStatement
---@param data System.Object
---@return System.Object
function m:TrackedVisitForNextStatement(forNextStatement, data) end
---@param classReferenceExpression ICSharpCode.NRefactory.Ast.ClassReferenceExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitClassReferenceExpression(classReferenceExpression, data) end
---@param primitiveExpression ICSharpCode.NRefactory.Ast.PrimitiveExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitPrimitiveExpression(primitiveExpression, data) end
---@param binaryOperatorExpression ICSharpCode.NRefactory.Ast.BinaryOperatorExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitBinaryOperatorExpression(binaryOperatorExpression, data) end
---@param parenthesizedExpression ICSharpCode.NRefactory.Ast.ParenthesizedExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitParenthesizedExpression(parenthesizedExpression, data) end
---@param invocationExpression ICSharpCode.NRefactory.Ast.InvocationExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitInvocationExpression(invocationExpression, data) end
---@param identifierExpression ICSharpCode.NRefactory.Ast.IdentifierExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitIdentifierExpression(identifierExpression, data) end
---@param typeReferenceExpression ICSharpCode.NRefactory.Ast.TypeReferenceExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitTypeReferenceExpression(typeReferenceExpression, data) end
---@param unaryOperatorExpression ICSharpCode.NRefactory.Ast.UnaryOperatorExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitUnaryOperatorExpression(unaryOperatorExpression, data) end
---@param assignmentExpression ICSharpCode.NRefactory.Ast.AssignmentExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitAssignmentExpression(assignmentExpression, data) end
---@param sizeOfExpression ICSharpCode.NRefactory.Ast.SizeOfExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitSizeOfExpression(sizeOfExpression, data) end
---@param typeOfExpression ICSharpCode.NRefactory.Ast.TypeOfExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitTypeOfExpression(typeOfExpression, data) end
---@param defaultValueExpression ICSharpCode.NRefactory.Ast.DefaultValueExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitDefaultValueExpression(defaultValueExpression, data) end
---@param typeOfIsExpression ICSharpCode.NRefactory.Ast.TypeOfIsExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitTypeOfIsExpression(typeOfIsExpression, data) end
---@param addressOfExpression ICSharpCode.NRefactory.Ast.AddressOfExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitAddressOfExpression(addressOfExpression, data) end
---@param anonymousMethodExpression ICSharpCode.NRefactory.Ast.AnonymousMethodExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitAnonymousMethodExpression(anonymousMethodExpression, data) end
---@param lambdaExpression ICSharpCode.NRefactory.Ast.LambdaExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitLambdaExpression(lambdaExpression, data) end
---@param checkedExpression ICSharpCode.NRefactory.Ast.CheckedExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitCheckedExpression(checkedExpression, data) end
---@param uncheckedExpression ICSharpCode.NRefactory.Ast.UncheckedExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitUncheckedExpression(uncheckedExpression, data) end
---@param pointerReferenceExpression ICSharpCode.NRefactory.Ast.PointerReferenceExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitPointerReferenceExpression(pointerReferenceExpression, data) end
---@param castExpression ICSharpCode.NRefactory.Ast.CastExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitCastExpression(castExpression, data) end
---@param stackAllocExpression ICSharpCode.NRefactory.Ast.StackAllocExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitStackAllocExpression(stackAllocExpression, data) end
---@param indexerExpression ICSharpCode.NRefactory.Ast.IndexerExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitIndexerExpression(indexerExpression, data) end
---@param thisReferenceExpression ICSharpCode.NRefactory.Ast.ThisReferenceExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitThisReferenceExpression(thisReferenceExpression, data) end
---@param baseReferenceExpression ICSharpCode.NRefactory.Ast.BaseReferenceExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitBaseReferenceExpression(baseReferenceExpression, data) end
---@param objectCreateExpression ICSharpCode.NRefactory.Ast.ObjectCreateExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitObjectCreateExpression(objectCreateExpression, data) end
---@param arrayCreateExpression ICSharpCode.NRefactory.Ast.ArrayCreateExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitArrayCreateExpression(arrayCreateExpression, data) end
---@param memberReferenceExpression ICSharpCode.NRefactory.Ast.MemberReferenceExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitMemberReferenceExpression(memberReferenceExpression, data) end
---@param directionExpression ICSharpCode.NRefactory.Ast.DirectionExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitDirectionExpression(directionExpression, data) end
---@param arrayInitializerExpression ICSharpCode.NRefactory.Ast.CollectionInitializerExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitCollectionInitializerExpression(arrayInitializerExpression, data) end
---@param conditionalExpression ICSharpCode.NRefactory.Ast.ConditionalExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitConditionalExpression(conditionalExpression, data) end
function m:Reset() end
---@param queryExpression ICSharpCode.NRefactory.Ast.QueryExpression
---@param data System.Object
---@return System.Object
function m:TrackedVisitQueryExpression(queryExpression, data) end
---@param fromClause ICSharpCode.NRefactory.Ast.QueryExpressionFromClause
---@param data System.Object
---@return System.Object
function m:TrackedVisitQueryExpressionFromClause(fromClause, data) end
---@param joinClause ICSharpCode.NRefactory.Ast.QueryExpressionJoinClause
---@param data System.Object
---@return System.Object
function m:TrackedVisitQueryExpressionJoinClause(joinClause, data) end
---@param letClause ICSharpCode.NRefactory.Ast.QueryExpressionLetClause
---@param data System.Object
---@return System.Object
function m:TrackedVisitQueryExpressionLetClause(letClause, data) end
---@param groupClause ICSharpCode.NRefactory.Ast.QueryExpressionGroupClause
---@param data System.Object
---@return System.Object
function m:TrackedVisitQueryExpressionGroupClause(groupClause, data) end
---@param queryExpressionOrderClause ICSharpCode.NRefactory.Ast.QueryExpressionOrderClause
---@param data System.Object
---@return System.Object
function m:TrackedVisitQueryExpressionOrderClause(queryExpressionOrderClause, data) end
---@param ordering ICSharpCode.NRefactory.Ast.QueryExpressionOrdering
---@param data System.Object
---@return System.Object
function m:TrackedVisitQueryExpressionOrdering(ordering, data) end
---@param selectClause ICSharpCode.NRefactory.Ast.QueryExpressionSelectClause
---@param data System.Object
---@return System.Object
function m:TrackedVisitQueryExpressionSelectClause(selectClause, data) end
---@param whereClause ICSharpCode.NRefactory.Ast.QueryExpressionWhereClause
---@param data System.Object
---@return System.Object
function m:TrackedVisitQueryExpressionWhereClause(whereClause, data) end
ICSharpCode.NRefactory.PrettyPrinter.CSharpOutputVisitor=m
return m;