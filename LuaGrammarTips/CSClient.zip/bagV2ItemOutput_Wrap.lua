---@class bagV2.ItemOutput
---instance properties
---@field public itemId System.Int32
---@field public itemIdSpecified System.Boolean
---@field public number System.Int64
---@field public numberSpecified System.Boolean
local m = {};

bagV2.ItemOutput=m
return m;