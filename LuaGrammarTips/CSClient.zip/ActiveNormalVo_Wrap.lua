---@class ActiveNormalVo
---fields
---@field public titleName System.String
---instance properties
---@field public getCount System.Int32
---@field public hasCompleteItem System.Boolean
---@field public id System.Int32
---@field public completeCount System.Int32
---@field public clientActiveNum System.Int32
---@field public activeTable TABLE.CFG_ACTIVE
local m = {};

---@param activeItem activeV2.ActiveItem
---@return System.Boolean
function m:UpdateVo(activeItem) end
---@return System.Collections.Generic.List1System.Int32
function m:GetActiveReward() end
---@return System.Boolean
function m:IsComplete() end
---@return System.Collections.Generic.List1TaskShowInfo
function m:GetDailyTaskShowInfo() end
---@return System.String
function m:GetActiveDes() end
ActiveNormalVo=m
return m;