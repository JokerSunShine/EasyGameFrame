---@class auctionV2.SalfProductsSortType
---@field OVERDUETIME @1
---@field BIDPRICE @2
---@field FIXEDPRICE @3
---@field PRICE @4
---@field BUYPRODUCTSPRICE @5
---@field PUTONTIME @6
local m = {};
auctionV2.SalfProductsSortType=m
return m;