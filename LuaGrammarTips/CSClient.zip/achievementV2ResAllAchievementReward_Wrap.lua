---@class achievementV2.ResAllAchievementReward
---instance properties
---@field public rewardList System.Collections.Generic.List1System.Int32
local m = {};

achievementV2.ResAllAchievementReward=m
return m;