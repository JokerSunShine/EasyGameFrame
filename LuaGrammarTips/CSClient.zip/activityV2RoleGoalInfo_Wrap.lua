---@class activityV2.RoleGoalInfo
---instance properties
---@field public goalId System.Int32
---@field public goalIdSpecified System.Boolean
---@field public ok System.Boolean
---@field public okSpecified System.Boolean
---@field public count System.Int32
---@field public countSpecified System.Boolean
local m = {};

activityV2.RoleGoalInfo=m
return m;