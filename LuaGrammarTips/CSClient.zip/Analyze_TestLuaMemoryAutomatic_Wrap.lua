---@class Analyze_TestLuaMemoryAutomatic : UnityEngine.MonoBehaviour
---instance fields
---@field public target Analyze_TestLuaMemory
---@field public isOperating System.Boolean
local m = {};

function m:StartAutoTest() end
function m:FinishAutoTest() end
Analyze_TestLuaMemoryAutomatic=m
return m;