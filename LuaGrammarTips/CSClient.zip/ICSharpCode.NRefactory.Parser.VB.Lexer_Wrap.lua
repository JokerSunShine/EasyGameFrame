---@class ICSharpCode.NRefactory.Parser.VB.Lexer : ICSharpCode.NRefactory.Parser.AbstractLexer
local m = {};
---@return ICSharpCode.NRefactory.Parser.Token
function m:NextToken() end
---@param targetToken System.Int32
function m:SkipCurrentBlock(targetToken) end
ICSharpCode.NRefactory.Parser.VB.Lexer=m
return m;