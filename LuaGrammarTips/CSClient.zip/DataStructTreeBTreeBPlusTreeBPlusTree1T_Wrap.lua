---@class DataStructTreeBTreeBPlusTreeBPlusTree1T : DataStructTreeBTreeBaseBTreeBase1T
local m = {};
---@param data T
function m:Insert(data) end
---@param data T
function m:Delete(data) end
---@param traversaList CommonOneWayChainListOneWayChainList1T
---@param action SystemAction1T @default_value:
function m:Traversal(traversaList, action) end
---@param data T
---@return DataStructTreeBTreeBaseBTreeNodeBase1T
function m:FindValue(data) end
---@param data T
---@return SystemBoolean
function m:HaveValue(data) end
DataStructTreeBTreeBPlusTreeBPlusTree1T=m
return m;