---@class ICSharpCodeSharpZipLibZipZipEntry
---instance properties
---@field public IsCrypted SystemBoolean
---@field public Flags SystemInt32
---@field public ZipFileIndex SystemInt32
---@field public Offset SystemInt32
---@field public ExternalFileAttributes SystemInt32
---@field public VersionMadeBy SystemInt32
---@field public HostSystem SystemInt32
---@field public Version SystemInt32
---@field public RequiresZip64 SystemBoolean
---@field public DosTime SystemInt64
---@field public DateTime SystemDateTime
---@field public Name SystemString
---@field public Size SystemInt64
---@field public CompressedSize SystemInt64
---@field public Crc SystemInt64
---@field public CompressionMethod ICSharpCodeSharpZipLibZipCompressionMethod
---@field public ExtraData SystemByte
---@field public Comment SystemString
---@field public IsDirectory SystemBoolean
---@field public IsFile SystemBoolean
local m = {};
---@param name SystemString
---@param relativePath SystemBoolean
---@return SystemString
function m.CleanName(name, relativePath) end
---@param name SystemString
---@return SystemString
function m.CleanName(name) end
---@return SystemObject
function m:Clone() end
---@return SystemString
function m:ToString() end
ICSharpCodeSharpZipLibZipZipEntry=m
return m;