---@class ICSharpCodeSharpZipLibZipCompressionStreamsDeflaterOutputStream : SystemIOStream
---instance properties
---@field public IsStreamOwner SystemBoolean
---@field public CanPatchEntries SystemBoolean
---@field public CanRead SystemBoolean
---@field public CanSeek SystemBoolean
---@field public CanWrite SystemBoolean
---@field public Length SystemInt64
---@field public Position SystemInt64
---@field public Password SystemString
local m = {};
---@param offset SystemInt64
---@param origin SystemIOSeekOrigin
---@return SystemInt64
function m:Seek(offset, origin) end
---@param val SystemInt64
function m:SetLength(val) end
---@return SystemInt32
function m:ReadByte() end
---@param b SystemByte
---@param off SystemInt32
---@param len SystemInt32
---@return SystemInt32
function m:Read(b, off, len) end
---@param buffer SystemByte
---@param offset SystemInt32
---@param count SystemInt32
---@param callback SystemAsyncCallback
---@param state SystemObject
---@return SystemIAsyncResult
function m:BeginRead(buffer, offset, count, callback, state) end
---@param buffer SystemByte
---@param offset SystemInt32
---@param count SystemInt32
---@param callback SystemAsyncCallback
---@param state SystemObject
---@return SystemIAsyncResult
function m:BeginWrite(buffer, offset, count, callback, state) end
function m:Flush() end
function m:Finish() end
function m:Close() end
---@param bval SystemByte
function m:WriteByte(bval) end
---@param buf SystemByte
---@param off SystemInt32
---@param len SystemInt32
function m:Write(buf, off, len) end
ICSharpCodeSharpZipLibZipCompressionStreamsDeflaterOutputStream=m
return m;