---@class ICSharpCodeNRefactoryAstForStatement : ICSharpCodeNRefactoryAstStatementWithEmbeddedStatement
---instance properties
---@field public Initializers SystemCollectionsGenericList1ICSharpCodeNRefactoryAstStatement
---@field public Condition ICSharpCodeNRefactoryAstExpression
---@field public Iterator SystemCollectionsGenericList1ICSharpCodeNRefactoryAstStatement
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstForStatement=m
return m;