---@class DataStructTreeHeapIHeap1T
---instance properties
---@field public Count SystemInt32
local m = {};
---@param data T
function m:Push(data) end
---@param index SystemInt32
---@return T
function m:RemoveByIndex(index) end
---@param data T
---@return SystemBoolean
function m:Remove(data) end
---@param data T
---@return SystemBoolean
function m:Find(data) end
---@param data T
---@return SystemInt32
function m:FindIndex(data) end
DataStructTreeHeapIHeap1T=m
return m;