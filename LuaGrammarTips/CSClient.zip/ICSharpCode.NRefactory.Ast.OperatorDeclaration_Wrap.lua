---@class ICSharpCode.NRefactory.Ast.OperatorDeclaration : ICSharpCode.NRefactory.Ast.MethodDeclaration
---instance properties
---@field public ConversionType ICSharpCode.NRefactory.Ast.ConversionType
---@field public ReturnTypeAttributes System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.AttributeSection]
---@field public OverloadableOperator ICSharpCode.NRefactory.Ast.OverloadableOperatorType
---@field public IsConversionOperator System.Boolean
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.OperatorDeclaration=m
return m;