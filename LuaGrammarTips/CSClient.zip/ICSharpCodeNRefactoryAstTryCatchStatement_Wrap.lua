---@class ICSharpCodeNRefactoryAstTryCatchStatement : ICSharpCodeNRefactoryAstStatement
---instance properties
---@field public StatementBlock ICSharpCodeNRefactoryAstStatement
---@field public CatchClauses SystemCollectionsGenericList1ICSharpCodeNRefactoryAstCatchClause
---@field public FinallyBlock ICSharpCodeNRefactoryAstStatement
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstTryCatchStatement=m
return m;