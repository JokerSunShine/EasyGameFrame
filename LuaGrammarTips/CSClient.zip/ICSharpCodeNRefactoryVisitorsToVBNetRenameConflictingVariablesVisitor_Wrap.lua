---@class ICSharpCodeNRefactoryVisitorsToVBNetRenameConflictingVariablesVisitor
local m = {};
---@param method ICSharpCodeNRefactoryAstParametrizedNode
function m.RenameConflicting(method) end
ICSharpCodeNRefactoryVisitorsToVBNetRenameConflictingVariablesVisitor=m
return m;