---@class bagV2.UpdateItemOutput
---instance properties
---@field public maxOpenDayOfAll System.Int32
---@field public maxOpenDayOfAllSpecified System.Boolean
---@field public itemOutputs System.Collections.Generic.List1bagV2.ItemOutput
local m = {};

bagV2.UpdateItemOutput=m
return m;