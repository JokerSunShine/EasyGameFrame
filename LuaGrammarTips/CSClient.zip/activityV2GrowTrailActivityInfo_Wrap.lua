---@class activityV2.GrowTrailActivityInfo
---instance properties
---@field public dayNo System.Int32
---@field public dayNoSpecified System.Boolean
---@field public group System.Int32
---@field public groupSpecified System.Boolean
---@field public index System.Int32
---@field public indexSpecified System.Boolean
---@field public curCount System.Int32
---@field public curCountSpecified System.Boolean
---@field public rewardState System.Int32
---@field public rewardStateSpecified System.Boolean
local m = {};

activityV2.GrowTrailActivityInfo=m
return m;