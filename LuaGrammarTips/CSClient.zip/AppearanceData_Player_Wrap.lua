---@class AppearanceData_Player : AppearanceData
local m = {};

AppearanceData_Player=m
return m;