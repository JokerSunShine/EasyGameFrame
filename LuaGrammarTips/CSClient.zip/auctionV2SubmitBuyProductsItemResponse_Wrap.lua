---@class auctionV2.SubmitBuyProductsItemResponse
---instance properties
---@field public lid System.Int64
---@field public lidSpecified System.Boolean
---@field public item auctionV2.AuctionItemInfo
---@field public leftCount System.Int32
---@field public leftCountSpecified System.Boolean
local m = {};

auctionV2.SubmitBuyProductsItemResponse=m
return m;