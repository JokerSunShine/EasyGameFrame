---@class artifactV2.ReqArtifactActive
---instance properties
---@field public type System.Int32
---@field public typeSpecified System.Boolean
local m = {};

artifactV2.ReqArtifactActive=m
return m;