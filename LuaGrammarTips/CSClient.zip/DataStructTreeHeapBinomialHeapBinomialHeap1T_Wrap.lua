---@class DataStructTreeHeapBinomialHeapBinomialHeap1T
local m = {};
---@param childTree DataStructTreeHeapBinomialHeapNode1T
---@param rootTree DataStructTreeHeapBinomialHeapNode1T
function m.Link(childTree, rootTree) end
---@param tree1 DataStructTreeHeapBinomialHeapNode1T
---@param tree2 DataStructTreeHeapBinomialHeapNode1T
---@return DataStructTreeHeapBinomialHeapNode1T
function m.Merge(tree1, tree2) end
---@param parentNode DataStructTreeHeapBinomialHeapNode1T
---@param compareFunc SystemFunc3TTSystemInt32
---@return DataStructTreeHeapBinomialHeapNode1T
function m.FindMinNode(parentNode, compareFunc) end
---@return T
function m:FindMin() end
---@param data T
---@return SystemBoolean
function m:Contains(data) end
---@param data T
function m:Insert(data) end
---@param data T
---@return DataStructTreeHeapBinomialHeapNode1T
function m:Remove(data) end
---@param node DataStructTreeHeapBinomialHeapNode1T
---@param data T
function m:DecreaseValue(node, data) end
---@param node DataStructTreeHeapBinomialHeapNode1T
---@param data T
function m:IncreaseValue(node, data) end
---@param oldData T
---@param newData T
function m:UpdateData(oldData, newData) end
---@param node DataStructTreeHeapBinomialHeapNode1T
---@param newData T
function m:UpdateDataByNode(node, newData) end
---@param tree1 DataStructTreeHeapBinomialHeapNode1T
---@param tree2 DataStructTreeHeapBinomialHeapNode1T
---@param compareFunc SystemFunc3TTSystemInt32
---@return DataStructTreeHeapBinomialHeapNode1T
function m:Union(tree1, tree2, compareFunc) end
---@param node DataStructTreeHeapBinomialHeapNode1T
---@return DataStructTreeHeapBinomialHeapNode1T
function m:Reverse(node) end
DataStructTreeHeapBinomialHeapBinomialHeap1T=m
return m;