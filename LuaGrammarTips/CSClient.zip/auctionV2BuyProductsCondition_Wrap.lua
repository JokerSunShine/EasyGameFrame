---@class auctionV2.BuyProductsCondition
---instance properties
---@field public itemId System.Int32
---@field public itemIdSpecified System.Boolean
---@field public count System.Int32
---@field public countSpecified System.Boolean
---@field public minLevel System.Int32
---@field public minLevelSpecified System.Boolean
---@field public maxLevel System.Int32
---@field public maxLevelSpecified System.Boolean
---@field public currency System.Int32
---@field public currencySpecified System.Boolean
---@field public sex System.Int32
---@field public sexSpecified System.Boolean
---@field public career System.Int32
---@field public careerSpecified System.Boolean
---@field public screenCondition System.Collections.Generic.List1System.Int32
---@field public propertyTendency System.Int32
---@field public propertyTendencySpecified System.Boolean
local m = {};

auctionV2.BuyProductsCondition=m
return m;