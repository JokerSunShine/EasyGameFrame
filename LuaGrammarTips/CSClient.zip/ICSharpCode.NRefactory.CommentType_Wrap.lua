---@class ICSharpCode.NRefactory.CommentType
---@field Block @0
---@field SingleLine @1
---@field Documentation @2
ICSharpCode.NRefactory.CommentType=m
return m;