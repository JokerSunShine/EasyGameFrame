---@class AppearanceData_MainPlayer : AppearanceData
---instance properties
---@field public IsInPreviewingMode System.Boolean
local m = {};

---@param resGetWearFashion appearanceV2.ResGetWearFashion
function m:RefreshEnabledAppearanceList(resGetWearFashion) end
function m:StartPreview() end
---@param partIndex System.Int32
---@param itemID System.Int32
---@return System.Boolean
function m:SetPreviewAppearance(partIndex, itemID) end
function m:StopPreview() end
AppearanceData_MainPlayer=m
return m;