---@class activityV2.ActivityInfo
---instance properties
---@field public goalInfo System.Collections.Generic.List1activityV2.GoalInfo
local m = {};

activityV2.ActivityInfo=m
return m;