---@class bagV2.CoinInfo
---instance properties
---@field public itemId System.Int32
---@field public itemIdSpecified System.Boolean
---@field public count System.Int64
---@field public countSpecified System.Boolean
local m = {};

bagV2.CoinInfo=m
return m;