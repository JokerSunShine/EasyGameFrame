---@class AncientBossVO : NormalBossVO
---instance properties
---@field public mapId System.Int32
---@field public MapId System.Int32
---@field public killCount System.Int32
local m = {};

---@param bossInfo bossV2.FieldBossInfo
function m:UpdateBossInfo(bossInfo) end
AncientBossVO=m
return m;