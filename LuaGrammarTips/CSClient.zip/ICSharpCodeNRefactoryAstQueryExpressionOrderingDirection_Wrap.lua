---@class ICSharpCodeNRefactoryAstQueryExpressionOrderingDirection
---@field None @0
---@field Ascending @1
---@field Descending @2
ICSharpCodeNRefactoryAstQueryExpressionOrderingDirection=m
return m;