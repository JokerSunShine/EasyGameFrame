---@class ActiveMissionVo : ActiveNormalVo
---instance properties
---@field public getCount System.Int32
---@field public mission CSMission
local m = {};
---@param targetMission CSMission
---@param name System.String
---@param curCount System.Int32 @out
---@param maxCount System.Int32 @out
---@return System.String
function m.GetActiveDes(targetMission, name, curCount, maxCount) end

---@param mission CSMission
function m:UpdateMission(mission) end
---@param itemId System.Int32 @out
---@return TABLE.CFG_RECOMMAND_POSITION
function m:GetMissionItemRecommend(itemId) end
---@return System.Int32
function m:GetDailyTaskType() end
---@return System.Int32
function m:GetItemGetWayTypeByMissionType() end
---@return System.Collections.Generic.List1TaskShowInfo
function m:GetDailyTaskShowInfo() end
---@return System.Int32
function m:GetTaskCanBuyCount() end
---@return System.Boolean
function m:IsComplete() end
ActiveMissionVo=m
return m;