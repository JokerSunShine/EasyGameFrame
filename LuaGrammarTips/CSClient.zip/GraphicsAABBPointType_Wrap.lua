---@class GraphicsAABBPointType
---@field FRONT_LEFT_BELOW @0
---@field FRONT_RIGHT_BELOW @1
---@field FRONT_LEFT_ABOVE @2
---@field FRONT_RIGHT_ABOVE @3
---@field BEHIND_LEFT_BELOW @4
---@field BEHIND_RIGHT_BELOW @5
---@field BEHIND_LEFT_ABOVE @6
---@field BEHIND_RIGHT_ABOVE @7
GraphicsAABBPointType=m
return m;