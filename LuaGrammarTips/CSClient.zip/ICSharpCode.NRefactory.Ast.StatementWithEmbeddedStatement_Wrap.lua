---@class ICSharpCode.NRefactory.Ast.StatementWithEmbeddedStatement : ICSharpCode.NRefactory.Ast.Statement
---instance properties
---@field public EmbeddedStatement ICSharpCode.NRefactory.Ast.Statement
local m = {};
ICSharpCode.NRefactory.Ast.StatementWithEmbeddedStatement=m
return m;