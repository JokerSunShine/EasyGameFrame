---@class ICSharpCode.NRefactory.Visitors.CodeDomVisitor : ICSharpCode.NRefactory.Visitors.AbstractAstVisitor
---instance fields
---@field public codeCompileUnit System.CodeDom.CodeCompileUnit
---instance properties
---@field public EnvironmentInformationProvider ICSharpCode.NRefactory.IEnvironmentInformationProvider
local m = {};
---@param compilationUnit ICSharpCode.NRefactory.Ast.CompilationUnit
---@param data System.Object
---@return System.Object
function m:VisitCompilationUnit(compilationUnit, data) end
---@param namespaceDeclaration ICSharpCode.NRefactory.Ast.NamespaceDeclaration
---@param data System.Object
---@return System.Object
function m:VisitNamespaceDeclaration(namespaceDeclaration, data) end
---@param usingDeclaration ICSharpCode.NRefactory.Ast.UsingDeclaration
---@param data System.Object
---@return System.Object
function m:VisitUsingDeclaration(usingDeclaration, data) end
---@param eventDeclaration ICSharpCode.NRefactory.Ast.EventDeclaration
---@param data System.Object
---@return System.Object
function m:VisitEventDeclaration(eventDeclaration, data) end
---@param attributeSection ICSharpCode.NRefactory.Ast.AttributeSection
---@param data System.Object
---@return System.Object
function m:VisitAttributeSection(attributeSection, data) end
---@param typeReferenceExpression ICSharpCode.NRefactory.Ast.TypeReferenceExpression
---@param data System.Object
---@return System.Object
function m:VisitTypeReferenceExpression(typeReferenceExpression, data) end
---@param typeDeclaration ICSharpCode.NRefactory.Ast.TypeDeclaration
---@param data System.Object
---@return System.Object
function m:VisitTypeDeclaration(typeDeclaration, data) end
---@param delegateDeclaration ICSharpCode.NRefactory.Ast.DelegateDeclaration
---@param data System.Object
---@return System.Object
function m:VisitDelegateDeclaration(delegateDeclaration, data) end
---@param variableDeclaration ICSharpCode.NRefactory.Ast.VariableDeclaration
---@param data System.Object
---@return System.Object
function m:VisitVariableDeclaration(variableDeclaration, data) end
---@param fieldDeclaration ICSharpCode.NRefactory.Ast.FieldDeclaration
---@param data System.Object
---@return System.Object
function m:VisitFieldDeclaration(fieldDeclaration, data) end
---@param methodDeclaration ICSharpCode.NRefactory.Ast.MethodDeclaration
---@param data System.Object
---@return System.Object
function m:VisitMethodDeclaration(methodDeclaration, data) end
---@param propertyDeclaration ICSharpCode.NRefactory.Ast.PropertyDeclaration
---@param data System.Object
---@return System.Object
function m:VisitPropertyDeclaration(propertyDeclaration, data) end
---@param constructorDeclaration ICSharpCode.NRefactory.Ast.ConstructorDeclaration
---@param data System.Object
---@return System.Object
function m:VisitConstructorDeclaration(constructorDeclaration, data) end
---@param blockStatement ICSharpCode.NRefactory.Ast.BlockStatement
---@param data System.Object
---@return System.Object
function m:VisitBlockStatement(blockStatement, data) end
---@param expressionStatement ICSharpCode.NRefactory.Ast.ExpressionStatement
---@param data System.Object
---@return System.Object
function m:VisitExpressionStatement(expressionStatement, data) end
---@param localVariableDeclaration ICSharpCode.NRefactory.Ast.LocalVariableDeclaration
---@param data System.Object
---@return System.Object
function m:VisitLocalVariableDeclaration(localVariableDeclaration, data) end
---@param emptyStatement ICSharpCode.NRefactory.Ast.EmptyStatement
---@param data System.Object
---@return System.Object
function m:VisitEmptyStatement(emptyStatement, data) end
---@param returnStatement ICSharpCode.NRefactory.Ast.ReturnStatement
---@param data System.Object
---@return System.Object
function m:VisitReturnStatement(returnStatement, data) end
---@param ifElseStatement ICSharpCode.NRefactory.Ast.IfElseStatement
---@param data System.Object
---@return System.Object
function m:VisitIfElseStatement(ifElseStatement, data) end
---@param foreachStatement ICSharpCode.NRefactory.Ast.ForeachStatement
---@param data System.Object
---@return System.Object
function m:VisitForeachStatement(foreachStatement, data) end
---@param doLoopStatement ICSharpCode.NRefactory.Ast.DoLoopStatement
---@param data System.Object
---@return System.Object
function m:VisitDoLoopStatement(doLoopStatement, data) end
---@param forStatement ICSharpCode.NRefactory.Ast.ForStatement
---@param data System.Object
---@return System.Object
function m:VisitForStatement(forStatement, data) end
---@param labelStatement ICSharpCode.NRefactory.Ast.LabelStatement
---@param data System.Object
---@return System.Object
function m:VisitLabelStatement(labelStatement, data) end
---@param gotoStatement ICSharpCode.NRefactory.Ast.GotoStatement
---@param data System.Object
---@return System.Object
function m:VisitGotoStatement(gotoStatement, data) end
---@param switchStatement ICSharpCode.NRefactory.Ast.SwitchStatement
---@param data System.Object
---@return System.Object
function m:VisitSwitchStatement(switchStatement, data) end
---@param tryCatchStatement ICSharpCode.NRefactory.Ast.TryCatchStatement
---@param data System.Object
---@return System.Object
function m:VisitTryCatchStatement(tryCatchStatement, data) end
---@param throwStatement ICSharpCode.NRefactory.Ast.ThrowStatement
---@param data System.Object
---@return System.Object
function m:VisitThrowStatement(throwStatement, data) end
---@param fixedStatement ICSharpCode.NRefactory.Ast.FixedStatement
---@param data System.Object
---@return System.Object
function m:VisitFixedStatement(fixedStatement, data) end
---@param primitiveExpression ICSharpCode.NRefactory.Ast.PrimitiveExpression
---@param data System.Object
---@return System.Object
function m:VisitPrimitiveExpression(primitiveExpression, data) end
---@param binaryOperatorExpression ICSharpCode.NRefactory.Ast.BinaryOperatorExpression
---@param data System.Object
---@return System.Object
function m:VisitBinaryOperatorExpression(binaryOperatorExpression, data) end
---@param parenthesizedExpression ICSharpCode.NRefactory.Ast.ParenthesizedExpression
---@param data System.Object
---@return System.Object
function m:VisitParenthesizedExpression(parenthesizedExpression, data) end
---@param invocationExpression ICSharpCode.NRefactory.Ast.InvocationExpression
---@param data System.Object
---@return System.Object
function m:VisitInvocationExpression(invocationExpression, data) end
---@param identifierExpression ICSharpCode.NRefactory.Ast.IdentifierExpression
---@param data System.Object
---@return System.Object
function m:VisitIdentifierExpression(identifierExpression, data) end
---@param unaryOperatorExpression ICSharpCode.NRefactory.Ast.UnaryOperatorExpression
---@param data System.Object
---@return System.Object
function m:VisitUnaryOperatorExpression(unaryOperatorExpression, data) end
---@param assignmentExpression ICSharpCode.NRefactory.Ast.AssignmentExpression
---@param data System.Object
---@return System.Object
function m:VisitAssignmentExpression(assignmentExpression, data) end
---@param addHandlerStatement ICSharpCode.NRefactory.Ast.AddHandlerStatement
---@param data System.Object
---@return System.Object
function m:VisitAddHandlerStatement(addHandlerStatement, data) end
---@param addressOfExpression ICSharpCode.NRefactory.Ast.AddressOfExpression
---@param data System.Object
---@return System.Object
function m:VisitAddressOfExpression(addressOfExpression, data) end
---@param using ICSharpCode.NRefactory.Ast.Using
---@param data System.Object
---@return System.Object
function m:VisitUsing(using, data) end
---@param usingStatement ICSharpCode.NRefactory.Ast.UsingStatement
---@param data System.Object
---@return System.Object
function m:VisitUsingStatement(usingStatement, data) end
---@param typeOfExpression ICSharpCode.NRefactory.Ast.TypeOfExpression
---@param data System.Object
---@return System.Object
function m:VisitTypeOfExpression(typeOfExpression, data) end
---@param castExpression ICSharpCode.NRefactory.Ast.CastExpression
---@param data System.Object
---@return System.Object
function m:VisitCastExpression(castExpression, data) end
---@param indexerExpression ICSharpCode.NRefactory.Ast.IndexerExpression
---@param data System.Object
---@return System.Object
function m:VisitIndexerExpression(indexerExpression, data) end
---@param thisReferenceExpression ICSharpCode.NRefactory.Ast.ThisReferenceExpression
---@param data System.Object
---@return System.Object
function m:VisitThisReferenceExpression(thisReferenceExpression, data) end
---@param baseReferenceExpression ICSharpCode.NRefactory.Ast.BaseReferenceExpression
---@param data System.Object
---@return System.Object
function m:VisitBaseReferenceExpression(baseReferenceExpression, data) end
---@param arrayCreateExpression ICSharpCode.NRefactory.Ast.ArrayCreateExpression
---@param data System.Object
---@return System.Object
function m:VisitArrayCreateExpression(arrayCreateExpression, data) end
---@param objectCreateExpression ICSharpCode.NRefactory.Ast.ObjectCreateExpression
---@param data System.Object
---@return System.Object
function m:VisitObjectCreateExpression(objectCreateExpression, data) end
---@param parameterDeclarationExpression ICSharpCode.NRefactory.Ast.ParameterDeclarationExpression
---@param data System.Object
---@return System.Object
function m:VisitParameterDeclarationExpression(parameterDeclarationExpression, data) end
---@param breakStatement ICSharpCode.NRefactory.Ast.BreakStatement
---@param data System.Object
---@return System.Object
function m:VisitBreakStatement(breakStatement, data) end
---@param continueStatement ICSharpCode.NRefactory.Ast.ContinueStatement
---@param data System.Object
---@return System.Object
function m:VisitContinueStatement(continueStatement, data) end
---@param fieldReferenceExpression ICSharpCode.NRefactory.Ast.MemberReferenceExpression
---@param data System.Object
---@return System.Object
function m:VisitMemberReferenceExpression(fieldReferenceExpression, data) end
ICSharpCode.NRefactory.Visitors.CodeDomVisitor=m
return m;