---@class Analyze_TestUILuaMemoryState
---@field Idle @0
---@field PanelOpened @1
---@field PanelClosed @2
---@field GCing @3
---@field ResultCollecting @4
---@field RapidOpenPanel @5
local m = {};
Analyze_TestUILuaMemoryState=m
return m;