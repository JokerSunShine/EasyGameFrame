---@class ArrestTypeEnum
---@field Monster @1
---@field System @2
---@field NormalPersonal @3
---@field NormalWord @4
local m = {};
ArrestTypeEnum=m
return m;