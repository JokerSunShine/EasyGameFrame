---@class JetBrains.Rider.Unity.Editor.RiderMenu
local m = {};
function m.MenuOpenProject() end
JetBrains.Rider.Unity.Editor.RiderMenu=m
return m;