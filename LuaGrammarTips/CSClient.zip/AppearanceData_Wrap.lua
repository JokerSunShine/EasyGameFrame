---@class AppearanceData : AppearanceDataBasic
---instance fields
---@field public AppearanceEnabledList System.Collections.Generic.Dictionary2System.Int32System.Int32
---instance properties
---@field public Avatar CSAvater
---@field public AppearanceInfo AppearanceInfoBasic
---@field public IsOnceHoldAnyFashion System.Boolean
---@field public FashionList System.Collections.Generic.List1appearanceV2.FashionType
---@field public CurAppellationID System.Int32
---@field public CurAppellationInfo appearanceV2.TitleInfo
---@field public AppellationDic System.Collections.Generic.Dictionary2System.Int32appearanceV2.TitleInfo
---@field public AppellationList System.Collections.Generic.List1appearanceV2.TitleInfo
local m = {};
---@param bagItemInfo bagV2.BagItemInfo
---@return TABLE.CFG_APPEARANCE
function m.GetAppearanceTable(bagItemInfo) end
---@param itemID System.Int32
---@return TABLE.CFG_APPEARANCE
function m.GetAppearanceTable(itemID) end

---@param fashionTypes System.Collections.Generic.List1appearanceV2.FashionType
function m:RefreshFashionList(fashionTypes) end
---@param resGetWearFashion appearanceV2.ResGetWearFashion
function m:RefreshEnabledAppearanceList(resGetWearFashion) end
---@param wearPositions System.Collections.Generic.List1appearanceV2.wearPosition
function m:RefreshEnabledAppearanceList(wearPositions) end
---@param bagItemInfo bagV2.BagItemInfo
---@return System.Boolean
function m:IsFashionEnabled(bagItemInfo) end
---@param partIndex System.Int32
function m:RefreshAppearance(partIndex) end
---@return System.Boolean
function m:IsEmptyAppearanceData() end
---@param itemID System.Int32
---@return bagV2.BagItemInfo
function m:GetBagItemInfoByItemID(itemID) end
---@param appellationInfo appearanceV2.ResGetHasAppellation
function m:RefreshAppellationList(appellationInfo) end
---@param info appearanceV2.ResEnableAppellation
function m:SetCurAppellationInfo(info) end
---@param info appearanceV2.ResModifyTitle
function m:SetCurAppellationInfo(info) end
---@param info appearanceV2.TitleInfo
function m:SetCurAppellationInfo(info) end
function m:Clear() end
AppearanceData=m
return m;