---@class bagV2.TidyItem
---instance properties
---@field public itemId System.Collections.Generic.List1System.Int64
local m = {};

bagV2.TidyItem=m
return m;