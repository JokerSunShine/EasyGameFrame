---@class DynamicTerrainTerrainData : UnityEngineScriptableObject
---instance fields
---@field public mapSize UnityEngineVector2Int
---@field public bloackSize UnityEngineVector2Int
---@field public viewSize UnityEngineVector2Int
---@field public mat UnityEngineMaterial
---@field public mainTex_STs UnityEngineVector4
---@field public heightMapData DynamicTerrainHeightMapData
---@field public lightMap UnityEngineTexture2D
local m = {};
DynamicTerrainTerrainData=m
return m;