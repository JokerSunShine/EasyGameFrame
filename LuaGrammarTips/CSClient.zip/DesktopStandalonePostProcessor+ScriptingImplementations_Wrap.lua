---@class DesktopStandalonePostProcessor+ScriptingImplementations : UnityEditor.Modules.DefaultScriptingImplementations
local m = {};
DesktopStandalonePostProcessor+ScriptingImplementations=m
return m;