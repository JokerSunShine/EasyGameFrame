---@class ICSharpCodeNRefactoryAstQueryExpressionJoinClause : ICSharpCodeNRefactoryAstQueryExpressionFromOrJoinClause
---instance properties
---@field public OnExpression ICSharpCodeNRefactoryAstExpression
---@field public EqualsExpression ICSharpCodeNRefactoryAstExpression
---@field public IntoIdentifier SystemString
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstQueryExpressionJoinClause=m
return m;