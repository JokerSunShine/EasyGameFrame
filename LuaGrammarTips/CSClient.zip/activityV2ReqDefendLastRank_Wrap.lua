---@class activityV2.ReqDefendLastRank
---instance properties
---@field public time System.Int64
local m = {};

activityV2.ReqDefendLastRank=m
return m;