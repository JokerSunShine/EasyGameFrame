---@class activityV2.DefendRank
---instance properties
---@field public selfInfos System.Collections.Generic.List1activityV2.DefendRankPlayerInfo
---@field public otherInfos System.Collections.Generic.List1activityV2.DefendRankPlayerInfo
---@field public common activityV2.DefendRankCommon
local m = {};

activityV2.DefendRank=m
return m;