---@class backV2.ResStopAnnounceResult
---instance properties
---@field public type System.Int32
---@field public typeSpecified System.Boolean
local m = {};

backV2.ResStopAnnounceResult=m
return m;