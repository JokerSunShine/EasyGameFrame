---@class CommonOneWayLoopChainListNode1T
---instance properties
---@field public Data T
---@field public Next CommonOneWayLoopChainListNode1T
local m = {};
---@param item T
---@return CommonOneWayLoopChainListNode1T
function m:AddNext(item) end
---@param node CommonOneWayLoopChainListNode1T
---@return CommonOneWayLoopChainListNode1T
function m:AddNext(node) end
---@return SystemBoolean
function m:HaveData() end
---@return SystemBoolean
function m:HaveNextData() end
CommonOneWayLoopChainListNode1T=m
return m;