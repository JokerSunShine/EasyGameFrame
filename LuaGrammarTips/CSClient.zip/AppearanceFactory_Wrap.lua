---@class AppearanceFactory
---properties
---@field public Instance AppearanceFactory
local m = {};

---@param avatar NewI_CSAvater
---@param avatarType EAvatarType
---@return AppearanceInfoBasic
function m:GetAppearanceInfo(avatar, avatarType) end
---@param avatar NewI_CSAvater
---@param avatarType EAvatarType
---@param appearanceInfo AppearanceInfoBasic
---@return AppearanceDataBasic
function m:GetAppearanceData(avatar, avatarType, appearanceInfo) end
AppearanceFactory=m
return m;