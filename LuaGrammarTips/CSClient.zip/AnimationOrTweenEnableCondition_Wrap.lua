---@class AnimationOrTween.EnableCondition
---@field DoNothing @0
---@field EnableThenPlay @1
---@field IgnoreDisabledState @2
local m = {};
AnimationOrTween.EnableCondition=m
return m;