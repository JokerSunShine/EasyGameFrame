---@class DesktopStandalonePostProcessorScriptingImplementations : UnityEditorModulesDefaultScriptingImplementations
local m = {};
DesktopStandalonePostProcessorScriptingImplementations=m
return m;