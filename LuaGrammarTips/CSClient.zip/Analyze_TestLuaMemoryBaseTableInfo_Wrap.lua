---@class Analyze_TestLuaMemoryBaseTableInfo
---instance fields
---@field public name System.String
---@field public id System.Int32
---@field public size System.Int64
---@field public isOldTable System.Boolean
---@field public type Analyze_TestLuaMemoryBaseTableType
---@field public infos System.Collections.Generic.List1System.String
local m = {};

---@return Analyze_TestLuaMemoryBaseTableInfo
function m:GetDeepCopy() end
Analyze_TestLuaMemoryBaseTableInfo=m
return m;