---@class bagV2.ItemAttribute
---instance properties
---@field public type System.Int32
---@field public num System.Int32
local m = {};

bagV2.ItemAttribute=m
return m;