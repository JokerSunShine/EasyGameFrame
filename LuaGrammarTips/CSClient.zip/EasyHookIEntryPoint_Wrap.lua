---@class EasyHookIEntryPoint
local m = {};
EasyHookIEntryPoint=m
return m;