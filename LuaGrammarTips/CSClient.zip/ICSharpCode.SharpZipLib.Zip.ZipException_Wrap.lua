---@class ICSharpCode.SharpZipLib.Zip.ZipException : ICSharpCode.SharpZipLib.SharpZipBaseException
local m = {};
ICSharpCode.SharpZipLib.Zip.ZipException=m
return m;