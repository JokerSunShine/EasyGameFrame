---@class activityV2.ResGrowTrailInfo
---instance properties
---@field public growTrailDailyInfos System.Collections.Generic.List1activityV2.GrowTrailActivityInfo
---@field public growTrailFinalInfos System.Collections.Generic.List1activityV2.GrowTrailFinalInfo
---@field public completeCount System.Int32
---@field public completeCountSpecified System.Boolean
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
local m = {};

activityV2.ResGrowTrailInfo=m
return m;