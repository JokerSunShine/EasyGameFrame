---@class CommonUtility_Filed
local m = {};
---@param path System.String
---@return System.String
function m.GetFileName(path) end
---@param path System.String
---@return System.String
function m.GetDirectory(path) end
CommonUtility_Filed=m
return m;