---@class CommonUtility_Filed
local m = {};
---@param path SystemString
---@return SystemString
function m.GetFileName(path) end
---@param path SystemString
---@return SystemString
function m.GetDirectory(path) end
CommonUtility_Filed=m
return m;