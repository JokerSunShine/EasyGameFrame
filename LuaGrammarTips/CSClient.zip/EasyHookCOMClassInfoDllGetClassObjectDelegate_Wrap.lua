---@class EasyHookCOMClassInfoDllGetClassObjectDelegate : SystemMulticastDelegate
local m = {};
---@param ClassId SystemGuid
---@param InterfaceId SystemGuid
---@param ppunk SystemObject @out
---@return SystemInt32
function m:Invoke(ClassId, InterfaceId, ppunk) end
---@param ClassId SystemGuid
---@param InterfaceId SystemGuid
---@param ppunk SystemObject @out
---@param callback SystemAsyncCallback
---@param object SystemObject
---@return SystemIAsyncResult
function m:BeginInvoke(ClassId, InterfaceId, ppunk, callback, object) end
---@param ClassId SystemGuid
---@param InterfaceId SystemGuid
---@param ppunk SystemObject @out
---@param result SystemIAsyncResult
---@return SystemInt32
function m:EndInvoke(ClassId, InterfaceId, ppunk, result) end
EasyHookCOMClassInfoDllGetClassObjectDelegate=m
return m;