---@class ILPostProcessCompiledAssembly
---instance properties
---@field public InMemoryAssembly Unity.CompilationPipeline.Common.ILPostProcessing.InMemoryAssembly
---@field public Name System.String
---@field public References System.String[]
---@field public Defines System.String[]
local m = {};
function m:WriteAssembly() end
ILPostProcessCompiledAssembly=m
return m;