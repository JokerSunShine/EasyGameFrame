---@class ConfigXmlTextReader : SystemXmlXmlTextReader
---instance properties
---@field public Filename SystemString
local m = {};
ConfigXmlTextReader=m
return m;