---@class ConfigXmlTextReader : System.Xml.XmlTextReader
---instance properties
---@field public Filename System.String
local m = {};
ConfigXmlTextReader=m
return m;