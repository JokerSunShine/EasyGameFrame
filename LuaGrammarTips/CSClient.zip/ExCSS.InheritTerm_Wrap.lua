---@class ExCSS.InheritTerm : ExCSS.Term
local m = {};
---@return System.String
function m:ToString() end
ExCSS.InheritTerm=m
return m;