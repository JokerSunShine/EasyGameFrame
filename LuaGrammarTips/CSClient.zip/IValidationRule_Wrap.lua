---@class IValidationRule
local m = {};
---@param userAssemblies SystemCollectionsGenericIEnumerable1SystemString
---@param options SystemObject
---@return ValidationResult
function m:Validate(userAssemblies, options) end
IValidationRule=m
return m;