---@class IValidationRule
local m = {};
---@param userAssemblies System.Collections.Generic.IEnumerable`1[System.String]
---@param options System.Object[]
---@return ValidationResult
function m:Validate(userAssemblies, options) end
IValidationRule=m
return m;