---@class FrameworkUtilityTexture
local m = {};
---@param texture2D UnityEngineTexture2D
---@param path SystemString
---@param type FrameworkUtilityTextureTextureFormatType @default_value:PNG
---@return UnityEngineTexture2D
function m.SaveToPic(texture2D, path, type) end
FrameworkUtilityTexture=m
return m;