---@class CommonBothWayChainListNode1T
---instance properties
---@field public Data T
---@field public Next CommonBothWayChainListNode1T
---@field public Prev CommonBothWayChainListNode1T
local m = {};
---@param item T
---@return CommonBothWayChainListNode1T
function m:AddNext(item) end
---@param node CommonBothWayChainListNode1T
---@param prev CommonBothWayChainListNode1T
---@return CommonBothWayChainListNode1T
function m:AddNext(node, prev) end
---@return SystemBoolean
function m:HaveData() end
---@return SystemBoolean
function m:HaveNextData() end
CommonBothWayChainListNode1T=m
return m;