---@class MicrosoftVisualBasicVBCodeGenerator : SystemCodeDomCompilerCodeCompiler
local m = {};
---@param value SystemString
---@return SystemBoolean
function m.IsKeyword(value) end
MicrosoftVisualBasicVBCodeGenerator=m
return m;