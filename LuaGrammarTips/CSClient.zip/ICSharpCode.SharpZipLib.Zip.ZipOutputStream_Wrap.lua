---@class ICSharpCode.SharpZipLib.Zip.ZipOutputStream : ICSharpCode.SharpZipLib.Zip.Compression.Streams.DeflaterOutputStream
---instance properties
---@field public IsFinished System.Boolean
local m = {};
---@param comment System.String
function m:SetComment(comment) end
---@param level System.Int32
function m:SetLevel(level) end
---@return System.Int32
function m:GetLevel() end
---@param entry ICSharpCode.SharpZipLib.Zip.ZipEntry
function m:PutNextEntry(entry) end
function m:CloseEntry() end
---@param b System.Byte[]
---@param off System.Int32
---@param len System.Int32
function m:Write(b, off, len) end
function m:Finish() end
ICSharpCode.SharpZipLib.Zip.ZipOutputStream=m
return m;