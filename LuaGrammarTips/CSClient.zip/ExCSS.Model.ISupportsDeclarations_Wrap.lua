---@class ExCSS.Model.ISupportsDeclarations
---instance properties
---@field public Declarations ExCSS.StyleDeclaration
local m = {};
ExCSS.Model.ISupportsDeclarations=m
return m;