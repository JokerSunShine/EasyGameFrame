---@class CSAndroidPlatformInfo : AbstractPlatformInfo
---fields
---@field public LuaRoot System.String
---@field public XLuaMainPath System.String
local m = {};
CSAndroidPlatformInfo=m
return m;