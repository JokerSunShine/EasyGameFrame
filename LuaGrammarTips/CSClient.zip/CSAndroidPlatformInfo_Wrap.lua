---@class CSAndroidPlatformInfo : AbstractPlatformInfo
---fields
---@field public LuaRoot SystemString
---@field public XLuaMainPath SystemString
local m = {};
CSAndroidPlatformInfo=m
return m;