---@class ICSharpCodeNRefactoryAstCharsetModifier
---@field None @0
---@field Auto @1
---@field Unicode @2
---@field Ansi @3
ICSharpCodeNRefactoryAstCharsetModifier=m
return m;