---@class ExCSSConditionalRule : ExCSSAggregateRule
---instance properties
---@field public Condition SystemString
local m = {};
ExCSSConditionalRule=m
return m;