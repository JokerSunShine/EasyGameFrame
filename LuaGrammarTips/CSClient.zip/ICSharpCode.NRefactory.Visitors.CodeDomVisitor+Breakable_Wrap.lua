---@class ICSharpCode.NRefactory.Visitors.CodeDomVisitor+Breakable
---fields
---@field public NextId System.Int32
---instance fields
---@field public Id System.Int32
---@field public IsBreak System.Boolean
---@field public IsContinue System.Boolean
---@field public AllowContinue System.Boolean
local m = {};
ICSharpCode.NRefactory.Visitors.CodeDomVisitor+Breakable=m
return m;