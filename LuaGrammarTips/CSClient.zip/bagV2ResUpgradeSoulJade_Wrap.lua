---@class bagV2.ResUpgradeSoulJade
---instance properties
---@field public newId System.Int32
local m = {};

bagV2.ResUpgradeSoulJade=m
return m;