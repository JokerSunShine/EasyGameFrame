---@class activityV2.ActivityCommonStatus
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public status System.Int32
---@field public statusSpecified System.Boolean
local m = {};

activityV2.ActivityCommonStatus=m
return m;