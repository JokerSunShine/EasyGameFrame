---@class ICSharpCodeNRefactoryAstCastExpression : ICSharpCodeNRefactoryAstExpression
---instance properties
---@field public CastTo ICSharpCodeNRefactoryAstTypeReference
---@field public Expression ICSharpCodeNRefactoryAstExpression
---@field public CastType ICSharpCodeNRefactoryAstCastType
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstCastExpression=m
return m;