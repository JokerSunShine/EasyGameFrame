---@class ExCSSParserError
---@field EndOfFile @0
---@field UnexpectedLineBreak @1
---@field InvalidCharacter @2
---@field UnexpectedCommentToken @3
ExCSSParserError=m
return m;