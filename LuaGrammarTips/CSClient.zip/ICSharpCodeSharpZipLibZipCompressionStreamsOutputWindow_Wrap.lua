---@class ICSharpCodeSharpZipLibZipCompressionStreamsOutputWindow
local m = {};
---@param abyte SystemInt32
function m:Write(abyte) end
---@param len SystemInt32
---@param dist SystemInt32
function m:Repeat(len, dist) end
---@param input ICSharpCodeSharpZipLibZipCompressionStreamsStreamManipulator
---@param len SystemInt32
---@return SystemInt32
function m:CopyStored(input, len) end
---@param dict SystemByte
---@param offset SystemInt32
---@param len SystemInt32
function m:CopyDict(dict, offset, len) end
---@return SystemInt32
function m:GetFreeSpace() end
---@return SystemInt32
function m:GetAvailable() end
---@param output SystemByte
---@param offset SystemInt32
---@param len SystemInt32
---@return SystemInt32
function m:CopyOutput(output, offset, len) end
function m:Reset() end
ICSharpCodeSharpZipLibZipCompressionStreamsOutputWindow=m
return m;