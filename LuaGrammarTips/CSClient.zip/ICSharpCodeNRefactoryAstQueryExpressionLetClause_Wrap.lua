---@class ICSharpCodeNRefactoryAstQueryExpressionLetClause : ICSharpCodeNRefactoryAstQueryExpressionClause
---instance properties
---@field public Identifier SystemString
---@field public Expression ICSharpCodeNRefactoryAstExpression
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstQueryExpressionLetClause=m
return m;