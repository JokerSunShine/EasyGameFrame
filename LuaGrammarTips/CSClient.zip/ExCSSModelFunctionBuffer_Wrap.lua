---@class ExCSSModelFunctionBuffer
---instance properties
---@field public TermList SystemCollectionsGenericList1ExCSSTerm
---@field public Term ExCSSTerm
local m = {};
function m:Include() end
---@return ExCSSTerm
function m:Done() end
ExCSSModelFunctionBuffer=m
return m;