---@class ICSharpCodeNRefactoryPreprocessingDirective : ICSharpCodeNRefactoryAbstractSpecial
---instance properties
---@field public Cmd SystemString
---@field public Arg SystemString
---@field public Expression ICSharpCodeNRefactoryAstExpression
---@field public LastLineEnd ICSharpCodeNRefactoryLocation
local m = {};
---@param list SystemCollectionsGenericIList1ICSharpCodeNRefactoryISpecial
function m.VBToCSharp(list) end
---@param dir ICSharpCodeNRefactoryPreprocessingDirective
---@return ICSharpCodeNRefactoryPreprocessingDirective
function m.VBToCSharp(dir) end
---@param list SystemCollectionsGenericList1ICSharpCodeNRefactoryISpecial
function m.CSharpToVB(list) end
---@param dir ICSharpCodeNRefactoryPreprocessingDirective
---@return ICSharpCodeNRefactoryPreprocessingDirective
function m.CSharpToVB(dir) end
---@return SystemString
function m:ToString() end
---@param visitor ICSharpCodeNRefactoryISpecialVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
ICSharpCodeNRefactoryPreprocessingDirective=m
return m;