---@class ExCSSModelExtensionsStringExtensions
local m = {};
---@param value SystemString
---@param friendlyForamt SystemBoolean
---@param indentation SystemInt32
---@return SystemString
function m.Indent(value, friendlyForamt, indentation) end
---@param value SystemString
---@param friendlyFormat SystemBoolean
---@param indentation SystemInt32
---@return SystemString
function m.NewLineIndent(value, friendlyFormat, indentation) end
---@param value SystemString
---@return SystemString
function m.TrimFirstLine(value) end
---@param builder SystemTextStringBuilder
---@return SystemTextStringBuilder
function m.TrimLastLine(builder) end
---@param builder SystemTextStringBuilder
---@return SystemTextStringBuilder
function m.TrimFirstLine(builder) end
ExCSSModelExtensionsStringExtensions=m
return m;