---@class BehaviourProvider
---instance fields
---@field public onRunOverDoSmoethingStart BehaviourProviderOnRunOverDoSmoethingStart
---@field public onRunOverDoSmoethingEnd BehaviourProviderOnRunOverDoSmoethingEnd
local m = {};

---@param fsm FSMState
---@return System.Boolean
function m:InitializeFSM(fsm) end
function m:Reset() end
function m:RegCallBack() end
function m:UnRegCallBack() end
BehaviourProvider=m
return m;