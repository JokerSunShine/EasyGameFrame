---@class bagV2.ResRechargeBoxInfo
---instance properties
---@field public itemId System.Int32
---@field public state System.Int32
---@field public stateSpecified System.Boolean
local m = {};

bagV2.ResRechargeBoxInfo=m
return m;