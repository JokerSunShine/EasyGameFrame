---@class ExCSSFontFaceRule : ExCSSRuleSet
---instance properties
---@field public Declarations ExCSSStyleDeclaration
---@field public FontFamily SystemString
---@field public Src SystemString
---@field public FontStyle SystemString
---@field public FontWeight SystemString
---@field public Stretch SystemString
---@field public UnicodeRange SystemString
---@field public FontVariant SystemString
---@field public FeatureSettings SystemString
local m = {};
---@return SystemString
function m:ToString() end
---@param friendlyFormat SystemBoolean
---@param indentation SystemInt32 @default_value:0
---@return SystemString
function m:ToString(friendlyFormat, indentation) end
ExCSSFontFaceRule=m
return m;