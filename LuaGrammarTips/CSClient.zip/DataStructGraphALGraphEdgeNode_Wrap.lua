---@class DataStructGraphALGraphEdgeNode
---instance fields
---@field public vertexIndex SystemInt32
---@field public next DataStructGraphALGraphEdgeNode
---@field public len SystemInt32
local m = {};
---@param vertexIndex SystemInt32
---@param len SystemInt32
function m:SetNext(vertexIndex, len) end
DataStructGraphALGraphEdgeNode=m
return m;