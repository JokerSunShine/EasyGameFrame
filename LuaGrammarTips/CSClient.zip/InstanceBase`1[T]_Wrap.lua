---@class InstanceBase`1[T]
---properties
---@field public Instance T
local m = {};
function m:Dispose() end
InstanceBase`1[T]=m
return m;