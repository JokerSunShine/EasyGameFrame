---@class EasyHookIClassFactory2
local m = {};
---@param unused SystemObject @in
---@param iid SystemGuid @in
---@return SystemObject
function m:CreateInstance(unused, iid) end
---@param fLock SystemInt32
function m:LockServer(fLock) end
---@return SystemIntPtr
function m:GetLicInfo() end
---@param reserved SystemInt32 @in
---@return SystemString
function m:RequestLicKey(reserved) end
---@param pUnkOuter SystemObject @in
---@param pUnkReserved SystemObject @in
---@param iid SystemGuid @in
---@param bstrKey SystemString @in
---@return SystemObject
function m:CreateInstanceLic(pUnkOuter, pUnkReserved, iid, bstrKey) end
EasyHookIClassFactory2=m
return m;