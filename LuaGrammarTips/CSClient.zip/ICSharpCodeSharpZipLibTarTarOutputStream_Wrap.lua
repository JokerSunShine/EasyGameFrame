---@class ICSharpCodeSharpZipLibTarTarOutputStream : SystemIOStream
---instance properties
---@field public CanRead SystemBoolean
---@field public CanSeek SystemBoolean
---@field public CanWrite SystemBoolean
---@field public Length SystemInt64
---@field public Position SystemInt64
local m = {};
---@param offset SystemInt64
---@param origin SystemIOSeekOrigin
---@return SystemInt64
function m:Seek(offset, origin) end
---@param val SystemInt64
function m:SetLength(val) end
---@return SystemInt32
function m:ReadByte() end
---@param b SystemByte
---@param off SystemInt32
---@param len SystemInt32
---@return SystemInt32
function m:Read(b, off, len) end
function m:Flush() end
function m:Finish() end
function m:Close() end
---@return SystemInt32
function m:GetRecordSize() end
---@param entry ICSharpCodeSharpZipLibTarTarEntry
function m:PutNextEntry(entry) end
function m:CloseEntry() end
---@param b SystemByte
function m:WriteByte(b) end
---@param wBuf SystemByte
---@param wOffset SystemInt32
---@param numToWrite SystemInt32
function m:Write(wBuf, wOffset, numToWrite) end
ICSharpCodeSharpZipLibTarTarOutputStream=m
return m;