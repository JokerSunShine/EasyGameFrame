---@class JetBrains.Annotations.AssertionConditionType
---@field IS_TRUE @0
---@field IS_FALSE @1
---@field IS_NULL @2
---@field IS_NOT_NULL @3
JetBrains.Annotations.AssertionConditionType=m
return m;