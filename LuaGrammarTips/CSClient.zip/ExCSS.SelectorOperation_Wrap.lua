---@class ExCSS.SelectorOperation
---@field Data @0
---@field Attribute @1
---@field AttributeOperator @2
---@field AttributeValue @3
---@field AttributeEnd @4
---@field Class @5
---@field PseudoClass @6
---@field PseudoClassFunction @7
---@field PseudoClassFunctionEnd @8
---@field PseudoElement @9
ExCSS.SelectorOperation=m
return m;