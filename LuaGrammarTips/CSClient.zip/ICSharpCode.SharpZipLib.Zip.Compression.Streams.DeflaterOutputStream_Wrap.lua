---@class ICSharpCode.SharpZipLib.Zip.Compression.Streams.DeflaterOutputStream : System.IO.Stream
---instance properties
---@field public IsStreamOwner System.Boolean
---@field public CanPatchEntries System.Boolean
---@field public CanRead System.Boolean
---@field public CanSeek System.Boolean
---@field public CanWrite System.Boolean
---@field public Length System.Int64
---@field public Position System.Int64
---@field public Password System.String
local m = {};
---@param offset System.Int64
---@param origin System.IO.SeekOrigin
---@return System.Int64
function m:Seek(offset, origin) end
---@param val System.Int64
function m:SetLength(val) end
---@return System.Int32
function m:ReadByte() end
---@param b System.Byte[]
---@param off System.Int32
---@param len System.Int32
---@return System.Int32
function m:Read(b, off, len) end
---@param buffer System.Byte[]
---@param offset System.Int32
---@param count System.Int32
---@param callback System.AsyncCallback
---@param state System.Object
---@return System.IAsyncResult
function m:BeginRead(buffer, offset, count, callback, state) end
---@param buffer System.Byte[]
---@param offset System.Int32
---@param count System.Int32
---@param callback System.AsyncCallback
---@param state System.Object
---@return System.IAsyncResult
function m:BeginWrite(buffer, offset, count, callback, state) end
function m:Flush() end
function m:Finish() end
function m:Close() end
---@param bval System.Byte
function m:WriteByte(bval) end
---@param buf System.Byte[]
---@param off System.Int32
---@param len System.Int32
function m:Write(buf, off, len) end
ICSharpCode.SharpZipLib.Zip.Compression.Streams.DeflaterOutputStream=m
return m;