---@class ICSharpCode.NRefactory.Ast.Attribute : ICSharpCode.NRefactory.Ast.AbstractNode
---instance properties
---@field public Name System.String
---@field public PositionalArguments System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.Expression]
---@field public NamedArguments System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.NamedArgumentExpression]
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.Attribute=m
return m;