---@class activityV2.ResActivityBossState
---instance properties
---@field public duplicateId System.Int32
---@field public duplicateIdSpecified System.Boolean
---@field public state System.Int32
---@field public stateSpecified System.Boolean
local m = {};

activityV2.ResActivityBossState=m
return m;