---@class ICSharpCode.NRefactory.Ast.ParentType
---@field ClassOrStruct @0
---@field InterfaceOrEnum @1
---@field Namespace @2
---@field Unknown @3
ICSharpCode.NRefactory.Ast.ParentType=m
return m;