---@class MicrosoftWin32SafeHandlesCriticalHandleMinusOneIsInvalid : SystemRuntimeInteropServicesCriticalHandle
---instance properties
---@field public IsInvalid SystemBoolean
local m = {};
MicrosoftWin32SafeHandlesCriticalHandleMinusOneIsInvalid=m
return m;