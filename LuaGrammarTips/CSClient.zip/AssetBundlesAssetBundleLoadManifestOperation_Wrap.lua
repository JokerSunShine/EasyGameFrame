---@class AssetBundles.AssetBundleLoadManifestOperation : AssetBundles.AssetBundleLoadAssetOperationFull
local m = {};

---@return System.Boolean
function m:Update() end
AssetBundles.AssetBundleLoadManifestOperation=m
return m;