---@class ICSharpCodeNRefactoryAstCaseLabel : ICSharpCodeNRefactoryAstAbstractNode
---instance properties
---@field public Label ICSharpCodeNRefactoryAstExpression
---@field public BinaryOperatorType ICSharpCodeNRefactoryAstBinaryOperatorType
---@field public ToExpression ICSharpCodeNRefactoryAstExpression
---@field public IsDefault SystemBoolean
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstCaseLabel=m
return m;