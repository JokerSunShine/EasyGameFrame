---@class ExCSS.MediaTypeList
---instance properties
---@field public Item System.String
---@field public Count System.Int32
---@field public MediaType System.String
local m = {};
---@return System.String
function m:ToString() end
---@param friendlyFormat System.Boolean
---@param indentation System.Int32 @default_value:0
---@return System.String
function m:ToString(friendlyFormat, indentation) end
---@return System.Collections.Generic.IEnumerator`1[System.String]
function m:GetEnumerator() end
ExCSS.MediaTypeList=m
return m;