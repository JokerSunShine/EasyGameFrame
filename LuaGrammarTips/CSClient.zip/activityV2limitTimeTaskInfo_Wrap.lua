---@class activityV2.limitTimeTaskInfo
---instance properties
---@field public taskId System.Int32
---@field public taskIdSpecified System.Boolean
---@field public taskValue System.Int32
---@field public taskValueSpecified System.Boolean
---@field public state System.Int32
---@field public stateSpecified System.Boolean
---@field public endTime System.Int32
---@field public endTimeSpecified System.Boolean
local m = {};

activityV2.limitTimeTaskInfo=m
return m;