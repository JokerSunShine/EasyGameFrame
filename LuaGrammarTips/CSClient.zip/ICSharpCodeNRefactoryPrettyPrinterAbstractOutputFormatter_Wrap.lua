---@class ICSharpCodeNRefactoryPrettyPrinterAbstractOutputFormatter
---instance properties
---@field public IsInMemberBody SystemBoolean
---@field public IndentationLevel SystemInt32
---@field public Text SystemString
---@field public TextLength SystemInt32
---@field public DoIndent SystemBoolean
---@field public DoNewLine SystemBoolean
---@field public LastCharacterIsNewLine SystemBoolean
---@field public LastCharacterIsWhiteSpace SystemBoolean
local m = {};
function m:Indent() end
function m:Reset() end
function m:Space() end
function m:NewLine() end
function m:EndFile() end
---@param tokenList SystemCollectionsArrayList
function m:PrintTokenList(tokenList) end
---@param comment ICSharpCodeNRefactoryComment
---@param forceWriteInPreviousBlock SystemBoolean
function m:PrintComment(comment, forceWriteInPreviousBlock) end
---@param directive ICSharpCodeNRefactoryPreprocessingDirective
---@param forceWriteInPreviousBlock SystemBoolean
function m:PrintPreprocessingDirective(directive, forceWriteInPreviousBlock) end
---@param forceWriteInPreviousBlock SystemBoolean
function m:PrintBlankLine(forceWriteInPreviousBlock) end
---@param token SystemInt32
function m:PrintToken(token) end
---@param text SystemString
function m:PrintText(text) end
---@param identifier SystemString
function m:PrintIdentifier(identifier) end
ICSharpCodeNRefactoryPrettyPrinterAbstractOutputFormatter=m
return m;