---@class ExCSSStylesheetParseError
---instance properties
---@field public ParserError ExCSSParserError
---@field public Line SystemInt32
---@field public Column SystemInt32
---@field public Message SystemString
local m = {};
---@return SystemString
function m:ToString() end
ExCSSStylesheetParseError=m
return m;