---@class bagV2.ResIntensify
---instance properties
---@field public equipId System.Int64
---@field public equipInfo bagV2.BagItemInfo
local m = {};

bagV2.ResIntensify=m
return m;