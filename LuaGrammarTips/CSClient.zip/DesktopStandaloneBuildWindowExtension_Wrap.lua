---@class DesktopStandaloneBuildWindowExtension : UnityEditorModulesDefaultBuildWindowExtension
local m = {};
function m:ShowPlatformBuildOptions() end
---@return SystemBoolean
function m:EnabledBuildButton() end
---@return SystemBoolean
function m:EnabledBuildAndRunButton() end
---@return SystemBoolean
function m:ShouldDrawWaitForManagedDebugger() end
DesktopStandaloneBuildWindowExtension=m
return m;