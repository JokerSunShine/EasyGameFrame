---@class DesktopStandaloneBuildWindowExtension : UnityEditor.Modules.DefaultBuildWindowExtension
local m = {};
function m:ShowPlatformBuildOptions() end
---@return System.Boolean
function m:EnabledBuildButton() end
---@return System.Boolean
function m:EnabledBuildAndRunButton() end
---@return System.Boolean
function m:ShouldDrawWaitForManagedDebugger() end
DesktopStandaloneBuildWindowExtension=m
return m;