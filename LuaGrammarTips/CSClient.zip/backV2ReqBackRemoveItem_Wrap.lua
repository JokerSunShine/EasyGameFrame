---@class backV2.ReqBackRemoveItem
---instance properties
---@field public uid System.Int64
---@field public uidSpecified System.Boolean
---@field public itemId System.Int32
---@field public itemIdSpecified System.Boolean
---@field public count System.Int32
---@field public countSpecified System.Boolean
local m = {};

backV2.ReqBackRemoveItem=m
return m;