---@class ICSharpCodeNRefactoryAstLocalVariableDeclaration : ICSharpCodeNRefactoryAstStatement
---instance properties
---@field public TypeReference ICSharpCodeNRefactoryAstTypeReference
---@field public Modifier ICSharpCodeNRefactoryAstModifiers
---@field public Variables SystemCollectionsGenericList1ICSharpCodeNRefactoryAstVariableDeclaration
local m = {};
---@param variableIndex SystemInt32
---@return ICSharpCodeNRefactoryAstTypeReference
function m:GetTypeForVariable(variableIndex) end
---@param variableName SystemString
---@return ICSharpCodeNRefactoryAstVariableDeclaration
function m:GetVariableDeclaration(variableName) end
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstLocalVariableDeclaration=m
return m;