---@class ICSharpCode.NRefactory.Location : System.ValueType
---fields
---@field public Empty ICSharpCode.NRefactory.Location
---instance properties
---@field public X System.Int32
---@field public Y System.Int32
---@field public Line System.Int32
---@field public Column System.Int32
---@field public IsEmpty System.Boolean
local m = {};
---@param a ICSharpCode.NRefactory.Location
---@param b ICSharpCode.NRefactory.Location
---@return System.Boolean
function m.op_Equality(a, b) end
---@param a ICSharpCode.NRefactory.Location
---@param b ICSharpCode.NRefactory.Location
---@return System.Boolean
function m.op_Inequality(a, b) end
---@param a ICSharpCode.NRefactory.Location
---@param b ICSharpCode.NRefactory.Location
---@return System.Boolean
function m.op_LessThan(a, b) end
---@param a ICSharpCode.NRefactory.Location
---@param b ICSharpCode.NRefactory.Location
---@return System.Boolean
function m.op_GreaterThan(a, b) end
---@param a ICSharpCode.NRefactory.Location
---@param b ICSharpCode.NRefactory.Location
---@return System.Boolean
function m.op_LessThanOrEqual(a, b) end
---@param a ICSharpCode.NRefactory.Location
---@param b ICSharpCode.NRefactory.Location
---@return System.Boolean
function m.op_GreaterThanOrEqual(a, b) end
---@return System.String
function m:ToString() end
---@return System.Int32
function m:GetHashCode() end
---@param obj System.Object
---@return System.Boolean
function m:Equals(obj) end
---@param other ICSharpCode.NRefactory.Location
---@return System.Boolean
function m:Equals(other) end
---@param other ICSharpCode.NRefactory.Location
---@return System.Int32
function m:CompareTo(other) end
ICSharpCode.NRefactory.Location=m
return m;