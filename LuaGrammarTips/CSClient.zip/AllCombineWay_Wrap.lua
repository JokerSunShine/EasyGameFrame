---@class AllCombineWay
---@field Automatic @0
---@field Manual @1
local m = {};
AllCombineWay=m
return m;