---@class ICSharpCodeNRefactoryVisitorsToVBNetConvertVisitor : ICSharpCodeNRefactoryVisitorsConvertVisitorBase
local m = {};
---@param compilationUnit ICSharpCodeNRefactoryAstCompilationUnit
---@param data SystemObject
---@return SystemObject
function m:VisitCompilationUnit(compilationUnit, data) end
---@param usingDeclaration ICSharpCodeNRefactoryAstUsingDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitUsingDeclaration(usingDeclaration, data) end
---@param typeDeclaration ICSharpCodeNRefactoryAstTypeDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitTypeDeclaration(typeDeclaration, data) end
---@param delegateDeclaration ICSharpCodeNRefactoryAstDelegateDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitDelegateDeclaration(delegateDeclaration, data) end
---@param expressionStatement ICSharpCodeNRefactoryAstExpressionStatement
---@param data SystemObject
---@return SystemObject
function m:VisitExpressionStatement(expressionStatement, data) end
---@param anonymousMethodExpression ICSharpCodeNRefactoryAstAnonymousMethodExpression
---@param data SystemObject
---@return SystemObject
function m:VisitAnonymousMethodExpression(anonymousMethodExpression, data) end
---@param assignmentExpression ICSharpCodeNRefactoryAstAssignmentExpression
---@param data SystemObject
---@return SystemObject
function m:VisitAssignmentExpression(assignmentExpression, data) end
---@param methodDeclaration ICSharpCodeNRefactoryAstMethodDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitMethodDeclaration(methodDeclaration, data) end
---@param propertyDeclaration ICSharpCodeNRefactoryAstPropertyDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitPropertyDeclaration(propertyDeclaration, data) end
---@param eventDeclaration ICSharpCodeNRefactoryAstEventDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitEventDeclaration(eventDeclaration, data) end
---@param constructorDeclaration ICSharpCodeNRefactoryAstConstructorDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitConstructorDeclaration(constructorDeclaration, data) end
---@param parenthesizedExpression ICSharpCodeNRefactoryAstParenthesizedExpression
---@param data SystemObject
---@return SystemObject
function m:VisitParenthesizedExpression(parenthesizedExpression, data) end
---@param arrayCreateExpression ICSharpCodeNRefactoryAstArrayCreateExpression
---@param data SystemObject
---@return SystemObject
function m:VisitArrayCreateExpression(arrayCreateExpression, data) end
---@param defaultValueExpression ICSharpCodeNRefactoryAstDefaultValueExpression
---@param data SystemObject
---@return SystemObject
function m:VisitDefaultValueExpression(defaultValueExpression, data) end
---@param baseReferenceExpression ICSharpCodeNRefactoryAstBaseReferenceExpression
---@param data SystemObject
---@return SystemObject
function m:VisitBaseReferenceExpression(baseReferenceExpression, data) end
---@param localVariableDeclaration ICSharpCodeNRefactoryAstLocalVariableDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitLocalVariableDeclaration(localVariableDeclaration, data) end
ICSharpCodeNRefactoryVisitorsToVBNetConvertVisitor=m
return m;