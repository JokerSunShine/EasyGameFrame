---@class ICSharpCodeSharpZipLibGZipGZipOutputStream : ICSharpCodeSharpZipLibZipCompressionStreamsDeflaterOutputStream
local m = {};
---@param buf SystemByte
---@param off SystemInt32
---@param len SystemInt32
function m:Write(buf, off, len) end
function m:Close() end
---@param level SystemInt32
function m:SetLevel(level) end
---@return SystemInt32
function m:GetLevel() end
function m:Finish() end
ICSharpCodeSharpZipLibGZipGZipOutputStream=m
return m;