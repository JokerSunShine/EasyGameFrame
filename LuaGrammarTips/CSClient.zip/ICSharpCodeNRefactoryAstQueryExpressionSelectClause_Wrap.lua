---@class ICSharpCodeNRefactoryAstQueryExpressionSelectClause : ICSharpCodeNRefactoryAstQueryExpressionClause
---instance properties
---@field public Projection ICSharpCodeNRefactoryAstExpression
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstQueryExpressionSelectClause=m
return m;