---@class bagV2.StorageInItemRequest
---instance properties
---@field public objId System.Int64
local m = {};

bagV2.StorageInItemRequest=m
return m;