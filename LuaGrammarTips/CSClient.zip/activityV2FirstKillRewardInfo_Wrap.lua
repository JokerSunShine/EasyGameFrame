---@class activityV2.FirstKillRewardInfo
---instance properties
---@field public KillInfos System.Collections.Generic.List1activityV2.FirstKillInfo
---@field public reward System.Int32
---@field public rewardSpecified System.Boolean
---@field public num System.Int32
---@field public numSpecified System.Boolean
local m = {};

activityV2.FirstKillRewardInfo=m
return m;