---@class AppearanceDataBasic
---instance properties
---@field public Avatar CSAvater
---@field public AppearanceInfo AppearanceInfoBasic
---@field public IsOnceHoldAnyFashion System.Boolean
local m = {};

function m:Clear() end
---@return System.Boolean
function m:IsEmptyAppearanceData() end
---@param resGetWearFashion appearanceV2.ResGetWearFashion
function m:RefreshEnabledAppearanceList(resGetWearFashion) end
---@param wearPositions System.Collections.Generic.List1appearanceV2.wearPosition
function m:RefreshEnabledAppearanceList(wearPositions) end
---@param fashionTypes System.Collections.Generic.List1appearanceV2.FashionType
function m:RefreshFashionList(fashionTypes) end
AppearanceDataBasic=m
return m;