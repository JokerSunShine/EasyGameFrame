---@class AlgorithmShortPathShortPath1DJSNodeT
---instance fields
---@field public nodeIndex SystemInt32
---@field public pathNodes CommonDataStructQueueChainQueueChainQueue1SystemInt32
---@field public state SystemBoolean
---@field public weight SystemInt32
local m = {};
AlgorithmShortPathShortPath1DJSNodeT=m
return m;