---@class ICSharpCodeNRefactoryAstQueryExpressionFromOrJoinClause : ICSharpCodeNRefactoryAstQueryExpressionClause
---instance properties
---@field public Type ICSharpCodeNRefactoryAstTypeReference
---@field public Identifier SystemString
---@field public InExpression ICSharpCodeNRefactoryAstExpression
local m = {};
ICSharpCodeNRefactoryAstQueryExpressionFromOrJoinClause=m
return m;