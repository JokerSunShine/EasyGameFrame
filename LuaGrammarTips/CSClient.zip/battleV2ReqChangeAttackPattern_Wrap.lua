---@class battleV2.ReqChangeAttackPattern
---instance properties
---@field public line System.Int32
---@field public lineSpecified System.Boolean
local m = {};

battleV2.ReqChangeAttackPattern=m
return m;