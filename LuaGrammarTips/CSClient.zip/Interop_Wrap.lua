---@class Interop
local m = {};
Interop=m
return m;