---@class CSObjectWrapEditorGeneratorParameterInfoSimulation
---instance fields
---@field public Name SystemString
---@field public IsOut SystemBoolean
---@field public IsIn SystemBoolean
---@field public ParameterType SystemType
---@field public IsParamArray SystemBoolean
local m = {};
CSObjectWrapEditorGeneratorParameterInfoSimulation=m
return m;