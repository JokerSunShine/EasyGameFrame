---@class ICSharpCode.SharpZipLib.Encryption.PkzipClassicManaged : ICSharpCode.SharpZipLib.Encryption.PkzipClassic
---instance properties
---@field public BlockSize System.Int32
---@field public LegalKeySizes System.Security.Cryptography.KeySizes[]
---@field public LegalBlockSizes System.Security.Cryptography.KeySizes[]
---@field public Key System.Byte[]
local m = {};
function m:GenerateIV() end
function m:GenerateKey() end
---@param rgbKey System.Byte[]
---@param rgbIV System.Byte[]
---@return System.Security.Cryptography.ICryptoTransform
function m:CreateEncryptor(rgbKey, rgbIV) end
---@param rgbKey System.Byte[]
---@param rgbIV System.Byte[]
---@return System.Security.Cryptography.ICryptoTransform
function m:CreateDecryptor(rgbKey, rgbIV) end
ICSharpCode.SharpZipLib.Encryption.PkzipClassicManaged=m
return m;