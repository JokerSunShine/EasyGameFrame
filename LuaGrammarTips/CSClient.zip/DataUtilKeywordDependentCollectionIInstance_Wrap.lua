---@class DataUtilKeywordDependentCollectionIInstance
---instance properties
---@field public type DataUtilKeywordDependentCollectionKeywordPermutationInstanceType
---@field public permutationIndex SystemInt32
local m = {};
DataUtilKeywordDependentCollectionIInstance=m
return m;