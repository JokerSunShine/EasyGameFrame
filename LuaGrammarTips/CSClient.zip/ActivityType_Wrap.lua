---@class ActivityType
---@field NONE @0
---@field BUDOUKAI @35
local m = {};
ActivityType=m
return m;