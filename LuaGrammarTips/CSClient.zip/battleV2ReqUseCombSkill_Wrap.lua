---@class battleV2.ReqUseCombSkill
---instance properties
---@field public round System.Int32
---@field public roundSpecified System.Boolean
local m = {};

battleV2.ReqUseCombSkill=m
return m;