---@class activityV2.ResSendBossScore
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public num System.Int32
---@field public numSpecified System.Boolean
local m = {};

activityV2.ResSendBossScore=m
return m;