---@class ICSharpCodeNRefactoryAstBinaryOperatorExpression : ICSharpCodeNRefactoryAstExpression
---instance properties
---@field public Left ICSharpCodeNRefactoryAstExpression
---@field public Op ICSharpCodeNRefactoryAstBinaryOperatorType
---@field public Right ICSharpCodeNRefactoryAstExpression
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstBinaryOperatorExpression=m
return m;