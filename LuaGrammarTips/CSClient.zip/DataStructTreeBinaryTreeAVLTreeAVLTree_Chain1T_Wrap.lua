---@class DataStructTreeBinaryTreeAVLTreeAVLTree_Chain1T : DataStructTreeBinaryTreeBinarySearchTreeBinarySearchTree_Chain1T
local m = {};
---@param value T
---@return DataStructTreeBinaryTreeNode1T
function m:InsertNode(value) end
---@param data T
---@param changeCount SystemBoolean @default_value:True
---@return DataStructTreeBinaryTreeNode1T
function m:DeleteNode(data, changeCount) end
---@param node DataStructTreeBinaryTreeNode1T
function m:TryBalanceChange(node) end
---@param node DataStructTreeBinaryTreeNode1T
function m:LL_Rotate(node) end
---@param node DataStructTreeBinaryTreeNode1T
function m:RR_Rotate(node) end
---@param node DataStructTreeBinaryTreeNode1T
function m:LR_Rotate(node) end
---@param node DataStructTreeBinaryTreeNode1T
function m:RL_Rotate(node) end
DataStructTreeBinaryTreeAVLTreeAVLTree_Chain1T=m
return m;