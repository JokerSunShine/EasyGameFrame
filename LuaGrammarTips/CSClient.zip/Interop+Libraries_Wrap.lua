---@class Interop+Libraries
local m = {};
Interop+Libraries=m
return m;