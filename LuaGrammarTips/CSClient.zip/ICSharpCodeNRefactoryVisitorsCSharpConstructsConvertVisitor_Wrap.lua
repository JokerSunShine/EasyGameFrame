---@class ICSharpCodeNRefactoryVisitorsCSharpConstructsConvertVisitor : ICSharpCodeNRefactoryVisitorsConvertVisitorBase
local m = {};
---@param binaryOperatorExpression ICSharpCodeNRefactoryAstBinaryOperatorExpression
---@param data SystemObject
---@return SystemObject
function m:VisitBinaryOperatorExpression(binaryOperatorExpression, data) end
---@param expressionStatement ICSharpCodeNRefactoryAstExpressionStatement
---@param data SystemObject
---@return SystemObject
function m:VisitExpressionStatement(expressionStatement, data) end
---@param ifElseStatement ICSharpCodeNRefactoryAstIfElseStatement
---@param data SystemObject
---@return SystemObject
function m:VisitIfElseStatement(ifElseStatement, data) end
---@param forStatement ICSharpCodeNRefactoryAstForStatement
---@param data SystemObject
---@return SystemObject
function m:VisitForStatement(forStatement, data) end
---@param castExpression ICSharpCodeNRefactoryAstCastExpression
---@param data SystemObject
---@return SystemObject
function m:VisitCastExpression(castExpression, data) end
ICSharpCodeNRefactoryVisitorsCSharpConstructsConvertVisitor=m
return m;