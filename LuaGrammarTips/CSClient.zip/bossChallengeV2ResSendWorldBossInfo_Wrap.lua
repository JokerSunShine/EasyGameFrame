---@class bossChallengeV2.ResSendWorldBossInfo
---instance properties
---@field public worldBossInfo System.Collections.Generic.List1bossChallengeV2.WorldBossInfo
local m = {};

bossChallengeV2.ResSendWorldBossInfo=m
return m;