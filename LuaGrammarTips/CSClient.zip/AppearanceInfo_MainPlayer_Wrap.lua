---@class AppearanceInfo_MainPlayer : AppearanceInfo1CSCharacter
local m = {};

AppearanceInfo_MainPlayer=m
return m;