---@class GraphicsPolygonType
---@field RegularPolygon @0
---@field ConvexPolygon @1
---@field ConcavePolygon @2
GraphicsPolygonType=m
return m;