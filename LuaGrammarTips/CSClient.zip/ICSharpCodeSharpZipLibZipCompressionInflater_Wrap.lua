---@class ICSharpCodeSharpZipLibZipCompressionInflater
---instance properties
---@field public IsNeedingInput SystemBoolean
---@field public IsNeedingDictionary SystemBoolean
---@field public IsFinished SystemBoolean
---@field public Adler SystemInt32
---@field public TotalOut SystemInt32
---@field public TotalIn SystemInt32
---@field public RemainingInput SystemInt32
local m = {};
function m:Reset() end
---@param buffer SystemByte
function m:SetDictionary(buffer) end
---@param buffer SystemByte
---@param offset SystemInt32
---@param len SystemInt32
function m:SetDictionary(buffer, offset, len) end
---@param buf SystemByte
function m:SetInput(buf) end
---@param buffer SystemByte
---@param offset SystemInt32
---@param length SystemInt32
function m:SetInput(buffer, offset, length) end
---@param buf SystemByte
---@return SystemInt32
function m:Inflate(buf) end
---@param buf SystemByte
---@param offset SystemInt32
---@param len SystemInt32
---@return SystemInt32
function m:Inflate(buf, offset, len) end
ICSharpCodeSharpZipLibZipCompressionInflater=m
return m;