---@class FrameworkUtilityFolder
local m = {};
---@param path SystemString
function m.Execute(path) end
FrameworkUtilityFolder=m
return m;