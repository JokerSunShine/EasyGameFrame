---@class activityV2.ResSendTotalLoginDay
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public num System.Int32
---@field public numSpecified System.Boolean
local m = {};

activityV2.ResSendTotalLoginDay=m
return m;