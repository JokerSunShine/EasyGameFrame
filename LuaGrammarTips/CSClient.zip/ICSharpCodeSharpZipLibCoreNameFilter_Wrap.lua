---@class ICSharpCodeSharpZipLibCoreNameFilter
local m = {};
---@param e SystemString
---@return SystemBoolean
function m.IsValidExpression(e) end
---@param toTest SystemString
---@return SystemBoolean
function m.IsValidFilterExpression(toTest) end
---@return SystemString
function m:ToString() end
---@param testValue SystemString
---@return SystemBoolean
function m:IsIncluded(testValue) end
---@param testValue SystemString
---@return SystemBoolean
function m:IsExcluded(testValue) end
---@param testValue SystemString
---@return SystemBoolean
function m:IsMatch(testValue) end
ICSharpCodeSharpZipLibCoreNameFilter=m
return m;