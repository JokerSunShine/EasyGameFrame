---@class ICSharpCodeNRefactoryAstPrimitiveExpression : ICSharpCodeNRefactoryAstExpression
---instance properties
---@field public LiteralFormat ICSharpCodeNRefactoryParserLiteralFormat
---@field public Value SystemObject
---@field public StringValue SystemString
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstPrimitiveExpression=m
return m;