---@class battleV2.ResFakeOutRobotInfo
---instance properties
---@field public teamInfo battleV2.TeamInfo
local m = {};

battleV2.ResFakeOutRobotInfo=m
return m;