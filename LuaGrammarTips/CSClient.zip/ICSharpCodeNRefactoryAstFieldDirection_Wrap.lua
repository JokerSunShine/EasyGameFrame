---@class ICSharpCodeNRefactoryAstFieldDirection
---@field None @0
---@field In @1
---@field Out @2
---@field Ref @3
ICSharpCodeNRefactoryAstFieldDirection=m
return m;