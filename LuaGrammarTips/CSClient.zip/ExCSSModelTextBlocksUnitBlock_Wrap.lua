---@class ExCSSModelTextBlocksUnitBlock : ExCSSModelTextBlocksBlock
local m = {};
---@return SystemString
function m:ToString() end
ExCSSModelTextBlocksUnitBlock=m
return m;