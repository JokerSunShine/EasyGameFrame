---@class CSObjectWrapEditorGeneratorMethodInfoSimulation
---instance fields
---@field public ReturnType SystemType
---@field public ParameterInfos CSObjectWrapEditorGeneratorParameterInfoSimulation
---@field public HashCode SystemInt32
---@field public DeclaringType SystemType
---@field public DeclaringTypeName SystemString
local m = {};
---@return CSObjectWrapEditorGeneratorParameterInfoSimulation
function m:GetParameters() end
CSObjectWrapEditorGeneratorMethodInfoSimulation=m
return m;