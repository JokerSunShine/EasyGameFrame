---@class CSObjectWrapEditorCustomGenTask : SystemValueType
---instance fields
---@field public Data XLuaLuaTable
---@field public Output SystemIOTextWriter
local m = {};
CSObjectWrapEditorCustomGenTask=m
return m;