---@class ICSharpCode.NRefactory.PrettyPrinter.BraceStyle
---@field EndOfLine @0
---@field EndOfLineWithoutSpace @1
---@field NextLine @2
---@field NextLineShifted @3
---@field NextLineShifted2 @4
ICSharpCode.NRefactory.PrettyPrinter.BraceStyle=m
return m;