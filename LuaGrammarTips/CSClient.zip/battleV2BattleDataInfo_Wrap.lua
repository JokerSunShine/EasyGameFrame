---@class battleV2.BattleDataInfo
---instance properties
---@field public skillId System.Int32
---@field public skillIdSpecified System.Boolean
---@field public attacker System.String
---@field public attackerSpecified System.Boolean
---@field public target System.String
---@field public targetSpecified System.Boolean
---@field public attackerId System.Int64
---@field public attackerIdSpecified System.Boolean
---@field public targetId System.Int64
---@field public targetIdSpecified System.Boolean
---@field public round System.Int32
---@field public roundSpecified System.Boolean
---@field public hurtDataInfo System.Collections.Generic.List1battleV2.HurtDataInfo
---@field public selfBuff System.Collections.Generic.List1battleV2.BufferAdd
local m = {};

battleV2.BattleDataInfo=m
return m;