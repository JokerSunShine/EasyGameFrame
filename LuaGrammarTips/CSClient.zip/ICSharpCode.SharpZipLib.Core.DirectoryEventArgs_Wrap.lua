---@class ICSharpCode.SharpZipLib.Core.DirectoryEventArgs : ICSharpCode.SharpZipLib.Core.ScanEventArgs
---instance properties
---@field public HasMatchingFiles System.Boolean
local m = {};
ICSharpCode.SharpZipLib.Core.DirectoryEventArgs=m
return m;