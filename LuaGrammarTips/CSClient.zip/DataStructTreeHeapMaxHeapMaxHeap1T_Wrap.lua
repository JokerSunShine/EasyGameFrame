---@class DataStructTreeHeapMaxHeapMaxHeap1T : DataStructTreeBinaryTreeArrayBinaryTreeAbstract1T
---instance properties
---@field public NodeArray T
---@field public Count SystemInt32
local m = {};
---@param data T
function m:Push(data) end
---@param index SystemInt32
---@return T
function m:RemoveByIndex(index) end
---@param data T
---@return SystemBoolean
function m:Remove(data) end
---@param data T
---@return SystemBoolean
function m:Find(data) end
---@param data T
---@return SystemInt32
function m:FindIndex(data) end
function m:ExtenSize() end
DataStructTreeHeapMaxHeapMaxHeap1T=m
return m;