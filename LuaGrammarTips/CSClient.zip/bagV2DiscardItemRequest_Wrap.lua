---@class bagV2.DiscardItemRequest
---instance properties
---@field public objId System.Int64
---@field public count System.Int32
local m = {};

bagV2.DiscardItemRequest=m
return m;