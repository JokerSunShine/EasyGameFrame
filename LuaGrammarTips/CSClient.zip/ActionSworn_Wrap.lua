---@class ActionSworn : BehaviorState
---instance fields
---@field public curState ActionSwornSwornState
---instance properties
---@field public Behavior System.Int32
local m = {};

---@param a ISFAvater
---@param last BehaviorState
function m:Start(a, last) end
---@param avater ISFAvater
---@return System.Int32
function m:Update(avater) end
---@param a ISFAvater
---@param nextBehv BehaviorState
function m:End(a, nextBehv) end
ActionSworn=m
return m;