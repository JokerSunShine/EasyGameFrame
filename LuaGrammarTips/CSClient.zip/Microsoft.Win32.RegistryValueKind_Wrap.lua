---@class Microsoft.Win32.RegistryValueKind
---@field Unknown @0
---@field String @1
---@field ExpandString @2
---@field Binary @3
---@field DWord @4
---@field MultiString @7
---@field QWord @11
---@field None @-1
Microsoft.Win32.RegistryValueKind=m
return m;