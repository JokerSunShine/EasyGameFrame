---@class ICSharpCode.NRefactory.Parser.AbstractParser
---instance properties
---@field public ParseMethodBodies System.Boolean
---@field public Lexer ICSharpCode.NRefactory.Parser.ILexer
---@field public Errors ICSharpCode.NRefactory.Parser.Errors
---@field public CompilationUnit ICSharpCode.NRefactory.Ast.CompilationUnit
local m = {};
function m:Parse() end
---@return ICSharpCode.NRefactory.Ast.TypeReference
function m:ParseTypeReference() end
---@return ICSharpCode.NRefactory.Ast.Expression
function m:ParseExpression() end
---@return ICSharpCode.NRefactory.Ast.BlockStatement
function m:ParseBlock() end
---@return System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.INode]
function m:ParseTypeMembers() end
function m:Dispose() end
ICSharpCode.NRefactory.Parser.AbstractParser=m
return m;