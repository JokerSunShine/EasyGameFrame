---@class ICSharpCode.SharpZipLib.Zip.Compression.DeflateStrategy
---@field Default @0
---@field Filtered @1
---@field HuffmanOnly @2
ICSharpCode.SharpZipLib.Zip.Compression.DeflateStrategy=m
return m;