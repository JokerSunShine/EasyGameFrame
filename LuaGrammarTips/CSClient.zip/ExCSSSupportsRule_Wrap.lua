---@class ExCSSSupportsRule : ExCSSConditionalRule
---instance properties
---@field public Condition SystemString
---@field public IsSupported SystemBoolean
local m = {};
---@return SystemString
function m:ToString() end
---@param friendlyFormat SystemBoolean
---@param indentation SystemInt32 @default_value:0
---@return SystemString
function m:ToString(friendlyFormat, indentation) end
ExCSSSupportsRule=m
return m;