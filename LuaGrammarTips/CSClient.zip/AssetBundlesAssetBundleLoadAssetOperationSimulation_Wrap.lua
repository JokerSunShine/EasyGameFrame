---@class AssetBundles.AssetBundleLoadAssetOperationSimulation : AssetBundles.AssetBundleLoadAssetOperation
local m = {};

---@return System.Boolean
function m:Update() end
---@return System.Boolean
function m:IsDone() end
AssetBundles.AssetBundleLoadAssetOperationSimulation=m
return m;