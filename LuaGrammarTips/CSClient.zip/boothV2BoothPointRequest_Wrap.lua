---@class boothV2.BoothPointRequest
---instance properties
---@field public mapId System.Int32
---@field public mapIdSpecified System.Boolean
local m = {};

boothV2.BoothPointRequest=m
return m;