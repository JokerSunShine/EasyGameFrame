---@class CSObjectWrapEditor.UserConfig : System.ValueType
---instance fields
---@field public LuaCallCSharp System.Collections.Generic.IEnumerable`1[System.Type]
---@field public CSharpCallLua System.Collections.Generic.IEnumerable`1[System.Type]
---@field public ReflectionUse System.Collections.Generic.IEnumerable`1[System.Type]
local m = {};
CSObjectWrapEditor.UserConfig=m
return m;