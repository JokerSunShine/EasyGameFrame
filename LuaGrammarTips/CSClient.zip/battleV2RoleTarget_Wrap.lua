---@class battleV2.RoleTarget
---instance properties
---@field public memberId System.Int64
---@field public memberIdSpecified System.Boolean
---@field public career System.Int32
---@field public careerSpecified System.Boolean
---@field public name System.String
---@field public nameSpecified System.Boolean
---@field public sex System.Int32
---@field public sexSpecified System.Boolean
---@field public hp System.Int64
---@field public hpSpecified System.Boolean
---@field public maxHp System.Int64
---@field public maxHpSpecified System.Boolean
---@field public isSameUnion System.Int32
---@field public isSameUnionSpecified System.Boolean
---@field public isPalaceOwner System.Int32
---@field public isPalaceOwnerSpecified System.Boolean
local m = {};

battleV2.RoleTarget=m
return m;