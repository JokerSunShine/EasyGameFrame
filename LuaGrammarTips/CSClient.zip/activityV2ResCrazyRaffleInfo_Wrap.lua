---@class activityV2.ResCrazyRaffleInfo
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public hasIndexList System.Collections.Generic.List1System.Int32
local m = {};

activityV2.ResCrazyRaffleInfo=m
return m;