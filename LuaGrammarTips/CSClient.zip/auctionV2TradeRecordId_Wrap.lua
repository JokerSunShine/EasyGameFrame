---@class auctionV2.TradeRecordId
---instance properties
---@field public id System.Int64
---@field public idSpecified System.Boolean
local m = {};

auctionV2.TradeRecordId=m
return m;