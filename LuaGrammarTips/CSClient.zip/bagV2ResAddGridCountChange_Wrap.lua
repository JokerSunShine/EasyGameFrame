---@class bagV2.ResAddGridCountChange
---instance properties
---@field public addGridCount System.Int32
---@field public addGridCountSpecified System.Boolean
---@field public emptyGridCount System.Int32
---@field public emptyGridCountSpecified System.Boolean
---@field public maxGridCount System.Int32
---@field public maxGridCountSpecified System.Boolean
local m = {};

bagV2.ResAddGridCountChange=m
return m;