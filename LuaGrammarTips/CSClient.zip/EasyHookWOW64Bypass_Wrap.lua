---@class EasyHookWOW64Bypass
local m = {};
---@param InHostPID SystemInt32
---@param InTargetPID SystemInt32
---@param InWakeUpTID SystemInt32
---@param InNativeOptions SystemInt32
---@param InLibraryPath_x86 SystemString
---@param InLibraryPath_x64 SystemString
---@param InRequireStrongName SystemBoolean
---@param InPassThruArgs SystemObject
function m.Inject(InHostPID, InTargetPID, InWakeUpTID, InNativeOptions, InLibraryPath_x86, InLibraryPath_x64, InRequireStrongName, InPassThruArgs) end
EasyHookWOW64Bypass=m
return m;