---@class ICSharpCodeSharpZipLibZipZipFile
---instance fields
---@field public KeysRequired ICSharpCodeSharpZipLibZipZipFileKeysRequiredEventHandler
---instance properties
---@field public Password SystemString
---@field public EntryByIndex ICSharpCodeSharpZipLibZipZipEntry
---@field public ZipFileComment SystemString
---@field public Name SystemString
---@field public Size SystemInt32
local m = {};
function m:Close() end
---@return SystemCollectionsIEnumerator
function m:GetEnumerator() end
---@param name SystemString
---@param ignoreCase SystemBoolean
---@return SystemInt32
function m:FindEntry(name, ignoreCase) end
---@param name SystemString
---@return ICSharpCodeSharpZipLibZipZipEntry
function m:GetEntry(name) end
---@param testData SystemBoolean
---@return SystemBoolean
function m:TestArchive(testData) end
---@param entry ICSharpCodeSharpZipLibZipZipEntry
---@return SystemIOStream
function m:GetInputStream(entry) end
---@param entryIndex SystemInt32
---@return SystemIOStream
function m:GetInputStream(entryIndex) end
ICSharpCodeSharpZipLibZipZipFile=m
return m;