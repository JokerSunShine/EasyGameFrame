---@class ICSharpCodeNRefactoryVisitorsCodeDomVisitorBreakable
---fields
---@field public NextId SystemInt32
---instance fields
---@field public Id SystemInt32
---@field public IsBreak SystemBoolean
---@field public IsContinue SystemBoolean
---@field public AllowContinue SystemBoolean
local m = {};
ICSharpCodeNRefactoryVisitorsCodeDomVisitorBreakable=m
return m;