---@class ICSharpCodeNRefactoryPrettyPrinterSpecialOutputVisitor
---instance fields
---@field public ForceWriteInPreviousLine SystemBoolean
local m = {};
---@param special ICSharpCodeNRefactoryISpecial
---@param data SystemObject
---@return SystemObject
function m:Visit(special, data) end
---@param special ICSharpCodeNRefactoryBlankLine
---@param data SystemObject
---@return SystemObject
function m:Visit(special, data) end
---@param special ICSharpCodeNRefactoryComment
---@param data SystemObject
---@return SystemObject
function m:Visit(special, data) end
---@param special ICSharpCodeNRefactoryPreprocessingDirective
---@param data SystemObject
---@return SystemObject
function m:Visit(special, data) end
ICSharpCodeNRefactoryPrettyPrinterSpecialOutputVisitor=m
return m;