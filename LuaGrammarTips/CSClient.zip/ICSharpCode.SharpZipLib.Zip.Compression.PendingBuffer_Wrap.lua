---@class ICSharpCode.SharpZipLib.Zip.Compression.PendingBuffer
---instance properties
---@field public BitCount System.Int32
---@field public IsFlushed System.Boolean
local m = {};
function m:Reset() end
---@param b System.Int32
function m:WriteByte(b) end
---@param s System.Int32
function m:WriteShort(s) end
---@param s System.Int32
function m:WriteInt(s) end
---@param block System.Byte[]
---@param offset System.Int32
---@param len System.Int32
function m:WriteBlock(block, offset, len) end
function m:AlignToByte() end
---@param b System.Int32
---@param count System.Int32
function m:WriteBits(b, count) end
---@param s System.Int32
function m:WriteShortMSB(s) end
---@param output System.Byte[]
---@param offset System.Int32
---@param length System.Int32
---@return System.Int32
function m:Flush(output, offset, length) end
---@return System.Byte[]
function m:ToByteArray() end
ICSharpCode.SharpZipLib.Zip.Compression.PendingBuffer=m
return m;