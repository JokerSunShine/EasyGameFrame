---@class biqiV2.ScoreRankInfo
---instance properties
---@field public rank System.Int32
---@field public rankSpecified System.Boolean
---@field public name System.String
---@field public nameSpecified System.Boolean
---@field public score System.Int32
---@field public scoreSpecified System.Boolean
---@field public self System.Int32
---@field public selfSpecified System.Boolean
---@field public career System.Int32
---@field public careerSpecified System.Boolean
---@field public info System.Collections.Generic.List1biqiV2.ItemInfo
---@field public lv System.Int32
---@field public lvSpecified System.Boolean
local m = {};

biqiV2.ScoreRankInfo=m
return m;