---@class ICSharpCode.SharpZipLib.Core.DirectoryFailureDelegate : System.MulticastDelegate
local m = {};
---@param sender System.Object
---@param e ICSharpCode.SharpZipLib.Core.ScanFailureEventArgs
function m:Invoke(sender, e) end
---@param sender System.Object
---@param e ICSharpCode.SharpZipLib.Core.ScanFailureEventArgs
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(sender, e, callback, object) end
---@param result System.IAsyncResult
function m:EndInvoke(result) end
ICSharpCode.SharpZipLib.Core.DirectoryFailureDelegate=m
return m;