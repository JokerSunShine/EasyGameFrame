---@class ActivitySettleBaseVO
---instance properties
---@field public rid System.Int64
---@field public rank System.Int32
---@field public name System.String
---@field public integral System.Single
---@field public firstValue System.Int32
---@field public secondValue System.Int32
---@field public thirdValue System.Int32
---@field public sidebar_FirstValue System.String
---@field public sidebar_SecondValue System.String
---@field public sidebar_ThirdValue System.String
---@field public likeNum System.Int32
---@field public sex System.Int32
---@field public career System.Int32
---@field public Score System.Int64
---@field public isWin System.Boolean
---@field public likeRoleList System.Collections.Generic.List1System.Int64
---@field public level System.Int32
local m = {};

---@return System.String
function m:GetHeadIcon() end
---@return System.String
function m:GetTitle() end
---@return System.String
function m:GetName() end
---@return System.Boolean
function m:IsLiked() end
---@return System.Boolean
function m:IsHaveLike() end
---@param rid System.Int64
---@return ActivitySettleBaseVO
function m:GetOtherPlayerSettleBaseInfo(rid) end
---@return PraiseType
function m:GetPraiseType() end
ActivitySettleBaseVO=m
return m;