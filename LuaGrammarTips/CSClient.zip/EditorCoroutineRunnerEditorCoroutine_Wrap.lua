---@class EditorCoroutineRunnerEditorCoroutine
---instance properties
---@field public Current SystemObject
local m = {};
---@return SystemBoolean
function m:MoveNext() end
function m:Reset() end
---@param coroutine SystemCollectionsIEnumerator
---@return SystemBoolean
function m:Find(coroutine) end
EditorCoroutineRunnerEditorCoroutine=m
return m;