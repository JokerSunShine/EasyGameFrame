---@class backV2.ResRecharge
---instance properties
---@field public loginName System.String
---@field public loginNameSpecified System.Boolean
---@field public code System.Int32
---@field public codeSpecified System.Boolean
---@field public msg System.String
---@field public msgSpecified System.Boolean
---@field public count System.Int32
---@field public countSpecified System.Boolean
---@field public type System.Int32
---@field public typeSpecified System.Boolean
local m = {};

backV2.ResRecharge=m
return m;