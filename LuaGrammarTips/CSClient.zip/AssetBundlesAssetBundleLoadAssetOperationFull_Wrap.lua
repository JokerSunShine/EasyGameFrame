---@class AssetBundles.AssetBundleLoadAssetOperationFull : AssetBundles.AssetBundleLoadAssetOperation
local m = {};

---@return System.Boolean
function m:Update() end
---@return System.Boolean
function m:IsDone() end
AssetBundles.AssetBundleLoadAssetOperationFull=m
return m;