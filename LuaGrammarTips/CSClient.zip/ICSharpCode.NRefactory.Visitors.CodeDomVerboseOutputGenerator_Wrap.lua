---@class ICSharpCode.NRefactory.Visitors.CodeDomVerboseOutputGenerator : System.CodeDom.Compiler.CodeGenerator
local m = {};
---@param e System.CodeDom.CodeStatement
---@param w System.IO.TextWriter
---@param o System.CodeDom.Compiler.CodeGeneratorOptions
function m:PublicGenerateCodeFromStatement(e, w, o) end
ICSharpCode.NRefactory.Visitors.CodeDomVerboseOutputGenerator=m
return m;