---@class activityV2.RoleActivityInfo
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public rewardState System.Int32
---@field public rewardStateSpecified System.Boolean
---@field public count System.Int32
---@field public countSpecified System.Boolean
---@field public time System.Int32
---@field public timeSpecified System.Boolean
---@field public roleGoalInfos System.Collections.Generic.List1activityV2.RoleGoalInfo
local m = {};

activityV2.RoleActivityInfo=m
return m;