---@class ExCSS.Model.TextBlocks.StringBlock : ExCSS.Model.TextBlocks.Block
local m = {};
---@return System.String
function m:ToString() end
ExCSS.Model.TextBlocks.StringBlock=m
return m;