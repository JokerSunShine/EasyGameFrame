---@class bagV2.ResBloodSmelt
---instance properties
---@field public item bagV2.BagItemInfo
---@field public index System.Int32
---@field public indexSpecified System.Boolean
local m = {};

bagV2.ResBloodSmelt=m
return m;