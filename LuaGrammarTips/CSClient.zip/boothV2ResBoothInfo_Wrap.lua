---@class boothV2.ResBoothInfo
---instance properties
---@field public info boothV2.BoothInfo
---@field public hasBooth System.Boolean
---@field public hasBoothSpecified System.Boolean
local m = {};

boothV2.ResBoothInfo=m
return m;