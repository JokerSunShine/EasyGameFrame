---@class ICSharpCodeNRefactoryAstQueryExpressionOrdering : ICSharpCodeNRefactoryAstAbstractNode
---instance properties
---@field public Criteria ICSharpCodeNRefactoryAstExpression
---@field public Direction ICSharpCodeNRefactoryAstQueryExpressionOrderingDirection
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstQueryExpressionOrdering=m
return m;