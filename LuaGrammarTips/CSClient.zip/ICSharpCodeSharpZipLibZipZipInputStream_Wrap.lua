---@class ICSharpCodeSharpZipLibZipZipInputStream : ICSharpCodeSharpZipLibZipCompressionStreamsInflaterInputStream
---instance properties
---@field public Password SystemString
---@field public CanDecompressEntry SystemBoolean
---@field public Available SystemInt32
local m = {};
---@return ICSharpCodeSharpZipLibZipZipEntry
function m:GetNextEntry() end
function m:CloseEntry() end
---@return SystemInt32
function m:ReadByte() end
---@param destination SystemByte
---@param index SystemInt32
---@param count SystemInt32
---@return SystemInt32
function m:Read(destination, index, count) end
---@param b SystemByte
---@param off SystemInt32
---@param len SystemInt32
---@return SystemInt32
function m:BodyRead(b, off, len) end
function m:Close() end
ICSharpCodeSharpZipLibZipZipInputStream=m
return m;