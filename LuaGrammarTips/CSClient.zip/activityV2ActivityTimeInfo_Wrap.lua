---@class activityV2.ActivityTimeInfo
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public beginTime System.Int32
---@field public beginTimeSpecified System.Boolean
---@field public endTime System.Int32
---@field public endTimeSpecified System.Boolean
local m = {};

activityV2.ActivityTimeInfo=m
return m;