---@class bagV2.GemUpgrade
---instance properties
---@field public currentId System.Int32
local m = {};

bagV2.GemUpgrade=m
return m;