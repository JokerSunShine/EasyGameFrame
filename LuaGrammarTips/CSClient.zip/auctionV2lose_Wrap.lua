---@class auctionV2.lose
local m = {};

auctionV2.lose=m
return m;