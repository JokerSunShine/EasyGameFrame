---@class backV2.ReqBackOnlineCount
---instance properties
---@field public time System.Int32
---@field public timeSpecified System.Boolean
local m = {};

backV2.ReqBackOnlineCount=m
return m;