---@class MicrosoftCSharpCSharpTypeAttributeConverter : MicrosoftCSharpCSharpModifierAttributeConverter
---properties
---@field public Default MicrosoftCSharpCSharpTypeAttributeConverter
local m = {};
MicrosoftCSharpCSharpTypeAttributeConverter=m
return m;