---@class BaseExposedPropertyDrawerExposedPropertyMode
---@field DefaultValue @0
---@field Named @1
---@field NamedGUID @2
BaseExposedPropertyDrawerExposedPropertyMode=m
return m;