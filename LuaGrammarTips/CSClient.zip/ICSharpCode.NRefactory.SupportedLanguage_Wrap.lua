---@class ICSharpCode.NRefactory.SupportedLanguage
---@field CSharp @0
---@field VBNet @1
ICSharpCode.NRefactory.SupportedLanguage=m
return m;