---@class MicrosoftWin32RegistryKeyPermissionCheck
---@field Default @0
---@field ReadSubTree @1
---@field ReadWriteSubTree @2
MicrosoftWin32RegistryKeyPermissionCheck=m
return m;