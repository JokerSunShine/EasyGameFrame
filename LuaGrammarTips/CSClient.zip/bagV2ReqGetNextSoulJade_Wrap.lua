---@class bagV2.ReqGetNextSoulJade
---instance properties
---@field public thisId System.Int64
---@field public thisIdSpecified System.Boolean
local m = {};

bagV2.ReqGetNextSoulJade=m
return m;