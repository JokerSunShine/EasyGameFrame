---@class BaseFrameOnStart : System.MulticastDelegate
local m = {};

function m:Invoke() end
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(callback, object) end
---@param result System.IAsyncResult
function m:EndInvoke(result) end
BaseFrameOnStart=m
return m;