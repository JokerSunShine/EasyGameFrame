---@class ICSharpCodeNRefactoryParserFactory
local m = {};
---@param language ICSharpCodeNRefactorySupportedLanguage
---@param textReader SystemIOTextReader
---@return ICSharpCodeNRefactoryParserILexer
function m.CreateLexer(language, textReader) end
---@param language ICSharpCodeNRefactorySupportedLanguage
---@param textReader SystemIOTextReader
---@return ICSharpCodeNRefactoryIParser
function m.CreateParser(language, textReader) end
---@param fileName SystemString
---@return ICSharpCodeNRefactoryIParser
function m.CreateParser(fileName) end
---@param fileName SystemString
---@param encoding SystemTextEncoding
---@return ICSharpCodeNRefactoryIParser
function m.CreateParser(fileName, encoding) end
ICSharpCodeNRefactoryParserFactory=m
return m;