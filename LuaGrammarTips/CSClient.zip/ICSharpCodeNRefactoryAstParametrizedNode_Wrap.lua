---@class ICSharpCodeNRefactoryAstParametrizedNode : ICSharpCodeNRefactoryAstAttributedNode
---instance properties
---@field public Name SystemString
---@field public Parameters SystemCollectionsGenericList1ICSharpCodeNRefactoryAstParameterDeclarationExpression
local m = {};
ICSharpCodeNRefactoryAstParametrizedNode=m
return m;