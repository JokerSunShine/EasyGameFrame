---@class activityV2.ResCrazyHappyReward
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public hasDrawIndexList System.Collections.Generic.List1System.Int32
local m = {};

activityV2.ResCrazyHappyReward=m
return m;