---@class ICSharpCode.NRefactory.Ast.ClassType
---@field Class @0
---@field Module @1
---@field Interface @2
---@field Struct @3
---@field Enum @4
ICSharpCode.NRefactory.Ast.ClassType=m
return m;