---@class ICSharpCode.NRefactory.Visitors.PrefixFieldsVisitor : ICSharpCode.NRefactory.Visitors.AbstractAstVisitor
local m = {};
---@param typeDeclaration ICSharpCode.NRefactory.Ast.INode
function m:Run(typeDeclaration) end
---@param typeDeclaration ICSharpCode.NRefactory.Ast.TypeDeclaration
---@param data System.Object
---@return System.Object
function m:VisitTypeDeclaration(typeDeclaration, data) end
---@param blockStatement ICSharpCode.NRefactory.Ast.BlockStatement
---@param data System.Object
---@return System.Object
function m:VisitBlockStatement(blockStatement, data) end
---@param methodDeclaration ICSharpCode.NRefactory.Ast.MethodDeclaration
---@param data System.Object
---@return System.Object
function m:VisitMethodDeclaration(methodDeclaration, data) end
---@param propertyDeclaration ICSharpCode.NRefactory.Ast.PropertyDeclaration
---@param data System.Object
---@return System.Object
function m:VisitPropertyDeclaration(propertyDeclaration, data) end
---@param constructorDeclaration ICSharpCode.NRefactory.Ast.ConstructorDeclaration
---@param data System.Object
---@return System.Object
function m:VisitConstructorDeclaration(constructorDeclaration, data) end
---@param variableDeclaration ICSharpCode.NRefactory.Ast.VariableDeclaration
---@param data System.Object
---@return System.Object
function m:VisitVariableDeclaration(variableDeclaration, data) end
---@param parameterDeclarationExpression ICSharpCode.NRefactory.Ast.ParameterDeclarationExpression
---@param data System.Object
---@return System.Object
function m:VisitParameterDeclarationExpression(parameterDeclarationExpression, data) end
---@param foreachStatement ICSharpCode.NRefactory.Ast.ForeachStatement
---@param data System.Object
---@return System.Object
function m:VisitForeachStatement(foreachStatement, data) end
---@param identifierExpression ICSharpCode.NRefactory.Ast.IdentifierExpression
---@param data System.Object
---@return System.Object
function m:VisitIdentifierExpression(identifierExpression, data) end
---@param fieldReferenceExpression ICSharpCode.NRefactory.Ast.MemberReferenceExpression
---@param data System.Object
---@return System.Object
function m:VisitMemberReferenceExpression(fieldReferenceExpression, data) end
ICSharpCode.NRefactory.Visitors.PrefixFieldsVisitor=m
return m;