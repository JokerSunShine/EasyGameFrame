---@class bagV2.ResBuyMaterialWaySuccess
---instance properties
---@field public buyId System.Int32
---@field public buyIdSpecified System.Boolean
---@field public buyCount System.Int32
---@field public buyCountSpecified System.Boolean
local m = {};

bagV2.ResBuyMaterialWaySuccess=m
return m;