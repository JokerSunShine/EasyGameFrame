---@class AppellationIdEnum
---@field Union @1
---@field Marriage @2
local m = {};
AppellationIdEnum=m
return m;