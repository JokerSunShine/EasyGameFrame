---@class boothV2.UpdateBoothPointResponse
---instance properties
---@field public boothId System.Int64
---@field public boothIdSpecified System.Boolean
---@field public success System.Int32
---@field public successSpecified System.Boolean
local m = {};

boothV2.UpdateBoothPointResponse=m
return m;