---@class FrameworkOpenFolder
local m = {};
function m.OpenFolderDataPath() end
function m.OpenStreamAssetsPath() end
function m.OpenFolderConsoleLogPath() end
function m.OpenFolderPersistenDataPath() end
function m.OpenFolderTemporaryCachePath() end
FrameworkOpenFolder=m
return m;