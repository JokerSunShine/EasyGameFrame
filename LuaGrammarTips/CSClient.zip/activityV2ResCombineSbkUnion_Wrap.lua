---@class activityV2.ResCombineSbkUnion
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public unionNameList System.Collections.Generic.List1System.String
local m = {};

activityV2.ResCombineSbkUnion=m
return m;