---@class auctionV2.ReleaseBuyProductsRequest
---instance properties
---@field public price bagV2.CoinInfo
---@field public condition auctionV2.BuyProductsCondition
---@field public name System.String
---@field public nameSpecified System.Boolean
local m = {};

auctionV2.ReleaseBuyProductsRequest=m
return m;