---@class DataStructGraphBaseNodeAbstract1T
---instance fields
---@field public data T
---@field public len SystemInt32
---@field public isVisit SystemBoolean
local m = {};
function m:ResetState() end
---@param vertexIndex SystemInt32
---@param len SystemInt32
function m:AddEdge(vertexIndex, len) end
---@param index SystemInt32
function m:RemoveEdge(index) end
DataStructGraphBaseNodeAbstract1T=m
return m;