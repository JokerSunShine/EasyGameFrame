---@class Microsoft.VisualBasic.VBTypeAttributeConverter : Microsoft.VisualBasic.VBModifierAttributeConverter
---properties
---@field public Default Microsoft.VisualBasic.VBTypeAttributeConverter
local m = {};
Microsoft.VisualBasic.VBTypeAttributeConverter=m
return m;