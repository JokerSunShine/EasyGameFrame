---@class ICSharpCodeSharpZipLibBZip2BZip2InputStream : SystemIOStream
---instance properties
---@field public CanRead SystemBoolean
---@field public CanSeek SystemBoolean
---@field public CanWrite SystemBoolean
---@field public Length SystemInt64
---@field public Position SystemInt64
local m = {};
function m:Flush() end
---@param offset SystemInt64
---@param origin SystemIOSeekOrigin
---@return SystemInt64
function m:Seek(offset, origin) end
---@param val SystemInt64
function m:SetLength(val) end
---@param array SystemByte
---@param offset SystemInt32
---@param count SystemInt32
function m:Write(array, offset, count) end
---@param val SystemByte
function m:WriteByte(val) end
---@param b SystemByte
---@param offset SystemInt32
---@param count SystemInt32
---@return SystemInt32
function m:Read(b, offset, count) end
function m:Close() end
---@return SystemInt32
function m:ReadByte() end
ICSharpCodeSharpZipLibBZip2BZip2InputStream=m
return m;