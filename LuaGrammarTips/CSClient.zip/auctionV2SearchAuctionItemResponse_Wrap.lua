---@class auctionV2.SearchAuctionItemResponse
---instance properties
---@field public list auctionV2.AuctionItemList
---@field public totalCount System.Int32
---@field public totalCountSpecified System.Boolean
local m = {};

auctionV2.SearchAuctionItemResponse=m
return m;