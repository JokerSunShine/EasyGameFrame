---@class Microsoft.Win32.PowerModeChangedEventArgs : System.EventArgs
---instance properties
---@field public Mode Microsoft.Win32.PowerModes
local m = {};
Microsoft.Win32.PowerModeChangedEventArgs=m
return m;