---@class ICSharpCode.NRefactory.Visitors.SetParentVisitor : ICSharpCode.NRefactory.Visitors.NodeTrackingAstVisitor
local m = {};
ICSharpCode.NRefactory.Visitors.SetParentVisitor=m
return m;