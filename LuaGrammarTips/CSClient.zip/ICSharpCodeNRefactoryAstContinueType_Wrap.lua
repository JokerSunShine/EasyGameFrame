---@class ICSharpCodeNRefactoryAstContinueType
---@field None @0
---@field Do @1
---@field For @2
---@field While @3
ICSharpCodeNRefactoryAstContinueType=m
return m;