---@class bagV2.SellActivityItemRequest
---instance properties
---@field public itemId System.Int32
---@field public count System.Int32
local m = {};

bagV2.SellActivityItemRequest=m
return m;