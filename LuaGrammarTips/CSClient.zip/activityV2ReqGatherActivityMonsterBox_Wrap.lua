---@class activityV2.ReqGatherActivityMonsterBox
---instance properties
---@field public box System.Int64
local m = {};

activityV2.ReqGatherActivityMonsterBox=m
return m;