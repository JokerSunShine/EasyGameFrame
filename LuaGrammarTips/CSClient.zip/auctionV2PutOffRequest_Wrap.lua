---@class auctionV2.PutOffRequest
---instance properties
---@field public lid System.Int64
---@field public lidSpecified System.Boolean
---@field public itemType System.Int32
---@field public itemTypeSpecified System.Boolean
local m = {};

auctionV2.PutOffRequest=m
return m;