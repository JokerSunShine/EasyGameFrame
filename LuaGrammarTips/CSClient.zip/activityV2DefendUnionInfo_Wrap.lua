---@class activityV2.DefendUnionInfo
---instance properties
---@field public unionName System.String
---@field public unionNameSpecified System.Boolean
---@field public unionScore System.Int32
---@field public unionScoreSpecified System.Boolean
---@field public totalScore System.Int32
---@field public totalScoreSpecified System.Boolean
---@field public unionId System.Int64
---@field public unionIdSpecified System.Boolean
local m = {};

activityV2.DefendUnionInfo=m
return m;