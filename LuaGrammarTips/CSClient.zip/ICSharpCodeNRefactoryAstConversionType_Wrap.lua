---@class ICSharpCodeNRefactoryAstConversionType
---@field None @0
---@field Implicit @1
---@field Explicit @2
ICSharpCodeNRefactoryAstConversionType=m
return m;