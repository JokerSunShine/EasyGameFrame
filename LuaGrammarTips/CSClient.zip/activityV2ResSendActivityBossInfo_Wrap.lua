---@class activityV2.ResSendActivityBossInfo
---instance properties
---@field public remainNum System.Int32
---@field public remainNumSpecified System.Boolean
---@field public hasBuyNum System.Int32
---@field public hasBuyNumSpecified System.Boolean
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
local m = {};

activityV2.ResSendActivityBossInfo=m
return m;