---@class activityV2.ResSoulStoneCost
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public costNum System.Int32
---@field public costNumSpecified System.Boolean
local m = {};

activityV2.ResSoulStoneCost=m
return m;