---@class ExCSSIRuleContainer
---instance properties
---@field public Declarations SystemCollectionsGenericList1ExCSSRuleSet
local m = {};
ExCSSIRuleContainer=m
return m;