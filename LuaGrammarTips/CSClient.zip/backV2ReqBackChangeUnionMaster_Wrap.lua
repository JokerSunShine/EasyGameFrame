---@class backV2.ReqBackChangeUnionMaster
---instance properties
---@field public unionId System.Int64
---@field public unionIdSpecified System.Boolean
---@field public uid System.Int64
---@field public uidSpecified System.Boolean
local m = {};

backV2.ReqBackChangeUnionMaster=m
return m;