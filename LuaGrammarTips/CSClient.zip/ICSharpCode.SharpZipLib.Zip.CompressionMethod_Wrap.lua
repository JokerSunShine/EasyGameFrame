---@class ICSharpCode.SharpZipLib.Zip.CompressionMethod
---@field Stored @0
---@field Deflated @8
---@field Deflate64 @9
---@field BZip2 @11
---@field WinZipAES @99
ICSharpCode.SharpZipLib.Zip.CompressionMethod=m
return m;