---@class Microsoft.VisualBasic.VBCodeGenerator : System.CodeDom.Compiler.CodeCompiler
local m = {};
---@param value System.String
---@return System.Boolean
function m.IsKeyword(value) end
Microsoft.VisualBasic.VBCodeGenerator=m
return m;