---@class ICSharpCode.SharpZipLib.Tar.TarHeader
---fields
---@field public CHKSUMOFS System.Int32
---@field public LF_OLDNORM System.Byte
---@field public LF_NORMAL System.Byte
---@field public LF_LINK System.Byte
---@field public LF_SYMLINK System.Byte
---@field public LF_CHR System.Byte
---@field public LF_BLK System.Byte
---@field public LF_DIR System.Byte
---@field public LF_FIFO System.Byte
---@field public LF_CONTIG System.Byte
---@field public LF_GHDR System.Byte
---@field public LF_ACL System.Byte
---@field public LF_GNU_DUMPDIR System.Byte
---@field public LF_EXTATTR System.Byte
---@field public LF_META System.Byte
---@field public LF_GNU_LONGLINK System.Byte
---@field public LF_GNU_LONGNAME System.Byte
---@field public LF_GNU_MULTIVOL System.Byte
---@field public LF_GNU_NAMES System.Byte
---@field public LF_GNU_SPARSE System.Byte
---@field public LF_GNU_VOLHDR System.Byte
---@field public NAMELEN System.Int32
---@field public MODELEN System.Int32
---@field public UIDLEN System.Int32
---@field public GIDLEN System.Int32
---@field public CHKSUMLEN System.Int32
---@field public SIZELEN System.Int32
---@field public MAGICLEN System.Int32
---@field public VERSIONLEN System.Int32
---@field public MODTIMELEN System.Int32
---@field public UNAMELEN System.Int32
---@field public GNAMELEN System.Int32
---@field public DEVLEN System.Int32
---@field public LF_XHDR System.Byte
---@field public TMAGIC System.String
---@field public GNU_TMAGIC System.String
---instance properties
---@field public Name System.String
---@field public Mode System.Int32
---@field public UserId System.Int32
---@field public GroupId System.Int32
---@field public Size System.Int64
---@field public ModTime System.DateTime
---@field public Checksum System.Int32
---@field public IsChecksumValid System.Boolean
---@field public TypeFlag System.Byte
---@field public LinkName System.String
---@field public Magic System.String
---@field public Version System.String
---@field public UserName System.String
---@field public GroupName System.String
---@field public DevMajor System.Int32
---@field public DevMinor System.Int32
local m = {};
---@param userId System.Int32
---@param userName System.String
---@param groupId System.Int32
---@param groupName System.String
function m.SetValueDefaults(userId, userName, groupId, groupName) end
function m.ResetValueDefaults() end
---@param header System.Byte[]
---@param offset System.Int32
---@param length System.Int32
---@return System.Int64
function m.ParseOctal(header, offset, length) end
---@param header System.Byte[]
---@param offset System.Int32
---@param length System.Int32
---@return System.Text.StringBuilder
function m.ParseName(header, offset, length) end
---@param name System.Text.StringBuilder
---@param nameOffset System.Int32
---@param buf System.Byte[]
---@param bufferOffset System.Int32
---@param length System.Int32
---@return System.Int32
function m.GetNameBytes(name, nameOffset, buf, bufferOffset, length) end
---@param name System.String
---@param nameOffset System.Int32
---@param buf System.Byte[]
---@param bufferOffset System.Int32
---@param length System.Int32
---@return System.Int32
function m.GetNameBytes(name, nameOffset, buf, bufferOffset, length) end
---@param name System.Text.StringBuilder
---@param buf System.Byte[]
---@param offset System.Int32
---@param length System.Int32
---@return System.Int32
function m.GetNameBytes(name, buf, offset, length) end
---@param name System.String
---@param buf System.Byte[]
---@param offset System.Int32
---@param length System.Int32
---@return System.Int32
function m.GetNameBytes(name, buf, offset, length) end
---@param toAdd System.String
---@param nameOffset System.Int32
---@param buffer System.Byte[]
---@param bufferOffset System.Int32
---@param length System.Int32
---@return System.Int32
function m.GetAsciiBytes(toAdd, nameOffset, buffer, bufferOffset, length) end
---@param val System.Int64
---@param buf System.Byte[]
---@param offset System.Int32
---@param length System.Int32
---@return System.Int32
function m.GetOctalBytes(val, buf, offset, length) end
---@param val System.Int64
---@param buf System.Byte[]
---@param offset System.Int32
---@param length System.Int32
---@return System.Int32
function m.GetLongOctalBytes(val, buf, offset, length) end
---@return System.Object
function m:Clone() end
---@return System.Int32
function m:GetHashCode() end
---@param obj System.Object
---@return System.Boolean
function m:Equals(obj) end
---@param header System.Byte[]
function m:ParseBuffer(header) end
---@param outbuf System.Byte[]
function m:WriteHeader(outbuf) end
ICSharpCode.SharpZipLib.Tar.TarHeader=m
return m;