---@class AppearanceInfo_Player : AppearanceInfo1CSPlayer
local m = {};

AppearanceInfo_Player=m
return m;