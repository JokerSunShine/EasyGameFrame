---@class bagV2.InstanceItemInfo
---instance properties
---@field public globalId System.Int32
---@field public globalIdSpecified System.Boolean
---@field public useNum System.Int32
---@field public useNumSpecified System.Boolean
local m = {};

bagV2.InstanceItemInfo=m
return m;