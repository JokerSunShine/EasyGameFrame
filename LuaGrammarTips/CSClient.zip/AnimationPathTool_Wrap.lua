---@class AnimationPathTool : UnityEngine.MonoBehaviour
---instance fields
---@field public ShowPath System.Boolean
---@field public activeParentTransform UnityEngine.Transform
---@field public animationClip UnityEngine.AnimationClip
---@field public OnAnimationEventDelegate AnimationPathToolAnimationEventDelegate
local m = {};

---@param data UnityEngine.AnimationEvent
function m:SendEventID(data) end
AnimationPathTool=m
return m;