---@class bagV2.ResItemTips
---instance properties
---@field public tip System.Collections.Generic.List1bagV2.ItemTip
local m = {};

bagV2.ResItemTips=m
return m;