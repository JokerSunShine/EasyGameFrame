---@class activityV2.ResRaffleResult
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public index System.Int32
---@field public indexSpecified System.Boolean
---@field public raffleItemList System.Collections.Generic.List1activityV2.RaffleItem
local m = {};

activityV2.ResRaffleResult=m
return m;