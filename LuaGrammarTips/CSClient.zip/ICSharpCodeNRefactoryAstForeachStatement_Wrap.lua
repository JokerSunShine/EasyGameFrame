---@class ICSharpCodeNRefactoryAstForeachStatement : ICSharpCodeNRefactoryAstStatementWithEmbeddedStatement
---instance properties
---@field public TypeReference ICSharpCodeNRefactoryAstTypeReference
---@field public VariableName SystemString
---@field public Expression ICSharpCodeNRefactoryAstExpression
---@field public NextExpression ICSharpCodeNRefactoryAstExpression
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstForeachStatement=m
return m;