---@class EasyHookCOMClassInfo
---instance properties
---@field public MethodPointers SystemIntPtr
---@field public LibraryOfFunction SystemDiagnosticsProcessModule
local m = {};
---@return SystemBoolean
function m:Query() end
---@return SystemBoolean
function m:IsModuleLoaded() end
EasyHookCOMClassInfo=m
return m;