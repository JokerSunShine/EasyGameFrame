---@class ICSharpCode.SharpZipLib.Checksums.Crc32
---instance properties
---@field public Value System.Int64
local m = {};
function m:Reset() end
---@param bval System.Int32
function m:Update(bval) end
---@param buffer System.Byte[]
function m:Update(buffer) end
---@param buf System.Byte[]
---@param off System.Int32
---@param len System.Int32
function m:Update(buf, off, len) end
ICSharpCode.SharpZipLib.Checksums.Crc32=m
return m;