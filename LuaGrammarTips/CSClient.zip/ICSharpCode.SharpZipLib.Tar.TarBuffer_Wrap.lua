---@class ICSharpCode.SharpZipLib.Tar.TarBuffer
---fields
---@field public BlockSize System.Int32
---@field public DefaultBlockFactor System.Int32
---@field public DefaultRecordSize System.Int32
---instance properties
---@field public RecordSize System.Int32
---@field public BlockFactor System.Int32
local m = {};
---@param inputStream System.IO.Stream
---@return ICSharpCode.SharpZipLib.Tar.TarBuffer
function m.CreateInputTarBuffer(inputStream) end
---@param inputStream System.IO.Stream
---@param blockFactor System.Int32
---@return ICSharpCode.SharpZipLib.Tar.TarBuffer
function m.CreateInputTarBuffer(inputStream, blockFactor) end
---@param outputStream System.IO.Stream
---@return ICSharpCode.SharpZipLib.Tar.TarBuffer
function m.CreateOutputTarBuffer(outputStream) end
---@param outputStream System.IO.Stream
---@param blockFactor System.Int32
---@return ICSharpCode.SharpZipLib.Tar.TarBuffer
function m.CreateOutputTarBuffer(outputStream, blockFactor) end
---@return System.Int32
function m:GetBlockFactor() end
---@return System.Int32
function m:GetRecordSize() end
---@param block System.Byte[]
---@return System.Boolean
function m:IsEOFBlock(block) end
function m:SkipBlock() end
---@return System.Byte[]
function m:ReadBlock() end
---@return System.Int32
function m:GetCurrentBlockNum() end
---@return System.Int32
function m:GetCurrentRecordNum() end
---@param block System.Byte[]
function m:WriteBlock(block) end
---@param buf System.Byte[]
---@param offset System.Int32
function m:WriteBlock(buf, offset) end
function m:Close() end
ICSharpCode.SharpZipLib.Tar.TarBuffer=m
return m;