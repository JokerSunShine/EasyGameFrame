---@class ICSharpCodeNRefactoryComment : ICSharpCodeNRefactoryAbstractSpecial
---instance properties
---@field public CommentType ICSharpCodeNRefactoryCommentType
---@field public CommentText SystemString
---@field public CommentStartsLine SystemBoolean
local m = {};
---@return SystemString
function m:ToString() end
---@param visitor ICSharpCodeNRefactoryISpecialVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
ICSharpCodeNRefactoryComment=m
return m;