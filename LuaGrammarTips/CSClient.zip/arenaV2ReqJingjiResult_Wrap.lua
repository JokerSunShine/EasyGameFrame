---@class arenaV2.ReqJingjiResult
---instance properties
---@field public targetRank System.Int32
---@field public targetRankSpecified System.Boolean
---@field public line System.Int32
---@field public lineSpecified System.Boolean
local m = {};

arenaV2.ReqJingjiResult=m
return m;