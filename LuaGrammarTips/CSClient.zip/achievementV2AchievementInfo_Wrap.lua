---@class achievementV2.AchievementInfo
---instance properties
---@field public id System.Int32
---@field public idSpecified System.Boolean
---@field public state System.Int32
---@field public stateSpecified System.Boolean
---@field public achievementValue System.Int32
---@field public achievementValueSpecified System.Boolean
local m = {};

achievementV2.AchievementInfo=m
return m;