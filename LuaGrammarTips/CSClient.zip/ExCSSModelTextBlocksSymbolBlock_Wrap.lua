---@class ExCSSModelTextBlocksSymbolBlock : ExCSSModelTextBlocksBlock
local m = {};
---@return SystemString
function m:ToString() end
ExCSSModelTextBlocksSymbolBlock=m
return m;