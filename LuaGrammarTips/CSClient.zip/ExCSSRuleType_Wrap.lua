---@class ExCSSRuleType
---@field Unknown @0
---@field Style @1
---@field Charset @2
---@field Import @3
---@field Media @4
---@field FontFace @5
---@field Page @6
---@field Keyframes @7
---@field Keyframe @8
---@field Namespace @10
---@field CounterStyle @11
---@field Supports @12
---@field Document @13
---@field FontFeatureValues @14
---@field Viewport @15
---@field RegionStyle @16
ExCSSRuleType=m
return m;