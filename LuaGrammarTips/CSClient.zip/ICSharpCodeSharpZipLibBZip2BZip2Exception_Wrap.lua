---@class ICSharpCodeSharpZipLibBZip2BZip2Exception : ICSharpCodeSharpZipLibSharpZipBaseException
local m = {};
ICSharpCodeSharpZipLibBZip2BZip2Exception=m
return m;