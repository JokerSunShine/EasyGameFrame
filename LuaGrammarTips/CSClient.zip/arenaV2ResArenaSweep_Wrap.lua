---@class arenaV2.ResArenaSweep
---instance properties
---@field public resultRewardList System.Collections.Generic.List1arenaV2.RankRewardInfo
local m = {};

arenaV2.ResArenaSweep=m
return m;