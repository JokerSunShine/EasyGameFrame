---@class FrameworkUtilityType
local m = {};
---@return SystemCollectionsGenericList1SystemType
function m.GetAllTypes() end
---@param type SystemType
---@param str SystemString
---@return SystemBoolean
function m.IsNameCurSpace(type, str) end
---@param type SystemType
---@return SystemString
function m.GetTypeFileName(type) end
---@param typeName SystemString
---@return SystemString
function m.GetTypeFileName(typeName) end
---@param typeName SystemString
---@return SystemString
function m.GetTypeTagName(typeName) end
FrameworkUtilityType=m
return m;