---@class ICSharpCodeSharpZipLibTarTarInputStream : SystemIOStream
---instance properties
---@field public CanRead SystemBoolean
---@field public CanSeek SystemBoolean
---@field public CanWrite SystemBoolean
---@field public Length SystemInt64
---@field public Position SystemInt64
---@field public Available SystemInt64
---@field public IsMarkSupported SystemBoolean
local m = {};
function m:Flush() end
---@param offset SystemInt64
---@param origin SystemIOSeekOrigin
---@return SystemInt64
function m:Seek(offset, origin) end
---@param val SystemInt64
function m:SetLength(val) end
---@param array SystemByte
---@param offset SystemInt32
---@param count SystemInt32
function m:Write(array, offset, count) end
---@param val SystemByte
function m:WriteByte(val) end
---@param factory ICSharpCodeSharpZipLibTarTarInputStreamIEntryFactory
function m:SetEntryFactory(factory) end
function m:Close() end
---@return SystemInt32
function m:GetRecordSize() end
---@param numToSkip SystemInt64
function m:Skip(numToSkip) end
---@param markLimit SystemInt32
function m:Mark(markLimit) end
function m:Reset() end
---@return ICSharpCodeSharpZipLibTarTarEntry
function m:GetNextEntry() end
---@return SystemInt32
function m:ReadByte() end
---@param outputBuffer SystemByte
---@param offset SystemInt32
---@param count SystemInt32
---@return SystemInt32
function m:Read(outputBuffer, offset, count) end
---@param outputStream SystemIOStream
function m:CopyEntryContents(outputStream) end
ICSharpCodeSharpZipLibTarTarInputStream=m
return m;