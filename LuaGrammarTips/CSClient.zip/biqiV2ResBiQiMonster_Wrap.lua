---@class biqiV2.ResBiQiMonster
---instance properties
---@field public monsterList System.Collections.Generic.List1biqiV2.MonsterInfo
local m = {};

biqiV2.ResBiQiMonster=m
return m;