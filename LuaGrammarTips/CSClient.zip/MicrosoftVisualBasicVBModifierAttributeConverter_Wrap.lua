---@class MicrosoftVisualBasicVBModifierAttributeConverter : SystemComponentModelTypeConverter
local m = {};
---@param context SystemComponentModelITypeDescriptorContext
---@param sourceType SystemType
---@return SystemBoolean
function m:CanConvertFrom(context, sourceType) end
---@param context SystemComponentModelITypeDescriptorContext
---@param culture SystemGlobalizationCultureInfo
---@param value SystemObject
---@return SystemObject
function m:ConvertFrom(context, culture, value) end
---@param context SystemComponentModelITypeDescriptorContext
---@param culture SystemGlobalizationCultureInfo
---@param value SystemObject
---@param destinationType SystemType
---@return SystemObject
function m:ConvertTo(context, culture, value, destinationType) end
---@param context SystemComponentModelITypeDescriptorContext
---@return SystemBoolean
function m:GetStandardValuesExclusive(context) end
---@param context SystemComponentModelITypeDescriptorContext
---@return SystemBoolean
function m:GetStandardValuesSupported(context) end
---@param context SystemComponentModelITypeDescriptorContext
---@return SystemComponentModelTypeConverterStandardValuesCollection
function m:GetStandardValues(context) end
MicrosoftVisualBasicVBModifierAttributeConverter=m
return m;