---@class ICSharpCode.SharpZipLib.Tar.TarInputStream : System.IO.Stream
---instance properties
---@field public CanRead System.Boolean
---@field public CanSeek System.Boolean
---@field public CanWrite System.Boolean
---@field public Length System.Int64
---@field public Position System.Int64
---@field public Available System.Int64
---@field public IsMarkSupported System.Boolean
local m = {};
function m:Flush() end
---@param offset System.Int64
---@param origin System.IO.SeekOrigin
---@return System.Int64
function m:Seek(offset, origin) end
---@param val System.Int64
function m:SetLength(val) end
---@param array System.Byte[]
---@param offset System.Int32
---@param count System.Int32
function m:Write(array, offset, count) end
---@param val System.Byte
function m:WriteByte(val) end
---@param factory ICSharpCode.SharpZipLib.Tar.TarInputStream+IEntryFactory
function m:SetEntryFactory(factory) end
function m:Close() end
---@return System.Int32
function m:GetRecordSize() end
---@param numToSkip System.Int64
function m:Skip(numToSkip) end
---@param markLimit System.Int32
function m:Mark(markLimit) end
function m:Reset() end
---@return ICSharpCode.SharpZipLib.Tar.TarEntry
function m:GetNextEntry() end
---@return System.Int32
function m:ReadByte() end
---@param outputBuffer System.Byte[]
---@param offset System.Int32
---@param count System.Int32
---@return System.Int32
function m:Read(outputBuffer, offset, count) end
---@param outputStream System.IO.Stream
function m:CopyEntryContents(outputStream) end
ICSharpCode.SharpZipLib.Tar.TarInputStream=m
return m;