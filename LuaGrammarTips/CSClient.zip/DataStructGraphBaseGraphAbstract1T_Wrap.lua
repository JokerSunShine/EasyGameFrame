---@class DataStructGraphBaseGraphAbstract1T
---instance fields
---@field public vertexNum SystemInt32
---@field public edgeNum SystemInt32
---instance properties
---@field public Vertexs DataStructGraphBaseNodeAbstract1T
local m = {};
---@param data T
function m:AddNode(data) end
---@param data T
---@return T
function m:RemoveNode(data) end
---@param start SystemInt32
---@param endParam SystemInt32
---@param len SystemInt32
function m:GraphAddEdge(start, endParam, len) end
---@param start SystemInt32
---@param endParam SystemInt32
function m:GraphRemoveEdge(start, endParam) end
---@param data T
---@return SystemInt32
function m:GetIndex(data) end
---@param index SystemInt32
---@return T
function m:GetData(index) end
---@param index SystemInt32
---@return DataStructGraphBaseNodeAbstract1T
function m:GetNode(index) end
function m:ClearNodeVisit() end
---@param index SystemInt32
---@return CommonDataStructQueueChainQueueChainQueue1DataStructGraphBaseNodeAbstract1T
function m:GraphBFS(index) end
---@param index SystemInt32
---@return CommonDataStructQueueChainQueueChainQueue1DataStructGraphBaseNodeAbstract1T
function m:SingleBFS(index) end
---@param index SystemInt32
---@return CommonDataStructQueueChainQueueChainQueue1DataStructGraphBaseNodeAbstract1T
function m:GraphDFS(index) end
---@param index SystemInt32
---@return CommonDataStructQueueChainQueueChainQueue1DataStructGraphBaseNodeAbstract1T
function m:SingleDFS(index) end
---@param index SystemInt32
---@return DataStructGraphBaseEdge
function m:GetEdges(index) end
function m:Expand() end
---@param data T
---@return DataStructGraphBaseNodeAbstract1T
function m:GetNode(data) end
---@param index SystemInt32
---@return T
function m:RemoveNode(index) end
---@param start SystemInt32
---@param endParam SystemInt32
---@param len SystemInt32
function m:AddEdge(start, endParam, len) end
---@param start SystemInt32
---@param endParam SystemInt32
---@param len SystemInt32
function m:AddArc(start, endParam, len) end
---@param start SystemInt32
---@param endParam SystemInt32
function m:RemvoeEdge(start, endParam) end
---@param start SystemInt32
---@param endParam SystemInt32
function m:RemvoeArc(start, endParam) end
---@param start SystemInt32
---@param endParam SystemInt32
---@return SystemInt32
function m:GetEdgeWeight(start, endParam) end
---@param index SystemInt32
---@return CommonDataStructQueueChainQueueChainQueue1DataStructGraphBaseNodeAbstract1T
function m:BFSorder(index) end
---@param index SystemInt32
---@return CommonDataStructQueueChainQueueChainQueue1DataStructGraphBaseNodeAbstract1T
function m:DFSorder(index) end
---@return DataStructGraphBaseEdge
function m:GetMinEdge() end
DataStructGraphBaseGraphAbstract1T=m
return m;