---@class CSObjectWrapEditor.Generator+MethodInfoSimulationComparer
local m = {};
---@param x CSObjectWrapEditor.Generator+MethodInfoSimulation
---@param y CSObjectWrapEditor.Generator+MethodInfoSimulation
---@return System.Boolean
function m:Equals(x, y) end
---@param obj CSObjectWrapEditor.Generator+MethodInfoSimulation
---@return System.Int32
function m:GetHashCode(obj) end
CSObjectWrapEditor.Generator+MethodInfoSimulationComparer=m
return m;