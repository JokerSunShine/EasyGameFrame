---@class INativeCompiler
local m = {};
---@param outFile SystemString
---@param sources SystemCollectionsGenericIEnumerable1SystemString
---@param includePaths SystemCollectionsGenericIEnumerable1SystemString
---@param libraries SystemCollectionsGenericIEnumerable1SystemString
---@param libraryPaths SystemCollectionsGenericIEnumerable1SystemString
function m:CompileDynamicLibrary(outFile, sources, includePaths, libraries, libraryPaths) end
INativeCompiler=m
return m;