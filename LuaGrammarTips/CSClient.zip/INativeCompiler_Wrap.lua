---@class INativeCompiler
local m = {};
---@param outFile System.String
---@param sources System.Collections.Generic.IEnumerable`1[System.String]
---@param includePaths System.Collections.Generic.IEnumerable`1[System.String]
---@param libraries System.Collections.Generic.IEnumerable`1[System.String]
---@param libraryPaths System.Collections.Generic.IEnumerable`1[System.String]
function m:CompileDynamicLibrary(outFile, sources, includePaths, libraries, libraryPaths) end
INativeCompiler=m
return m;