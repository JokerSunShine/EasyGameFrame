---@class ICSharpCode.SharpZipLib.BZip2.BZip2InputStream : System.IO.Stream
---instance properties
---@field public CanRead System.Boolean
---@field public CanSeek System.Boolean
---@field public CanWrite System.Boolean
---@field public Length System.Int64
---@field public Position System.Int64
local m = {};
function m:Flush() end
---@param offset System.Int64
---@param origin System.IO.SeekOrigin
---@return System.Int64
function m:Seek(offset, origin) end
---@param val System.Int64
function m:SetLength(val) end
---@param array System.Byte[]
---@param offset System.Int32
---@param count System.Int32
function m:Write(array, offset, count) end
---@param val System.Byte
function m:WriteByte(val) end
---@param b System.Byte[]
---@param offset System.Int32
---@param count System.Int32
---@return System.Int32
function m:Read(b, offset, count) end
function m:Close() end
---@return System.Int32
function m:ReadByte() end
ICSharpCode.SharpZipLib.BZip2.BZip2InputStream=m
return m;