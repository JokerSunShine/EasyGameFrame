---@class ExCSSModelISupportsMedia
---instance properties
---@field public Media ExCSSMediaTypeList
local m = {};
ExCSSModelISupportsMedia=m
return m;