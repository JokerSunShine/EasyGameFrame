---@class AwardsItem : System.ValueType
---instance fields
---@field public itemID System.Int32
---@field public effectID System.Int32
local m = {};

AwardsItem=m
return m;