---@class MicrosoftWin32IRegistryApi
local m = {};
---@param rkey MicrosoftWin32RegistryKey
---@param keyname SystemString
---@return MicrosoftWin32RegistryKey
function m:CreateSubKey(rkey, keyname) end
---@param hKey MicrosoftWin32RegistryHive
---@param machineName SystemString
---@return MicrosoftWin32RegistryKey
function m:OpenRemoteBaseKey(hKey, machineName) end
---@param rkey MicrosoftWin32RegistryKey
---@param keyname SystemString
---@param writtable SystemBoolean
---@return MicrosoftWin32RegistryKey
function m:OpenSubKey(rkey, keyname, writtable) end
---@param rkey MicrosoftWin32RegistryKey
function m:Flush(rkey) end
---@param rkey MicrosoftWin32RegistryKey
function m:Close(rkey) end
---@param rkey MicrosoftWin32RegistryKey
---@param name SystemString
---@param default_value SystemObject
---@param options MicrosoftWin32RegistryValueOptions
---@return SystemObject
function m:GetValue(rkey, name, default_value, options) end
---@param rkey MicrosoftWin32RegistryKey
---@param name SystemString
---@return MicrosoftWin32RegistryValueKind
function m:GetValueKind(rkey, name) end
---@param rkey MicrosoftWin32RegistryKey
---@param name SystemString
---@param value SystemObject
function m:SetValue(rkey, name, value) end
---@param rkey MicrosoftWin32RegistryKey
---@return SystemInt32
function m:SubKeyCount(rkey) end
---@param rkey MicrosoftWin32RegistryKey
---@return SystemInt32
function m:ValueCount(rkey) end
---@param rkey MicrosoftWin32RegistryKey
---@param value SystemString
---@param throw_if_missing SystemBoolean
function m:DeleteValue(rkey, value, throw_if_missing) end
---@param rkey MicrosoftWin32RegistryKey
---@param keyName SystemString
---@param throw_if_missing SystemBoolean
function m:DeleteKey(rkey, keyName, throw_if_missing) end
---@param rkey MicrosoftWin32RegistryKey
---@return SystemString
function m:GetSubKeyNames(rkey) end
---@param rkey MicrosoftWin32RegistryKey
---@return SystemString
function m:GetValueNames(rkey) end
---@param rkey MicrosoftWin32RegistryKey
---@return SystemString
function m:ToString(rkey) end
---@param rkey MicrosoftWin32RegistryKey
---@param name SystemString
---@param value SystemObject
---@param valueKind MicrosoftWin32RegistryValueKind
function m:SetValue(rkey, name, value, valueKind) end
---@param rkey MicrosoftWin32RegistryKey
---@param keyname SystemString
---@param options MicrosoftWin32RegistryOptions
---@return MicrosoftWin32RegistryKey
function m:CreateSubKey(rkey, keyname, options) end
---@param handle MicrosoftWin32SafeHandlesSafeRegistryHandle
---@return MicrosoftWin32RegistryKey
function m:FromHandle(handle) end
---@param key MicrosoftWin32RegistryKey
---@return SystemIntPtr
function m:GetHandle(key) end
MicrosoftWin32IRegistryApi=m
return m;