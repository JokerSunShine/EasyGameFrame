---@class ICSharpCodeNRefactoryAstOperatorDeclaration : ICSharpCodeNRefactoryAstMethodDeclaration
---instance properties
---@field public ConversionType ICSharpCodeNRefactoryAstConversionType
---@field public ReturnTypeAttributes SystemCollectionsGenericList1ICSharpCodeNRefactoryAstAttributeSection
---@field public OverloadableOperator ICSharpCodeNRefactoryAstOverloadableOperatorType
---@field public IsConversionOperator SystemBoolean
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstOperatorDeclaration=m
return m;