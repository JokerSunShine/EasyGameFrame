---@class ICSharpCodeNRefactoryAstPropertySetRegion : ICSharpCodeNRefactoryAstPropertyGetSetRegion
---properties
---@field public Null ICSharpCodeNRefactoryAstPropertySetRegion
---instance properties
---@field public Parameters SystemCollectionsGenericList1ICSharpCodeNRefactoryAstParameterDeclarationExpression
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstPropertySetRegion=m
return m;