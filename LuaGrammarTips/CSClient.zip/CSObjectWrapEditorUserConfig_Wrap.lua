---@class CSObjectWrapEditorUserConfig : SystemValueType
---instance fields
---@field public LuaCallCSharp SystemCollectionsGenericIEnumerable1SystemType
---@field public CSharpCallLua SystemCollectionsGenericIEnumerable1SystemType
---@field public ReflectionUse SystemCollectionsGenericIEnumerable1SystemType
local m = {};
CSObjectWrapEditorUserConfig=m
return m;