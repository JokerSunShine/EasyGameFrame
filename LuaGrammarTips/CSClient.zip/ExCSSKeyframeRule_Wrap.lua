---@class ExCSSKeyframeRule : ExCSSRuleSet
---instance properties
---@field public Declarations ExCSSStyleDeclaration
local m = {};
---@param value SystemString
function m:AddValue(value) end
---@return SystemString
function m:ToString() end
---@param friendlyFormat SystemBoolean
---@param indentation SystemInt32 @default_value:0
---@return SystemString
function m:ToString(friendlyFormat, indentation) end
ExCSSKeyframeRule=m
return m;