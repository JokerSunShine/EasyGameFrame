---@class ExCSS.GenericRule : ExCSS.AggregateRule
---instance properties
---@field public Declarations ExCSS.StyleDeclaration
local m = {};
---@return System.String
function m:ToString() end
---@param friendlyFormat System.Boolean
---@param indentation System.Int32 @default_value:0
---@return System.String
function m:ToString(friendlyFormat, indentation) end
ExCSS.GenericRule=m
return m;