---@class JetBrains.Annotations.ImplicitUseTargetFlags
---@field Itself @1
---@field Itself @1
---@field Members @2
---@field WithMembers @3
JetBrains.Annotations.ImplicitUseTargetFlags=m
return m;