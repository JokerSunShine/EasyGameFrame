---@class ICSharpCodeNRefactoryParserTagComment : ICSharpCodeNRefactoryComment
---instance properties
---@field public Tag SystemString
local m = {};
ICSharpCodeNRefactoryParserTagComment=m
return m;