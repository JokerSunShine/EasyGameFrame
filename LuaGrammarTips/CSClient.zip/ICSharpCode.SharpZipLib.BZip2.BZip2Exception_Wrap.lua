---@class ICSharpCode.SharpZipLib.BZip2.BZip2Exception : ICSharpCode.SharpZipLib.SharpZipBaseException
local m = {};
ICSharpCode.SharpZipLib.BZip2.BZip2Exception=m
return m;