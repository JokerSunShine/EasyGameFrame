---@class ICSharpCodeSharpZipLibEncryptionPkzipClassic : SystemSecurityCryptographySymmetricAlgorithm
local m = {};
---@param seed SystemByte
---@return SystemByte
function m.GenerateKeys(seed) end
ICSharpCodeSharpZipLibEncryptionPkzipClassic=m
return m;