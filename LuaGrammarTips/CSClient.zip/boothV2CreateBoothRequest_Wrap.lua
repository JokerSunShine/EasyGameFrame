---@class boothV2.CreateBoothRequest
---instance properties
---@field public label System.Collections.Generic.List1System.Int32
---@field public boothConfigId System.Int32
---@field public boothConfigIdSpecified System.Boolean
---@field public boothCoordinateId System.Int32
---@field public boothCoordinateIdSpecified System.Boolean
local m = {};

boothV2.CreateBoothRequest=m
return m;