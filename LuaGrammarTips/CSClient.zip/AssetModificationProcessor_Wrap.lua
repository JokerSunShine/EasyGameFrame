---@class AssetModificationProcessor
local m = {};
AssetModificationProcessor=m
return m;