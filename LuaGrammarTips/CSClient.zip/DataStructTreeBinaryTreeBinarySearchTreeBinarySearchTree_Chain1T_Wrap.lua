---@class DataStructTreeBinaryTreeBinarySearchTreeBinarySearchTree_Chain1T : DataStructTreeBinaryTreeChainBinaryTreeAbstract1T
---instance properties
---@field public Head DataStructTreeBinaryTreeNode1T
---@field public Count SystemInt32
---@field public CompareFunc SystemFunc3TTSystemInt32
local m = {};
---@param value T
---@return DataStructTreeBinaryTreeNode1T
function m:InsertNode(value) end
---@param data T
---@param node DataStructTreeBinaryTreeNode1T @default_value:
---@return DataStructTreeBinaryTreeNode1T
function m:GetInsertNode(data, node) end
---@param data T
---@param changeCount SystemBoolean @default_value:True
---@return DataStructTreeBinaryTreeNode1T
function m:DeleteNode(data, changeCount) end
---@param data T
---@param node DataStructTreeBinaryTreeNode1T @default_value:
---@param isFirstFind SystemBoolean @default_value:True
---@return DataStructTreeBinaryTreeNode1T
function m:FindNode(data, node, isFirstFind) end
---@param node DataStructTreeBinaryTreeNode1T
---@return DataStructTreeBinaryTreeNode1T
function m:GetDescendantNode(node) end
DataStructTreeBinaryTreeBinarySearchTreeBinarySearchTree_Chain1T=m
return m;