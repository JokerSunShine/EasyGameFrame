---@class activityV2.ResSendFirstKillBoss
---instance properties
---@field public rewardInfos System.Collections.Generic.List1activityV2.FirstKillRewardInfo
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
local m = {};

activityV2.ResSendFirstKillBoss=m
return m;