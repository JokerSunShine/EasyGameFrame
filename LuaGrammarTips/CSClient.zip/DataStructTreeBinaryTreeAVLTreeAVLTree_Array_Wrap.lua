---@class DataStructTreeBinaryTreeAVLTreeAVLTree_Array
local m = {};
DataStructTreeBinaryTreeAVLTreeAVLTree_Array=m
return m;