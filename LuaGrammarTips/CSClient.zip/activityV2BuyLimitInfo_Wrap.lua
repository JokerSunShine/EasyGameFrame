---@class activityV2.BuyLimitInfo
---instance properties
---@field public activityId System.Int32
---@field public isGetReward System.Boolean
---@field public isGetRewardSpecified System.Boolean
local m = {};

activityV2.BuyLimitInfo=m
return m;