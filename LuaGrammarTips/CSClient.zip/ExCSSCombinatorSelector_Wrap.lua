---@class ExCSSCombinatorSelector : SystemValueType
---instance fields
---@field public Selector ExCSSBaseSelector
---@field public Delimiter ExCSSCombinator
---instance properties
---@field public Character SystemChar
local m = {};
ExCSSCombinatorSelector=m
return m;