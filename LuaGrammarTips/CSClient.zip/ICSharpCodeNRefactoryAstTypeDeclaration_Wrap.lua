---@class ICSharpCodeNRefactoryAstTypeDeclaration : ICSharpCodeNRefactoryAstAttributedNode
---instance properties
---@field public Name SystemString
---@field public Type ICSharpCodeNRefactoryAstClassType
---@field public BaseTypes SystemCollectionsGenericList1ICSharpCodeNRefactoryAstTypeReference
---@field public Templates SystemCollectionsGenericList1ICSharpCodeNRefactoryAstTemplateDefinition
---@field public BodyStartLocation ICSharpCodeNRefactoryLocation
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstTypeDeclaration=m
return m;