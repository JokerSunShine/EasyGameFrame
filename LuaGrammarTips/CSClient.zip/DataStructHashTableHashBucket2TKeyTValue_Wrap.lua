---@class DataStructHashTableHashBucket2TKeyTValue
---instance fields
---@field public KeyHashCode SystemInt32
---@field public ValueHashCode SystemInt32
---@field public Next SystemInt32
---@field public state DataStructHashTableHashBucket2BucketStateTKeyTValue
---instance properties
---@field public Key TKey
---@field public Value TValue
local m = {};
---@param key TKey
---@param value TValue
function m:RefreshValue(key, value) end
---@param key TKey
---@return SystemBoolean
function m:KeyIsEqual(key) end
---@param value TValue
---@return SystemBoolean
function m:ValueIsEqual(value) end
function m:Delete() end
DataStructHashTableHashBucket2TKeyTValue=m
return m;