---@class AutomaticTeamVO
---instance properties
---@field public state System.Int32
---@field public panelName System.String
---@field public targetPlayerName System.String
---@field public targetPlayerId System.Int64
---@field public targetTeamId System.Int64
local m = {};

---@param state System.Int32
---@param targetTeamId System.Int64
---@param targetPlayerId System.Int64
---@param targetPlayerName System.String
---@param panelName System.String
function m:UpdateVo(state, targetTeamId, targetPlayerId, targetPlayerName, panelName) end
---@param state System.Int32
function m:UpdateState(state) end
---@return System.Int64
function m:GetJoinTeamParam() end
---@return System.String
function m:GetDesString() end
AutomaticTeamVO=m
return m;