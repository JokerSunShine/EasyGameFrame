---@class ICSharpCode.NRefactory.PrettyPrinter.IOutputAstVisitor
---instance properties
---@field public Text System.String
---@field public Errors ICSharpCode.NRefactory.Parser.Errors
---@field public Options ICSharpCode.NRefactory.PrettyPrinter.AbstractPrettyPrintOptions
---@field public OutputFormatter ICSharpCode.NRefactory.PrettyPrinter.IOutputFormatter
local m = {};
---@param value System.Action`1[ICSharpCode.NRefactory.Ast.INode]
function m:add_BeforeNodeVisit(value) end
---@param value System.Action`1[ICSharpCode.NRefactory.Ast.INode]
function m:remove_BeforeNodeVisit(value) end
---@param value System.Action`1[ICSharpCode.NRefactory.Ast.INode]
function m:add_AfterNodeVisit(value) end
---@param value System.Action`1[ICSharpCode.NRefactory.Ast.INode]
function m:remove_AfterNodeVisit(value) end
ICSharpCode.NRefactory.PrettyPrinter.IOutputAstVisitor=m
return m;