---@class CommonTrieSearchTrieSearch
local m = {};
---@param s SystemString
---@param trieNode CommonTrieSearchTrieNode @default_value:
---@param pos SystemInt32 @default_value:0
function m:Insert(s, trieNode, pos) end
---@param s SystemString
---@param trieNode CommonTrieSearchTrieNode @default_value:
---@param pos SystemInt32 @default_value:0
---@return SystemBoolean
function m:Delete(s, trieNode, pos) end
---@param s SystemString
---@return SystemBoolean
function m:SearchWord(s) end
---@param s SystemString
---@param node CommonTrieSearchTrieNode @default_value:
---@return SystemCollectionsGenericList1SystemString
function m:GetPrefixWord(s, node) end
CommonTrieSearchTrieSearch=m
return m;