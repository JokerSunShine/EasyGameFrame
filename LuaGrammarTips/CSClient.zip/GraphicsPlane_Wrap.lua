---@class GraphicsPlane
---instance fields
---@field public normal _3DMathVector3
---@field public constant SystemSingle
local m = {};
---@param plane GraphicsPlane
---@param sphere GraphicsSphere
---@return SystemInt32
function m.CrossForSphere(plane, sphere) end
GraphicsPlane=m
return m;