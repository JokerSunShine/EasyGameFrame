---@class FrameworkUtilityDirectory
local m = {};
---@param rootPath SystemString
---@param searchPatten SystemString @default_value:*
---@return SystemString
function m.GetAllFilePath(rootPath, searchPatten) end
FrameworkUtilityDirectory=m
return m;