---@class ICSharpCodeNRefactoryAstFixedStatement : ICSharpCodeNRefactoryAstStatementWithEmbeddedStatement
---instance properties
---@field public PointerDeclaration ICSharpCodeNRefactoryAstStatement
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstFixedStatement=m
return m;