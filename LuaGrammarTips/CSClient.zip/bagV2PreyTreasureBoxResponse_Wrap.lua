---@class bagV2.PreyTreasureBoxResponse
---instance properties
---@field public jackpot System.Collections.Generic.List1bagV2.BagItemInfo
---@field public rewardIndex System.Int32
---@field public rewardIndexSpecified System.Boolean
---@field public isRaffle System.Boolean
---@field public isRaffleSpecified System.Boolean
local m = {};

bagV2.PreyTreasureBoxResponse=m
return m;