---@class CSStringBuilder
---instance fields
---@field public strBuilder SystemTextStringBuilder
---properties
---@field public SB CSStringBuilder
local m = {};
---@param str SystemString
---@return SystemTextStringBuilder
function m.Append(str) end
---@param str0 SystemString
---@param str1 SystemString
---@return SystemTextStringBuilder
function m.Append(str0, str1) end
---@param str0 SystemString
---@param str1 SystemString
---@param str2 SystemString
---@return SystemTextStringBuilder
function m.Append(str0, str1, str2) end
---@param str0 SystemString
---@param str1 SystemString
---@param str2 SystemString
---@param str3 SystemString
---@return SystemTextStringBuilder
function m.Append(str0, str1, str2, str3) end
---@param str0 SystemString
---@param str1 SystemString
---@param str2 SystemString
---@param str3 SystemString
---@param str4 SystemString
---@return SystemTextStringBuilder
function m.Append(str0, str1, str2, str3, str4) end
---@param str0 SystemString
---@param str1 SystemString
---@param str2 SystemString
---@param str3 SystemString
---@param str4 SystemString
---@param str5 SystemString
---@return SystemTextStringBuilder
function m.Append(str0, str1, str2, str3, str4, str5) end
---@param strs SystemObject
---@return SystemTextStringBuilder
function m.Append(strs) end
function m.Clear() end
---@return SystemString
function m.ToString() end
CSStringBuilder=m
return m;