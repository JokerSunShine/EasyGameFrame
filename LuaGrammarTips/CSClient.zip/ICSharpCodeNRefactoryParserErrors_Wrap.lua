---@class ICSharpCodeNRefactoryParserErrors
---instance fields
---@field public SynErr ICSharpCodeNRefactoryParserErrorCodeProc
---@field public SemErr ICSharpCodeNRefactoryParserErrorCodeProc
---@field public Error ICSharpCodeNRefactoryParserErrorMsgProc
---instance properties
---@field public ErrorOutput SystemString
---@field public Count SystemInt32
local m = {};
ICSharpCodeNRefactoryParserErrors=m
return m;