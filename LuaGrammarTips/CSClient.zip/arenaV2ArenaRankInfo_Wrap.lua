---@class arenaV2.ArenaRankInfo
---instance properties
---@field public id System.Int32
---@field public idSpecified System.Boolean
---@field public startRank System.Int32
---@field public startRankSpecified System.Boolean
---@field public endRank System.Int32
---@field public endRankSpecified System.Boolean
---@field public name System.String
---@field public nameSpecified System.Boolean
---@field public robot System.Int32
---@field public robotSpecified System.Boolean
---@field public rankRewardList System.Collections.Generic.List1arenaV2.RankRewardInfo
local m = {};

arenaV2.ArenaRankInfo=m
return m;