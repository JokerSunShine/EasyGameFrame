---@class ICSharpCode.NRefactory.Ast.EventDeclaration : ICSharpCode.NRefactory.Ast.MemberNode
---instance properties
---@field public AddRegion ICSharpCode.NRefactory.Ast.EventAddRegion
---@field public RemoveRegion ICSharpCode.NRefactory.Ast.EventRemoveRegion
---@field public RaiseRegion ICSharpCode.NRefactory.Ast.EventRaiseRegion
---@field public BodyStart ICSharpCode.NRefactory.Location
---@field public BodyEnd ICSharpCode.NRefactory.Location
---@field public Initializer ICSharpCode.NRefactory.Ast.Expression
---@field public HasRemoveRegion System.Boolean
---@field public HasRaiseRegion System.Boolean
---@field public HasAddRegion System.Boolean
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.EventDeclaration=m
return m;