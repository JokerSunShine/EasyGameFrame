---@class BaseExposedPropertyDrawer+ExposedPropertyMode
---@field DefaultValue @0
---@field Named @1
---@field NamedGUID @2
BaseExposedPropertyDrawer+ExposedPropertyMode=m
return m;