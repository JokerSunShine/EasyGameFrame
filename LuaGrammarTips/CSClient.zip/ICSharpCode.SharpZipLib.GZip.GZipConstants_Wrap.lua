---@class ICSharpCode.SharpZipLib.GZip.GZipConstants
---fields
---@field public FTEXT System.Int32
---@field public FHCRC System.Int32
---@field public FEXTRA System.Int32
---@field public FNAME System.Int32
---@field public FCOMMENT System.Int32
---@field public GZIP_MAGIC System.Int32
local m = {};
ICSharpCode.SharpZipLib.GZip.GZipConstants=m
return m;