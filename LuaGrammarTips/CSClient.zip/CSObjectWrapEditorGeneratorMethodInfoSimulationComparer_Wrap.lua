---@class CSObjectWrapEditorGeneratorMethodInfoSimulationComparer
local m = {};
---@param x CSObjectWrapEditorGeneratorMethodInfoSimulation
---@param y CSObjectWrapEditorGeneratorMethodInfoSimulation
---@return SystemBoolean
function m:Equals(x, y) end
---@param obj CSObjectWrapEditorGeneratorMethodInfoSimulation
---@return SystemInt32
function m:GetHashCode(obj) end
CSObjectWrapEditorGeneratorMethodInfoSimulationComparer=m
return m;