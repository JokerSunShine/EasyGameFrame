---@class AlgorithmMiniSpanTreeMiniSpanTreeMiniSpanTree1EdgeCompareT
local m = {};
---@param x DataStructGraphBaseEdge
---@param y DataStructGraphBaseEdge
---@return SystemInt32
function m:Compare(x, y) end
AlgorithmMiniSpanTreeMiniSpanTreeMiniSpanTree1EdgeCompareT=m
return m;