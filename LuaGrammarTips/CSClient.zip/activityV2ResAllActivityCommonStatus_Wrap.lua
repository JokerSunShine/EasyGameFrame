---@class activityV2.ResAllActivityCommonStatus
---instance properties
---@field public statusList System.Collections.Generic.List1activityV2.ActivityCommonStatus
local m = {};

activityV2.ResAllActivityCommonStatus=m
return m;