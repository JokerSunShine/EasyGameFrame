---@class ICSharpCode.NRefactory.Ast.QueryExpressionPartitionType
---@field Take @0
---@field TakeWhile @1
---@field Skip @2
---@field SkipWhile @3
ICSharpCode.NRefactory.Ast.QueryExpressionPartitionType=m
return m;