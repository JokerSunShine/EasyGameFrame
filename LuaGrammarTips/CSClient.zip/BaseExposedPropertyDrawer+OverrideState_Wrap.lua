---@class BaseExposedPropertyDrawer+OverrideState
---@field DefaultValue @0
---@field MissingOverride @1
---@field Overridden @2
BaseExposedPropertyDrawer+OverrideState=m
return m;