---@class EasyHookInjectionLoaderAllowAllAssemblyVersionsDeserializationBinder : SystemRuntimeSerializationSerializationBinder
local m = {};
---@param assemblyName SystemString
---@param typeName SystemString
---@return SystemType
function m:BindToType(assemblyName, typeName) end
EasyHookInjectionLoaderAllowAllAssemblyVersionsDeserializationBinder=m
return m;