---@class ICSharpCodeNRefactoryAstIndexerExpression : ICSharpCodeNRefactoryAstExpression
---instance properties
---@field public TargetObject ICSharpCodeNRefactoryAstExpression
---@field public Indexes SystemCollectionsGenericList1ICSharpCodeNRefactoryAstExpression
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstIndexerExpression=m
return m;