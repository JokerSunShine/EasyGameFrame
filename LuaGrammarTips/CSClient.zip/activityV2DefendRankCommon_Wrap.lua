---@class activityV2.DefendRankCommon
---instance properties
---@field public totalKillSmall System.Int32
---@field public totalKillSmallSpecified System.Boolean
---@field public totalKillBig System.Int32
---@field public totalKillBigSpecified System.Boolean
---@field public totalKill System.Int32
---@field public totalKillSpecified System.Boolean
---@field public totalDied System.Int32
---@field public totalDiedSpecified System.Boolean
---@field public rankSmall System.Int32
---@field public rankSmallSpecified System.Boolean
---@field public rankBig System.Int32
---@field public rankBigSpecified System.Boolean
---@field public rankKill System.Int32
---@field public rankKillSpecified System.Boolean
---@field public rankDied System.Int32
---@field public rankDiedSpecified System.Boolean
---@field public rankGrade System.Int32
---@field public rankGradeSpecified System.Boolean
---@field public kingDied System.Int32
---@field public kingDiedSpecified System.Boolean
---@field public lastFirstUnionName System.String
---@field public lastFirstUnionNameSpecified System.Boolean
local m = {};

activityV2.DefendRankCommon=m
return m;