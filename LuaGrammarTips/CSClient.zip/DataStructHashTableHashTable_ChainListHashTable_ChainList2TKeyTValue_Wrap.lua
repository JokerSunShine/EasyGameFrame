---@class DataStructHashTableHashTable_ChainListHashTable_ChainList2TKeyTValue
---instance properties
---@field public Count SystemInt32
---@field public Item TValue
local m = {};
---@param key TKey
---@param value TValue
function m:TryAdd(key, value) end
---@param key TKey
---@param value TValue
---@param bucketChainList CommonBothWayChainListBothWayChainList1DataStructHashTableHashBucket2TKeyTValue
function m:Add(key, value, bucketChainList) end
---@param key TKey
function m:TryRemove(key) end
function m:Clear() end
---@param key TKey
---@return SystemBoolean
function m:ContainKey(key) end
---@param value TValue
---@return SystemBoolean
function m:ContainValue(value) end
---@param key TKey
---@return TValue
function m:GetValue(key) end
function m:CheckChangeSize() end
DataStructHashTableHashTable_ChainListHashTable_ChainList2TKeyTValue=m
return m;