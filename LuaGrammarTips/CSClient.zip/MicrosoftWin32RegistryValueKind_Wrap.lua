---@class MicrosoftWin32RegistryValueKind
---@field Unknown @0
---@field String @1
---@field ExpandString @2
---@field Binary @3
---@field DWord @4
---@field MultiString @7
---@field QWord @11
---@field None @-1
MicrosoftWin32RegistryValueKind=m
return m;