---@class AssetBundles.AssetBundleManagerLogType
---@field Info @0
---@field Warning @1
---@field Error @2
local m = {};
AssetBundles.AssetBundleManagerLogType=m
return m;