---@class Microsoft.Win32.RegistryKey : System.MarshalByRefObject
---instance properties
---@field public Name System.String
---@field public SubKeyCount System.Int32
---@field public ValueCount System.Int32
---@field public Handle Microsoft.Win32.SafeHandles.SafeRegistryHandle
---@field public View Microsoft.Win32.RegistryView
local m = {};
---@param handle Microsoft.Win32.SafeHandles.SafeRegistryHandle
---@return Microsoft.Win32.RegistryKey
function m.FromHandle(handle) end
---@param handle Microsoft.Win32.SafeHandles.SafeRegistryHandle
---@param view Microsoft.Win32.RegistryView
---@return Microsoft.Win32.RegistryKey
function m.FromHandle(handle, view) end
---@param hKey Microsoft.Win32.RegistryHive
---@param machineName System.String
---@return Microsoft.Win32.RegistryKey
function m.OpenRemoteBaseKey(hKey, machineName) end
---@param hKey Microsoft.Win32.RegistryHive
---@param machineName System.String
---@param view Microsoft.Win32.RegistryView
---@return Microsoft.Win32.RegistryKey
function m.OpenRemoteBaseKey(hKey, machineName, view) end
---@param hKey Microsoft.Win32.RegistryHive
---@param view Microsoft.Win32.RegistryView
---@return Microsoft.Win32.RegistryKey
function m.OpenBaseKey(hKey, view) end
function m:Dispose() end
function m:Flush() end
function m:Close() end
---@param name System.String
---@param value System.Object
function m:SetValue(name, value) end
---@param name System.String
---@param value System.Object
---@param valueKind Microsoft.Win32.RegistryValueKind
function m:SetValue(name, value, valueKind) end
---@param name System.String
---@return Microsoft.Win32.RegistryKey
function m:OpenSubKey(name) end
---@param name System.String
---@param writable System.Boolean
---@return Microsoft.Win32.RegistryKey
function m:OpenSubKey(name, writable) end
---@param name System.String
---@return System.Object
function m:GetValue(name) end
---@param name System.String
---@param defaultValue System.Object
---@return System.Object
function m:GetValue(name, defaultValue) end
---@param name System.String
---@param defaultValue System.Object
---@param options Microsoft.Win32.RegistryValueOptions
---@return System.Object
function m:GetValue(name, defaultValue, options) end
---@param name System.String
---@return Microsoft.Win32.RegistryValueKind
function m:GetValueKind(name) end
---@param subkey System.String
---@return Microsoft.Win32.RegistryKey
function m:CreateSubKey(subkey) end
---@param subkey System.String
---@param permissionCheck Microsoft.Win32.RegistryKeyPermissionCheck
---@return Microsoft.Win32.RegistryKey
function m:CreateSubKey(subkey, permissionCheck) end
---@param subkey System.String
---@param permissionCheck Microsoft.Win32.RegistryKeyPermissionCheck
---@param registrySecurity System.Security.AccessControl.RegistrySecurity
---@return Microsoft.Win32.RegistryKey
function m:CreateSubKey(subkey, permissionCheck, registrySecurity) end
---@param subkey System.String
---@param permissionCheck Microsoft.Win32.RegistryKeyPermissionCheck
---@param options Microsoft.Win32.RegistryOptions
---@return Microsoft.Win32.RegistryKey
function m:CreateSubKey(subkey, permissionCheck, options) end
---@param subkey System.String
---@param permissionCheck Microsoft.Win32.RegistryKeyPermissionCheck
---@param registryOptions Microsoft.Win32.RegistryOptions
---@param registrySecurity System.Security.AccessControl.RegistrySecurity
---@return Microsoft.Win32.RegistryKey
function m:CreateSubKey(subkey, permissionCheck, registryOptions, registrySecurity) end
---@param subkey System.String
---@param writable System.Boolean
---@return Microsoft.Win32.RegistryKey
function m:CreateSubKey(subkey, writable) end
---@param subkey System.String
---@param writable System.Boolean
---@param options Microsoft.Win32.RegistryOptions
---@return Microsoft.Win32.RegistryKey
function m:CreateSubKey(subkey, writable, options) end
---@param subkey System.String
function m:DeleteSubKey(subkey) end
---@param subkey System.String
---@param throwOnMissingSubKey System.Boolean
function m:DeleteSubKey(subkey, throwOnMissingSubKey) end
---@param subkey System.String
function m:DeleteSubKeyTree(subkey) end
---@param subkey System.String
---@param throwOnMissingSubKey System.Boolean
function m:DeleteSubKeyTree(subkey, throwOnMissingSubKey) end
---@param name System.String
function m:DeleteValue(name) end
---@param name System.String
---@param throwOnMissingValue System.Boolean
function m:DeleteValue(name, throwOnMissingValue) end
---@return System.Security.AccessControl.RegistrySecurity
function m:GetAccessControl() end
---@param includeSections System.Security.AccessControl.AccessControlSections
---@return System.Security.AccessControl.RegistrySecurity
function m:GetAccessControl(includeSections) end
---@return System.String[]
function m:GetSubKeyNames() end
---@return System.String[]
function m:GetValueNames() end
---@param name System.String
---@param permissionCheck Microsoft.Win32.RegistryKeyPermissionCheck
---@return Microsoft.Win32.RegistryKey
function m:OpenSubKey(name, permissionCheck) end
---@param name System.String
---@param rights System.Security.AccessControl.RegistryRights
---@return Microsoft.Win32.RegistryKey
function m:OpenSubKey(name, rights) end
---@param name System.String
---@param permissionCheck Microsoft.Win32.RegistryKeyPermissionCheck
---@param rights System.Security.AccessControl.RegistryRights
---@return Microsoft.Win32.RegistryKey
function m:OpenSubKey(name, permissionCheck, rights) end
---@param registrySecurity System.Security.AccessControl.RegistrySecurity
function m:SetAccessControl(registrySecurity) end
---@return System.String
function m:ToString() end
Microsoft.Win32.RegistryKey=m
return m;