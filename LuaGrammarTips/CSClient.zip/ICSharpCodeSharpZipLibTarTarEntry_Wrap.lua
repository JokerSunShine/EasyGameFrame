---@class ICSharpCodeSharpZipLibTarTarEntry
---instance properties
---@field public TarHeader ICSharpCodeSharpZipLibTarTarHeader
---@field public Name SystemString
---@field public UserId SystemInt32
---@field public GroupId SystemInt32
---@field public UserName SystemString
---@field public GroupName SystemString
---@field public ModTime SystemDateTime
---@field public File SystemString
---@field public Size SystemInt64
---@field public IsDirectory SystemBoolean
local m = {};
---@param name SystemString
---@return ICSharpCodeSharpZipLibTarTarEntry
function m.CreateTarEntry(name) end
---@param fileName SystemString
---@return ICSharpCodeSharpZipLibTarTarEntry
function m.CreateEntryFromFile(fileName) end
---@return SystemObject
function m:Clone() end
---@param it SystemObject
---@return SystemBoolean
function m:Equals(it) end
---@return SystemInt32
function m:GetHashCode() end
---@param desc ICSharpCodeSharpZipLibTarTarEntry
---@return SystemBoolean
function m:IsDescendent(desc) end
---@param userId SystemInt32
---@param groupId SystemInt32
function m:SetIds(userId, groupId) end
---@param userName SystemString
---@param groupName SystemString
function m:SetNames(userName, groupName) end
---@param outbuf SystemByte
---@param newName SystemString
function m:AdjustEntryName(outbuf, newName) end
---@param hdr ICSharpCodeSharpZipLibTarTarHeader
---@param file SystemString
function m:GetFileTarHeader(hdr, file) end
---@return ICSharpCodeSharpZipLibTarTarEntry
function m:GetDirectoryEntries() end
---@param outbuf SystemByte
function m:WriteEntryHeader(outbuf) end
---@param hdr ICSharpCodeSharpZipLibTarTarHeader
---@param name SystemString
function m:NameTarHeader(hdr, name) end
ICSharpCodeSharpZipLibTarTarEntry=m
return m;