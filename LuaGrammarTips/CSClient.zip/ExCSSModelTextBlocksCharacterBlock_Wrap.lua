---@class ExCSSModelTextBlocksCharacterBlock : ExCSSModelTextBlocksBlock
local m = {};
ExCSSModelTextBlocksCharacterBlock=m
return m;