---@class DataStructHashTableHashTable_OpenAddressHashTable_OpenAddress2TKeyTValue
---instance properties
---@field public LoadedValue SystemSingle
---@field public Count SystemInt32
---@field public Item TValue
local m = {};
---@param key TKey
---@param value TValue
function m:TryAdd(key, value) end
---@param key TKey
function m:TryRemove(key) end
function m:Clear() end
---@param key TKey
---@return SystemBoolean
function m:ContainKey(key) end
---@param value TValue
---@return SystemBoolean
function m:ContainValue(value) end
---@param key TKey
---@return TValue
function m:GetValue(key) end
---@param key TKey
---@param length SystemInt32
---@param step SystemInt32
---@param type DataStructHashTableHashTable_OpenAddressHashTable_OpenAddress2HashFuncTypeTKeyTValue
---@return SystemInt32
function m:GetHashCode(key, length, step, type) end
DataStructHashTableHashTable_OpenAddressHashTable_OpenAddress2TKeyTValue=m
return m;