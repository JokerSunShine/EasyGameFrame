---@class ICSharpCodeNRefactoryIAstVisitor
local m = {};
---@param addHandlerStatement ICSharpCodeNRefactoryAstAddHandlerStatement
---@param data SystemObject
---@return SystemObject
function m:VisitAddHandlerStatement(addHandlerStatement, data) end
---@param addressOfExpression ICSharpCodeNRefactoryAstAddressOfExpression
---@param data SystemObject
---@return SystemObject
function m:VisitAddressOfExpression(addressOfExpression, data) end
---@param anonymousMethodExpression ICSharpCodeNRefactoryAstAnonymousMethodExpression
---@param data SystemObject
---@return SystemObject
function m:VisitAnonymousMethodExpression(anonymousMethodExpression, data) end
---@param arrayCreateExpression ICSharpCodeNRefactoryAstArrayCreateExpression
---@param data SystemObject
---@return SystemObject
function m:VisitArrayCreateExpression(arrayCreateExpression, data) end
---@param assignmentExpression ICSharpCodeNRefactoryAstAssignmentExpression
---@param data SystemObject
---@return SystemObject
function m:VisitAssignmentExpression(assignmentExpression, data) end
---@param attribute ICSharpCodeNRefactoryAstAttribute
---@param data SystemObject
---@return SystemObject
function m:VisitAttribute(attribute, data) end
---@param attributeSection ICSharpCodeNRefactoryAstAttributeSection
---@param data SystemObject
---@return SystemObject
function m:VisitAttributeSection(attributeSection, data) end
---@param baseReferenceExpression ICSharpCodeNRefactoryAstBaseReferenceExpression
---@param data SystemObject
---@return SystemObject
function m:VisitBaseReferenceExpression(baseReferenceExpression, data) end
---@param binaryOperatorExpression ICSharpCodeNRefactoryAstBinaryOperatorExpression
---@param data SystemObject
---@return SystemObject
function m:VisitBinaryOperatorExpression(binaryOperatorExpression, data) end
---@param blockStatement ICSharpCodeNRefactoryAstBlockStatement
---@param data SystemObject
---@return SystemObject
function m:VisitBlockStatement(blockStatement, data) end
---@param breakStatement ICSharpCodeNRefactoryAstBreakStatement
---@param data SystemObject
---@return SystemObject
function m:VisitBreakStatement(breakStatement, data) end
---@param caseLabel ICSharpCodeNRefactoryAstCaseLabel
---@param data SystemObject
---@return SystemObject
function m:VisitCaseLabel(caseLabel, data) end
---@param castExpression ICSharpCodeNRefactoryAstCastExpression
---@param data SystemObject
---@return SystemObject
function m:VisitCastExpression(castExpression, data) end
---@param catchClause ICSharpCodeNRefactoryAstCatchClause
---@param data SystemObject
---@return SystemObject
function m:VisitCatchClause(catchClause, data) end
---@param checkedExpression ICSharpCodeNRefactoryAstCheckedExpression
---@param data SystemObject
---@return SystemObject
function m:VisitCheckedExpression(checkedExpression, data) end
---@param checkedStatement ICSharpCodeNRefactoryAstCheckedStatement
---@param data SystemObject
---@return SystemObject
function m:VisitCheckedStatement(checkedStatement, data) end
---@param classReferenceExpression ICSharpCodeNRefactoryAstClassReferenceExpression
---@param data SystemObject
---@return SystemObject
function m:VisitClassReferenceExpression(classReferenceExpression, data) end
---@param collectionInitializerExpression ICSharpCodeNRefactoryAstCollectionInitializerExpression
---@param data SystemObject
---@return SystemObject
function m:VisitCollectionInitializerExpression(collectionInitializerExpression, data) end
---@param compilationUnit ICSharpCodeNRefactoryAstCompilationUnit
---@param data SystemObject
---@return SystemObject
function m:VisitCompilationUnit(compilationUnit, data) end
---@param conditionalExpression ICSharpCodeNRefactoryAstConditionalExpression
---@param data SystemObject
---@return SystemObject
function m:VisitConditionalExpression(conditionalExpression, data) end
---@param constructorDeclaration ICSharpCodeNRefactoryAstConstructorDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitConstructorDeclaration(constructorDeclaration, data) end
---@param constructorInitializer ICSharpCodeNRefactoryAstConstructorInitializer
---@param data SystemObject
---@return SystemObject
function m:VisitConstructorInitializer(constructorInitializer, data) end
---@param continueStatement ICSharpCodeNRefactoryAstContinueStatement
---@param data SystemObject
---@return SystemObject
function m:VisitContinueStatement(continueStatement, data) end
---@param declareDeclaration ICSharpCodeNRefactoryAstDeclareDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitDeclareDeclaration(declareDeclaration, data) end
---@param defaultValueExpression ICSharpCodeNRefactoryAstDefaultValueExpression
---@param data SystemObject
---@return SystemObject
function m:VisitDefaultValueExpression(defaultValueExpression, data) end
---@param delegateDeclaration ICSharpCodeNRefactoryAstDelegateDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitDelegateDeclaration(delegateDeclaration, data) end
---@param destructorDeclaration ICSharpCodeNRefactoryAstDestructorDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitDestructorDeclaration(destructorDeclaration, data) end
---@param directionExpression ICSharpCodeNRefactoryAstDirectionExpression
---@param data SystemObject
---@return SystemObject
function m:VisitDirectionExpression(directionExpression, data) end
---@param doLoopStatement ICSharpCodeNRefactoryAstDoLoopStatement
---@param data SystemObject
---@return SystemObject
function m:VisitDoLoopStatement(doLoopStatement, data) end
---@param elseIfSection ICSharpCodeNRefactoryAstElseIfSection
---@param data SystemObject
---@return SystemObject
function m:VisitElseIfSection(elseIfSection, data) end
---@param emptyStatement ICSharpCodeNRefactoryAstEmptyStatement
---@param data SystemObject
---@return SystemObject
function m:VisitEmptyStatement(emptyStatement, data) end
---@param endStatement ICSharpCodeNRefactoryAstEndStatement
---@param data SystemObject
---@return SystemObject
function m:VisitEndStatement(endStatement, data) end
---@param eraseStatement ICSharpCodeNRefactoryAstEraseStatement
---@param data SystemObject
---@return SystemObject
function m:VisitEraseStatement(eraseStatement, data) end
---@param errorStatement ICSharpCodeNRefactoryAstErrorStatement
---@param data SystemObject
---@return SystemObject
function m:VisitErrorStatement(errorStatement, data) end
---@param eventAddRegion ICSharpCodeNRefactoryAstEventAddRegion
---@param data SystemObject
---@return SystemObject
function m:VisitEventAddRegion(eventAddRegion, data) end
---@param eventDeclaration ICSharpCodeNRefactoryAstEventDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitEventDeclaration(eventDeclaration, data) end
---@param eventRaiseRegion ICSharpCodeNRefactoryAstEventRaiseRegion
---@param data SystemObject
---@return SystemObject
function m:VisitEventRaiseRegion(eventRaiseRegion, data) end
---@param eventRemoveRegion ICSharpCodeNRefactoryAstEventRemoveRegion
---@param data SystemObject
---@return SystemObject
function m:VisitEventRemoveRegion(eventRemoveRegion, data) end
---@param exitStatement ICSharpCodeNRefactoryAstExitStatement
---@param data SystemObject
---@return SystemObject
function m:VisitExitStatement(exitStatement, data) end
---@param expressionRangeVariable ICSharpCodeNRefactoryAstExpressionRangeVariable
---@param data SystemObject
---@return SystemObject
function m:VisitExpressionRangeVariable(expressionRangeVariable, data) end
---@param expressionStatement ICSharpCodeNRefactoryAstExpressionStatement
---@param data SystemObject
---@return SystemObject
function m:VisitExpressionStatement(expressionStatement, data) end
---@param externAliasDirective ICSharpCodeNRefactoryAstExternAliasDirective
---@param data SystemObject
---@return SystemObject
function m:VisitExternAliasDirective(externAliasDirective, data) end
---@param fieldDeclaration ICSharpCodeNRefactoryAstFieldDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitFieldDeclaration(fieldDeclaration, data) end
---@param fixedStatement ICSharpCodeNRefactoryAstFixedStatement
---@param data SystemObject
---@return SystemObject
function m:VisitFixedStatement(fixedStatement, data) end
---@param foreachStatement ICSharpCodeNRefactoryAstForeachStatement
---@param data SystemObject
---@return SystemObject
function m:VisitForeachStatement(foreachStatement, data) end
---@param forNextStatement ICSharpCodeNRefactoryAstForNextStatement
---@param data SystemObject
---@return SystemObject
function m:VisitForNextStatement(forNextStatement, data) end
---@param forStatement ICSharpCodeNRefactoryAstForStatement
---@param data SystemObject
---@return SystemObject
function m:VisitForStatement(forStatement, data) end
---@param gotoCaseStatement ICSharpCodeNRefactoryAstGotoCaseStatement
---@param data SystemObject
---@return SystemObject
function m:VisitGotoCaseStatement(gotoCaseStatement, data) end
---@param gotoStatement ICSharpCodeNRefactoryAstGotoStatement
---@param data SystemObject
---@return SystemObject
function m:VisitGotoStatement(gotoStatement, data) end
---@param identifierExpression ICSharpCodeNRefactoryAstIdentifierExpression
---@param data SystemObject
---@return SystemObject
function m:VisitIdentifierExpression(identifierExpression, data) end
---@param ifElseStatement ICSharpCodeNRefactoryAstIfElseStatement
---@param data SystemObject
---@return SystemObject
function m:VisitIfElseStatement(ifElseStatement, data) end
---@param indexerDeclaration ICSharpCodeNRefactoryAstIndexerDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitIndexerDeclaration(indexerDeclaration, data) end
---@param indexerExpression ICSharpCodeNRefactoryAstIndexerExpression
---@param data SystemObject
---@return SystemObject
function m:VisitIndexerExpression(indexerExpression, data) end
---@param innerClassTypeReference ICSharpCodeNRefactoryAstInnerClassTypeReference
---@param data SystemObject
---@return SystemObject
function m:VisitInnerClassTypeReference(innerClassTypeReference, data) end
---@param interfaceImplementation ICSharpCodeNRefactoryAstInterfaceImplementation
---@param data SystemObject
---@return SystemObject
function m:VisitInterfaceImplementation(interfaceImplementation, data) end
---@param invocationExpression ICSharpCodeNRefactoryAstInvocationExpression
---@param data SystemObject
---@return SystemObject
function m:VisitInvocationExpression(invocationExpression, data) end
---@param labelStatement ICSharpCodeNRefactoryAstLabelStatement
---@param data SystemObject
---@return SystemObject
function m:VisitLabelStatement(labelStatement, data) end
---@param lambdaExpression ICSharpCodeNRefactoryAstLambdaExpression
---@param data SystemObject
---@return SystemObject
function m:VisitLambdaExpression(lambdaExpression, data) end
---@param localVariableDeclaration ICSharpCodeNRefactoryAstLocalVariableDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitLocalVariableDeclaration(localVariableDeclaration, data) end
---@param lockStatement ICSharpCodeNRefactoryAstLockStatement
---@param data SystemObject
---@return SystemObject
function m:VisitLockStatement(lockStatement, data) end
---@param memberReferenceExpression ICSharpCodeNRefactoryAstMemberReferenceExpression
---@param data SystemObject
---@return SystemObject
function m:VisitMemberReferenceExpression(memberReferenceExpression, data) end
---@param methodDeclaration ICSharpCodeNRefactoryAstMethodDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitMethodDeclaration(methodDeclaration, data) end
---@param namedArgumentExpression ICSharpCodeNRefactoryAstNamedArgumentExpression
---@param data SystemObject
---@return SystemObject
function m:VisitNamedArgumentExpression(namedArgumentExpression, data) end
---@param namespaceDeclaration ICSharpCodeNRefactoryAstNamespaceDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitNamespaceDeclaration(namespaceDeclaration, data) end
---@param objectCreateExpression ICSharpCodeNRefactoryAstObjectCreateExpression
---@param data SystemObject
---@return SystemObject
function m:VisitObjectCreateExpression(objectCreateExpression, data) end
---@param onErrorStatement ICSharpCodeNRefactoryAstOnErrorStatement
---@param data SystemObject
---@return SystemObject
function m:VisitOnErrorStatement(onErrorStatement, data) end
---@param operatorDeclaration ICSharpCodeNRefactoryAstOperatorDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitOperatorDeclaration(operatorDeclaration, data) end
---@param optionDeclaration ICSharpCodeNRefactoryAstOptionDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitOptionDeclaration(optionDeclaration, data) end
---@param parameterDeclarationExpression ICSharpCodeNRefactoryAstParameterDeclarationExpression
---@param data SystemObject
---@return SystemObject
function m:VisitParameterDeclarationExpression(parameterDeclarationExpression, data) end
---@param parenthesizedExpression ICSharpCodeNRefactoryAstParenthesizedExpression
---@param data SystemObject
---@return SystemObject
function m:VisitParenthesizedExpression(parenthesizedExpression, data) end
---@param pointerReferenceExpression ICSharpCodeNRefactoryAstPointerReferenceExpression
---@param data SystemObject
---@return SystemObject
function m:VisitPointerReferenceExpression(pointerReferenceExpression, data) end
---@param primitiveExpression ICSharpCodeNRefactoryAstPrimitiveExpression
---@param data SystemObject
---@return SystemObject
function m:VisitPrimitiveExpression(primitiveExpression, data) end
---@param propertyDeclaration ICSharpCodeNRefactoryAstPropertyDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitPropertyDeclaration(propertyDeclaration, data) end
---@param propertyGetRegion ICSharpCodeNRefactoryAstPropertyGetRegion
---@param data SystemObject
---@return SystemObject
function m:VisitPropertyGetRegion(propertyGetRegion, data) end
---@param propertySetRegion ICSharpCodeNRefactoryAstPropertySetRegion
---@param data SystemObject
---@return SystemObject
function m:VisitPropertySetRegion(propertySetRegion, data) end
---@param queryExpression ICSharpCodeNRefactoryAstQueryExpression
---@param data SystemObject
---@return SystemObject
function m:VisitQueryExpression(queryExpression, data) end
---@param queryExpressionAggregateClause ICSharpCodeNRefactoryAstQueryExpressionAggregateClause
---@param data SystemObject
---@return SystemObject
function m:VisitQueryExpressionAggregateClause(queryExpressionAggregateClause, data) end
---@param queryExpressionDistinctClause ICSharpCodeNRefactoryAstQueryExpressionDistinctClause
---@param data SystemObject
---@return SystemObject
function m:VisitQueryExpressionDistinctClause(queryExpressionDistinctClause, data) end
---@param queryExpressionFromClause ICSharpCodeNRefactoryAstQueryExpressionFromClause
---@param data SystemObject
---@return SystemObject
function m:VisitQueryExpressionFromClause(queryExpressionFromClause, data) end
---@param queryExpressionGroupClause ICSharpCodeNRefactoryAstQueryExpressionGroupClause
---@param data SystemObject
---@return SystemObject
function m:VisitQueryExpressionGroupClause(queryExpressionGroupClause, data) end
---@param queryExpressionGroupJoinVBClause ICSharpCodeNRefactoryAstQueryExpressionGroupJoinVBClause
---@param data SystemObject
---@return SystemObject
function m:VisitQueryExpressionGroupJoinVBClause(queryExpressionGroupJoinVBClause, data) end
---@param queryExpressionGroupVBClause ICSharpCodeNRefactoryAstQueryExpressionGroupVBClause
---@param data SystemObject
---@return SystemObject
function m:VisitQueryExpressionGroupVBClause(queryExpressionGroupVBClause, data) end
---@param queryExpressionJoinClause ICSharpCodeNRefactoryAstQueryExpressionJoinClause
---@param data SystemObject
---@return SystemObject
function m:VisitQueryExpressionJoinClause(queryExpressionJoinClause, data) end
---@param queryExpressionJoinConditionVB ICSharpCodeNRefactoryAstQueryExpressionJoinConditionVB
---@param data SystemObject
---@return SystemObject
function m:VisitQueryExpressionJoinConditionVB(queryExpressionJoinConditionVB, data) end
---@param queryExpressionJoinVBClause ICSharpCodeNRefactoryAstQueryExpressionJoinVBClause
---@param data SystemObject
---@return SystemObject
function m:VisitQueryExpressionJoinVBClause(queryExpressionJoinVBClause, data) end
---@param queryExpressionLetClause ICSharpCodeNRefactoryAstQueryExpressionLetClause
---@param data SystemObject
---@return SystemObject
function m:VisitQueryExpressionLetClause(queryExpressionLetClause, data) end
---@param queryExpressionLetVBClause ICSharpCodeNRefactoryAstQueryExpressionLetVBClause
---@param data SystemObject
---@return SystemObject
function m:VisitQueryExpressionLetVBClause(queryExpressionLetVBClause, data) end
---@param queryExpressionOrderClause ICSharpCodeNRefactoryAstQueryExpressionOrderClause
---@param data SystemObject
---@return SystemObject
function m:VisitQueryExpressionOrderClause(queryExpressionOrderClause, data) end
---@param queryExpressionOrdering ICSharpCodeNRefactoryAstQueryExpressionOrdering
---@param data SystemObject
---@return SystemObject
function m:VisitQueryExpressionOrdering(queryExpressionOrdering, data) end
---@param queryExpressionPartitionVBClause ICSharpCodeNRefactoryAstQueryExpressionPartitionVBClause
---@param data SystemObject
---@return SystemObject
function m:VisitQueryExpressionPartitionVBClause(queryExpressionPartitionVBClause, data) end
---@param queryExpressionSelectClause ICSharpCodeNRefactoryAstQueryExpressionSelectClause
---@param data SystemObject
---@return SystemObject
function m:VisitQueryExpressionSelectClause(queryExpressionSelectClause, data) end
---@param queryExpressionSelectVBClause ICSharpCodeNRefactoryAstQueryExpressionSelectVBClause
---@param data SystemObject
---@return SystemObject
function m:VisitQueryExpressionSelectVBClause(queryExpressionSelectVBClause, data) end
---@param queryExpressionWhereClause ICSharpCodeNRefactoryAstQueryExpressionWhereClause
---@param data SystemObject
---@return SystemObject
function m:VisitQueryExpressionWhereClause(queryExpressionWhereClause, data) end
---@param raiseEventStatement ICSharpCodeNRefactoryAstRaiseEventStatement
---@param data SystemObject
---@return SystemObject
function m:VisitRaiseEventStatement(raiseEventStatement, data) end
---@param reDimStatement ICSharpCodeNRefactoryAstReDimStatement
---@param data SystemObject
---@return SystemObject
function m:VisitReDimStatement(reDimStatement, data) end
---@param removeHandlerStatement ICSharpCodeNRefactoryAstRemoveHandlerStatement
---@param data SystemObject
---@return SystemObject
function m:VisitRemoveHandlerStatement(removeHandlerStatement, data) end
---@param resumeStatement ICSharpCodeNRefactoryAstResumeStatement
---@param data SystemObject
---@return SystemObject
function m:VisitResumeStatement(resumeStatement, data) end
---@param returnStatement ICSharpCodeNRefactoryAstReturnStatement
---@param data SystemObject
---@return SystemObject
function m:VisitReturnStatement(returnStatement, data) end
---@param sizeOfExpression ICSharpCodeNRefactoryAstSizeOfExpression
---@param data SystemObject
---@return SystemObject
function m:VisitSizeOfExpression(sizeOfExpression, data) end
---@param stackAllocExpression ICSharpCodeNRefactoryAstStackAllocExpression
---@param data SystemObject
---@return SystemObject
function m:VisitStackAllocExpression(stackAllocExpression, data) end
---@param stopStatement ICSharpCodeNRefactoryAstStopStatement
---@param data SystemObject
---@return SystemObject
function m:VisitStopStatement(stopStatement, data) end
---@param switchSection ICSharpCodeNRefactoryAstSwitchSection
---@param data SystemObject
---@return SystemObject
function m:VisitSwitchSection(switchSection, data) end
---@param switchStatement ICSharpCodeNRefactoryAstSwitchStatement
---@param data SystemObject
---@return SystemObject
function m:VisitSwitchStatement(switchStatement, data) end
---@param templateDefinition ICSharpCodeNRefactoryAstTemplateDefinition
---@param data SystemObject
---@return SystemObject
function m:VisitTemplateDefinition(templateDefinition, data) end
---@param thisReferenceExpression ICSharpCodeNRefactoryAstThisReferenceExpression
---@param data SystemObject
---@return SystemObject
function m:VisitThisReferenceExpression(thisReferenceExpression, data) end
---@param throwStatement ICSharpCodeNRefactoryAstThrowStatement
---@param data SystemObject
---@return SystemObject
function m:VisitThrowStatement(throwStatement, data) end
---@param tryCatchStatement ICSharpCodeNRefactoryAstTryCatchStatement
---@param data SystemObject
---@return SystemObject
function m:VisitTryCatchStatement(tryCatchStatement, data) end
---@param typeDeclaration ICSharpCodeNRefactoryAstTypeDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitTypeDeclaration(typeDeclaration, data) end
---@param typeOfExpression ICSharpCodeNRefactoryAstTypeOfExpression
---@param data SystemObject
---@return SystemObject
function m:VisitTypeOfExpression(typeOfExpression, data) end
---@param typeOfIsExpression ICSharpCodeNRefactoryAstTypeOfIsExpression
---@param data SystemObject
---@return SystemObject
function m:VisitTypeOfIsExpression(typeOfIsExpression, data) end
---@param typeReference ICSharpCodeNRefactoryAstTypeReference
---@param data SystemObject
---@return SystemObject
function m:VisitTypeReference(typeReference, data) end
---@param typeReferenceExpression ICSharpCodeNRefactoryAstTypeReferenceExpression
---@param data SystemObject
---@return SystemObject
function m:VisitTypeReferenceExpression(typeReferenceExpression, data) end
---@param unaryOperatorExpression ICSharpCodeNRefactoryAstUnaryOperatorExpression
---@param data SystemObject
---@return SystemObject
function m:VisitUnaryOperatorExpression(unaryOperatorExpression, data) end
---@param uncheckedExpression ICSharpCodeNRefactoryAstUncheckedExpression
---@param data SystemObject
---@return SystemObject
function m:VisitUncheckedExpression(uncheckedExpression, data) end
---@param uncheckedStatement ICSharpCodeNRefactoryAstUncheckedStatement
---@param data SystemObject
---@return SystemObject
function m:VisitUncheckedStatement(uncheckedStatement, data) end
---@param unsafeStatement ICSharpCodeNRefactoryAstUnsafeStatement
---@param data SystemObject
---@return SystemObject
function m:VisitUnsafeStatement(unsafeStatement, data) end
---@param using ICSharpCodeNRefactoryAstUsing
---@param data SystemObject
---@return SystemObject
function m:VisitUsing(using, data) end
---@param usingDeclaration ICSharpCodeNRefactoryAstUsingDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitUsingDeclaration(usingDeclaration, data) end
---@param usingStatement ICSharpCodeNRefactoryAstUsingStatement
---@param data SystemObject
---@return SystemObject
function m:VisitUsingStatement(usingStatement, data) end
---@param variableDeclaration ICSharpCodeNRefactoryAstVariableDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitVariableDeclaration(variableDeclaration, data) end
---@param withStatement ICSharpCodeNRefactoryAstWithStatement
---@param data SystemObject
---@return SystemObject
function m:VisitWithStatement(withStatement, data) end
---@param yieldStatement ICSharpCodeNRefactoryAstYieldStatement
---@param data SystemObject
---@return SystemObject
function m:VisitYieldStatement(yieldStatement, data) end
ICSharpCodeNRefactoryIAstVisitor=m
return m;