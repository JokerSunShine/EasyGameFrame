---@class ICSharpCodeSharpZipLibTarTarBuffer
---fields
---@field public BlockSize SystemInt32
---@field public DefaultBlockFactor SystemInt32
---@field public DefaultRecordSize SystemInt32
---instance properties
---@field public RecordSize SystemInt32
---@field public BlockFactor SystemInt32
local m = {};
---@param inputStream SystemIOStream
---@return ICSharpCodeSharpZipLibTarTarBuffer
function m.CreateInputTarBuffer(inputStream) end
---@param inputStream SystemIOStream
---@param blockFactor SystemInt32
---@return ICSharpCodeSharpZipLibTarTarBuffer
function m.CreateInputTarBuffer(inputStream, blockFactor) end
---@param outputStream SystemIOStream
---@return ICSharpCodeSharpZipLibTarTarBuffer
function m.CreateOutputTarBuffer(outputStream) end
---@param outputStream SystemIOStream
---@param blockFactor SystemInt32
---@return ICSharpCodeSharpZipLibTarTarBuffer
function m.CreateOutputTarBuffer(outputStream, blockFactor) end
---@return SystemInt32
function m:GetBlockFactor() end
---@return SystemInt32
function m:GetRecordSize() end
---@param block SystemByte
---@return SystemBoolean
function m:IsEOFBlock(block) end
function m:SkipBlock() end
---@return SystemByte
function m:ReadBlock() end
---@return SystemInt32
function m:GetCurrentBlockNum() end
---@return SystemInt32
function m:GetCurrentRecordNum() end
---@param block SystemByte
function m:WriteBlock(block) end
---@param buf SystemByte
---@param offset SystemInt32
function m:WriteBlock(buf, offset) end
function m:Close() end
ICSharpCodeSharpZipLibTarTarBuffer=m
return m;