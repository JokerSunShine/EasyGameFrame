---@class backV2.AutoBanInfo
---instance properties
---@field public uid System.Int64
---@field public uidSpecified System.Boolean
---@field public unBanTime System.Int32
---@field public unBanTimeSpecified System.Boolean
---@field public banReason System.String
---@field public banReasonSpecified System.Boolean
local m = {};

backV2.AutoBanInfo=m
return m;