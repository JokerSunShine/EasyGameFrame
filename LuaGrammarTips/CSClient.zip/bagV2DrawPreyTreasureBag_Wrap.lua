---@class bagV2.DrawPreyTreasureBag
---instance properties
---@field public lid System.Int64
---@field public lidSpecified System.Boolean
local m = {};

bagV2.DrawPreyTreasureBag=m
return m;