---@class ICSharpCodeNRefactoryAstUsingDeclaration : ICSharpCodeNRefactoryAstAbstractNode
---instance properties
---@field public Usings SystemCollectionsGenericList1ICSharpCodeNRefactoryAstUsing
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstUsingDeclaration=m
return m;