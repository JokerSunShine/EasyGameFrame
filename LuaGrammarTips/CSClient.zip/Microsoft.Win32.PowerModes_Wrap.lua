---@class Microsoft.Win32.PowerModes
---@field Resume @1
---@field StatusChange @2
---@field Suspend @3
Microsoft.Win32.PowerModes=m
return m;