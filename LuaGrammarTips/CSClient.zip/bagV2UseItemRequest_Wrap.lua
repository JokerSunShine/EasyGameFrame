---@class bagV2.UseItemRequest
---instance properties
---@field public count System.Int32
---@field public itemId System.Int64
---@field public clientParam System.Int32
---@field public clientParamSpecified System.Boolean
---@field public clientParams System.Collections.Generic.List1System.Int32
---@field public clientParamStrs System.Collections.Generic.List1System.String
local m = {};

bagV2.UseItemRequest=m
return m;