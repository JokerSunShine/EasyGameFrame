---@class biqiV2.ItemInfo
---instance properties
---@field public itemId System.Int32
---@field public itemIdSpecified System.Boolean
---@field public count System.Int32
---@field public countSpecified System.Boolean
local m = {};

biqiV2.ItemInfo=m
return m;