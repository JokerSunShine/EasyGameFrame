---@class ICSharpCode.NRefactory.Ast.Expression : ICSharpCode.NRefactory.Ast.AbstractNode
---properties
---@field public Null ICSharpCode.NRefactory.Ast.Expression
---instance properties
---@field public IsNull System.Boolean
local m = {};
---@param expression ICSharpCode.NRefactory.Ast.Expression
---@return ICSharpCode.NRefactory.Ast.Expression
function m.CheckNull(expression) end
---@param expr ICSharpCode.NRefactory.Ast.Expression
---@param value System.Int32
---@return ICSharpCode.NRefactory.Ast.Expression
function m.AddInteger(expr, value) end
ICSharpCode.NRefactory.Ast.Expression=m
return m;