---@class ExCSS.Model.TextBlocks.SpecialCharacter : ExCSS.Model.TextBlocks.CharacterBlock
local m = {};
---@return System.String
function m:ToString() end
ExCSS.Model.TextBlocks.SpecialCharacter=m
return m;