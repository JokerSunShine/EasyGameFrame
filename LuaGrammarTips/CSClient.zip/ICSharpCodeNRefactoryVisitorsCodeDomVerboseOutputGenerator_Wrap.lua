---@class ICSharpCodeNRefactoryVisitorsCodeDomVerboseOutputGenerator : SystemCodeDomCompilerCodeGenerator
local m = {};
---@param e SystemCodeDomCodeStatement
---@param w SystemIOTextWriter
---@param o SystemCodeDomCompilerCodeGeneratorOptions
function m:PublicGenerateCodeFromStatement(e, w, o) end
ICSharpCodeNRefactoryVisitorsCodeDomVerboseOutputGenerator=m
return m;