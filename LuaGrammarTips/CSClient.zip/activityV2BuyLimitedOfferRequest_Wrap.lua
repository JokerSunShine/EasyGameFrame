---@class activityV2.BuyLimitedOfferRequest
---instance properties
---@field public activityId System.Int32
local m = {};

activityV2.BuyLimitedOfferRequest=m
return m;