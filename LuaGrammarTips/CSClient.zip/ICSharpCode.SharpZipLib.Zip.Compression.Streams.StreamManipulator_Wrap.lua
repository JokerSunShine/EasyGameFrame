---@class ICSharpCode.SharpZipLib.Zip.Compression.Streams.StreamManipulator
---instance properties
---@field public AvailableBits System.Int32
---@field public AvailableBytes System.Int32
---@field public IsNeedingInput System.Boolean
local m = {};
---@param n System.Int32
---@return System.Int32
function m:PeekBits(n) end
---@param n System.Int32
function m:DropBits(n) end
---@param n System.Int32
---@return System.Int32
function m:GetBits(n) end
function m:SkipToByteBoundary() end
---@param output System.Byte[]
---@param offset System.Int32
---@param length System.Int32
---@return System.Int32
function m:CopyBytes(output, offset, length) end
function m:Reset() end
---@param buf System.Byte[]
---@param off System.Int32
---@param len System.Int32
function m:SetInput(buf, off, len) end
ICSharpCode.SharpZipLib.Zip.Compression.Streams.StreamManipulator=m
return m;