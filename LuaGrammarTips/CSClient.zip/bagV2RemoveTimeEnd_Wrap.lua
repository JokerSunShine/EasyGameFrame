---@class bagV2.RemoveTimeEnd
---instance properties
---@field public itemIdList System.Collections.Generic.List1System.Int64
local m = {};

bagV2.RemoveTimeEnd=m
return m;