---@class ExCSSDocumentFunction
---@field Url @0
---@field UrlPrefix @1
---@field Domain @2
---@field RegExp @3
ExCSSDocumentFunction=m
return m;