---@class EditorUtil
local m = {};
---@return System.Boolean
function m.EditorIsPlaying() end
---@param macro System.String
---@param isAdd System.Boolean
---@return System.Boolean
function m.SetMacro(macro, isAdd) end
---@param macro System.String
---@return System.Boolean
function m.HaveMacro(macro) end
EditorUtil=m
return m;