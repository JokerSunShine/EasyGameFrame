---@class EditorUtil
local m = {};
---@return SystemBoolean
function m.EditorIsPlaying() end
---@param macro SystemString
---@param isAdd SystemBoolean
---@return SystemBoolean
function m.SetMacro(macro, isAdd) end
---@param macro SystemString
---@return SystemBoolean
function m.HaveMacro(macro) end
EditorUtil=m
return m;