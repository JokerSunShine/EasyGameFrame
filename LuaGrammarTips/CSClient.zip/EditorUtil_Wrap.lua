---@class EditorUtil
---fields
---@field public CommonSpace SystemSingle
---@field public ButtonHegiht SystemSingle
local m = {};
---@return SystemBoolean
function m.EditorIsPlaying() end
---@param macro SystemString
---@param isAdd SystemBoolean
---@return SystemBoolean
function m.SetMacro(macro, isAdd) end
---@param macro SystemString
---@return SystemBoolean
function m.HaveMacro(macro) end
---@param rect UnityEngineRect
---@param mouseCursor UnityEditorMouseCursor
---@param mounseDownCallBack SystemAction1UnityEngineVector3 @default_value:
---@param mouseUpCallBack SystemAction1UnityEngineVector3 @default_value:
function m.AddSpliterLineEvent(rect, mouseCursor, mounseDownCallBack, mouseUpCallBack) end
EditorUtil=m
return m;