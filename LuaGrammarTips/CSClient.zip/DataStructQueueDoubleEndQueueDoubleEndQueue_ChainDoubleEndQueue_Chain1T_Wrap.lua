---@class DataStructQueueDoubleEndQueueDoubleEndQueue_ChainDoubleEndQueue_Chain1T
---instance properties
---@field public Count SystemInt32
local m = {};
---@param item T
function m:FirstEnqueue(item) end
---@param item T
function m:LastEnqueue(item) end
---@return T
function m:FirstDequeue() end
---@return T
function m:LastDequeue() end
---@return SystemBoolean
function m:IsEmpty() end
DataStructQueueDoubleEndQueueDoubleEndQueue_ChainDoubleEndQueue_Chain1T=m
return m;