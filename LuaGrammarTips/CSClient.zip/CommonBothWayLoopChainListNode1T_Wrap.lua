---@class CommonBothWayLoopChainListNode1T
---instance properties
---@field public Data T
---@field public Next CommonBothWayLoopChainListNode1T
---@field public Prev CommonBothWayLoopChainListNode1T
local m = {};
---@param item T
---@return CommonBothWayLoopChainListNode1T
function m:AddNext(item) end
---@param node CommonBothWayLoopChainListNode1T
---@param prev CommonBothWayLoopChainListNode1T
---@return CommonBothWayLoopChainListNode1T
function m:AddNext(node, prev) end
---@return SystemBoolean
function m:HaveData() end
---@return SystemBoolean
function m:HaveNextData() end
CommonBothWayLoopChainListNode1T=m
return m;