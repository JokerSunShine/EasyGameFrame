---@class backV2.ReqBackChangeUnionAnnounce
---instance properties
---@field public uid System.Int64
---@field public uidSpecified System.Boolean
---@field public content System.String
---@field public contentSpecified System.Boolean
local m = {};

backV2.ReqBackChangeUnionAnnounce=m
return m;