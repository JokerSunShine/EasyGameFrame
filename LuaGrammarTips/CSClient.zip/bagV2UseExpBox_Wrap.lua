---@class bagV2.UseExpBox
---instance properties
---@field public itemId System.Int32
---@field public itemIdSpecified System.Boolean
---@field public count System.Int32
---@field public countSpecified System.Boolean
---@field public useSpiritPoint System.Int32
---@field public useSpiritPointSpecified System.Boolean
local m = {};

bagV2.UseExpBox=m
return m;