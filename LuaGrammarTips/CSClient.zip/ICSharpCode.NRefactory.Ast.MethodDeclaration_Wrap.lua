---@class ICSharpCode.NRefactory.Ast.MethodDeclaration : ICSharpCode.NRefactory.Ast.MemberNode
---instance properties
---@field public Body ICSharpCode.NRefactory.Ast.BlockStatement
---@field public HandlesClause System.Collections.Generic.List`1[System.String]
---@field public Templates System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.TemplateDefinition]
---@field public IsExtensionMethod System.Boolean
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.MethodDeclaration=m
return m;