---@class bagV2.ResUseAttackDrag
---instance properties
---@field public rate System.Int32
---@field public rateSpecified System.Boolean
---@field public instanceId System.Int32
---@field public instanceIdSpecified System.Boolean
---@field public useCount System.Int32
---@field public useCountSpecified System.Boolean
local m = {};

bagV2.ResUseAttackDrag=m
return m;