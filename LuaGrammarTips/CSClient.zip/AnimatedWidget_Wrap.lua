---@class AnimatedWidget : UnityEngine.MonoBehaviour
---instance fields
---@field public width System.Single
---@field public height System.Single
local m = {};

AnimatedWidget=m
return m;