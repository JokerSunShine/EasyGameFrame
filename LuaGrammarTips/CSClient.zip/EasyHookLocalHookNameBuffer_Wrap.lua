---@class EasyHookLocalHookNameBuffer : SystemRuntimeConstrainedExecutionCriticalFinalizerObject
---instance fields
---@field public Buffer SystemIntPtr
---@field public Size SystemInt32
local m = {};
---@param InDesiredSize SystemInt32
function m:Alloc(InDesiredSize) end
EasyHookLocalHookNameBuffer=m
return m;