---@class ICSharpCodeNRefactoryParserLookupTable
---instance properties
---@field public Count SystemInt32
---@field public Item SystemInt32
local m = {};
ICSharpCodeNRefactoryParserLookupTable=m
return m;