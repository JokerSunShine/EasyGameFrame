---@class CSPlatformManager : AbstractManager
---properties
---@field public Instance CSPlatformManager
---instance properties
---@field public GameManager CSGameManager
---@field public runTimePlatform UnityEngineRuntimePlatform
---@field public BuildTargetGroup UnityEditorBuildTargetGroup
---@field public OperationPlatform OperationPlatform
---@field public PlatformInfo AbstractPlatformInfo
local m = {};
CSPlatformManager=m
return m;