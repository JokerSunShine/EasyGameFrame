---@class CSPlatformManager : AbstractManager
---properties
---@field public Instance CSPlatformManager
---instance properties
---@field public GameManager CSGameManager
---@field public runTimePlatform UnityEngine.RuntimePlatform
---@field public BuildTargetGroup UnityEditor.BuildTargetGroup
---@field public OperationPlatform OperationPlatform
---@field public PlatformInfo AbstractPlatformInfo
local m = {};
CSPlatformManager=m
return m;