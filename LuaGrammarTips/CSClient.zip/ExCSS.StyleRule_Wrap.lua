---@class ExCSS.StyleRule : ExCSS.RuleSet
---instance properties
---@field public Selector ExCSS.BaseSelector
---@field public Value System.String
---@field public Declarations ExCSS.StyleDeclaration
---@field public Line System.Int32
local m = {};
---@return System.String
function m:ToString() end
---@param friendlyFormat System.Boolean
---@param indentation System.Int32 @default_value:0
---@return System.String
function m:ToString(friendlyFormat, indentation) end
ExCSS.StyleRule=m
return m;