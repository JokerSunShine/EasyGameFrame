---@class AppearancesInfo_Empty : AppearanceInfoBasic
---instance properties
---@field public IsAnyAppearanceEnabled System.Boolean
---@field public Avatar CSAvater
local m = {};

function m:Clear() end
---@param equipPartIndex System.Int32
---@param appearance TABLE.CFG_APPEARANCE @out
---@return System.Boolean
function m:GetAppearance(equipPartIndex, appearance) end
---@param equipPartIndex System.Int32
---@param modelID System.Int32 @out
---@return System.Boolean
function m:GetAppearanceModelID(equipPartIndex, modelID) end
---@return System.Boolean
function m:IsNullAppearance() end
function m:Refresh() end
---@param equipPartIndex System.Int32
---@param appearance TABLE.CFG_APPEARANCE
---@return System.Boolean
function m:SetAppearance(equipPartIndex, appearance) end
AppearancesInfo_Empty=m
return m;