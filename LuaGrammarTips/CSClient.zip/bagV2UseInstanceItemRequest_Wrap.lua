---@class bagV2.UseInstanceItemRequest
---instance properties
---@field public line System.Int32
---@field public lineSpecified System.Boolean
---@field public globalId System.Int32
---@field public globalIdSpecified System.Boolean
---@field public instanceId System.Int32
---@field public instanceIdSpecified System.Boolean
---@field public useTime System.Int32
---@field public useTimeSpecified System.Boolean
local m = {};

bagV2.UseInstanceItemRequest=m
return m;