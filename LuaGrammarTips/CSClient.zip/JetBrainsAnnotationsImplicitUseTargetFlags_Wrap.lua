---@class JetBrainsAnnotationsImplicitUseTargetFlags
---@field Itself @1
---@field Itself @1
---@field Members @2
---@field WithMembers @3
JetBrainsAnnotationsImplicitUseTargetFlags=m
return m;