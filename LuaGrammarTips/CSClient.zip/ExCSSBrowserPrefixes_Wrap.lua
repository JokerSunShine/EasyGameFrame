---@class ExCSSBrowserPrefixes
local m = {};
ExCSSBrowserPrefixes=m
return m;