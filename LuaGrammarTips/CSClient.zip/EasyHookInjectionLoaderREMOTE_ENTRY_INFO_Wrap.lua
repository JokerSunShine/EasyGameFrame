---@class EasyHookInjectionLoaderREMOTE_ENTRY_INFO
---instance fields
---@field public m_HostPID SystemInt32
---@field public UserData SystemIntPtr
---@field public UserDataSize SystemInt32
---instance properties
---@field public HostPID SystemInt32
local m = {};
EasyHookInjectionLoaderREMOTE_ENTRY_INFO=m
return m;