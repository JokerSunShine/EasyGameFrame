---@class ICSharpCodeNRefactoryAstTypeReference : ICSharpCodeNRefactoryAstAbstractNode
---fields
---@field public StructConstraint ICSharpCodeNRefactoryAstTypeReference
---@field public ClassConstraint ICSharpCodeNRefactoryAstTypeReference
---@field public NewConstraint ICSharpCodeNRefactoryAstTypeReference
---properties
---@field public PrimitiveTypesCSharp SystemCollectionsGenericIDictionary2SystemStringSystemString
---@field public PrimitiveTypesVB SystemCollectionsGenericIDictionary2SystemStringSystemString
---@field public PrimitiveTypesCSharpReverse SystemCollectionsGenericIDictionary2SystemStringSystemString
---@field public PrimitiveTypesVBReverse SystemCollectionsGenericIDictionary2SystemStringSystemString
---@field public Null ICSharpCodeNRefactoryAstTypeReference
---instance properties
---@field public Type SystemString
---@field public PointerNestingLevel SystemInt32
---@field public RankSpecifier SystemInt32
---@field public GenericTypes SystemCollectionsGenericList1ICSharpCodeNRefactoryAstTypeReference
---@field public IsArrayType SystemBoolean
---@field public IsNull SystemBoolean
---@field public IsGlobal SystemBoolean
---@field public IsKeyword SystemBoolean
local m = {};
---@param tr ICSharpCodeNRefactoryAstTypeReference
---@return SystemString
function m.StripLastIdentifierFromType(tr) end
---@param typeReference ICSharpCodeNRefactoryAstTypeReference
---@return ICSharpCodeNRefactoryAstTypeReference
function m.CheckNull(typeReference) end
---@param a ICSharpCodeNRefactoryAstTypeReference
---@param b ICSharpCodeNRefactoryAstTypeReference
---@return SystemBoolean
function m.AreEqualReferences(a, b) end
---@return ICSharpCodeNRefactoryAstTypeReference
function m:Clone() end
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstTypeReference=m
return m;