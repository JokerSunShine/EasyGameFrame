---@class ICSharpCodeNRefactoryAstExpressionRangeVariable : ICSharpCodeNRefactoryAstAbstractNode
---properties
---@field public Null ICSharpCodeNRefactoryAstExpressionRangeVariable
---instance properties
---@field public Identifier SystemString
---@field public Expression ICSharpCodeNRefactoryAstExpression
---@field public Type ICSharpCodeNRefactoryAstTypeReference
---@field public IsNull SystemBoolean
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstExpressionRangeVariable=m
return m;