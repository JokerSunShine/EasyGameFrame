---@class ICSharpCode.SharpZipLib.BZip2.BZip2
local m = {};
---@param instream System.IO.Stream
---@param outstream System.IO.Stream
function m.Decompress(instream, outstream) end
---@param instream System.IO.Stream
---@param outstream System.IO.Stream
---@param blockSize System.Int32
function m.Compress(instream, outstream, blockSize) end
ICSharpCode.SharpZipLib.BZip2.BZip2=m
return m;