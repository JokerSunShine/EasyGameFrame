---@class InternalRuntimeAugmentsEnvironmentAugments
---fields
---@field public StackTrace SystemString
local m = {};
InternalRuntimeAugmentsEnvironmentAugments=m
return m;