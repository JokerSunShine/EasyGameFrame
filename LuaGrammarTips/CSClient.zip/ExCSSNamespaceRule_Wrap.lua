---@class ExCSSNamespaceRule : ExCSSRuleSet
---instance properties
---@field public Uri SystemString
---@field public Prefix SystemString
local m = {};
---@return SystemString
function m:ToString() end
---@param friendlyFormat SystemBoolean
---@param indentation SystemInt32 @default_value:0
---@return SystemString
function m:ToString(friendlyFormat, indentation) end
ExCSSNamespaceRule=m
return m;