---@class ICSharpCodeNRefactoryPrettyPrinterIOutputFormatter
---instance properties
---@field public IndentationLevel SystemInt32
---@field public Text SystemString
---@field public IsInMemberBody SystemBoolean
local m = {};
function m:NewLine() end
function m:Indent() end
---@param comment ICSharpCodeNRefactoryComment
---@param forceWriteInPreviousBlock SystemBoolean
function m:PrintComment(comment, forceWriteInPreviousBlock) end
---@param directive ICSharpCodeNRefactoryPreprocessingDirective
---@param forceWriteInPreviousBlock SystemBoolean
function m:PrintPreprocessingDirective(directive, forceWriteInPreviousBlock) end
---@param forceWriteInPreviousBlock SystemBoolean
function m:PrintBlankLine(forceWriteInPreviousBlock) end
ICSharpCodeNRefactoryPrettyPrinterIOutputFormatter=m
return m;