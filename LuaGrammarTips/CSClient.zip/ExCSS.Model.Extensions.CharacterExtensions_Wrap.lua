---@class ExCSS.Model.Extensions.CharacterExtensions
local m = {};
---@param character System.Char
---@return System.Int32
function m.FromHex(character) end
---@param array System.Char[]
---@return System.String
function m.TrimArray(array) end
---@param value System.String
---@return System.String[]
function m.SplitOnCommas(value) end
---@param num System.Byte
---@return System.String
function m.ToHex(num) end
---@param num System.Byte
---@return System.Char
function m.ToHexChar(num) end
ExCSS.Model.Extensions.CharacterExtensions=m
return m;