---@class ICSharpCode.SharpZipLib.Zip.ZipFile
---instance fields
---@field public KeysRequired ICSharpCode.SharpZipLib.Zip.ZipFile+KeysRequiredEventHandler
---instance properties
---@field public Password System.String
---@field public EntryByIndex ICSharpCode.SharpZipLib.Zip.ZipEntry
---@field public ZipFileComment System.String
---@field public Name System.String
---@field public Size System.Int32
local m = {};
function m:Close() end
---@return System.Collections.IEnumerator
function m:GetEnumerator() end
---@param name System.String
---@param ignoreCase System.Boolean
---@return System.Int32
function m:FindEntry(name, ignoreCase) end
---@param name System.String
---@return ICSharpCode.SharpZipLib.Zip.ZipEntry
function m:GetEntry(name) end
---@param testData System.Boolean
---@return System.Boolean
function m:TestArchive(testData) end
---@param entry ICSharpCode.SharpZipLib.Zip.ZipEntry
---@return System.IO.Stream
function m:GetInputStream(entry) end
---@param entryIndex System.Int32
---@return System.IO.Stream
function m:GetInputStream(entryIndex) end
ICSharpCode.SharpZipLib.Zip.ZipFile=m
return m;