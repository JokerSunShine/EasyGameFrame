---@class ExCSSPrimitiveTerm : ExCSSTerm
---instance properties
---@field public Value SystemObject
---@field public PrimitiveType ExCSSUnitType
local m = {};
---@param unit ExCSSUnitType
---@return SystemNullable1SystemSingle
function m:GetFloatValue(unit) end
---@return SystemString
function m:ToString() end
ExCSSPrimitiveTerm=m
return m;