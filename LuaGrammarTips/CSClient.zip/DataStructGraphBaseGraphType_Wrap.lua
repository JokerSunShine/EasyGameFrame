---@class DataStructGraphBaseGraphType
---@field UndirectedGraph @0
---@field DirectedGraph @1
DataStructGraphBaseGraphType=m
return m;