---@class ICSharpCodeNRefactoryParserLookupTableNode
---instance fields
---@field public word SystemString
---@field public val SystemInt32
---@field public leaf ICSharpCodeNRefactoryParserLookupTableNode
local m = {};
ICSharpCodeNRefactoryParserLookupTableNode=m
return m;