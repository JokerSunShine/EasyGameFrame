---@class ICSharpCodeNRefactoryAstObjectCreateExpression : ICSharpCodeNRefactoryAstExpression
---instance properties
---@field public CreateType ICSharpCodeNRefactoryAstTypeReference
---@field public Parameters SystemCollectionsGenericList1ICSharpCodeNRefactoryAstExpression
---@field public ObjectInitializer ICSharpCodeNRefactoryAstCollectionInitializerExpression
---@field public IsAnonymousType SystemBoolean
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstObjectCreateExpression=m
return m;