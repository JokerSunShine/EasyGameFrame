---@class ICSharpCode.NRefactory.Parser.CSharp.Keywords
local m = {};
---@param keyword System.String
---@return System.Int32
function m.GetToken(keyword) end
---@param word System.String
---@return System.Boolean
function m.IsNonIdentifierKeyword(word) end
ICSharpCode.NRefactory.Parser.CSharp.Keywords=m
return m;