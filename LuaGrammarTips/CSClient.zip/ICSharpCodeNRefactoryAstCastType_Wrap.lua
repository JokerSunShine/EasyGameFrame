---@class ICSharpCodeNRefactoryAstCastType
---@field Cast @0
---@field TryCast @1
---@field Conversion @2
---@field PrimitiveConversion @3
ICSharpCodeNRefactoryAstCastType=m
return m;