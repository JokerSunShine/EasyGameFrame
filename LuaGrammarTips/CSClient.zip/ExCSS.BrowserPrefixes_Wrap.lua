---@class ExCSS.BrowserPrefixes
local m = {};
ExCSS.BrowserPrefixes=m
return m;