---@class ExCSSParser
local m = {};
---@param css SystemString
---@return ExCSSStyleSheet
function m:Parse(css) end
ExCSSParser=m
return m;