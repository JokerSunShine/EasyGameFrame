---@class ICSharpCodeNRefactoryPrettyPrinterBraceStyle
---@field EndOfLine @0
---@field EndOfLineWithoutSpace @1
---@field NextLine @2
---@field NextLineShifted @3
---@field NextLineShifted2 @4
ICSharpCodeNRefactoryPrettyPrinterBraceStyle=m
return m;