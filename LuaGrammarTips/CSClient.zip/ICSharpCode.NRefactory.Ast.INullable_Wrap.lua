---@class ICSharpCode.NRefactory.Ast.INullable
---instance properties
---@field public IsNull System.Boolean
local m = {};
ICSharpCode.NRefactory.Ast.INullable=m
return m;