---@class ICSharpCodeNRefactoryParserVBParamModifierList
---instance properties
---@field public Modifier ICSharpCodeNRefactoryAstParameterModifiers
---@field public isNone SystemBoolean
local m = {};
---@param m ICSharpCodeNRefactoryAstParameterModifiers
function m:Add(m) end
---@param m ICSharpCodeNRefactoryParserVBParamModifierList
function m:Add(m) end
function m:Check() end
ICSharpCodeNRefactoryParserVBParamModifierList=m
return m;