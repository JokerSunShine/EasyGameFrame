---@class AssetBundles.AssetBundleLoadAssetOperation : AssetBundles.AssetBundleLoadOperation
local m = {};

AssetBundles.AssetBundleLoadAssetOperation=m
return m;