---@class DataUtilIActiveFields
---instance properties
---@field public fields SystemCollectionsGenericIEnumerable1SystemString
local m = {};
---@param field SystemString
---@return SystemBoolean
function m:Add(field) end
---@param field SystemString
---@return SystemBoolean
function m:Contains(field) end
DataUtilIActiveFields=m
return m;