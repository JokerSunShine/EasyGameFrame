---@class activityV2.ResDrawTimeLimitTaskReward
---instance properties
---@field public taskId System.Int32
---@field public taskIdSpecified System.Boolean
local m = {};

activityV2.ResDrawTimeLimitTaskReward=m
return m;