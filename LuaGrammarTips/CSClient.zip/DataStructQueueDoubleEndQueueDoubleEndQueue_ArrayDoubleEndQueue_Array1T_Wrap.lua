---@class DataStructQueueDoubleEndQueueDoubleEndQueue_ArrayDoubleEndQueue_Array1T
---instance properties
---@field public Count SystemInt32
local m = {};
---@param item T
function m:AddFrist(item) end
---@param item T
function m:AddLast(item) end
---@return T
function m:RemoveFirst() end
---@return T
function m:RemoveLast() end
---@return T
function m:GetFirst() end
---@return T
function m:GetLast() end
function m:Dilatation() end
DataStructQueueDoubleEndQueueDoubleEndQueue_ArrayDoubleEndQueue_Array1T=m
return m;