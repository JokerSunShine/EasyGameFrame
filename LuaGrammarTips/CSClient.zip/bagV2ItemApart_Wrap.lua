---@class bagV2.ItemApart
---instance properties
---@field public itemId System.Int64
---@field public count System.Int32
local m = {};

bagV2.ItemApart=m
return m;