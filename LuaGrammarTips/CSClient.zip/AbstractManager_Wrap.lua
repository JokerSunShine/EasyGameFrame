---@class AbstractManager
---instance fields
---@field public testInt System.Int32
local m = {};
function m:Awake() end
function m:Start() end
function m:Update() end
function m:Destroy() end
AbstractManager=m
return m;