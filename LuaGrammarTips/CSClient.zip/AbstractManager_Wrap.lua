---@class AbstractManager
---instance fields
---@field public testInt SystemInt32
local m = {};
function m:Awake() end
function m:Start() end
function m:Update() end
function m:Destroy() end
AbstractManager=m
return m;