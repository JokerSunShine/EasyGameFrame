---@class ICSharpCode.SharpZipLib.Tar.TarEntry
---instance properties
---@field public TarHeader ICSharpCode.SharpZipLib.Tar.TarHeader
---@field public Name System.String
---@field public UserId System.Int32
---@field public GroupId System.Int32
---@field public UserName System.String
---@field public GroupName System.String
---@field public ModTime System.DateTime
---@field public File System.String
---@field public Size System.Int64
---@field public IsDirectory System.Boolean
local m = {};
---@param name System.String
---@return ICSharpCode.SharpZipLib.Tar.TarEntry
function m.CreateTarEntry(name) end
---@param fileName System.String
---@return ICSharpCode.SharpZipLib.Tar.TarEntry
function m.CreateEntryFromFile(fileName) end
---@return System.Object
function m:Clone() end
---@param it System.Object
---@return System.Boolean
function m:Equals(it) end
---@return System.Int32
function m:GetHashCode() end
---@param desc ICSharpCode.SharpZipLib.Tar.TarEntry
---@return System.Boolean
function m:IsDescendent(desc) end
---@param userId System.Int32
---@param groupId System.Int32
function m:SetIds(userId, groupId) end
---@param userName System.String
---@param groupName System.String
function m:SetNames(userName, groupName) end
---@param outbuf System.Byte[]
---@param newName System.String
function m:AdjustEntryName(outbuf, newName) end
---@param hdr ICSharpCode.SharpZipLib.Tar.TarHeader
---@param file System.String
function m:GetFileTarHeader(hdr, file) end
---@return ICSharpCode.SharpZipLib.Tar.TarEntry[]
function m:GetDirectoryEntries() end
---@param outbuf System.Byte[]
function m:WriteEntryHeader(outbuf) end
---@param hdr ICSharpCode.SharpZipLib.Tar.TarHeader
---@param name System.String
function m:NameTarHeader(hdr, name) end
ICSharpCode.SharpZipLib.Tar.TarEntry=m
return m;