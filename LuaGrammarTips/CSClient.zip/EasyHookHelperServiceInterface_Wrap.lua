---@class EasyHookHelperServiceInterface : SystemMarshalByRefObject
local m = {};
---@param InTargetPID SystemInt32
function m.BeginInjection(InTargetPID) end
---@param InTargetPID SystemInt32
function m.EndInjection(InTargetPID) end
---@param InTargetPID SystemInt32
function m.WaitForInjection(InTargetPID) end
---@param InHostPID SystemInt32
---@param InTargetPID SystemInt32
---@param InWakeUpTID SystemInt32
---@param InNativeOptions SystemInt32
---@param InLibraryPath_x86 SystemString
---@param InLibraryPath_x64 SystemString
---@param InCanBypassWOW64 SystemBoolean
---@param InCanCreateService SystemBoolean
---@param InRequireStrongName SystemBoolean
---@param InPassThruArgs SystemObject
function m:InjectEx(InHostPID, InTargetPID, InWakeUpTID, InNativeOptions, InLibraryPath_x86, InLibraryPath_x64, InCanBypassWOW64, InCanCreateService, InRequireStrongName, InPassThruArgs) end
---@param InClientPID SystemInt32
---@param e SystemException
function m:InjectionException(InClientPID, e) end
---@param InClientPID SystemInt32
function m:InjectionCompleted(InClientPID) end
function m:Ping() end
EasyHookHelperServiceInterface=m
return m;