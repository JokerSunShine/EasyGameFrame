---@class ICSharpCodeNRefactoryAstFieldDeclaration : ICSharpCodeNRefactoryAstAttributedNode
---instance properties
---@field public TypeReference ICSharpCodeNRefactoryAstTypeReference
---@field public Fields SystemCollectionsGenericList1ICSharpCodeNRefactoryAstVariableDeclaration
local m = {};
---@param variableName SystemString
---@return ICSharpCodeNRefactoryAstVariableDeclaration
function m:GetVariableDeclaration(variableName) end
---@param fieldIndex SystemInt32
---@return ICSharpCodeNRefactoryAstTypeReference
function m:GetTypeForField(fieldIndex) end
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstFieldDeclaration=m
return m;