---@class ICSharpCode.NRefactory.Visitors.ToCSharpConvertVisitor+ReplaceWithAccessTransformer : ICSharpCode.NRefactory.Visitors.AbstractAstTransformer
local m = {};
---@param fieldReferenceExpression ICSharpCode.NRefactory.Ast.MemberReferenceExpression
---@param data System.Object
---@return System.Object
function m:VisitMemberReferenceExpression(fieldReferenceExpression, data) end
---@param withStatement ICSharpCode.NRefactory.Ast.WithStatement
---@param data System.Object
---@return System.Object
function m:VisitWithStatement(withStatement, data) end
ICSharpCode.NRefactory.Visitors.ToCSharpConvertVisitor+ReplaceWithAccessTransformer=m
return m;