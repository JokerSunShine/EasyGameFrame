---@class activityV2.ResTodayClosedActivities
---instance properties
---@field public activityType System.Collections.Generic.List1System.Int32
local m = {};

activityV2.ResTodayClosedActivities=m
return m;