---@class DataStructTreeBinaryTreeFullBinaryTreeFullBinaryTree_Array1T : DataStructTreeBinaryTreeArrayBinaryTreeAbstract1T
---instance properties
---@field public NodeArray T
local m = {};
---@param length SystemInt32
---@return SystemBoolean
function m:CheckIsFullBinary(length) end
DataStructTreeBinaryTreeFullBinaryTreeFullBinaryTree_Array1T=m
return m;