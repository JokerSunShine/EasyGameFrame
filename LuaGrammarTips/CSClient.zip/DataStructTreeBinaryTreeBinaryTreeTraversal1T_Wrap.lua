---@class DataStructTreeBinaryTreeBinaryTreeTraversal1T
local m = {};
---@param treeRoot DataStructTreeBinaryTreeNode1T
---@param traversalList DataStructTreeBinaryTreeNode1T
---@param action SystemAction1DataStructTreeBinaryTreeNode1T @default_value:
---@param isFirst SystemBoolean @default_value:True
function m.PreorderTraversal_ChainTree(treeRoot, traversalList, action, isFirst) end
---@param treeRoot DataStructTreeBinaryTreeNode1T
---@param traversalList DataStructTreeBinaryTreeNode1T
---@param action SystemAction1DataStructTreeBinaryTreeNode1T @default_value:
---@param isFirst SystemBoolean @default_value:True
function m.MiddleTraversal_ChainTree(treeRoot, traversalList, action, isFirst) end
---@param treeRoot DataStructTreeBinaryTreeNode1T
---@param traversalList DataStructTreeBinaryTreeNode1T
---@param action SystemAction1DataStructTreeBinaryTreeNode1T @default_value:
---@param isFirst SystemBoolean @default_value:True
function m.BehindTraversal_ChainTree(treeRoot, traversalList, action, isFirst) end
---@param treeRoot DataStructTreeBinaryTreeNode1T
---@param traversalList DataStructTreeBinaryTreeNode1T
---@param action SystemAction1DataStructTreeBinaryTreeNode1T @default_value:
---@param isFirst SystemBoolean @default_value:True
function m.LayerTraversal_ChainTree(treeRoot, traversalList, action, isFirst) end
---@param arrayBinaryTree DataStructTreeBinaryTreeArrayBinaryTreeAbstract1T
---@param traversalList T
---@param action SystemAction1T @default_value:
---@param isFirst SystemBoolean @default_value:True
---@param curIndex SystemInt32 @default_value:0
function m.PreorderTraversal_ArrayTree(arrayBinaryTree, traversalList, action, isFirst, curIndex) end
---@param arrayBinaryTree DataStructTreeBinaryTreeArrayBinaryTreeAbstract1T
---@param traversalList T
---@param action SystemAction1T @default_value:
---@param isFirst SystemBoolean @default_value:True
---@param curIndex SystemInt32 @default_value:0
function m.MiddleTraversal_ArrayTree(arrayBinaryTree, traversalList, action, isFirst, curIndex) end
---@param arrayBinaryTree DataStructTreeBinaryTreeArrayBinaryTreeAbstract1T
---@param traversalList T
---@param action SystemAction1T @default_value:
---@param isFirst SystemBoolean @default_value:True
---@param curIndex SystemInt32 @default_value:0
function m.BehindTraversal_ArrayTree(arrayBinaryTree, traversalList, action, isFirst, curIndex) end
---@param arrayBinaryTree DataStructTreeBinaryTreeArrayBinaryTreeAbstract1T
---@param traversalList T
---@param action SystemAction1T @default_value:
---@param isFirst SystemBoolean @default_value:True
function m.LayerTraversal_ArrayTree(arrayBinaryTree, traversalList, action, isFirst) end
DataStructTreeBinaryTreeBinaryTreeTraversal1T=m
return m;