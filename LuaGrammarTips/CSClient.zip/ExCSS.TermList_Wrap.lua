---@class ExCSS.TermList : ExCSS.Term
---instance properties
---@field public Length System.Int32
---@field public ListItems ExCSS.Term
local m = {};
---@param term ExCSS.Term
function m:AddTerm(term) end
---@param termSepertor ExCSS.TermList+TermSeparator
function m:AddSeparator(termSepertor) end
---@param index System.Int32
---@return ExCSS.Term
function m:Item(index) end
---@return System.Collections.Generic.IEnumerator`1[ExCSS.Term]
function m:GetEnumerator() end
---@return System.String
function m:ToString() end
ExCSS.TermList=m
return m;