---@class ICSharpCode.NRefactory.Visitors.LookupTableVisitor : ICSharpCode.NRefactory.Visitors.AbstractAstVisitor
---instance properties
---@field public Variables System.Collections.Generic.Dictionary`2[System.String,System.Collections.Generic.List`1[ICSharpCode.NRefactory.Visitors.LocalLookupVariable]]
---@field public WithStatements System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.WithStatement]
local m = {};
---@param typeRef ICSharpCode.NRefactory.Ast.TypeReference
---@param name System.String
---@param startPos ICSharpCode.NRefactory.Location
---@param endPos ICSharpCode.NRefactory.Location
---@param isConst System.Boolean
---@param isLoopVariable System.Boolean
---@param initializer ICSharpCode.NRefactory.Ast.Expression
---@param parentLambdaExpression ICSharpCode.NRefactory.Ast.LambdaExpression
---@param isQueryContinuation System.Boolean
function m:AddVariable(typeRef, name, startPos, endPos, isConst, isLoopVariable, initializer, parentLambdaExpression, isQueryContinuation) end
---@param withStatement ICSharpCode.NRefactory.Ast.WithStatement
---@param data System.Object
---@return System.Object
function m:VisitWithStatement(withStatement, data) end
---@param compilationUnit ICSharpCode.NRefactory.Ast.CompilationUnit
---@param data System.Object
---@return System.Object
function m:VisitCompilationUnit(compilationUnit, data) end
---@param blockStatement ICSharpCode.NRefactory.Ast.BlockStatement
---@param data System.Object
---@return System.Object
function m:VisitBlockStatement(blockStatement, data) end
---@param localVariableDeclaration ICSharpCode.NRefactory.Ast.LocalVariableDeclaration
---@param data System.Object
---@return System.Object
function m:VisitLocalVariableDeclaration(localVariableDeclaration, data) end
---@param anonymousMethodExpression ICSharpCode.NRefactory.Ast.AnonymousMethodExpression
---@param data System.Object
---@return System.Object
function m:VisitAnonymousMethodExpression(anonymousMethodExpression, data) end
---@param lambdaExpression ICSharpCode.NRefactory.Ast.LambdaExpression
---@param data System.Object
---@return System.Object
function m:VisitLambdaExpression(lambdaExpression, data) end
---@param queryExpression ICSharpCode.NRefactory.Ast.QueryExpression
---@param data System.Object
---@return System.Object
function m:VisitQueryExpression(queryExpression, data) end
---@param fromClause ICSharpCode.NRefactory.Ast.QueryExpressionFromClause
---@param data System.Object
---@return System.Object
function m:VisitQueryExpressionFromClause(fromClause, data) end
---@param joinClause ICSharpCode.NRefactory.Ast.QueryExpressionJoinClause
---@param data System.Object
---@return System.Object
function m:VisitQueryExpressionJoinClause(joinClause, data) end
---@param letClause ICSharpCode.NRefactory.Ast.QueryExpressionLetClause
---@param data System.Object
---@return System.Object
function m:VisitQueryExpressionLetClause(letClause, data) end
---@param forNextStatement ICSharpCode.NRefactory.Ast.ForNextStatement
---@param data System.Object
---@return System.Object
function m:VisitForNextStatement(forNextStatement, data) end
---@param fixedStatement ICSharpCode.NRefactory.Ast.FixedStatement
---@param data System.Object
---@return System.Object
function m:VisitFixedStatement(fixedStatement, data) end
---@param forStatement ICSharpCode.NRefactory.Ast.ForStatement
---@param data System.Object
---@return System.Object
function m:VisitForStatement(forStatement, data) end
---@param usingStatement ICSharpCode.NRefactory.Ast.UsingStatement
---@param data System.Object
---@return System.Object
function m:VisitUsingStatement(usingStatement, data) end
---@param switchSection ICSharpCode.NRefactory.Ast.SwitchSection
---@param data System.Object
---@return System.Object
function m:VisitSwitchSection(switchSection, data) end
---@param foreachStatement ICSharpCode.NRefactory.Ast.ForeachStatement
---@param data System.Object
---@return System.Object
function m:VisitForeachStatement(foreachStatement, data) end
---@param tryCatchStatement ICSharpCode.NRefactory.Ast.TryCatchStatement
---@param data System.Object
---@return System.Object
function m:VisitTryCatchStatement(tryCatchStatement, data) end
ICSharpCode.NRefactory.Visitors.LookupTableVisitor=m
return m;