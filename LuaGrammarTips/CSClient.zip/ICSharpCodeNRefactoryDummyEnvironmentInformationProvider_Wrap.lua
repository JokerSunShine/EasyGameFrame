---@class ICSharpCodeNRefactoryDummyEnvironmentInformationProvider
local m = {};
---@param reflectionTypeName SystemString
---@param typeParameterCount SystemInt32
---@param fieldName SystemString
---@return SystemBoolean
function m:HasField(reflectionTypeName, typeParameterCount, fieldName) end
ICSharpCodeNRefactoryDummyEnvironmentInformationProvider=m
return m;