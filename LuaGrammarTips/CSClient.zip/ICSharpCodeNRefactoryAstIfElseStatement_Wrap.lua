---@class ICSharpCodeNRefactoryAstIfElseStatement : ICSharpCodeNRefactoryAstStatement
---instance properties
---@field public Condition ICSharpCodeNRefactoryAstExpression
---@field public TrueStatement SystemCollectionsGenericList1ICSharpCodeNRefactoryAstStatement
---@field public FalseStatement SystemCollectionsGenericList1ICSharpCodeNRefactoryAstStatement
---@field public ElseIfSections SystemCollectionsGenericList1ICSharpCodeNRefactoryAstElseIfSection
---@field public HasElseStatements SystemBoolean
---@field public HasElseIfSections SystemBoolean
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstIfElseStatement=m
return m;