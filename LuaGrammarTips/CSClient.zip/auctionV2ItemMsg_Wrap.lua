---@class auctionV2.ItemMsg
---instance properties
---@field public itemType System.Int32
---@field public itemTypeSpecified System.Boolean
---@field public item bagV2.BagItemInfo
local m = {};

auctionV2.ItemMsg=m
return m;