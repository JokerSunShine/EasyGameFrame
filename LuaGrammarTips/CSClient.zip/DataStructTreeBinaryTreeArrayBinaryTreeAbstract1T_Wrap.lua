---@class DataStructTreeBinaryTreeArrayBinaryTreeAbstract1T
---instance properties
---@field public NodeArray T
---@field public Item T
local m = {};
DataStructTreeBinaryTreeArrayBinaryTreeAbstract1T=m
return m;