---@class ICSharpCode.NRefactory.Ast.QueryExpressionOrderClause : ICSharpCode.NRefactory.Ast.QueryExpressionClause
---instance properties
---@field public Orderings System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.QueryExpressionOrdering]
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.QueryExpressionOrderClause=m
return m;