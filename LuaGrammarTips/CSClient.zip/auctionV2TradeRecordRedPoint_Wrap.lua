---@class auctionV2.TradeRecordRedPoint
---instance properties
---@field public redPoint System.Int32
---@field public redPointSpecified System.Boolean
local m = {};

auctionV2.TradeRecordRedPoint=m
return m;