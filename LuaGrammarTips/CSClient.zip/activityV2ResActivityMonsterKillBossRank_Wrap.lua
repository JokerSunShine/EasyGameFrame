---@class activityV2.ResActivityMonsterKillBossRank
---instance properties
---@field public info System.Collections.Generic.List1activityV2.RankInfo
local m = {};

activityV2.ResActivityMonsterKillBossRank=m
return m;