---@class ICSharpCodeSharpZipLibEncryptionPkzipClassicCryptoBase
local m = {};
ICSharpCodeSharpZipLibEncryptionPkzipClassicCryptoBase=m
return m;