---@class CommonDataStructQueueChainQueueNode1T
---instance properties
---@field public Item T
---@field public Next CommonDataStructQueueChainQueueNode1T
local m = {};
CommonDataStructQueueChainQueueNode1T=m
return m;