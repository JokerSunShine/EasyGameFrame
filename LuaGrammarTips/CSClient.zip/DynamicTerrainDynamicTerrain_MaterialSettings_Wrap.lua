---@class DynamicTerrainDynamicTerrain_MaterialSettings : UnityEngineMonoBehaviour
---instance fields
---@field public maintex_STs UnityEngineVector4
---@field public mainTex UnityEngineTexture2DArray
---@field public terrainData DynamicTerrainTerrainData
local m = {};
DynamicTerrainDynamicTerrain_MaterialSettings=m
return m;