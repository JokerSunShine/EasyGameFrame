---@class ICSharpCode.NRefactory.PrettyPrinter.AbstractPrettyPrintOptions
---instance properties
---@field public IndentationChar System.Char
---@field public TabSize System.Int32
---@field public IndentSize System.Int32
local m = {};
ICSharpCode.NRefactory.PrettyPrinter.AbstractPrettyPrintOptions=m
return m;