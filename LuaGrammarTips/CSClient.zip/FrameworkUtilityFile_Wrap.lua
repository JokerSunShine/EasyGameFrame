---@class FrameworkUtilityFile
local m = {};
---@param path SystemString
---@return SystemString
function m.GetFileName(path) end
---@param path SystemString
---@return SystemString
function m.GetDirectory(path) end
FrameworkUtilityFile=m
return m;