---@class ICSharpCodeNRefactoryAstClassType
---@field Class @0
---@field Module @1
---@field Interface @2
---@field Struct @3
---@field Enum @4
ICSharpCodeNRefactoryAstClassType=m
return m;