---@class activityV2.BossScoreRewards
---instance properties
---@field public id System.Int32
---@field public state System.Int32
---@field public killCount System.Int32
---@field public killCountSpecified System.Boolean
local m = {};

activityV2.BossScoreRewards=m
return m;