---@class MicrosoftWin32IntranetZoneCredentialPolicy
local m = {};
---@param challengeUri SystemUri
---@param request SystemNetWebRequest
---@param credential SystemNetNetworkCredential
---@param authModule SystemNetIAuthenticationModule
---@return SystemBoolean
function m:ShouldSendCredential(challengeUri, request, credential, authModule) end
MicrosoftWin32IntranetZoneCredentialPolicy=m
return m;