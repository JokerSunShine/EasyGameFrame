---@class ICSharpCodeSharpZipLibZipCompressionStreamsStreamManipulator
---instance properties
---@field public AvailableBits SystemInt32
---@field public AvailableBytes SystemInt32
---@field public IsNeedingInput SystemBoolean
local m = {};
---@param n SystemInt32
---@return SystemInt32
function m:PeekBits(n) end
---@param n SystemInt32
function m:DropBits(n) end
---@param n SystemInt32
---@return SystemInt32
function m:GetBits(n) end
function m:SkipToByteBoundary() end
---@param output SystemByte
---@param offset SystemInt32
---@param length SystemInt32
---@return SystemInt32
function m:CopyBytes(output, offset, length) end
function m:Reset() end
---@param buf SystemByte
---@param off SystemInt32
---@param len SystemInt32
function m:SetInput(buf, off, len) end
ICSharpCodeSharpZipLibZipCompressionStreamsStreamManipulator=m
return m;