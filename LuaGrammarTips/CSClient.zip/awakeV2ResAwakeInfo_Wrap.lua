---@class awakeV2.ResAwakeInfo
---instance properties
---@field public awakeList System.Collections.Generic.List1awakeV2.AwakeInfo
local m = {};

awakeV2.ResAwakeInfo=m
return m;