---@class Microsoft.CSharp.CSharpCodeProvider : System.CodeDom.Compiler.CodeDomProvider
---instance properties
---@field public FileExtension System.String
local m = {};
---@param type System.Type
---@return System.ComponentModel.TypeConverter
function m:GetConverter(type) end
---@param member System.CodeDom.CodeTypeMember
---@param writer System.IO.TextWriter
---@param options System.CodeDom.Compiler.CodeGeneratorOptions
function m:GenerateCodeFromMember(member, writer, options) end
Microsoft.CSharp.CSharpCodeProvider=m
return m;