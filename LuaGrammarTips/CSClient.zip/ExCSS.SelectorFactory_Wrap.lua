---@class ExCSS.SelectorFactory
local m = {};
ExCSS.SelectorFactory=m
return m;