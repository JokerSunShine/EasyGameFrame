---@class ICSharpCode.NRefactory.Ast.IndexerDeclaration : ICSharpCode.NRefactory.Ast.AttributedNode
---instance properties
---@field public Parameters System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.ParameterDeclarationExpression]
---@field public InterfaceImplementations System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.InterfaceImplementation]
---@field public TypeReference ICSharpCode.NRefactory.Ast.TypeReference
---@field public BodyStart ICSharpCode.NRefactory.Location
---@field public BodyEnd ICSharpCode.NRefactory.Location
---@field public GetRegion ICSharpCode.NRefactory.Ast.PropertyGetRegion
---@field public SetRegion ICSharpCode.NRefactory.Ast.PropertySetRegion
---@field public IsReadOnly System.Boolean
---@field public HasSetRegion System.Boolean
---@field public HasGetRegion System.Boolean
---@field public IsWriteOnly System.Boolean
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.IndexerDeclaration=m
return m;