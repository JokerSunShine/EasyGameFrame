---@class FrameworkUtilityPath
---fields
---@field public artResourcePath SystemString
---@field public artScenePath SystemString
---@field public clientResourcePath SystemString
---@field public cilentScenePath SystemString
---properties
---@field public LocalProjectName SystemString
---@field public LoadRootPath SystemString
---@field public LoadOriginRootPath SystemString
---@field public CreateLuaGrammarTipPath SystemString
---@field public CreateCSClientTipPath SystemString
---@field public LoadVideoPath SystemString
---@field public ResourcePath SystemString
---@field public ServerXmlPath SystemString
---@field public ArtResourcePath SystemString
---@field public ArtScenePath SystemString
---@field public ClientResourcePath SystemString
---@field public CilentScenePath SystemString
---@field public ConfigPath SystemString
---@field public ResourceCollectionConfigFilePath SystemString
local m = {};
---@param path SystemString
---@return SystemString
function m.GetRegularPath(path) end
FrameworkUtilityPath=m
return m;