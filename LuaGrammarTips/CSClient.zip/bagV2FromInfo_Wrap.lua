---@class bagV2.FromInfo
---instance properties
---@field public type System.Int32
---@field public params System.Collections.Generic.List1System.String
local m = {};

bagV2.FromInfo=m
return m;