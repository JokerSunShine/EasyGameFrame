---@class backV2.ReqBackChatUnBan
---instance properties
---@field public uid System.String
---@field public uidSpecified System.Boolean
local m = {};

backV2.ReqBackChatUnBan=m
return m;