---@class BasePanel : UnityEngine.MonoBehaviour
---instance properties
---@field public ListenerNotification CEvent
local m = {};

---@param uiEvtID System.UInt32
---@param data System.Object
function m:HandleNotification(uiEvtID, data) end
---@param uiEvtID CEvent
---@param data System.Object
function m:SendNotification(uiEvtID, data) end
BasePanel=m
return m;