---@class ICSharpCodeSharpZipLibCoreProcessDirectoryDelegate : SystemMulticastDelegate
local m = {};
---@param Sender SystemObject
---@param e ICSharpCodeSharpZipLibCoreDirectoryEventArgs
function m:Invoke(Sender, e) end
---@param Sender SystemObject
---@param e ICSharpCodeSharpZipLibCoreDirectoryEventArgs
---@param callback SystemAsyncCallback
---@param object SystemObject
---@return SystemIAsyncResult
function m:BeginInvoke(Sender, e, callback, object) end
---@param result SystemIAsyncResult
function m:EndInvoke(result) end
ICSharpCodeSharpZipLibCoreProcessDirectoryDelegate=m
return m;