---@class awakeV2.ReqUnEquipAwake
---instance properties
---@field public index System.Int32
---@field public indexSpecified System.Boolean
local m = {};

awakeV2.ReqUnEquipAwake=m
return m;