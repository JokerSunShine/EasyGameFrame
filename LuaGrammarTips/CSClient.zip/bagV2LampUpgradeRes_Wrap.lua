---@class bagV2.LampUpgradeRes
---instance properties
---@field public type System.Int32
---@field public id System.Int32
local m = {};

bagV2.LampUpgradeRes=m
return m;