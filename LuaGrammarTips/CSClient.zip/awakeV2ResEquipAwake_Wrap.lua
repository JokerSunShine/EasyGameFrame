---@class awakeV2.ResEquipAwake
---instance properties
---@field public index System.Int32
---@field public indexSpecified System.Boolean
---@field public itemId System.Int32
---@field public itemIdSpecified System.Boolean
---@field public uniqueId System.Int64
---@field public uniqueIdSpecified System.Boolean
---@field public power System.Int32
---@field public powerSpecified System.Boolean
local m = {};

awakeV2.ResEquipAwake=m
return m;