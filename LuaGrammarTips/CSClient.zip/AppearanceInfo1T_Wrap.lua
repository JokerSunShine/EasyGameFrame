---@class AppearanceInfo1T : AppearanceInfoBasic
---instance properties
---@field public Avatar CSAvater
---@field public IsAppearanceDataLocked System.Boolean
---@field public Appearances System.Collections.Generic.Dictionary2System.Int32TABLE.CFG_APPEARANCE
---@field public IsAnyAppearanceEnabled System.Boolean
local m = {};

---@param partIndex System.Int32
---@param appearance TABLE.CFG_APPEARANCE
---@return System.Boolean
function m:SetAppearance(partIndex, appearance) end
---@param equipPartIndex System.Int32
---@param appearance TABLE.CFG_APPEARANCE @out
---@return System.Boolean
function m:GetAppearance(equipPartIndex, appearance) end
---@param partIndex System.Int32
---@param appearance TABLE.CFG_APPEARANCE
---@return System.Boolean
function m:IsAppearanceAvailable(partIndex, appearance) end
---@param equipPartIndex System.Int32
---@param modelID System.Int32 @out
---@return System.Boolean
function m:GetAppearanceModelID(equipPartIndex, modelID) end
function m:Clear() end
---@return System.Boolean
function m:IsNullAppearance() end
function m:Refresh() end
AppearanceInfo1T=m
return m;