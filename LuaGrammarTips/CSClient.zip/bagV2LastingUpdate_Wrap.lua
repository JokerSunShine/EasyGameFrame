---@class bagV2.LastingUpdate
---instance properties
---@field public itemId System.Collections.Generic.List1System.Int64
local m = {};

bagV2.LastingUpdate=m
return m;