---@class ExCSS.Lexer
local m = {};
ExCSS.Lexer=m
return m;