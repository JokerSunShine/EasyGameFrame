---@class ICSharpCodeNRefactoryIEnvironmentInformationProvider
local m = {};
---@param reflectionTypeName SystemString
---@param typeParameterCount SystemInt32
---@param fieldName SystemString
---@return SystemBoolean
function m:HasField(reflectionTypeName, typeParameterCount, fieldName) end
ICSharpCodeNRefactoryIEnvironmentInformationProvider=m
return m;