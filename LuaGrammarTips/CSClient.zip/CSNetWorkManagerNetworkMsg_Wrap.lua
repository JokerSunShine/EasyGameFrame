---@class CSNetWorkManagerNetworkMsg : SystemValueType
---instance fields
---@field public length SystemInt32
---@field public msgId SystemInt32
---@field public data SystemByte
---@field public sequence SystemInt16
local m = {};
CSNetWorkManagerNetworkMsg=m
return m;