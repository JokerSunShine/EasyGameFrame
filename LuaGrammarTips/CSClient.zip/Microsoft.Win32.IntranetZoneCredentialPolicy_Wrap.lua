---@class Microsoft.Win32.IntranetZoneCredentialPolicy
local m = {};
---@param challengeUri System.Uri
---@param request System.Net.WebRequest
---@param credential System.Net.NetworkCredential
---@param authModule System.Net.IAuthenticationModule
---@return System.Boolean
function m:ShouldSendCredential(challengeUri, request, credential, authModule) end
Microsoft.Win32.IntranetZoneCredentialPolicy=m
return m;