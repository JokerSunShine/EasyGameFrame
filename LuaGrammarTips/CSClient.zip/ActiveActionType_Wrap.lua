---@class ActiveActionType
---@field KILL_BOSS @1
---@field DAILY_TASK @2
---@field ELITE_REWARD @3
---@field BOSS_REWARD @4
local m = {};
ActiveActionType=m
return m;