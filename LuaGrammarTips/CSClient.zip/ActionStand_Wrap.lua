---@class ActionStand : BehaviorState
---instance properties
---@field public Behavior System.Int32
local m = {};

---@param p ISFAvater
---@param lastBehv BehaviorState
function m:Start(p, lastBehv) end
---@param p ISFAvater
---@return System.Int32
function m:Update(p) end
function m:Reset() end
---@param chr CSAvater
function m:InitNPCShow(chr) end
ActionStand=m
return m;