---@class appearanceV2.ReqModifyTitle
---instance properties
---@field public titleId System.Int32
---@field public titleIdSpecified System.Boolean
---@field public modifyTitle System.String
---@field public modifyTitleSpecified System.Boolean
local m = {};

appearanceV2.ReqModifyTitle=m
return m;