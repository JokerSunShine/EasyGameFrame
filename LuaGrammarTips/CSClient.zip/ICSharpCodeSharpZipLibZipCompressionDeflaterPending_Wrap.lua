---@class ICSharpCodeSharpZipLibZipCompressionDeflaterPending : ICSharpCodeSharpZipLibZipCompressionPendingBuffer
local m = {};
ICSharpCodeSharpZipLibZipCompressionDeflaterPending=m
return m;