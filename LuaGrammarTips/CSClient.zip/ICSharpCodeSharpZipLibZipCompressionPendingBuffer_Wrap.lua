---@class ICSharpCodeSharpZipLibZipCompressionPendingBuffer
---instance properties
---@field public BitCount SystemInt32
---@field public IsFlushed SystemBoolean
local m = {};
function m:Reset() end
---@param b SystemInt32
function m:WriteByte(b) end
---@param s SystemInt32
function m:WriteShort(s) end
---@param s SystemInt32
function m:WriteInt(s) end
---@param block SystemByte
---@param offset SystemInt32
---@param len SystemInt32
function m:WriteBlock(block, offset, len) end
function m:AlignToByte() end
---@param b SystemInt32
---@param count SystemInt32
function m:WriteBits(b, count) end
---@param s SystemInt32
function m:WriteShortMSB(s) end
---@param output SystemByte
---@param offset SystemInt32
---@param length SystemInt32
---@return SystemInt32
function m:Flush(output, offset, length) end
---@return SystemByte
function m:ToByteArray() end
ICSharpCodeSharpZipLibZipCompressionPendingBuffer=m
return m;