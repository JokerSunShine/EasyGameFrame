---@class AnimationOrTween.Direction
---@field Toggle @0
---@field Forward @1
---@field Reverse @-1
local m = {};
AnimationOrTween.Direction=m
return m;