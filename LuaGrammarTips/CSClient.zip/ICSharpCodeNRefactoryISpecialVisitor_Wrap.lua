---@class ICSharpCodeNRefactoryISpecialVisitor
local m = {};
---@param special ICSharpCodeNRefactoryISpecial
---@param data SystemObject
---@return SystemObject
function m:Visit(special, data) end
---@param special ICSharpCodeNRefactoryBlankLine
---@param data SystemObject
---@return SystemObject
function m:Visit(special, data) end
---@param special ICSharpCodeNRefactoryComment
---@param data SystemObject
---@return SystemObject
function m:Visit(special, data) end
---@param special ICSharpCodeNRefactoryPreprocessingDirective
---@param data SystemObject
---@return SystemObject
function m:Visit(special, data) end
ICSharpCodeNRefactoryISpecialVisitor=m
return m;