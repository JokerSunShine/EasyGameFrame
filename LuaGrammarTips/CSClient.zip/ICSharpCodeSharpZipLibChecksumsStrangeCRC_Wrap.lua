---@class ICSharpCodeSharpZipLibChecksumsStrangeCRC
---instance properties
---@field public Value SystemInt64
local m = {};
function m:Reset() end
---@param inCh SystemInt32
function m:Update(inCh) end
---@param buf SystemByte
function m:Update(buf) end
---@param buf SystemByte
---@param off SystemInt32
---@param len SystemInt32
function m:Update(buf, off, len) end
ICSharpCodeSharpZipLibChecksumsStrangeCRC=m
return m;