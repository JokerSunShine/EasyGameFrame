---@class ExCSS.PseudoSelectorPrefix
local m = {};
ExCSS.PseudoSelectorPrefix=m
return m;