---@class GraphicsPolygon
local m = {};
---@param point _3DMathVector3
---@return GraphicsPolygonType
function m.GetPolygonAngleType(point) end
GraphicsPolygon=m
return m;