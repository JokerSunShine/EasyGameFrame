---@class DataStructTreeBTreeBaseBTreeNodeBase1T
---instance fields
---@field public count SystemInt32
---@field public childs DataStructTreeBTreeBaseBTreeNodeBase1T
---@field public isLeaf SystemBoolean
---@field public compareFunc SystemFunc3TTSystemInt32
---@field public parentNode DataStructTreeBTreeBaseBTreeNodeBase1T
---@field public parentChildIndex SystemInt32
---instance properties
---@field public Values T
---@field public MinCount SystemInt32
---@field public MaxCount SystemInt32
local m = {};
---@param i SystemInt32
function m:SplitChild(i) end
---@param i SystemInt32
---@param useLeftData SystemBoolean @default_value:False
function m:BTreeLeftToRightChild(i, useLeftData) end
---@param i SystemInt32
---@param useRightData SystemBoolean @default_value:False
function m:BTreeRightToLeftChild(i, useRightData) end
---@param i SystemInt32
function m:BTreeNodeMerge(i) end
---@return T
function m:GetMaxValue() end
---@param data T
---@return DataStructTreeBTreeBaseBTreeNodeBase1T
function m:FindNode(data) end
---@param traversaList CommonOneWayChainListOneWayChainList1T
---@param action SystemAction1T @default_value:
function m:Traversal(traversaList, action) end
---@param data T
function m:InserData(data) end
---@return SystemBoolean
function m:IsMinCount() end
---@return SystemBoolean
function m:IsMaxCount() end
---@param data T
function m:DeleteData(data) end
---@param order SystemInt32
---@param isLeaf SystemBoolean
---@param compareFunc SystemFunc3TTSystemInt32
---@param tree DataStructTreeBTreeBaseBTreeBase1T
---@param count SystemInt32 @default_value:0
---@return DataStructTreeBTreeBaseBTreeNodeBase1T
function m:GetNewTreeNoe(order, isLeaf, compareFunc, tree, count) end
DataStructTreeBTreeBaseBTreeNodeBase1T=m
return m;