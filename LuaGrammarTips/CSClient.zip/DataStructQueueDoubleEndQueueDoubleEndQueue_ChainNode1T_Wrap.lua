---@class DataStructQueueDoubleEndQueueDoubleEndQueue_ChainNode1T
---instance properties
---@field public Item T
---@field public Prev DataStructQueueDoubleEndQueueDoubleEndQueue_ChainNode1T
---@field public Next DataStructQueueDoubleEndQueueDoubleEndQueue_ChainNode1T
local m = {};
DataStructQueueDoubleEndQueueDoubleEndQueue_ChainNode1T=m
return m;