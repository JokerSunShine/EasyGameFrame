---@class ICSharpCodeNRefactoryAstGotoStatement : ICSharpCodeNRefactoryAstStatement
---instance properties
---@field public Label SystemString
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstGotoStatement=m
return m;