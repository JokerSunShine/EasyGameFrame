---@class ICSharpCode.SharpZipLib.Encryption.PkzipClassicDecryptCryptoTransform : ICSharpCode.SharpZipLib.Encryption.PkzipClassicCryptoBase
---instance properties
---@field public CanReuseTransform System.Boolean
---@field public InputBlockSize System.Int32
---@field public OutputBlockSize System.Int32
---@field public CanTransformMultipleBlocks System.Boolean
local m = {};
---@param inputBuffer System.Byte[]
---@param inputOffset System.Int32
---@param inputCount System.Int32
---@return System.Byte[]
function m:TransformFinalBlock(inputBuffer, inputOffset, inputCount) end
---@param inputBuffer System.Byte[]
---@param inputOffset System.Int32
---@param inputCount System.Int32
---@param outputBuffer System.Byte[]
---@param outputOffset System.Int32
---@return System.Int32
function m:TransformBlock(inputBuffer, inputOffset, inputCount, outputBuffer, outputOffset) end
function m:Dispose() end
ICSharpCode.SharpZipLib.Encryption.PkzipClassicDecryptCryptoTransform=m
return m;