---@class boothV2.BoothInfo
---instance properties
---@field public boothId System.Int64
---@field public boothIdSpecified System.Boolean
---@field public boothCoordinateId System.Int32
---@field public boothCoordinateIdSpecified System.Boolean
---@field public boothTypeId System.Int32
---@field public boothTypeIdSpecified System.Boolean
---@field public boothMapId System.Int32
---@field public boothMapIdSpecified System.Boolean
---@field public boothLine System.Int32
---@field public boothLineSpecified System.Boolean
---@field public rid System.Int64
---@field public ridSpecified System.Boolean
---@field public sex System.Int32
---@field public sexSpecified System.Boolean
---@field public career System.Int32
---@field public careerSpecified System.Boolean
---@field public name System.String
---@field public nameSpecified System.Boolean
---@field public isRemote System.Boolean
---@field public isRemoteSpecified System.Boolean
---@field public label System.Collections.Generic.List1System.Int32
---@field public overdueTime System.Int64
---@field public overdueTimeSpecified System.Boolean
local m = {};

boothV2.BoothInfo=m
return m;