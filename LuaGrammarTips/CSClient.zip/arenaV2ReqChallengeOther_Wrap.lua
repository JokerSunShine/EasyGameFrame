---@class arenaV2.ReqChallengeOther
---instance properties
---@field public targetRank System.Int32
---@field public targetRankSpecified System.Boolean
---@field public instanceId System.Int32
---@field public instanceIdSpecified System.Boolean
local m = {};

arenaV2.ReqChallengeOther=m
return m;