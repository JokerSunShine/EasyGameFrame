---@class ICSharpCodeNRefactoryAstCompilationUnit : ICSharpCodeNRefactoryAstAbstractNode
---instance properties
---@field public CurrentBock ICSharpCodeNRefactoryAstINode
local m = {};
---@param block ICSharpCodeNRefactoryAstINode
function m:BlockStart(block) end
function m:BlockEnd() end
---@param childNode ICSharpCodeNRefactoryAstINode
function m:AddChild(childNode) end
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstCompilationUnit=m
return m;