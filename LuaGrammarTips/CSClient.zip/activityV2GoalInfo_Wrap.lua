---@class activityV2.GoalInfo
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public goalType System.Int32
---@field public goalTypeSpecified System.Boolean
---@field public goal System.Int32
---@field public goalSpecified System.Boolean
---@field public rewardState System.Int32
---@field public rewardStateSpecified System.Boolean
---@field public leftCount System.Int32
---@field public leftCountSpecified System.Boolean
---@field public now System.Int32
---@field public nowSpecified System.Boolean
---@field public total System.Int32
---@field public totalSpecified System.Boolean
local m = {};

activityV2.GoalInfo=m
return m;