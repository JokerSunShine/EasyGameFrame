---@class ICSharpCode.NRefactory.Parser.ModifierList
---instance properties
---@field public Modifier ICSharpCode.NRefactory.Ast.Modifiers
---@field public isNone System.Boolean
local m = {};
---@param keywordLocation ICSharpCode.NRefactory.Location
---@return ICSharpCode.NRefactory.Location
function m:GetDeclarationLocation(keywordLocation) end
---@param m ICSharpCode.NRefactory.Ast.Modifiers
---@return System.Boolean
function m:Contains(m) end
---@param m ICSharpCode.NRefactory.Ast.Modifiers
---@param tokenLocation ICSharpCode.NRefactory.Location
function m:Add(m, tokenLocation) end
---@param allowed ICSharpCode.NRefactory.Ast.Modifiers
function m:Check(allowed) end
ICSharpCode.NRefactory.Parser.ModifierList=m
return m;