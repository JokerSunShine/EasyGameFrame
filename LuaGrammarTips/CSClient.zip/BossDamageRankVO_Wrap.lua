---@class BossDamageRankVO
---instance properties
---@field public career System.Int32
---@field public sex System.Int32
---@field public level System.Int32
---@field public rein System.Int32
---@field public rank System.Int32
---@field public hurt System.Int64
---@field public roleId System.Int64
---@field public roleName System.String
---@field public unionId System.Int64
---@field public unionName System.String
---@field public unionRank System.Int32
local m = {};

---@param bossDamageRank bossV2.AncientBossDamageRank
function m:UpdateVO(bossDamageRank) end
BossDamageRankVO=m
return m;