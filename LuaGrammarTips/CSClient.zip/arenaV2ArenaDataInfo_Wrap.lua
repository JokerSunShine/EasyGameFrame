---@class arenaV2.ArenaDataInfo
---instance properties
---@field public rank System.Int32
---@field public rankSpecified System.Boolean
---@field public uid System.Int64
---@field public uidSpecified System.Boolean
---@field public name System.String
---@field public nameSpecified System.Boolean
---@field public fightPower System.Int32
---@field public fightPowerSpecified System.Boolean
---@field public titleId System.Int32
---@field public titleIdSpecified System.Boolean
---@field public windId System.Int32
---@field public windIdSpecified System.Boolean
---@field public sex System.Int32
---@field public sexSpecified System.Boolean
---@field public career System.Int32
---@field public careerSpecified System.Boolean
---@field public weaponId System.Int32
---@field public weaponIdSpecified System.Boolean
---@field public clothesId System.Int32
---@field public clothesIdSpecified System.Boolean
---@field public junxian System.Int32
---@field public junxianSpecified System.Boolean
---@field public robot System.Int32
---@field public robotSpecified System.Boolean
local m = {};

arenaV2.ArenaDataInfo=m
return m;