---@class MicrosoftCSharpCSharpCodeGenerator
local m = {};
---@param member SystemCodeDomCodeTypeMember
---@param writer SystemIOTextWriter
---@param options SystemCodeDomCompilerCodeGeneratorOptions
function m:GenerateCodeFromMember(member, writer, options) end
---@param support SystemCodeDomCompilerGeneratorSupport
---@return SystemBoolean
function m:Supports(support) end
---@param value SystemString
---@return SystemBoolean
function m:IsValidIdentifier(value) end
---@param value SystemString
function m:ValidateIdentifier(value) end
---@param name SystemString
---@return SystemString
function m:CreateValidIdentifier(name) end
---@param name SystemString
---@return SystemString
function m:CreateEscapedIdentifier(name) end
---@param typeRef SystemCodeDomCodeTypeReference
---@return SystemString
function m:GetTypeOutput(typeRef) end
MicrosoftCSharpCSharpCodeGenerator=m
return m;