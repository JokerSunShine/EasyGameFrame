---@class arenaV2.ResChallengeOther
---instance properties
---@field public state System.Int32
---@field public stateSpecified System.Boolean
---@field public targetRank System.Int32
---@field public targetRankSpecified System.Boolean
local m = {};

arenaV2.ResChallengeOther=m
return m;