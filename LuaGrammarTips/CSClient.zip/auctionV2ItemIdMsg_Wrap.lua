---@class auctionV2.ItemIdMsg
---instance properties
---@field public lid System.Int64
---@field public lidSpecified System.Boolean
local m = {};

auctionV2.ItemIdMsg=m
return m;