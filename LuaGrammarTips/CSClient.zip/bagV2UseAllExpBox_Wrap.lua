---@class bagV2.UseAllExpBox
---instance properties
---@field public data System.Int32
---@field public useSpiritPoint System.Int32
---@field public useSpiritPointSpecified System.Boolean
local m = {};

bagV2.UseAllExpBox=m
return m;