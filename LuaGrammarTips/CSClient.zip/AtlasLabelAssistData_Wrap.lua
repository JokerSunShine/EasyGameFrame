---@class AtlasLabelAssistData
---instance fields
---@field public spriteDic System.Collections.Generic.Dictionary2System.StringUISpriteData
---@field public atlas UIAtlas
local m = {};

AtlasLabelAssistData=m
return m;