---@class boothV2.BoothBuy
---instance properties
---@field public boothId System.Int64
---@field public boothIdSpecified System.Boolean
---@field public lid System.Int64
---@field public lidSpecified System.Boolean
---@field public count System.Int32
---@field public countSpecified System.Boolean
local m = {};

boothV2.BoothBuy=m
return m;