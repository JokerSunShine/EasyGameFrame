---@class backV2.ResBackLogin
---instance properties
---@field public loginRet System.Int32
---@field public loginRetSpecified System.Boolean
local m = {};

backV2.ResBackLogin=m
return m;