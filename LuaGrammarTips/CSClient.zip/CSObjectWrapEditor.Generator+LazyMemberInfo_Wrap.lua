---@class CSObjectWrapEditor.Generator+LazyMemberInfo
---instance fields
---@field public Index System.String
---@field public Name System.String
---@field public MemberType System.String
---@field public IsStatic System.String
local m = {};
CSObjectWrapEditor.Generator+LazyMemberInfo=m
return m;