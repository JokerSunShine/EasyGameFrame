---@class backV2.ReqCustomizeAnnounce
---instance properties
---@field public uniqueId System.Int32
---@field public uniqueIdSpecified System.Boolean
---@field public startTime System.Int32
---@field public startTimeSpecified System.Boolean
---@field public endTime System.Int32
---@field public endTimeSpecified System.Boolean
---@field public period System.Int32
---@field public periodSpecified System.Boolean
---@field public type System.Int32
---@field public typeSpecified System.Boolean
---@field public content System.String
---@field public contentSpecified System.Boolean
local m = {};

backV2.ReqCustomizeAnnounce=m
return m;