---@class ExCSSModelISupportsDeclarations
---instance properties
---@field public Declarations ExCSSStyleDeclaration
local m = {};
ExCSSModelISupportsDeclarations=m
return m;