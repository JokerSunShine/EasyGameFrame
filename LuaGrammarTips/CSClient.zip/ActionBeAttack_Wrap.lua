---@class ActionBeAttack : BehaviorState
---instance properties
---@field public Behavior System.Int32
local m = {};

---@param avater ISFAvater
---@param last BehaviorState
function m:Start(avater, last) end
---@param avater ISFAvater
---@return System.Int32
function m:Update(avater) end
ActionBeAttack=m
return m;