---@class boothV2.BoothIdMsg
---instance properties
---@field public BoothId System.Int64
---@field public BoothIdSpecified System.Boolean
local m = {};

boothV2.BoothIdMsg=m
return m;