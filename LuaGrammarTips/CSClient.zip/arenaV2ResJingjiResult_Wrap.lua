---@class arenaV2.ResJingjiResult
---instance properties
---@field public result System.Int32
---@field public resultSpecified System.Boolean
---@field public nowRank System.Int32
---@field public nowRankSpecified System.Boolean
---@field public oldRank System.Int32
---@field public oldRankSpecified System.Boolean
---@field public targetName System.String
---@field public targetNameSpecified System.Boolean
---@field public resultRewardList System.Collections.Generic.List1arenaV2.RankRewardInfo
---@field public rankRewardList System.Collections.Generic.List1arenaV2.RankRewardInfo
local m = {};

arenaV2.ResJingjiResult=m
return m;