---@class ExCSSModelHtmlEncoding
local m = {};
ExCSSModelHtmlEncoding=m
return m;