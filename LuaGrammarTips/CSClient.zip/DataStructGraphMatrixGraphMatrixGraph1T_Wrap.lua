---@class DataStructGraphMatrixGraphMatrixGraph1T : DataStructGraphBaseGraphAbstract1T
---instance fields
---@field public edgeMatrix SystemInt32
local m = {};
---@param index SystemInt32
---@return T
function m:RemoveNode(index) end
---@param start SystemInt32
---@param endParam SystemInt32
---@param len SystemInt32
function m:AddEdge(start, endParam, len) end
---@param start SystemInt32
---@param endParam SystemInt32
---@param len SystemInt32
function m:AddArc(start, endParam, len) end
---@param start SystemInt32
---@param endParam SystemInt32
function m:RemvoeEdge(start, endParam) end
---@param start SystemInt32
---@param endParam SystemInt32
function m:RemvoeArc(start, endParam) end
---@param x SystemInt32
---@param y SystemInt32
---@return SystemInt32
function m:GetEdgeWeight(x, y) end
function m:Expand() end
---@param index SystemInt32
---@return CommonDataStructQueueChainQueueChainQueue1DataStructGraphBaseNodeAbstract1T
function m:BFSorder(index) end
---@param index SystemInt32
---@return CommonDataStructQueueChainQueueChainQueue1DataStructGraphBaseNodeAbstract1T
function m:DFSorder(index) end
---@return DataStructGraphBaseEdge
function m:GetMinEdge() end
---@param data T
---@return DataStructGraphBaseNodeAbstract1T
function m:GetNode(data) end
DataStructGraphMatrixGraphMatrixGraph1T=m
return m;