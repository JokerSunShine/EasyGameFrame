---@class ExCSS.TermList+TermSeparator
---@field Comma @0
---@field Space @1
---@field Colon @2
ExCSS.TermList+TermSeparator=m
return m;