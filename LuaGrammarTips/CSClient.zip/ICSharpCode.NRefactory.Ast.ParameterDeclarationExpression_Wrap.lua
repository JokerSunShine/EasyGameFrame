---@class ICSharpCode.NRefactory.Ast.ParameterDeclarationExpression : ICSharpCode.NRefactory.Ast.Expression
---instance properties
---@field public Attributes System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.AttributeSection]
---@field public ParameterName System.String
---@field public TypeReference ICSharpCode.NRefactory.Ast.TypeReference
---@field public ParamModifier ICSharpCode.NRefactory.Ast.ParameterModifiers
---@field public DefaultValue ICSharpCode.NRefactory.Ast.Expression
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.ParameterDeclarationExpression=m
return m;