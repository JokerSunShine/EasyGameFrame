---@class DataStructGraphEGGraphEGGraph1T : DataStructGraphBaseGraphAbstract1T
---instance fields
---@field public edges DataStructGraphBaseEdge
---@field public edgeNum SystemInt32
local m = {};
---@param vertexIndex SystemInt32
---@return T
function m:RemoveNode(vertexIndex) end
---@param start SystemInt32
---@param endParam SystemInt32
---@param len SystemInt32
function m:AddEdge(start, endParam, len) end
---@param start SystemInt32
---@param endParam SystemInt32
---@param len SystemInt32
function m:AddArc(start, endParam, len) end
---@param start SystemInt32
---@param endParam SystemInt32
function m:RemvoeEdge(start, endParam) end
---@param start SystemInt32
---@param endParam SystemInt32
function m:RemvoeArc(start, endParam) end
---@param start SystemInt32
---@param endParam SystemInt32
---@return SystemInt32
function m:GetEdgeWeight(start, endParam) end
function m:Expand() end
---@param index SystemInt32
---@return CommonDataStructQueueChainQueueChainQueue1DataStructGraphBaseNodeAbstract1T
function m:BFSorder(index) end
---@param index SystemInt32
---@return CommonDataStructQueueChainQueueChainQueue1DataStructGraphBaseNodeAbstract1T
function m:DFSorder(index) end
---@return DataStructGraphBaseEdge
function m:GetMinEdge() end
---@param data T
---@return DataStructGraphBaseNodeAbstract1T
function m:GetNode(data) end
DataStructGraphEGGraphEGGraph1T=m
return m;