---@class AnimationOrTween.Trigger
---@field OnClick @0
---@field OnHover @1
---@field OnPress @2
---@field OnHoverTrue @3
---@field OnHoverFalse @4
---@field OnPressTrue @5
---@field OnPressFalse @6
---@field OnActivate @7
---@field OnActivateTrue @8
---@field OnActivateFalse @9
---@field OnDoubleClick @10
---@field OnSelect @11
---@field OnSelectTrue @12
---@field OnSelectFalse @13
---@field None @14
local m = {};
AnimationOrTween.Trigger=m
return m;