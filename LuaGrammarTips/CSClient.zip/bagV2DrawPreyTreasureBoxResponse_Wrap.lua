---@class bagV2.DrawPreyTreasureBoxResponse
local m = {};

bagV2.DrawPreyTreasureBoxResponse=m
return m;