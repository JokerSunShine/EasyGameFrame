---@class appearanceV2.ResGetWearFashion
---instance properties
---@field public rid System.Int64
---@field public ridSpecified System.Boolean
---@field public wearIds System.Collections.Generic.List1appearanceV2.wearPosition
local m = {};

appearanceV2.ResGetWearFashion=m
return m;