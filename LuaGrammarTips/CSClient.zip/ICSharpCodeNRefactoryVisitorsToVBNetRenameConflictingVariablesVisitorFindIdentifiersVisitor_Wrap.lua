---@class ICSharpCodeNRefactoryVisitorsToVBNetRenameConflictingVariablesVisitorFindIdentifiersVisitor : ICSharpCodeNRefactoryVisitorsAbstractAstVisitor
local m = {};
---@param identifierExpression ICSharpCodeNRefactoryAstIdentifierExpression
---@param data SystemObject
---@return SystemObject
function m:VisitIdentifierExpression(identifierExpression, data) end
ICSharpCodeNRefactoryVisitorsToVBNetRenameConflictingVariablesVisitorFindIdentifiersVisitor=m
return m;