---@class AvatarBaseTimeCountData : HeadDataBase
---instance fields
---@field public timePos UnityEngine.Vector3
---@field public endTimeStamp System.Int64
---@field public startCountTimeDesc System.String
---@field public endCountTimeDesc System.String
local m = {};

AvatarBaseTimeCountData=m
return m;