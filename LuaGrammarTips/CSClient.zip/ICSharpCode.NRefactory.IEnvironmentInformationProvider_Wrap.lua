---@class ICSharpCode.NRefactory.IEnvironmentInformationProvider
local m = {};
---@param reflectionTypeName System.String
---@param typeParameterCount System.Int32
---@param fieldName System.String
---@return System.Boolean
function m:HasField(reflectionTypeName, typeParameterCount, fieldName) end
ICSharpCode.NRefactory.IEnvironmentInformationProvider=m
return m;