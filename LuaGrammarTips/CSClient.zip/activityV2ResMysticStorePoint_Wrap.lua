---@class activityV2.ResMysticStorePoint
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public point System.Int32
---@field public pointSpecified System.Boolean
local m = {};

activityV2.ResMysticStorePoint=m
return m;