---@class BoothModelLoad : ModelLoadBase3D2BoothModelLoadCSBoothGo
---fields
---@field public boothPlayerOffsetPosition UnityEngine.Vector3
---@field public uIAtlas Top_UIAtlas
---instance fields
---@field public boothModel CSResource
---instance properties
---@field public avater NewI_CSAvater
---@field public csAvater CSAvater
---@field public BoothSpriteInfo Cfg_GlobalTableManagerBoothSpriteInfo
local m = {};

function m:Analyze() end
BoothModelLoad=m
return m;