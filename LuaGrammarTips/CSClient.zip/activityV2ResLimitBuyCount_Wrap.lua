---@class activityV2.ResLimitBuyCount
---instance properties
---@field public ShouHuLimitBuyInfoList System.Collections.Generic.List1activityV2.ShouHuLimitBuyInfo
local m = {};

activityV2.ResLimitBuyCount=m
return m;