---@class ICSharpCode.SharpZipLib.Zip.Compression.InflaterHuffmanTree
---fields
---@field public defLitLenTree ICSharpCode.SharpZipLib.Zip.Compression.InflaterHuffmanTree
---@field public defDistTree ICSharpCode.SharpZipLib.Zip.Compression.InflaterHuffmanTree
local m = {};
---@param input ICSharpCode.SharpZipLib.Zip.Compression.Streams.StreamManipulator
---@return System.Int32
function m:GetSymbol(input) end
ICSharpCode.SharpZipLib.Zip.Compression.InflaterHuffmanTree=m
return m;