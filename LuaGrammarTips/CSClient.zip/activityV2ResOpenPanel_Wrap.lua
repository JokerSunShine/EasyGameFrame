---@class activityV2.ResOpenPanel
---instance properties
---@field public activityType System.Int32
---@field public activityTypeSpecified System.Boolean
---@field public info activityV2.ActivityListInfo
local m = {};

activityV2.ResOpenPanel=m
return m;