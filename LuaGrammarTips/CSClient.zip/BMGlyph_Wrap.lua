---@class BMGlyph
---instance fields
---@field public index System.Int32
---@field public x System.Int32
---@field public y System.Int32
---@field public width System.Int32
---@field public height System.Int32
---@field public offsetX System.Int32
---@field public offsetY System.Int32
---@field public advance System.Int32
---@field public channel System.Int32
---@field public kerning System.Collections.Generic.List1System.Int32
local m = {};

---@param previousChar System.Int32
---@return System.Int32
function m:GetKerning(previousChar) end
---@param previousChar System.Int32
---@param amount System.Int32
function m:SetKerning(previousChar, amount) end
---@param xMin System.Int32
---@param yMin System.Int32
---@param xMax System.Int32
---@param yMax System.Int32
function m:Trim(xMin, yMin, xMax, yMax) end
BMGlyph=m
return m;