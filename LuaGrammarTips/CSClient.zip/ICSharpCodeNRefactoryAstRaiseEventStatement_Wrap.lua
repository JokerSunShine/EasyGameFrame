---@class ICSharpCodeNRefactoryAstRaiseEventStatement : ICSharpCodeNRefactoryAstStatement
---instance properties
---@field public EventName SystemString
---@field public Arguments SystemCollectionsGenericList1ICSharpCodeNRefactoryAstExpression
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstRaiseEventStatement=m
return m;