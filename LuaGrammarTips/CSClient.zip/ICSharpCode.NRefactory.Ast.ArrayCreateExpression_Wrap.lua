---@class ICSharpCode.NRefactory.Ast.ArrayCreateExpression : ICSharpCode.NRefactory.Ast.Expression
---instance properties
---@field public CreateType ICSharpCode.NRefactory.Ast.TypeReference
---@field public Arguments System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.Expression]
---@field public ArrayInitializer ICSharpCode.NRefactory.Ast.CollectionInitializerExpression
---@field public IsImplicitlyTyped System.Boolean
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.ArrayCreateExpression=m
return m;