---@class ICSharpCodeNRefactoryVisitorsVBNetConstructsConvertVisitorReturnStatementForFunctionAssignment : ICSharpCodeNRefactoryVisitorsAbstractAstTransformer
local m = {};
---@param identifierExpression ICSharpCodeNRefactoryAstIdentifierExpression
---@param data SystemObject
---@return SystemObject
function m:VisitIdentifierExpression(identifierExpression, data) end
ICSharpCodeNRefactoryVisitorsVBNetConstructsConvertVisitorReturnStatementForFunctionAssignment=m
return m;