---@class bagV2.ResZhuanPanResult
---instance properties
---@field public index System.Int32
---@field public intemId System.Int32
---@field public count System.Int32
local m = {};

bagV2.ResZhuanPanResult=m
return m;