---@class auctionV2.TransactionRecord
---instance properties
---@field public id System.Int64
---@field public idSpecified System.Boolean
---@field public type System.Int32
---@field public typeSpecified System.Boolean
---@field public goods bagV2.BagItemInfo
---@field public tradeType System.Int32
---@field public tradeTypeSpecified System.Boolean
---@field public tradeTime System.Int64
---@field public tradeTimeSpecified System.Boolean
---@field public moneyId System.Int32
---@field public moneyIdSpecified System.Boolean
---@field public moneyCount System.Int32
---@field public moneyCountSpecified System.Boolean
---@field public substractMoney System.Int32
---@field public substractMoneySpecified System.Boolean
---@field public state System.Int32
---@field public stateSpecified System.Boolean
local m = {};

auctionV2.TransactionRecord=m
return m;