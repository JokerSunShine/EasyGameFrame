---@class BaseCalendarVO
---instance properties
---@field public id System.Int32
---@field public tableData TABLE.CFG_DAILY_ACTIVITY_TIME
---@field public timeStampUtc System.Int64
---@field public CrossServerStep System.Int32
local m = {};

---@return System.String
function m:GetDateString() end
---@return System.String
function m:GetTimeString() end
---@return System.Int64
function m:GetStartTimeStamp() end
---@return System.Int64
function m:GetEndTimeStamp() end
---@return System.Int32
function m:GetYear() end
---@return System.Int32
function m:GetMonth() end
---@return System.Int32
function m:GetDay() end
---@return System.Int32
function m:GetStartHour() end
---@return System.Int32
function m:GetStartMinute() end
---@return System.Int32
function m:GetOverHour() end
---@return System.Int32
function m:GetOverMinute() end
---@param isChoose System.Boolean @default_value:False
---@return System.String
function m:GetIconSpriteName(isChoose) end
---@return System.String
function m:GetMainIconSpriteName() end
---@return System.Int32
function m:GetActivityState() end
---@param b ICalendarVO
---@return System.Int32
function m:Compare(b) end
BaseCalendarVO=m
return m;