---@class CSObjectWrapEditorGeneratorConfig
---fields
---@field public common_path SystemString
local m = {};
CSObjectWrapEditorGeneratorConfig=m
return m;