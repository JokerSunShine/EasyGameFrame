---@class activityV2.ReqGetActivityReward
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public type System.Int32
---@field public typeSpecified System.Boolean
---@field public goal System.Int32
---@field public goalSpecified System.Boolean
---@field public multi System.Int32
---@field public multiSpecified System.Boolean
---@field public data64 System.Int64
---@field public data64Specified System.Boolean
local m = {};

activityV2.ReqGetActivityReward=m
return m;