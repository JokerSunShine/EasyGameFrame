---@class Microsoft.Win32.SafeHandles.CriticalHandleMinusOneIsInvalid : System.Runtime.InteropServices.CriticalHandle
---instance properties
---@field public IsInvalid System.Boolean
local m = {};
Microsoft.Win32.SafeHandles.CriticalHandleMinusOneIsInvalid=m
return m;