---@class bagV2.ReqIntensify
---instance properties
---@field public equipId System.Int64
---@field public itemId System.Int32
---@field public itemIdSpecified System.Boolean
local m = {};

bagV2.ReqIntensify=m
return m;