---@class ExCSS.Property
---instance properties
---@field public Name System.String
---@field public Term ExCSS.Term
---@field public Important System.Boolean
---@field public Line System.Int32
local m = {};
---@return System.String
function m:ToString() end
---@param friendlyFormat System.Boolean
---@param indentation System.Int32 @default_value:0
---@return System.String
function m:ToString(friendlyFormat, indentation) end
ExCSS.Property=m
return m;