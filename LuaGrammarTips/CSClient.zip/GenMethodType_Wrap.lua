---@class GenMethodType
---@field Static @0
---@field Instance @1
---@field Extension @2
GenMethodType=m
return m;