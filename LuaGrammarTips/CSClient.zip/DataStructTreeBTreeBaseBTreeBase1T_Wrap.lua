---@class DataStructTreeBTreeBaseBTreeBase1T
---instance properties
---@field public Root DataStructTreeBTreeBaseBTreeNodeBase1T
---@field public order SystemInt32
local m = {};
---@param order SystemInt32
---@param compareFunc SystemFunc3TTSystemInt32
---@return SystemBoolean
function m:BTreeCheck(order, compareFunc) end
---@param data T
---@return DataStructTreeBTreeBaseBTreeNodeBase1T
function m:FindValue(data) end
---@param data T
---@return SystemBoolean
function m:HaveValue(data) end
---@param traversaList CommonOneWayChainListOneWayChainList1T
---@param action SystemAction1T @default_value:
function m:Traversal(traversaList, action) end
---@param data T
function m:Insert(data) end
---@param data T
function m:Delete(data) end
DataStructTreeBTreeBaseBTreeBase1T=m
return m;