---@class activityV2.DayInfoOfHappySevenDay
---instance properties
---@field public day System.Int32
---@field public daySpecified System.Boolean
---@field public groupInfo System.Collections.Generic.List1activityV2.GroupInfoOfDay
local m = {};

activityV2.DayInfoOfHappySevenDay=m
return m;