---@class auctionV2.CurLoginNoPush
---instance properties
---@field public type System.Int32
---@field public typeSpecified System.Boolean
local m = {};

auctionV2.CurLoginNoPush=m
return m;