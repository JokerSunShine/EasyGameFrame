---@class ExCSS.Model.TextBlocks.CommentBlock : ExCSS.Model.TextBlocks.Block
local m = {};
---@return System.String
function m:ToString() end
ExCSS.Model.TextBlocks.CommentBlock=m
return m;