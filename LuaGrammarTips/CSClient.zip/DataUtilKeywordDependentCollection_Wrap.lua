---@class DataUtilKeywordDependentCollection
local m = {};
DataUtilKeywordDependentCollection=m
return m;