---@class ExCSSWhitespace : ExCSSTerm
local m = {};
---@return SystemString
function m:ToString() end
ExCSSWhitespace=m
return m;