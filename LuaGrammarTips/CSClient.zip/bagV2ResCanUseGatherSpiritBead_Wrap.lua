---@class bagV2.ResCanUseGatherSpiritBead
---instance properties
---@field public itemId System.Int32
---@field public itemIdSpecified System.Boolean
---@field public count System.Int32
---@field public countSpecified System.Boolean
---@field public canUse System.Boolean
---@field public canUseSpecified System.Boolean
local m = {};

bagV2.ResCanUseGatherSpiritBead=m
return m;