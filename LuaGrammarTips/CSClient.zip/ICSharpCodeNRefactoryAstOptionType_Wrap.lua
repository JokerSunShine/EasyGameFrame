---@class ICSharpCodeNRefactoryAstOptionType
---@field None @0
---@field Explicit @1
---@field Strict @2
---@field CompareBinary @3
---@field CompareText @4
---@field Infer @5
ICSharpCodeNRefactoryAstOptionType=m
return m;