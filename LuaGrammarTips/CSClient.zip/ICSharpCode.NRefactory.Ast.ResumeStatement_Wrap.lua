---@class ICSharpCode.NRefactory.Ast.ResumeStatement : ICSharpCode.NRefactory.Ast.Statement
---instance properties
---@field public LabelName System.String
---@field public IsResumeNext System.Boolean
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.ResumeStatement=m
return m;