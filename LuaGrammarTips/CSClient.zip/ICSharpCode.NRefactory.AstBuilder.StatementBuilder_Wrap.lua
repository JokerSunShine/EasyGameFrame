---@class ICSharpCode.NRefactory.AstBuilder.StatementBuilder
local m = {};
---@param block ICSharpCode.NRefactory.Ast.BlockStatement
---@param statement ICSharpCode.NRefactory.Ast.Statement
function m.AddStatement(block, statement) end
---@param block ICSharpCode.NRefactory.Ast.BlockStatement
---@param expressionStatement ICSharpCode.NRefactory.Ast.Expression
function m.AddStatement(block, expressionStatement) end
---@param block ICSharpCode.NRefactory.Ast.BlockStatement
---@param expression ICSharpCode.NRefactory.Ast.Expression
function m.Throw(block, expression) end
---@param block ICSharpCode.NRefactory.Ast.BlockStatement
---@param expression ICSharpCode.NRefactory.Ast.Expression
function m.Return(block, expression) end
---@param block ICSharpCode.NRefactory.Ast.BlockStatement
---@param left ICSharpCode.NRefactory.Ast.Expression
---@param right ICSharpCode.NRefactory.Ast.Expression
function m.Assign(block, left, right) end
ICSharpCode.NRefactory.AstBuilder.StatementBuilder=m
return m;