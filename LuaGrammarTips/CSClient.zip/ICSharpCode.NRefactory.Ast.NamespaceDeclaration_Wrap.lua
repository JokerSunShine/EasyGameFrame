---@class ICSharpCode.NRefactory.Ast.NamespaceDeclaration : ICSharpCode.NRefactory.Ast.AbstractNode
---instance properties
---@field public Name System.String
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.NamespaceDeclaration=m
return m;