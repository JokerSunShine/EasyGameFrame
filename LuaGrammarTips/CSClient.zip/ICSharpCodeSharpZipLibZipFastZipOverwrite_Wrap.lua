---@class ICSharpCodeSharpZipLibZipFastZipOverwrite
---@field Prompt @0
---@field Never @1
---@field Always @2
ICSharpCodeSharpZipLibZipFastZipOverwrite=m
return m;