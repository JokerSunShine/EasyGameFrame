---@class awakeV2.ReqEquipAwake
---instance properties
---@field public index System.Int32
---@field public indexSpecified System.Boolean
---@field public uniqueId System.Int64
---@field public uniqueIdSpecified System.Boolean
local m = {};

awakeV2.ReqEquipAwake=m
return m;