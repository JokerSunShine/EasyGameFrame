---@class activityV2.ServerActivityInfo
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public rewardState System.Int32
---@field public rewardStateSpecified System.Boolean
---@field public count System.Int32
---@field public countSpecified System.Boolean
---@field public time System.Int32
---@field public timeSpecified System.Boolean
---@field public serverGoalInfos System.Collections.Generic.List1activityV2.ServerGoalInfo
---@field public roleCanRewardGoalId System.Collections.Generic.List1System.Int32
local m = {};

activityV2.ServerActivityInfo=m
return m;