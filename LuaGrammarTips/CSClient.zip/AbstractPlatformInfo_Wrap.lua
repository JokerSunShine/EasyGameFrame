---@class AbstractPlatformInfo
local m = {};
AbstractPlatformInfo=m
return m;