---@class auctionV2.auctionRequest
---instance properties
---@field public lid System.Int64
---@field public lidSpecified System.Boolean
---@field public AuctionType System.Int32
---@field public AuctionTypeSpecified System.Boolean
local m = {};

auctionV2.auctionRequest=m
return m;