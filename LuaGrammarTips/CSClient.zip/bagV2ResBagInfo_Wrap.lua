---@class bagV2.ResBagInfo
---instance properties
---@field public emptyGridCount System.Int32
---@field public emptyGridCountSpecified System.Boolean
---@field public maxGridCount System.Int32
---@field public maxGridCountSpecified System.Boolean
---@field public addGridCount System.Int32
---@field public addGridCountSpecified System.Boolean
---@field public itemList System.Collections.Generic.List1bagV2.BagItemInfo
---@field public coinList System.Collections.Generic.List1bagV2.CoinInfo
---@field public recycleData System.Collections.Generic.List1System.Int32
---@field public extraEquip System.Collections.Generic.List1bagV2.ExtraEquip
local m = {};

bagV2.ResBagInfo=m
return m;