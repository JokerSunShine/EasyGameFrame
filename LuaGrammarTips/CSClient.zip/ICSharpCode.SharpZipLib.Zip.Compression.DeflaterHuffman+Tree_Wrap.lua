---@class ICSharpCode.SharpZipLib.Zip.Compression.DeflaterHuffman+Tree
---instance fields
---@field public freqs System.Int16[]
---@field public length System.Byte[]
---@field public minNumCodes System.Int32
---@field public numCodes System.Int32
local m = {};
function m:Reset() end
---@param code System.Int32
function m:WriteSymbol(code) end
function m:CheckEmpty() end
---@param stCodes System.Int16[]
---@param stLength System.Byte[]
function m:SetStaticCodes(stCodes, stLength) end
function m:BuildCodes() end
function m:BuildTree() end
---@return System.Int32
function m:GetEncodedLength() end
---@param blTree ICSharpCode.SharpZipLib.Zip.Compression.DeflaterHuffman+Tree
function m:CalcBLFreq(blTree) end
---@param blTree ICSharpCode.SharpZipLib.Zip.Compression.DeflaterHuffman+Tree
function m:WriteTree(blTree) end
ICSharpCode.SharpZipLib.Zip.Compression.DeflaterHuffman+Tree=m
return m;