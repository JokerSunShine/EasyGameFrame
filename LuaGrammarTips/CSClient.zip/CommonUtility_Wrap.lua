---@class CommonUtility
local m = {};
---@param o UnityEngineObject
---@return SystemBoolean
function m.IsNull(o) end
---@param txt SystemString
---@return SystemBoolean
function m.IsNullOrEmpty(txt) end
---@param list SystemCollectionsGenericList1SystemString
---@param str SystemString
function m.RemoveAll(list, str) end
---@param list SystemCollectionsGenericList1SystemString
---@param str SystemString
function m.Add_NoSame(list, str) end
---@param dir SystemString
---@param time SystemInt32
---@return SystemString
function m.RemoveBackDir(dir, time) end
---@return SystemCollectionsGenericList1SystemType
function m.GetAllTypes() end
---@param type SystemType
---@param str SystemString
---@return SystemBoolean
function m.IsNameCurSpace(type, str) end
---@param type SystemType
---@return SystemString
function m.GetTypeFileName(type) end
---@param typeName SystemString
---@return SystemString
function m.GetTypeFileName(typeName) end
---@param type SystemType
---@return SystemString
function m.GetTypeTagName(type) end
---@param typeName SystemString
---@return SystemString
function m.GetTypeTagName(typeName) end
---@param type SystemType
---@param curType SystemType
---@return SystemBoolean
function m.IsDefined(type, curType) end
---@param memberInfo SystemReflectionMemberInfo
---@param curType SystemType
---@return SystemBoolean
function m.IsDefined(memberInfo, curType) end
CommonUtility=m
return m;