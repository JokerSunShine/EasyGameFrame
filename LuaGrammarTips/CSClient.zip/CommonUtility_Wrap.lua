---@class CommonUtility
local m = {};
---@param o UnityEngine.Object
---@return System.Boolean
function m.IsNull(o) end
---@param txt System.String
---@return System.Boolean
function m.IsNullOrEmpty(txt) end
---@param list System.Collections.Generic.List`1[System.String]
---@param str System.String
function m.RemoveAll(list, str) end
---@param list System.Collections.Generic.List`1[System.String]
---@param str System.String
function m.Add_NoSame(list, str) end
---@param dir System.String
---@param time System.Int32
---@return System.String
function m.RemoveBackDir(dir, time) end
---@return System.Collections.Generic.List`1[System.Type]
function m.GetAllTypes() end
---@param type System.Type
---@param str System.String
---@return System.Boolean
function m.IsNameCurSpace(type, str) end
---@param type System.Type
---@return System.String
function m.GetTypeFileName(type) end
---@param typeName System.String
---@return System.String
function m.GetTypeFileName(typeName) end
---@param type System.Type
---@return System.String
function m.GetTypeTagName(type) end
---@param typeName System.String
---@return System.String
function m.GetTypeTagName(typeName) end
---@param type System.Type
---@param curType System.Type
---@return System.Boolean
function m.IsDefined(type, curType) end
---@param memberInfo System.Reflection.MemberInfo
---@param curType System.Type
---@return System.Boolean
function m.IsDefined(memberInfo, curType) end
CommonUtility=m
return m;