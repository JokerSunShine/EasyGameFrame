---@class ICSharpCodeNRefactoryParserCSharpParser : ICSharpCodeNRefactoryParserAbstractParser
local m = {};
---@param s SystemString
function m:Error(s) end
function m:Parse() end
---@return ICSharpCodeNRefactoryAstTypeReference
function m:ParseTypeReference() end
---@return ICSharpCodeNRefactoryAstExpression
function m:ParseExpression() end
---@return ICSharpCodeNRefactoryAstBlockStatement
function m:ParseBlock() end
---@return SystemCollectionsGenericList1ICSharpCodeNRefactoryAstINode
function m:ParseTypeMembers() end
ICSharpCodeNRefactoryParserCSharpParser=m
return m;