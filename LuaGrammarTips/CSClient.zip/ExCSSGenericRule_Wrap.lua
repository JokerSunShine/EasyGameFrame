---@class ExCSSGenericRule : ExCSSAggregateRule
---instance properties
---@field public Declarations ExCSSStyleDeclaration
local m = {};
---@return SystemString
function m:ToString() end
---@param friendlyFormat SystemBoolean
---@param indentation SystemInt32 @default_value:0
---@return SystemString
function m:ToString(friendlyFormat, indentation) end
ExCSSGenericRule=m
return m;