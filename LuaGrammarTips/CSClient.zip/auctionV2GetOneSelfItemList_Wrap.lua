---@class auctionV2.GetOneSelfItemList
---instance properties
---@field public itemType System.Int32
---@field public itemTypeSpecified System.Boolean
local m = {};

auctionV2.GetOneSelfItemList=m
return m;