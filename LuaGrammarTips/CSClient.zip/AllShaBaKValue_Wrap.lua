---@class AllShaBaKValue
---instance fields
---@field public allKillCount System.Int32
---@field public allDamage System.Int64
---@field public allHurt System.Int64
---@field public allCure System.Int64
local m = {};

AllShaBaKValue=m
return m;