---@class activityV2.ResHappySevenDayActivityDataChange
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public day System.Int32
---@field public daySpecified System.Boolean
---@field public group System.Int32
---@field public groupSpecified System.Boolean
---@field public index System.Int32
---@field public indexSpecified System.Boolean
---@field public completeCount System.Int32
---@field public completeCountSpecified System.Boolean
---@field public total System.Int32
---@field public totalSpecified System.Boolean
---@field public rewardState System.Int32
---@field public rewardStateSpecified System.Boolean
local m = {};

activityV2.ResHappySevenDayActivityDataChange=m
return m;