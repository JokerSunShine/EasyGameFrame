---@class ExCSSStyleRule : ExCSSRuleSet
---instance properties
---@field public Selector ExCSSBaseSelector
---@field public Value SystemString
---@field public Declarations ExCSSStyleDeclaration
---@field public Line SystemInt32
local m = {};
---@return SystemString
function m:ToString() end
---@param friendlyFormat SystemBoolean
---@param indentation SystemInt32 @default_value:0
---@return SystemString
function m:ToString(friendlyFormat, indentation) end
ExCSSStyleRule=m
return m;