---@class bagV2.ResEvolve
---instance properties
---@field public equipId System.Int64
---@field public equipInfo bagV2.BagItemInfo
local m = {};

bagV2.ResEvolve=m
return m;