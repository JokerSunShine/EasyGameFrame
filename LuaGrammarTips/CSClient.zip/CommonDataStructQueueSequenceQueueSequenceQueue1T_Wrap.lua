---@class CommonDataStructQueueSequenceQueueSequenceQueue1T
---instance properties
---@field public Count SystemInt32
local m = {};
---@param item T
function m:Enqueue(item) end
---@return T
function m:Dequeue() end
CommonDataStructQueueSequenceQueueSequenceQueue1T=m
return m;