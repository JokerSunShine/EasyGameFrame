---@class bagV2.ReqUpgradeSoulJade
---instance properties
---@field public soulJadeId System.Int32
---@field public thisId System.Int32
---@field public type System.Int32
local m = {};

bagV2.ReqUpgradeSoulJade=m
return m;