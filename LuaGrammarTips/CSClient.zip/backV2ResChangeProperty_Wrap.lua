---@class backV2.ResChangeProperty
---instance properties
---@field public propertyKey System.String
---@field public propertyKeySpecified System.Boolean
---@field public propertyValue System.String
---@field public propertyValueSpecified System.Boolean
local m = {};

backV2.ResChangeProperty=m
return m;