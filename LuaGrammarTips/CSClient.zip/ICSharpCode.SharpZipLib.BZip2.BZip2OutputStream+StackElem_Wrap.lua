---@class ICSharpCode.SharpZipLib.BZip2.BZip2OutputStream+StackElem
---instance fields
---@field public ll System.Int32
---@field public hh System.Int32
---@field public dd System.Int32
local m = {};
ICSharpCode.SharpZipLib.BZip2.BZip2OutputStream+StackElem=m
return m;