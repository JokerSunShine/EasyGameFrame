---@class ICSharpCode.NRefactory.Ast.ContinueType
---@field None @0
---@field Do @1
---@field For @2
---@field While @3
ICSharpCode.NRefactory.Ast.ContinueType=m
return m;