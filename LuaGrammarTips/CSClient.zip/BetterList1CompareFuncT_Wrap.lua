---@class BetterList1CompareFuncT : System.MulticastDelegate
local m = {};

---@param left T
---@param right T
---@return System.Int32
function m:Invoke(left, right) end
---@param left T
---@param right T
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(left, right, callback, object) end
---@param result System.IAsyncResult
---@return System.Int32
function m:EndInvoke(result) end
BetterList1CompareFuncT=m
return m;