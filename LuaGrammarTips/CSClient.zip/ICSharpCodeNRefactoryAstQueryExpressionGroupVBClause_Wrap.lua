---@class ICSharpCodeNRefactoryAstQueryExpressionGroupVBClause : ICSharpCodeNRefactoryAstQueryExpressionClause
---instance properties
---@field public GroupVariables SystemCollectionsGenericList1ICSharpCodeNRefactoryAstExpressionRangeVariable
---@field public ByVariables SystemCollectionsGenericList1ICSharpCodeNRefactoryAstExpressionRangeVariable
---@field public IntoVariables SystemCollectionsGenericList1ICSharpCodeNRefactoryAstExpressionRangeVariable
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstQueryExpressionGroupVBClause=m
return m;