---@class ICSharpCodeNRefactoryISpecial
---instance properties
---@field public StartPosition ICSharpCodeNRefactoryLocation
---@field public EndPosition ICSharpCodeNRefactoryLocation
local m = {};
---@param visitor ICSharpCodeNRefactoryISpecialVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
ICSharpCodeNRefactoryISpecial=m
return m;