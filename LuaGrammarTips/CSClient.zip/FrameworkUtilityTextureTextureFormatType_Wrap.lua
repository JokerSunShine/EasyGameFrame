---@class FrameworkUtilityTextureTextureFormatType
---@field EXR @0
---@field JPG @1
---@field PNG @2
---@field TGA @3
FrameworkUtilityTextureTextureFormatType=m
return m;