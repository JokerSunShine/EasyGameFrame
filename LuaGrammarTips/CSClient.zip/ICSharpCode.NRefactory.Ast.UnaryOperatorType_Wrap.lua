---@class ICSharpCode.NRefactory.Ast.UnaryOperatorType
---@field None @0
---@field Not @1
---@field BitNot @2
---@field Minus @3
---@field Plus @4
---@field Increment @5
---@field Decrement @6
---@field PostIncrement @7
---@field PostDecrement @8
---@field Dereference @9
---@field AddressOf @10
ICSharpCode.NRefactory.Ast.UnaryOperatorType=m
return m;