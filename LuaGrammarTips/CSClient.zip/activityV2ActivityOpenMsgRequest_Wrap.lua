---@class activityV2.ActivityOpenMsgRequest
---instance properties
---@field public type System.Int32
---@field public typeSpecified System.Boolean
local m = {};

activityV2.ActivityOpenMsgRequest=m
return m;