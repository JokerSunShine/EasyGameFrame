---@class ExCSS.ImportRule : ExCSS.RuleSet
---instance properties
---@field public Href System.String
---@field public Media ExCSS.MediaTypeList
local m = {};
---@return System.String
function m:ToString() end
---@param friendlyFormat System.Boolean
---@param indentation System.Int32 @default_value:0
---@return System.String
function m:ToString(friendlyFormat, indentation) end
ExCSS.ImportRule=m
return m;