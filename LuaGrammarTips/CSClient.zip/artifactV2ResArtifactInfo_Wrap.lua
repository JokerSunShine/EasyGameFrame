---@class artifactV2.ResArtifactInfo
---instance properties
---@field public artifactBeanList System.Collections.Generic.List1artifactV2.ArtifactInfo
---@field public power System.Int32
---@field public powerSpecified System.Boolean
local m = {};

artifactV2.ResArtifactInfo=m
return m;