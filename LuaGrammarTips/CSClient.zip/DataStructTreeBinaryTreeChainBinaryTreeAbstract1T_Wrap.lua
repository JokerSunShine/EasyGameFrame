---@class DataStructTreeBinaryTreeChainBinaryTreeAbstract1T
---instance properties
---@field public Head DataStructTreeBinaryTreeNode1T
---@field public LeftLeaf DataStructTreeBinaryTreeNode1T
---@field public Count SystemInt32
---@field public CompareFunc SystemFunc3TTSystemInt32
local m = {};
DataStructTreeBinaryTreeChainBinaryTreeAbstract1T=m
return m;