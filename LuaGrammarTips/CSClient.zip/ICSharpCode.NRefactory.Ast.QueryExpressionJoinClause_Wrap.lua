---@class ICSharpCode.NRefactory.Ast.QueryExpressionJoinClause : ICSharpCode.NRefactory.Ast.QueryExpressionFromOrJoinClause
---instance properties
---@field public OnExpression ICSharpCode.NRefactory.Ast.Expression
---@field public EqualsExpression ICSharpCode.NRefactory.Ast.Expression
---@field public IntoIdentifier System.String
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.QueryExpressionJoinClause=m
return m;