---@class DesktopStandalonePostProcessor : UnityEditorModulesDefaultBuildPostprocessor
local m = {};
---@param options UnityEditorBuildOptions
---@param target UnityEditorBuildTarget
---@return SystemString
function m:PrepareForBuild(options, target) end
---@param args UnityEditorModulesBuildPostProcessArgs
function m:PostProcess(args) end
---@return SystemBoolean
function m:SupportsLz4Compression() end
---@param target UnityEditorBuildTarget
---@param config UnityEngineBootConfigData
---@param options UnityEditorBuildOptions
function m:UpdateBootConfig(target, config, options) end
DesktopStandalonePostProcessor=m
return m;