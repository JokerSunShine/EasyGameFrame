---@class DesktopStandalonePostProcessor : UnityEditor.Modules.DefaultBuildPostprocessor
local m = {};
---@param options UnityEditor.BuildOptions
---@param target UnityEditor.BuildTarget
---@return System.String
function m:PrepareForBuild(options, target) end
---@param args UnityEditor.Modules.BuildPostProcessArgs
function m:PostProcess(args) end
---@return System.Boolean
function m:SupportsLz4Compression() end
---@param target UnityEditor.BuildTarget
---@param config UnityEngine.BootConfigData
---@param options UnityEditor.BuildOptions
function m:UpdateBootConfig(target, config, options) end
DesktopStandalonePostProcessor=m
return m;