---@class MicrosoftVisualBasicVBMemberAttributeConverter : MicrosoftVisualBasicVBModifierAttributeConverter
---properties
---@field public Default MicrosoftVisualBasicVBMemberAttributeConverter
local m = {};
MicrosoftVisualBasicVBMemberAttributeConverter=m
return m;