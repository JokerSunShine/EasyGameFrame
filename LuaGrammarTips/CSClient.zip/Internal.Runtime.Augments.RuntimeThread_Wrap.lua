---@class Internal.Runtime.Augments.RuntimeThread
local m = {};
function m.InitializeThreadPoolThread() end
Internal.Runtime.Augments.RuntimeThread=m
return m;