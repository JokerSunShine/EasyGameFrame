---@class DataUtilActiveFieldsAll : SystemValueType
---instance properties
---@field public instanceCount SystemInt32
---@field public instances SystemCollectionsGenericIEnumerable1DataUtilIActiveFields
local m = {};
---@param field SystemString
function m:AddAll(field) end
DataUtilActiveFieldsAll=m
return m;