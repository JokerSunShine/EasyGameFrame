---@class DataStructHashTableHashTableKeyAlgorithm
local m = {};
---@param key SystemObject
---@param length SystemInt32
---@param step SystemInt32 @default_value:0
---@return SystemInt32
function m.LinearProbing(key, length, step) end
---@param key SystemObject
---@param length SystemInt32
---@param step SystemInt32 @default_value:0
---@return SystemInt32
function m.QuadraticProbing(key, length, step) end
---@param key SystemObject
---@param length SystemInt32
---@param step SystemInt32 @default_value:0
---@return SystemInt32
function m.DoubleHash(key, length, step) end
DataStructHashTableHashTableKeyAlgorithm=m
return m;