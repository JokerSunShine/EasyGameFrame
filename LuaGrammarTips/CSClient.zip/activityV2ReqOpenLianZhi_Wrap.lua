---@class activityV2.ReqOpenLianZhi
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
local m = {};

activityV2.ReqOpenLianZhi=m
return m;