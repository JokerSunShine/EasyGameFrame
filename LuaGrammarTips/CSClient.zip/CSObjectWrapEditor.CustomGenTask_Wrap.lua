---@class CSObjectWrapEditor.CustomGenTask : System.ValueType
---instance fields
---@field public Data XLua.LuaTable
---@field public Output System.IO.TextWriter
local m = {};
CSObjectWrapEditor.CustomGenTask=m
return m;