---@class bagV2.DrawPreyTreasureBagResponse
local m = {};

bagV2.DrawPreyTreasureBagResponse=m
return m;