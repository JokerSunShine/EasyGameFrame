---@class ICSharpCodeSharpZipLibBZip2BZip2
local m = {};
---@param instream SystemIOStream
---@param outstream SystemIOStream
function m.Decompress(instream, outstream) end
---@param instream SystemIOStream
---@param outstream SystemIOStream
---@param blockSize SystemInt32
function m.Compress(instream, outstream, blockSize) end
ICSharpCodeSharpZipLibBZip2BZip2=m
return m;