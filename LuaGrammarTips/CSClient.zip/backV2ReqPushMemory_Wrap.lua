---@class backV2.ReqPushMemory
---instance properties
---@field public tableType System.Int32
---@field public tableTypeSpecified System.Boolean
---@field public mid System.Int64
---@field public midSpecified System.Boolean
---@field public byteArray System.Byte
---@field public byteArraySpecified System.Boolean
local m = {};

backV2.ReqPushMemory=m
return m;