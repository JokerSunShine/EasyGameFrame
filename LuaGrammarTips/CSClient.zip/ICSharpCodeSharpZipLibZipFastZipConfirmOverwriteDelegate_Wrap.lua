---@class ICSharpCodeSharpZipLibZipFastZipConfirmOverwriteDelegate : SystemMulticastDelegate
local m = {};
---@param fileName SystemString
---@return SystemBoolean
function m:Invoke(fileName) end
---@param fileName SystemString
---@param callback SystemAsyncCallback
---@param object SystemObject
---@return SystemIAsyncResult
function m:BeginInvoke(fileName, callback, object) end
---@param result SystemIAsyncResult
---@return SystemBoolean
function m:EndInvoke(result) end
ICSharpCodeSharpZipLibZipFastZipConfirmOverwriteDelegate=m
return m;