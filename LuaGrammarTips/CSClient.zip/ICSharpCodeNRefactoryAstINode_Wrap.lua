---@class ICSharpCodeNRefactoryAstINode
---instance properties
---@field public Parent ICSharpCodeNRefactoryAstINode
---@field public Children SystemCollectionsGenericList1ICSharpCodeNRefactoryAstINode
---@field public StartLocation ICSharpCodeNRefactoryLocation
---@field public EndLocation ICSharpCodeNRefactoryLocation
---@field public UserData SystemObject
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptChildren(visitor, data) end
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
ICSharpCodeNRefactoryAstINode=m
return m;