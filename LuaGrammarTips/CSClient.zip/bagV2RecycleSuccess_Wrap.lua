---@class bagV2.RecycleSuccess
---instance properties
---@field public idList System.Collections.Generic.List1System.Int64
local m = {};

bagV2.RecycleSuccess=m
return m;