---@class backV2.ResGetRole
---instance properties
---@field public byteArray System.Byte
---@field public byteArraySpecified System.Boolean
local m = {};

backV2.ResGetRole=m
return m;