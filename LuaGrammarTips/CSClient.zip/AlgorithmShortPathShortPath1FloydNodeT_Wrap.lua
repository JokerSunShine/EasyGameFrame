---@class AlgorithmShortPathShortPath1FloydNodeT
---instance fields
---@field public pathNodes CommonDataStructQueueChainQueueChainQueue1SystemInt32
---@field public weight SystemInt32
local m = {};
AlgorithmShortPathShortPath1FloydNodeT=m
return m;