---@class ICSharpCodeNRefactoryVisitorsConvertVisitorBase : ICSharpCodeNRefactoryVisitorsAbstractAstTransformer
local m = {};
---@param typeDeclaration ICSharpCodeNRefactoryAstTypeDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitTypeDeclaration(typeDeclaration, data) end
ICSharpCodeNRefactoryVisitorsConvertVisitorBase=m
return m;