---@class battleV2.BufferAdd
---instance properties
---@field public bufferId System.Int32
---@field public bufferIdSpecified System.Boolean
---@field public ownerId System.Int64
---@field public ownerIdSpecified System.Boolean
---@field public effect System.Int32
---@field public effectSpecified System.Boolean
local m = {};

battleV2.BufferAdd=m
return m;