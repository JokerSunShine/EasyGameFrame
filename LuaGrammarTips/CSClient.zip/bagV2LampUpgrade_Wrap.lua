---@class bagV2.LampUpgrade
---instance properties
---@field public currentId System.Int32
---@field public lampId System.Int32
---@field public type System.Int32
local m = {};

bagV2.LampUpgrade=m
return m;