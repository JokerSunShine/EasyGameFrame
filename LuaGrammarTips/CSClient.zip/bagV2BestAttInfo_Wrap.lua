---@class bagV2.BestAttInfo
---instance properties
---@field public attId System.Int32
---@field public attType System.Int32
---@field public attValue System.Int32
---@field public attValueSpecified System.Boolean
---@field public param System.Int32
---@field public paramSpecified System.Boolean
---@field public power System.Int32
---@field public powerSpecified System.Boolean
local m = {};

bagV2.BestAttInfo=m
return m;