---@class ICSharpCodeNRefactoryParserModifierList
---instance properties
---@field public Modifier ICSharpCodeNRefactoryAstModifiers
---@field public isNone SystemBoolean
local m = {};
---@param keywordLocation ICSharpCodeNRefactoryLocation
---@return ICSharpCodeNRefactoryLocation
function m:GetDeclarationLocation(keywordLocation) end
---@param m ICSharpCodeNRefactoryAstModifiers
---@return SystemBoolean
function m:Contains(m) end
---@param m ICSharpCodeNRefactoryAstModifiers
---@param tokenLocation ICSharpCodeNRefactoryLocation
function m:Add(m, tokenLocation) end
---@param allowed ICSharpCodeNRefactoryAstModifiers
function m:Check(allowed) end
ICSharpCodeNRefactoryParserModifierList=m
return m;