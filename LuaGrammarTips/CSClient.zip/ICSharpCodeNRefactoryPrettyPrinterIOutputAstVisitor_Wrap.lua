---@class ICSharpCodeNRefactoryPrettyPrinterIOutputAstVisitor
---instance properties
---@field public Text SystemString
---@field public Errors ICSharpCodeNRefactoryParserErrors
---@field public Options ICSharpCodeNRefactoryPrettyPrinterAbstractPrettyPrintOptions
---@field public OutputFormatter ICSharpCodeNRefactoryPrettyPrinterIOutputFormatter
local m = {};
---@param value SystemAction1ICSharpCodeNRefactoryAstINode
function m:add_BeforeNodeVisit(value) end
---@param value SystemAction1ICSharpCodeNRefactoryAstINode
function m:remove_BeforeNodeVisit(value) end
---@param value SystemAction1ICSharpCodeNRefactoryAstINode
function m:add_AfterNodeVisit(value) end
---@param value SystemAction1ICSharpCodeNRefactoryAstINode
function m:remove_AfterNodeVisit(value) end
ICSharpCodeNRefactoryPrettyPrinterIOutputAstVisitor=m
return m;