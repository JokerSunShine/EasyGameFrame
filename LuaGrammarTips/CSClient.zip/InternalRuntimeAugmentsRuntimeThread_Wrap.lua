---@class InternalRuntimeAugmentsRuntimeThread
local m = {};
function m.InitializeThreadPoolThread() end
InternalRuntimeAugmentsRuntimeThread=m
return m;