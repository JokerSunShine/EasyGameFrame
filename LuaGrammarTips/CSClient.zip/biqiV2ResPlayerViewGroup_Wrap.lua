---@class biqiV2.ResPlayerViewGroup
---instance properties
---@field public groupOne System.Collections.Generic.List1System.Int64
---@field public groupTwo System.Collections.Generic.List1System.Int64
local m = {};

biqiV2.ResPlayerViewGroup=m
return m;