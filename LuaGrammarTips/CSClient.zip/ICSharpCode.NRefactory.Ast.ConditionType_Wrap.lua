---@class ICSharpCode.NRefactory.Ast.ConditionType
---@field None @0
---@field Until @1
---@field While @2
---@field DoWhile @3
ICSharpCode.NRefactory.Ast.ConditionType=m
return m;