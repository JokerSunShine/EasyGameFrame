---@class ICSharpCode.NRefactory.Ast.FieldDeclaration : ICSharpCode.NRefactory.Ast.AttributedNode
---instance properties
---@field public TypeReference ICSharpCode.NRefactory.Ast.TypeReference
---@field public Fields System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.VariableDeclaration]
local m = {};
---@param variableName System.String
---@return ICSharpCode.NRefactory.Ast.VariableDeclaration
function m:GetVariableDeclaration(variableName) end
---@param fieldIndex System.Int32
---@return ICSharpCode.NRefactory.Ast.TypeReference
function m:GetTypeForField(fieldIndex) end
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.FieldDeclaration=m
return m;