---@class ICSharpCodeNRefactoryAbstractSpecial
---instance properties
---@field public StartPosition ICSharpCodeNRefactoryLocation
---@field public EndPosition ICSharpCodeNRefactoryLocation
local m = {};
---@param visitor ICSharpCodeNRefactoryISpecialVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAbstractSpecial=m
return m;