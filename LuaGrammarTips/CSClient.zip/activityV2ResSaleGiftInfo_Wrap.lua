---@class activityV2.ResSaleGiftInfo
---instance properties
---@field public info System.Collections.Generic.List1activityV2.BuyLimitInfo
local m = {};

activityV2.ResSaleGiftInfo=m
return m;