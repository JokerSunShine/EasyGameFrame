---@class BagItemViewVo
---instance properties
---@field public bagItemInfo bagV2.BagItemInfo
---@field public type System.Int32
---@field public itemTable TABLE.CFG_ITEMS
local m = {};

---@param bagItemInfo bagV2.BagItemInfo
function m:UpdateVo(bagItemInfo) end
BagItemViewVo=m
return m;