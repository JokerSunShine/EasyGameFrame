---@class ICSharpCodeNRefactorySnippetType
---@field None @0
---@field CompilationUnit @1
---@field Expression @2
---@field Statements @3
---@field TypeMembers @4
ICSharpCodeNRefactorySnippetType=m
return m;