---@class ICSharpCode.NRefactory.Ast.InnerClassTypeReference : ICSharpCode.NRefactory.Ast.TypeReference
---instance properties
---@field public BaseType ICSharpCode.NRefactory.Ast.TypeReference
local m = {};
---@return ICSharpCode.NRefactory.Ast.TypeReference
function m:Clone() end
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return ICSharpCode.NRefactory.Ast.TypeReference
function m:CombineToNormalTypeReference() end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.InnerClassTypeReference=m
return m;