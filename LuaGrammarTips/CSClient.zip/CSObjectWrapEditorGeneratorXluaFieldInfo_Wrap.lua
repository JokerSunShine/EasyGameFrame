---@class CSObjectWrapEditorGeneratorXluaFieldInfo
---instance fields
---@field public Name SystemString
---@field public Type SystemType
---@field public IsField SystemBoolean
---@field public Size SystemInt32
local m = {};
CSObjectWrapEditorGeneratorXluaFieldInfo=m
return m;