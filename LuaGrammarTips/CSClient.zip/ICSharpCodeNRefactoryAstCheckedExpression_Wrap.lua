---@class ICSharpCodeNRefactoryAstCheckedExpression : ICSharpCodeNRefactoryAstExpression
---instance properties
---@field public Expression ICSharpCodeNRefactoryAstExpression
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstCheckedExpression=m
return m;