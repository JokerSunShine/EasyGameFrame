---@class ICSharpCode.SharpZipLib.Zip.GeneralBitFlags
---@field Encrypted @1
---@field Method @6
---@field Descriptor @8
---@field Reserved @16
---@field Patched @32
---@field StrongEncryption @64
---@field EnhancedCompress @4096
---@field HeaderMasked @8192
ICSharpCode.SharpZipLib.Zip.GeneralBitFlags=m
return m;