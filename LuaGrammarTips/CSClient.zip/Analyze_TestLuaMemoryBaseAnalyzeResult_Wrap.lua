---@class Analyze_TestLuaMemoryBaseAnalyzeResult
---instance fields
---@field public tables System.Collections.Generic.Dictionary2System.Int32Analyze_TestLuaMemoryBaseTableInfo
local m = {};

---@param tableTypeStr System.String
---@return Analyze_TestLuaMemoryBaseTableType
function m:GetTableType(tableTypeStr) end
---@return System.String
function m:ToString() end
Analyze_TestLuaMemoryBaseAnalyzeResult=m
return m;