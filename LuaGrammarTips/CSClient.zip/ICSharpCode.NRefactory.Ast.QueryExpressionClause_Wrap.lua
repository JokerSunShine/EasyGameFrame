---@class ICSharpCode.NRefactory.Ast.QueryExpressionClause : ICSharpCode.NRefactory.Ast.AbstractNode
---properties
---@field public Null ICSharpCode.NRefactory.Ast.QueryExpressionClause
---instance properties
---@field public IsNull System.Boolean
local m = {};
ICSharpCode.NRefactory.Ast.QueryExpressionClause=m
return m;