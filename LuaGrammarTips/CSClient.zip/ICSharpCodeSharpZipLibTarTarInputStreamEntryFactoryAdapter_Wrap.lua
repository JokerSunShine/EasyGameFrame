---@class ICSharpCodeSharpZipLibTarTarInputStreamEntryFactoryAdapter
local m = {};
---@param name SystemString
---@return ICSharpCodeSharpZipLibTarTarEntry
function m:CreateEntry(name) end
---@param fileName SystemString
---@return ICSharpCodeSharpZipLibTarTarEntry
function m:CreateEntryFromFile(fileName) end
---@param headerBuf SystemByte
---@return ICSharpCodeSharpZipLibTarTarEntry
function m:CreateEntry(headerBuf) end
ICSharpCodeSharpZipLibTarTarInputStreamEntryFactoryAdapter=m
return m;