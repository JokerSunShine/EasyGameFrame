---@class backV2.UnionMemberInfo
---instance properties
---@field public id System.Int64
---@field public idSpecified System.Boolean
---@field public memberName System.String
---@field public memberNameSpecified System.Boolean
---@field public position System.Int32
---@field public positionSpecified System.Boolean
---@field public memberLevel System.Int32
---@field public memberLevelSpecified System.Boolean
---@field public fightPower System.Int32
---@field public fightPowerSpecified System.Boolean
---@field public sex System.Int32
---@field public sexSpecified System.Boolean
---@field public vipLevel System.Int32
---@field public vipLevelSpecified System.Boolean
---@field public recharge System.Int32
---@field public rechargeSpecified System.Boolean
local m = {};

backV2.UnionMemberInfo=m
return m;