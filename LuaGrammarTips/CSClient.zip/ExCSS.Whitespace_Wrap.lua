---@class ExCSS.Whitespace : ExCSS.Term
local m = {};
---@return System.String
function m:ToString() end
ExCSS.Whitespace=m
return m;