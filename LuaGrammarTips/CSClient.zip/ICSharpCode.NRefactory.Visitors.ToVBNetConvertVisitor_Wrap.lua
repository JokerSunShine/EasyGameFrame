---@class ICSharpCode.NRefactory.Visitors.ToVBNetConvertVisitor : ICSharpCode.NRefactory.Visitors.ConvertVisitorBase
local m = {};
---@param compilationUnit ICSharpCode.NRefactory.Ast.CompilationUnit
---@param data System.Object
---@return System.Object
function m:VisitCompilationUnit(compilationUnit, data) end
---@param usingDeclaration ICSharpCode.NRefactory.Ast.UsingDeclaration
---@param data System.Object
---@return System.Object
function m:VisitUsingDeclaration(usingDeclaration, data) end
---@param typeDeclaration ICSharpCode.NRefactory.Ast.TypeDeclaration
---@param data System.Object
---@return System.Object
function m:VisitTypeDeclaration(typeDeclaration, data) end
---@param delegateDeclaration ICSharpCode.NRefactory.Ast.DelegateDeclaration
---@param data System.Object
---@return System.Object
function m:VisitDelegateDeclaration(delegateDeclaration, data) end
---@param expressionStatement ICSharpCode.NRefactory.Ast.ExpressionStatement
---@param data System.Object
---@return System.Object
function m:VisitExpressionStatement(expressionStatement, data) end
---@param anonymousMethodExpression ICSharpCode.NRefactory.Ast.AnonymousMethodExpression
---@param data System.Object
---@return System.Object
function m:VisitAnonymousMethodExpression(anonymousMethodExpression, data) end
---@param assignmentExpression ICSharpCode.NRefactory.Ast.AssignmentExpression
---@param data System.Object
---@return System.Object
function m:VisitAssignmentExpression(assignmentExpression, data) end
---@param methodDeclaration ICSharpCode.NRefactory.Ast.MethodDeclaration
---@param data System.Object
---@return System.Object
function m:VisitMethodDeclaration(methodDeclaration, data) end
---@param propertyDeclaration ICSharpCode.NRefactory.Ast.PropertyDeclaration
---@param data System.Object
---@return System.Object
function m:VisitPropertyDeclaration(propertyDeclaration, data) end
---@param eventDeclaration ICSharpCode.NRefactory.Ast.EventDeclaration
---@param data System.Object
---@return System.Object
function m:VisitEventDeclaration(eventDeclaration, data) end
---@param constructorDeclaration ICSharpCode.NRefactory.Ast.ConstructorDeclaration
---@param data System.Object
---@return System.Object
function m:VisitConstructorDeclaration(constructorDeclaration, data) end
---@param parenthesizedExpression ICSharpCode.NRefactory.Ast.ParenthesizedExpression
---@param data System.Object
---@return System.Object
function m:VisitParenthesizedExpression(parenthesizedExpression, data) end
---@param arrayCreateExpression ICSharpCode.NRefactory.Ast.ArrayCreateExpression
---@param data System.Object
---@return System.Object
function m:VisitArrayCreateExpression(arrayCreateExpression, data) end
---@param defaultValueExpression ICSharpCode.NRefactory.Ast.DefaultValueExpression
---@param data System.Object
---@return System.Object
function m:VisitDefaultValueExpression(defaultValueExpression, data) end
---@param baseReferenceExpression ICSharpCode.NRefactory.Ast.BaseReferenceExpression
---@param data System.Object
---@return System.Object
function m:VisitBaseReferenceExpression(baseReferenceExpression, data) end
---@param localVariableDeclaration ICSharpCode.NRefactory.Ast.LocalVariableDeclaration
---@param data System.Object
---@return System.Object
function m:VisitLocalVariableDeclaration(localVariableDeclaration, data) end
ICSharpCode.NRefactory.Visitors.ToVBNetConvertVisitor=m
return m;