---@class DataUtilKeywordDependentCollectionISet1IInstance
---instance properties
---@field public instanceCount SystemInt32
---@field public instances SystemCollectionsGenericIEnumerable1IInstance
local m = {};
DataUtilKeywordDependentCollectionISet1IInstance=m
return m;