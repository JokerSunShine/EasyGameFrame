---@class AssetBundles.LoadedAssetBundle
---instance fields
---@field public m_AssetBundle UnityEngine.AssetBundle
---@field public m_ReferencedCount System.Int32
---@field public asset UnityEngine.Object
local m = {};

AssetBundles.LoadedAssetBundle=m
return m;