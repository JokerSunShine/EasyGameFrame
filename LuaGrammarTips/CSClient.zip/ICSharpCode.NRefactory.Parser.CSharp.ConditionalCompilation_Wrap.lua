---@class ICSharpCode.NRefactory.Parser.CSharp.ConditionalCompilation : ICSharpCode.NRefactory.Visitors.AbstractAstVisitor
---instance properties
---@field public Symbols System.Collections.Generic.IDictionary`2[System.String,System.Object]
local m = {};
---@param symbol System.String
function m:Define(symbol) end
---@param symbol System.String
function m:Undefine(symbol) end
---@param condition ICSharpCode.NRefactory.Ast.Expression
---@return System.Boolean
function m:Evaluate(condition) end
---@param primitiveExpression ICSharpCode.NRefactory.Ast.PrimitiveExpression
---@param data System.Object
---@return System.Object
function m:VisitPrimitiveExpression(primitiveExpression, data) end
---@param identifierExpression ICSharpCode.NRefactory.Ast.IdentifierExpression
---@param data System.Object
---@return System.Object
function m:VisitIdentifierExpression(identifierExpression, data) end
---@param unaryOperatorExpression ICSharpCode.NRefactory.Ast.UnaryOperatorExpression
---@param data System.Object
---@return System.Object
function m:VisitUnaryOperatorExpression(unaryOperatorExpression, data) end
---@param binaryOperatorExpression ICSharpCode.NRefactory.Ast.BinaryOperatorExpression
---@param data System.Object
---@return System.Object
function m:VisitBinaryOperatorExpression(binaryOperatorExpression, data) end
---@param parenthesizedExpression ICSharpCode.NRefactory.Ast.ParenthesizedExpression
---@param data System.Object
---@return System.Object
function m:VisitParenthesizedExpression(parenthesizedExpression, data) end
ICSharpCode.NRefactory.Parser.CSharp.ConditionalCompilation=m
return m;