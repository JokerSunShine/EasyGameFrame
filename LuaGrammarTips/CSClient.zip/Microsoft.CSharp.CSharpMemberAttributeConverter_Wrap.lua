---@class Microsoft.CSharp.CSharpMemberAttributeConverter : Microsoft.CSharp.CSharpModifierAttributeConverter
---properties
---@field public Default Microsoft.CSharp.CSharpMemberAttributeConverter
local m = {};
Microsoft.CSharp.CSharpMemberAttributeConverter=m
return m;