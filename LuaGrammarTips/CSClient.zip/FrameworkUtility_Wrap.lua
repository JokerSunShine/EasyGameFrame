---@class FrameworkUtility
local m = {};
---@param list SystemCollectionsGenericList1SystemString
---@param str SystemString
function m.RemoveAll(list, str) end
---@param list SystemCollectionsGenericList1SystemString
---@param str SystemString
function m.Add_NoSame(list, str) end
---@param type SystemType
---@return SystemString
function m.GetTypeTagName(type) end
---@param type SystemType
---@param curType SystemType
---@return SystemBoolean
function m.IsDefined(type, curType) end
---@param o UnityEngineObject
---@return SystemBoolean
function m.IsNull(o) end
---@param txt SystemString
---@return SystemBoolean
function m.IsNullOrEmpty(txt) end
---@param a SystemSingle
---@param b SystemSingle
function m.Swap(a, b) end
FrameworkUtility=m
return m;