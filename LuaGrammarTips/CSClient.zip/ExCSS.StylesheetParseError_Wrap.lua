---@class ExCSS.StylesheetParseError
---instance properties
---@field public ParserError ExCSS.ParserError
---@field public Line System.Int32
---@field public Column System.Int32
---@field public Message System.String
local m = {};
---@return System.String
function m:ToString() end
ExCSS.StylesheetParseError=m
return m;