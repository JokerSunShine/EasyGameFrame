---@class ICSharpCodeNRefactoryAstInnerClassTypeReference : ICSharpCodeNRefactoryAstTypeReference
---instance properties
---@field public BaseType ICSharpCodeNRefactoryAstTypeReference
local m = {};
---@return ICSharpCodeNRefactoryAstTypeReference
function m:Clone() end
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return ICSharpCodeNRefactoryAstTypeReference
function m:CombineToNormalTypeReference() end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstInnerClassTypeReference=m
return m;