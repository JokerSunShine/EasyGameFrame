---@class CSObjectWrapEditor.Generator+XluaFieldInfo
---instance fields
---@field public Name System.String
---@field public Type System.Type
---@field public IsField System.Boolean
---@field public Size System.Int32
local m = {};
CSObjectWrapEditor.Generator+XluaFieldInfo=m
return m;