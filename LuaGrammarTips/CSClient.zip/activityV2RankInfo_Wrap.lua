---@class activityV2.RankInfo
---instance properties
---@field public rank System.Int32
---@field public rankSpecified System.Boolean
---@field public roleName System.String
---@field public roleNameSpecified System.Boolean
---@field public rein System.Int32
---@field public reinSpecified System.Boolean
---@field public level System.Int32
---@field public levelSpecified System.Boolean
---@field public param System.Int32
---@field public paramSpecified System.Boolean
---@field public award System.Int32
---@field public awardSpecified System.Boolean
---@field public career System.Int32
---@field public careerSpecified System.Boolean
---@field public id System.Int64
---@field public idSpecified System.Boolean
local m = {};

activityV2.RankInfo=m
return m;