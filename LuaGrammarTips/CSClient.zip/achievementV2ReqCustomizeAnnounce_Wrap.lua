---@class achievementV2.ReqCustomizeAnnounce
---instance properties
---@field public achievementId System.Int32
---@field public achievementIdSpecified System.Boolean
local m = {};

achievementV2.ReqCustomizeAnnounce=m
return m;