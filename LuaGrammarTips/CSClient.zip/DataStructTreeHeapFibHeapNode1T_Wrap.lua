---@class DataStructTreeHeapFibHeapNode1T
---instance fields
---@field public data T
---@field public degree SystemInt32
---@field public left DataStructTreeHeapFibHeapNode1T
---@field public right DataStructTreeHeapFibHeapNode1T
---@field public child DataStructTreeHeapFibHeapNode1T
---@field public parent DataStructTreeHeapFibHeapNode1T
---@field public marked SystemBoolean
local m = {};
DataStructTreeHeapFibHeapNode1T=m
return m;