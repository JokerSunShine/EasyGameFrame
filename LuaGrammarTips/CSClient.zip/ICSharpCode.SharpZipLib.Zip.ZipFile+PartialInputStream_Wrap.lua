---@class ICSharpCode.SharpZipLib.Zip.ZipFile+PartialInputStream : ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputStream
---instance properties
---@field public Available System.Int32
local m = {};
---@return System.Int32
function m:ReadByte() end
function m:Close() end
---@param b System.Byte[]
---@param off System.Int32
---@param len System.Int32
---@return System.Int32
function m:Read(b, off, len) end
---@param amount System.Int64
---@return System.Int64
function m:SkipBytes(amount) end
ICSharpCode.SharpZipLib.Zip.ZipFile+PartialInputStream=m
return m;