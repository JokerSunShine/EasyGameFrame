---@class Microsoft.VisualBasic.VBMemberAttributeConverter : Microsoft.VisualBasic.VBModifierAttributeConverter
---properties
---@field public Default Microsoft.VisualBasic.VBMemberAttributeConverter
local m = {};
Microsoft.VisualBasic.VBMemberAttributeConverter=m
return m;