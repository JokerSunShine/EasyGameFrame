---@class ICSharpCodeSharpZipLibEncryptionPkzipClassicManaged : ICSharpCodeSharpZipLibEncryptionPkzipClassic
---instance properties
---@field public BlockSize SystemInt32
---@field public LegalKeySizes SystemSecurityCryptographyKeySizes
---@field public LegalBlockSizes SystemSecurityCryptographyKeySizes
---@field public Key SystemByte
local m = {};
function m:GenerateIV() end
function m:GenerateKey() end
---@param rgbKey SystemByte
---@param rgbIV SystemByte
---@return SystemSecurityCryptographyICryptoTransform
function m:CreateEncryptor(rgbKey, rgbIV) end
---@param rgbKey SystemByte
---@param rgbIV SystemByte
---@return SystemSecurityCryptographyICryptoTransform
function m:CreateDecryptor(rgbKey, rgbIV) end
ICSharpCodeSharpZipLibEncryptionPkzipClassicManaged=m
return m;