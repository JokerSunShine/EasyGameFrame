---@class activityV2.CrazyHappyInfo
---instance properties
---@field public group System.Int32
---@field public groupSpecified System.Boolean
---@field public index System.Int32
---@field public indexSpecified System.Boolean
---@field public status System.Int32
---@field public statusSpecified System.Boolean
---@field public curCount System.Int32
---@field public curCountSpecified System.Boolean
---@field public totalCount System.Int32
---@field public totalCountSpecified System.Boolean
local m = {};

activityV2.CrazyHappyInfo=m
return m;