---@class ICSharpCodeNRefactoryParserErrorCodeProc : SystemMulticastDelegate
local m = {};
---@param line SystemInt32
---@param col SystemInt32
---@param n SystemInt32
function m:Invoke(line, col, n) end
---@param line SystemInt32
---@param col SystemInt32
---@param n SystemInt32
---@param callback SystemAsyncCallback
---@param object SystemObject
---@return SystemIAsyncResult
function m:BeginInvoke(line, col, n, callback, object) end
---@param result SystemIAsyncResult
function m:EndInvoke(result) end
ICSharpCodeNRefactoryParserErrorCodeProc=m
return m;