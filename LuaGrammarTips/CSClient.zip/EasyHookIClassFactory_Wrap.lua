---@class EasyHookIClassFactory
local m = {};
---@param pUnkOuter SystemObject @in
---@param riid SystemGuid
---@param obj SystemObject @out
---@return SystemInt32
function m:CreateInstance(pUnkOuter, riid, obj) end
---@param fLock SystemBoolean @in
---@return SystemInt32
function m:LockServer(fLock) end
EasyHookIClassFactory=m
return m;