---@class ExCSS.Model.Extensions.StringExtensions
local m = {};
---@param value System.String
---@param friendlyForamt System.Boolean
---@param indentation System.Int32
---@return System.String
function m.Indent(value, friendlyForamt, indentation) end
---@param value System.String
---@param friendlyFormat System.Boolean
---@param indentation System.Int32
---@return System.String
function m.NewLineIndent(value, friendlyFormat, indentation) end
---@param value System.String
---@return System.String
function m.TrimFirstLine(value) end
---@param builder System.Text.StringBuilder
---@return System.Text.StringBuilder
function m.TrimLastLine(builder) end
---@param builder System.Text.StringBuilder
---@return System.Text.StringBuilder
function m.TrimFirstLine(builder) end
ExCSS.Model.Extensions.StringExtensions=m
return m;