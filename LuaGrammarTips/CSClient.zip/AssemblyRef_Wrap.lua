---@class AssemblyRef
---fields
---@field public EcmaPublicKey SystemString
---@field public FrameworkPublicKeyFull SystemString
---@field public FrameworkPublicKeyFull2 SystemString
---@field public MicrosoftPublicKey SystemString
---@field public MicrosoftJScript SystemString
---@field public MicrosoftVSDesigner SystemString
---@field public SystemData SystemString
---@field public SystemDesign SystemString
---@field public SystemDrawing SystemString
---@field public SystemWeb SystemString
---@field public SystemWebExtensions SystemString
---@field public SystemWindowsForms SystemString
local m = {};
AssemblyRef=m
return m;