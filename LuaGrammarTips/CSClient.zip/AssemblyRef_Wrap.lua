---@class AssemblyRef
---fields
---@field public EcmaPublicKey System.String
---@field public FrameworkPublicKeyFull System.String
---@field public FrameworkPublicKeyFull2 System.String
---@field public MicrosoftPublicKey System.String
---@field public MicrosoftJScript System.String
---@field public MicrosoftVSDesigner System.String
---@field public SystemData System.String
---@field public SystemDesign System.String
---@field public SystemDrawing System.String
---@field public SystemWeb System.String
---@field public SystemWebExtensions System.String
---@field public SystemWindowsForms System.String
local m = {};
AssemblyRef=m
return m;