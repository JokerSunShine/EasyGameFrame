---@class ICSharpCodeNRefactoryAstQueryExpressionOrderClause : ICSharpCodeNRefactoryAstQueryExpressionClause
---instance properties
---@field public Orderings SystemCollectionsGenericList1ICSharpCodeNRefactoryAstQueryExpressionOrdering
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstQueryExpressionOrderClause=m
return m;