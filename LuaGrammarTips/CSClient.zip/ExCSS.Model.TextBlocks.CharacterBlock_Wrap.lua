---@class ExCSS.Model.TextBlocks.CharacterBlock : ExCSS.Model.TextBlocks.Block
local m = {};
ExCSS.Model.TextBlocks.CharacterBlock=m
return m;