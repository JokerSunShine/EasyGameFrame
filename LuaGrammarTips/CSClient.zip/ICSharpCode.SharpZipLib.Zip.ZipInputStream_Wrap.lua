---@class ICSharpCode.SharpZipLib.Zip.ZipInputStream : ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputStream
---instance properties
---@field public Password System.String
---@field public CanDecompressEntry System.Boolean
---@field public Available System.Int32
local m = {};
---@return ICSharpCode.SharpZipLib.Zip.ZipEntry
function m:GetNextEntry() end
function m:CloseEntry() end
---@return System.Int32
function m:ReadByte() end
---@param destination System.Byte[]
---@param index System.Int32
---@param count System.Int32
---@return System.Int32
function m:Read(destination, index, count) end
---@param b System.Byte[]
---@param off System.Int32
---@param len System.Int32
---@return System.Int32
function m:BodyRead(b, off, len) end
function m:Close() end
ICSharpCode.SharpZipLib.Zip.ZipInputStream=m
return m;