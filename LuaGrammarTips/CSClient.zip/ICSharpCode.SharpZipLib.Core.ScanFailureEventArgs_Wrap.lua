---@class ICSharpCode.SharpZipLib.Core.ScanFailureEventArgs
---instance properties
---@field public Name System.String
---@field public Exception System.Exception
---@field public ContinueRunning System.Boolean
local m = {};
ICSharpCode.SharpZipLib.Core.ScanFailureEventArgs=m
return m;