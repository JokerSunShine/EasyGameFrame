---@class activityV2.ResGrowTrailDataChange
---instance properties
---@field public growTrailDataInfo activityV2.GrowTrailActivityInfo
---@field public completeCount System.Int32
---@field public completeCountSpecified System.Boolean
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
local m = {};

activityV2.ResGrowTrailDataChange=m
return m;