---@class ICSharpCodeNRefactoryParserVBKeywords
local m = {};
---@param keyword SystemString
---@return SystemInt32
function m.GetToken(keyword) end
---@param word SystemString
---@return SystemBoolean
function m.IsNonIdentifierKeyword(word) end
ICSharpCodeNRefactoryParserVBKeywords=m
return m;