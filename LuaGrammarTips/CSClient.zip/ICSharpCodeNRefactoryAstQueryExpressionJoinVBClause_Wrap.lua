---@class ICSharpCodeNRefactoryAstQueryExpressionJoinVBClause : ICSharpCodeNRefactoryAstQueryExpressionClause
---properties
---@field public Null ICSharpCodeNRefactoryAstQueryExpressionJoinVBClause
---instance properties
---@field public JoinVariable ICSharpCodeNRefactoryAstQueryExpressionFromClause
---@field public SubJoin ICSharpCodeNRefactoryAstQueryExpressionJoinVBClause
---@field public Conditions SystemCollectionsGenericList1ICSharpCodeNRefactoryAstQueryExpressionJoinConditionVB
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstQueryExpressionJoinVBClause=m
return m;