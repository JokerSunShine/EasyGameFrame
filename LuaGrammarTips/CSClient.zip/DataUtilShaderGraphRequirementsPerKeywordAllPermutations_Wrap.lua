---@class DataUtilShaderGraphRequirementsPerKeywordAllPermutations : SystemValueType
---instance properties
---@field public instanceCount SystemInt32
---@field public instances SystemCollectionsGenericIEnumerable1DataUtilShaderGraphRequirementsPerKeywordIRequirements
local m = {};
DataUtilShaderGraphRequirementsPerKeywordAllPermutations=m
return m;