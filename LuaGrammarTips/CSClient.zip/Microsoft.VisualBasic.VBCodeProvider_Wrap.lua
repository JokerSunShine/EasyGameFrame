---@class Microsoft.VisualBasic.VBCodeProvider : System.CodeDom.Compiler.CodeDomProvider
---instance properties
---@field public FileExtension System.String
---@field public LanguageOptions System.CodeDom.Compiler.LanguageOptions
local m = {};
---@param type System.Type
---@return System.ComponentModel.TypeConverter
function m:GetConverter(type) end
---@param member System.CodeDom.CodeTypeMember
---@param writer System.IO.TextWriter
---@param options System.CodeDom.Compiler.CodeGeneratorOptions
function m:GenerateCodeFromMember(member, writer, options) end
Microsoft.VisualBasic.VBCodeProvider=m
return m;