---@class ICSharpCodeSharpZipLibZipZipNameTransform
---instance properties
---@field public TrimPrefix SystemString
local m = {};
---@param name SystemString
---@return SystemString
function m:TransformDirectory(name) end
---@param name SystemString
---@return SystemString
function m:TransformFile(name) end
ICSharpCodeSharpZipLibZipZipNameTransform=m
return m;