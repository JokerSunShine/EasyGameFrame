---@class DataUtilActiveFieldsNoPermutation : SystemValueType
---instance properties
---@field public fields SystemCollectionsGenericIEnumerable1SystemString
---@field public instanceCount SystemInt32
---@field public permutationIndex SystemInt32
---@field public type DataUtilKeywordDependentCollectionKeywordPermutationInstanceType
---@field public instances SystemCollectionsGenericIEnumerable1DataUtilIActiveFields
local m = {};
---@param field SystemString
---@return SystemBoolean
function m:Add(field) end
---@param field SystemString
---@return SystemBoolean
function m:Contains(field) end
---@param field SystemString
function m:AddAll(field) end
DataUtilActiveFieldsNoPermutation=m
return m;