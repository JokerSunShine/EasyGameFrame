---@class bagV2.ResTradeItemChange
---instance properties
---@field public uid System.Int64
---@field public itemList System.Collections.Generic.List1bagV2.BagItemInfo
---@field public coinList System.Collections.Generic.List1bagV2.CoinInfo
local m = {};

bagV2.ResTradeItemChange=m
return m;