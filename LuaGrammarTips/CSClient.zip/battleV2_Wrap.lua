battleV2 = {};
