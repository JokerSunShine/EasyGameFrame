---@class activityV2.ResActivityMonsterAttackTimesInfo
---instance properties
---@field public curTimes System.Int32
---@field public subTime System.Int64
---@field public subTimeSpecified System.Boolean
---@field public waveId System.Collections.Generic.List1System.Int32
local m = {};

activityV2.ResActivityMonsterAttackTimesInfo=m
return m;