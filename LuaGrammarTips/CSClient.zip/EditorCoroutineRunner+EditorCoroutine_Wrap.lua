---@class EditorCoroutineRunner+EditorCoroutine
---instance properties
---@field public Current System.Object
local m = {};
---@return System.Boolean
function m:MoveNext() end
function m:Reset() end
---@param coroutine System.Collections.IEnumerator
---@return System.Boolean
function m:Find(coroutine) end
EditorCoroutineRunner+EditorCoroutine=m
return m;