---@class bagV2.DrawPreyTreasureBox
---instance properties
---@field public lid System.Int64
---@field public lidSpecified System.Boolean
---@field public dayCount System.Int32
---@field public dayCountSpecified System.Boolean
local m = {};

bagV2.DrawPreyTreasureBox=m
return m;