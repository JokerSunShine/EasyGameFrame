---@class ICSharpCode.NRefactory.Ast.AttributedNode : ICSharpCode.NRefactory.Ast.AbstractNode
---instance properties
---@field public Attributes System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.AttributeSection]
---@field public Modifier ICSharpCode.NRefactory.Ast.Modifiers
local m = {};
ICSharpCode.NRefactory.Ast.AttributedNode=m
return m;