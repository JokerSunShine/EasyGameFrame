---@class ICSharpCodeSharpZipLibCoreScanEventArgs : SystemEventArgs
---instance properties
---@field public Name SystemString
---@field public ContinueRunning SystemBoolean
local m = {};
ICSharpCodeSharpZipLibCoreScanEventArgs=m
return m;