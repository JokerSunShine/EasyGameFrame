---@class ICSharpCodeNRefactoryAstYieldStatement : ICSharpCodeNRefactoryAstStatement
---instance properties
---@field public Statement ICSharpCodeNRefactoryAstStatement
---@field public IsYieldBreak SystemBoolean
---@field public IsYieldReturn SystemBoolean
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstYieldStatement=m
return m;