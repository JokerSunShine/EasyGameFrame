---@class ExCSSNthLastOfTypeSelector : ExCSSNthChildSelector
local m = {};
---@param friendlyFormat SystemBoolean
---@param indentation SystemInt32 @default_value:0
---@return SystemString
function m:ToString(friendlyFormat, indentation) end
ExCSSNthLastOfTypeSelector=m
return m;