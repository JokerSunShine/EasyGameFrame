---@class ICSharpCode.SharpZipLib.Core.ScanEventArgs : System.EventArgs
---instance properties
---@field public Name System.String
---@field public ContinueRunning System.Boolean
local m = {};
ICSharpCode.SharpZipLib.Core.ScanEventArgs=m
return m;