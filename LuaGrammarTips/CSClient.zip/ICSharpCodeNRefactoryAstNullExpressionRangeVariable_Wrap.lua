---@class ICSharpCodeNRefactoryAstNullExpressionRangeVariable : ICSharpCodeNRefactoryAstExpressionRangeVariable
---instance properties
---@field public IsNull SystemBoolean
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstNullExpressionRangeVariable=m
return m;