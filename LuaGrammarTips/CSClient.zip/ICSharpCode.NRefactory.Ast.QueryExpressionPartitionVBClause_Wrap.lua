---@class ICSharpCode.NRefactory.Ast.QueryExpressionPartitionVBClause : ICSharpCode.NRefactory.Ast.QueryExpressionClause
---instance properties
---@field public Expression ICSharpCode.NRefactory.Ast.Expression
---@field public PartitionType ICSharpCode.NRefactory.Ast.QueryExpressionPartitionType
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.QueryExpressionPartitionVBClause=m
return m;