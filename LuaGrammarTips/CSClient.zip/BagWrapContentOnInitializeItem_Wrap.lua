---@class BagWrapContentOnInitializeItem : System.MulticastDelegate
local m = {};

---@param go UnityEngine.GameObject
---@param realIndex System.Int32
function m:Invoke(go, realIndex) end
---@param go UnityEngine.GameObject
---@param realIndex System.Int32
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(go, realIndex, callback, object) end
---@param result System.IAsyncResult
function m:EndInvoke(result) end
BagWrapContentOnInitializeItem=m
return m;