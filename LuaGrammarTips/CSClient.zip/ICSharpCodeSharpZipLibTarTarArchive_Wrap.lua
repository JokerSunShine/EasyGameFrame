---@class ICSharpCodeSharpZipLibTarTarArchive
---instance properties
---@field public PathPrefix SystemString
---@field public RootPath SystemString
---@field public ApplyUserInfoOverrides SystemBoolean
---@field public UserId SystemInt32
---@field public UserName SystemString
---@field public GroupId SystemInt32
---@field public GroupName SystemString
---@field public RecordSize SystemInt32
local m = {};
---@param inputStream SystemIOStream
---@return ICSharpCodeSharpZipLibTarTarArchive
function m.CreateInputTarArchive(inputStream) end
---@param inputStream SystemIOStream
---@param blockFactor SystemInt32
---@return ICSharpCodeSharpZipLibTarTarArchive
function m.CreateInputTarArchive(inputStream, blockFactor) end
---@param outputStream SystemIOStream
---@return ICSharpCodeSharpZipLibTarTarArchive
function m.CreateOutputTarArchive(outputStream) end
---@param outputStream SystemIOStream
---@param blockFactor SystemInt32
---@return ICSharpCodeSharpZipLibTarTarArchive
function m.CreateOutputTarArchive(outputStream, blockFactor) end
---@param value ICSharpCodeSharpZipLibTarProgressMessageHandler
function m:add_ProgressMessageEvent(value) end
---@param value ICSharpCodeSharpZipLibTarProgressMessageHandler
function m:remove_ProgressMessageEvent(value) end
---@param keepOldFiles SystemBoolean
function m:SetKeepOldFiles(keepOldFiles) end
---@param asciiTranslate SystemBoolean
function m:SetAsciiTranslation(asciiTranslate) end
---@param userId SystemInt32
---@param userName SystemString
---@param groupId SystemInt32
---@param groupName SystemString
function m:SetUserInfo(userId, userName, groupId, groupName) end
function m:CloseArchive() end
function m:ListContents() end
---@param destDir SystemString
function m:ExtractContents(destDir) end
---@param sourceEntry ICSharpCodeSharpZipLibTarTarEntry
---@param recurse SystemBoolean
function m:WriteEntry(sourceEntry, recurse) end
ICSharpCodeSharpZipLibTarTarArchive=m
return m;