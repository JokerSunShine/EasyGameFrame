---@class activityV2.ReqCrazyRaffle
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
local m = {};

activityV2.ReqCrazyRaffle=m
return m;