---@class CSObjectWrapEditorGeneratorDelegateByMethodDecComparer
local m = {};
---@param x SystemType
---@param y SystemType
---@return SystemBoolean
function m:Equals(x, y) end
---@param obj SystemType
---@return SystemInt32
function m:GetHashCode(obj) end
CSObjectWrapEditorGeneratorDelegateByMethodDecComparer=m
return m;