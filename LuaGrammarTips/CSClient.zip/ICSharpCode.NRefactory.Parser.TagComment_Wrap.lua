---@class ICSharpCode.NRefactory.Parser.TagComment : ICSharpCode.NRefactory.Comment
---instance properties
---@field public Tag System.String
local m = {};
ICSharpCode.NRefactory.Parser.TagComment=m
return m;