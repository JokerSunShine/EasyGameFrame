---@class boothV2.ChangeBoothNameRequest
---instance properties
---@field public label System.Collections.Generic.List1System.Int32
local m = {};

boothV2.ChangeBoothNameRequest=m
return m;