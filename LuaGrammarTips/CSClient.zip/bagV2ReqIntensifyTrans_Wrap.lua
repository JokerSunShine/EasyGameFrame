---@class bagV2.ReqIntensifyTrans
---instance properties
---@field public oldEquipId System.Int64
---@field public newEquipId System.Int64
local m = {};

bagV2.ReqIntensifyTrans=m
return m;