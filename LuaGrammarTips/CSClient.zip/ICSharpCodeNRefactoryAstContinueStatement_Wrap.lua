---@class ICSharpCodeNRefactoryAstContinueStatement : ICSharpCodeNRefactoryAstStatement
---instance properties
---@field public ContinueType ICSharpCodeNRefactoryAstContinueType
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstContinueStatement=m
return m;