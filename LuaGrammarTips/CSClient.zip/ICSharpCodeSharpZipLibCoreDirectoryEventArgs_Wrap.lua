---@class ICSharpCodeSharpZipLibCoreDirectoryEventArgs : ICSharpCodeSharpZipLibCoreScanEventArgs
---instance properties
---@field public HasMatchingFiles SystemBoolean
local m = {};
ICSharpCodeSharpZipLibCoreDirectoryEventArgs=m
return m;