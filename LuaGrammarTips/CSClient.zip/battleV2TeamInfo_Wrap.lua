---@class battleV2.TeamInfo
---instance properties
---@field public teamId System.Int64
---@field public teamIdSpecified System.Boolean
---@field public teamMembers System.Collections.Generic.List1battleV2.TeamMemberInfo
---@field public shouhuId System.Int32
---@field public shouhuIdSpecified System.Boolean
local m = {};

battleV2.TeamInfo=m
return m;