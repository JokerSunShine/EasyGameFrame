---@class battleV2.ResMultiInsViewInfo
---instance properties
---@field public roleTeam System.Collections.Generic.List1battleV2.RoleTeamInfo
---@field public ownerInfo battleV2.OwnerInfo
---@field public state System.Int32
---@field public stateSpecified System.Boolean
local m = {};

battleV2.ResMultiInsViewInfo=m
return m;