---@class ExCSS.HtmlColor : ExCSS.Term
---instance fields
---@field public A System.Byte
---@field public R System.Byte
---@field public G System.Byte
---@field public B System.Byte
---instance properties
---@field public Alpha System.Double
local m = {};
---@param r System.Byte
---@param g System.Byte
---@param b System.Byte
---@param a System.Single
---@return ExCSS.HtmlColor
function m.FromRgba(r, g, b, a) end
---@param r System.Byte
---@param g System.Byte
---@param b System.Byte
---@param a System.Double
---@return ExCSS.HtmlColor
function m.FromRgba(r, g, b, a) end
---@param r System.Byte
---@param g System.Byte
---@param b System.Byte
---@return ExCSS.HtmlColor
function m.FromRgb(r, g, b) end
---@param h System.Single
---@param s System.Single
---@param l System.Single
---@return ExCSS.HtmlColor
function m.FromHsl(h, s, l) end
---@param color System.String
---@return ExCSS.HtmlColor
function m.FromHex(color) end
---@param color System.String
---@param htmlColor ExCSS.HtmlColor& @out
---@return System.Boolean
function m.TryFromHex(color, htmlColor) end
---@param a ExCSS.HtmlColor
---@param b ExCSS.HtmlColor
---@return System.Boolean
function m.op_Equality(a, b) end
---@param a ExCSS.HtmlColor
---@param b ExCSS.HtmlColor
---@return System.Boolean
function m.op_Inequality(a, b) end
---@param obj System.Object
---@return System.Boolean
function m:Equals(obj) end
---@return System.Int32
function m:GetHashCode() end
---@return System.String
function m:ToString() end
---@param friendlyFormat System.Boolean
---@param indentation System.Int32 @default_value:0
---@return System.String
function m:ToString(friendlyFormat, indentation) end
---@param forceLong System.Boolean
---@param friendlyFormat System.Boolean
---@param indentation System.Int32 @default_value:0
---@return System.String
function m:ToString(forceLong, friendlyFormat, indentation) end
---@param other ExCSS.HtmlColor
---@return System.Boolean
function m:Equals(other) end
ExCSS.HtmlColor=m
return m;