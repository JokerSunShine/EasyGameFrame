---@class ICSharpCode.SharpZipLib.Zip.Compression.Inflater
---instance properties
---@field public IsNeedingInput System.Boolean
---@field public IsNeedingDictionary System.Boolean
---@field public IsFinished System.Boolean
---@field public Adler System.Int32
---@field public TotalOut System.Int32
---@field public TotalIn System.Int32
---@field public RemainingInput System.Int32
local m = {};
function m:Reset() end
---@param buffer System.Byte[]
function m:SetDictionary(buffer) end
---@param buffer System.Byte[]
---@param offset System.Int32
---@param len System.Int32
function m:SetDictionary(buffer, offset, len) end
---@param buf System.Byte[]
function m:SetInput(buf) end
---@param buffer System.Byte[]
---@param offset System.Int32
---@param length System.Int32
function m:SetInput(buffer, offset, length) end
---@param buf System.Byte[]
---@return System.Int32
function m:Inflate(buf) end
---@param buf System.Byte[]
---@param offset System.Int32
---@param len System.Int32
---@return System.Int32
function m:Inflate(buf, offset, len) end
ICSharpCode.SharpZipLib.Zip.Compression.Inflater=m
return m;