---@class backV2.ReqDeleteUnion
---instance properties
---@field public unionId System.Int64
---@field public unionIdSpecified System.Boolean
local m = {};

backV2.ReqDeleteUnion=m
return m;