---@class ICSharpCodeNRefactoryIParser
---instance properties
---@field public Errors ICSharpCodeNRefactoryParserErrors
---@field public Lexer ICSharpCodeNRefactoryParserILexer
---@field public CompilationUnit ICSharpCodeNRefactoryAstCompilationUnit
---@field public ParseMethodBodies SystemBoolean
local m = {};
function m:Parse() end
---@return ICSharpCodeNRefactoryAstExpression
function m:ParseExpression() end
---@return ICSharpCodeNRefactoryAstTypeReference
function m:ParseTypeReference() end
---@return ICSharpCodeNRefactoryAstBlockStatement
function m:ParseBlock() end
---@return SystemCollectionsGenericList1ICSharpCodeNRefactoryAstINode
function m:ParseTypeMembers() end
ICSharpCodeNRefactoryIParser=m
return m;