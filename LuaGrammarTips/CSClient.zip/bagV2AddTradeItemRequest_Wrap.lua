---@class bagV2.AddTradeItemRequest
---instance properties
---@field public lid System.Int64
---@field public lidSpecified System.Boolean
---@field public itemId System.Int32
---@field public itemIdSpecified System.Boolean
---@field public count System.Int32
---@field public countSpecified System.Boolean
local m = {};

bagV2.AddTradeItemRequest=m
return m;