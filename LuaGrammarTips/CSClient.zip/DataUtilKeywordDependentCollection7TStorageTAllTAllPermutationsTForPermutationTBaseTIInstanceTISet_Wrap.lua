---@class DataUtilKeywordDependentCollection7TStorageTAllTAllPermutationsTForPermutationTBaseTIInstanceTISet
---instance properties
---@field public permutationCount SystemInt32
---@field public Item TForPermutation
---@field public all TAll
---@field public allPermutations TAllPermutations
---@field public baseInstance TBase
local m = {};
DataUtilKeywordDependentCollection7TStorageTAllTAllPermutationsTForPermutationTBaseTIInstanceTISet=m
return m;