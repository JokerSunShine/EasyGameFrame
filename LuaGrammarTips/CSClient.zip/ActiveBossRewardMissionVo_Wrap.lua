---@class ActiveBossRewardMissionVo : ActiveNormalVo
---instance properties
---@field public mission CSMission
---@field public getCount System.Int32
local m = {};

---@param mission CSMission
function m:UpdateMission(mission) end
---@return System.Collections.Generic.List1System.UInt32
function m:GetBossRewardMissionTargetRecommend() end
---@return System.Boolean
function m:IsComplete() end
---@return System.Collections.Generic.List1TaskShowInfo
function m:GetDailyTaskShowInfo() end
ActiveBossRewardMissionVo=m
return m;