---@class auctionV2.GetAuctionItemsRequest
---instance properties
---@field public page System.Int32
---@field public pageSpecified System.Boolean
---@field public minLevel System.Int32
---@field public minLevelSpecified System.Boolean
---@field public maxLevel System.Int32
---@field public maxLevelSpecified System.Boolean
---@field public currency System.Int32
---@field public currencySpecified System.Boolean
---@field public sex System.Int32
---@field public sexSpecified System.Boolean
---@field public career System.Int32
---@field public careerSpecified System.Boolean
---@field public toatlPageCount System.Int32
---@field public toatlPageCountSpecified System.Boolean
---@field public screenCondition System.Collections.Generic.List1System.Int32
---@field public itemType System.Int32
---@field public itemTypeSpecified System.Boolean
---@field public sortBy System.Int32
---@field public sortBySpecified System.Boolean
---@field public sort System.Boolean
---@field public sortSpecified System.Boolean
---@field public propertyTendency System.Int32
---@field public propertyTendencySpecified System.Boolean
---@field public selectType System.Int32
---@field public selectTypeSpecified System.Boolean
local m = {};

auctionV2.GetAuctionItemsRequest=m
return m;