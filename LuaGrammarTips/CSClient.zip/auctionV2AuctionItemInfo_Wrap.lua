---@class auctionV2.AuctionItemInfo
---instance properties
---@field public roleId System.Int64
---@field public roleIdSpecified System.Boolean
---@field public itemType System.Int32
---@field public itemTypeSpecified System.Boolean
---@field public item bagV2.BagItemInfo
---@field public price bagV2.CoinInfo
---@field public addTime System.Int64
---@field public addTimeSpecified System.Boolean
---@field public serverId System.Int32
---@field public serverIdSpecified System.Boolean
---@field public overdueTime System.Int64
---@field public overdueTimeSpecified System.Boolean
---@field public itemCount System.Int64
---@field public itemCountSpecified System.Boolean
---@field public auctionItemLotInfo auctionV2.AuctionItemLotInfo
---@field public auctionItemBuyProductsInfo auctionV2.AuctionItemBuyProductsInfo
---@field public delayTime System.Int64
---@field public delayTimeSpecified System.Boolean
local m = {};

auctionV2.AuctionItemInfo=m
return m;