---@class backV2.ResCustomizeAnnounce
---instance properties
---@field public type System.Int32
---@field public typeSpecified System.Boolean
---@field public content System.String
---@field public contentSpecified System.Boolean
local m = {};

backV2.ResCustomizeAnnounce=m
return m;