---@class bagV2.ResDayUseItemCount
---instance properties
---@field public itemId System.Int32
---@field public itemIdSpecified System.Boolean
---@field public useCount System.Int32
---@field public useCountSpecified System.Boolean
---@field public totalCount System.Int32
---@field public totalCountSpecified System.Boolean
local m = {};

bagV2.ResDayUseItemCount=m
return m;