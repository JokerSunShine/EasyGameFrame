---@class FrameworkUtilityArray
local m = {};
---@param array SystemInt32
---@param value SystemInt32
---@return SystemInt32
function m.ArrayAppend(array, value) end
FrameworkUtilityArray=m
return m;