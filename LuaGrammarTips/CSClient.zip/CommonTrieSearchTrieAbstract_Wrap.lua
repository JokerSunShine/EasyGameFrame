---@class CommonTrieSearchTrieAbstract
local m = {};
CommonTrieSearchTrieAbstract=m
return m;