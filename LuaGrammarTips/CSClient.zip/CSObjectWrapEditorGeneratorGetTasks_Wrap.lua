---@class CSObjectWrapEditorGeneratorGetTasks : SystemMulticastDelegate
local m = {};
---@param lua_env XLuaLuaEnv
---@param user_cfg CSObjectWrapEditorUserConfig
---@return SystemCollectionsGenericIEnumerable1CSObjectWrapEditorCustomGenTask
function m:Invoke(lua_env, user_cfg) end
---@param lua_env XLuaLuaEnv
---@param user_cfg CSObjectWrapEditorUserConfig
---@param callback SystemAsyncCallback
---@param object SystemObject
---@return SystemIAsyncResult
function m:BeginInvoke(lua_env, user_cfg, callback, object) end
---@param result SystemIAsyncResult
---@return SystemCollectionsGenericIEnumerable1CSObjectWrapEditorCustomGenTask
function m:EndInvoke(result) end
CSObjectWrapEditorGeneratorGetTasks=m
return m;