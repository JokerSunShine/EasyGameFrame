---@class EasyHookConfig
---properties
---@field public DependencyPath SystemString
---@field public HelperLibraryLocation SystemString
local m = {};
---@return SystemString
function m.GetProcessPath() end
---@return SystemString
function m.GetSvcExecutableName() end
---@return SystemString
function m.GetWOW64BypassExecutableName() end
---@return SystemString
function m.GetDependantSvcExecutableName() end
---@param InDescription SystemString
---@param InUserAssemblies SystemString
function m.Register(InDescription, InUserAssemblies) end
EasyHookConfig=m
return m;