---@class CommonBothWayChainListBothWayChainList1T
---instance properties
---@field public Head CommonBothWayChainListNode1T
---@field public Item T
---@field public Count SystemInt32
local m = {};
---@param i SystemInt32
---@return T
function m:GetNodeValue(i) end
---@return SystemBoolean
function m:IsEmpty() end
---@param item T
function m:Append(item) end
---@param item T
---@param i SystemInt32 @default_value:-1
function m:Insert(item, i) end
---@param i SystemInt32
function m:Delete(i) end
---@param list CommonBothWayChainListBothWayChainList1T
function m:Merge(list) end
function m:Clear() end
---@return SystemCollectionsIEnumerator
function m:GetEnumerator() end
CommonBothWayChainListBothWayChainList1T=m
return m;