---@class ICSharpCode.NRefactory.Comment : ICSharpCode.NRefactory.AbstractSpecial
---instance properties
---@field public CommentType ICSharpCode.NRefactory.CommentType
---@field public CommentText System.String
---@field public CommentStartsLine System.Boolean
local m = {};
---@return System.String
function m:ToString() end
---@param visitor ICSharpCode.NRefactory.ISpecialVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
ICSharpCode.NRefactory.Comment=m
return m;