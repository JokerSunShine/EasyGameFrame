---@class ExCSSComma : ExCSSTerm
local m = {};
---@return SystemString
function m:ToString() end
ExCSSComma=m
return m;