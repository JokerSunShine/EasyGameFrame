---@class ICSharpCodeSharpZipLibZipCompressionInflaterHuffmanTree
---fields
---@field public defLitLenTree ICSharpCodeSharpZipLibZipCompressionInflaterHuffmanTree
---@field public defDistTree ICSharpCodeSharpZipLibZipCompressionInflaterHuffmanTree
local m = {};
---@param input ICSharpCodeSharpZipLibZipCompressionStreamsStreamManipulator
---@return SystemInt32
function m:GetSymbol(input) end
ICSharpCodeSharpZipLibZipCompressionInflaterHuffmanTree=m
return m;