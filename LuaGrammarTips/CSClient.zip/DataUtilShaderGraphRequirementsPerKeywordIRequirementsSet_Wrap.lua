---@class DataUtilShaderGraphRequirementsPerKeywordIRequirementsSet
local m = {};
DataUtilShaderGraphRequirementsPerKeywordIRequirementsSet=m
return m;