---@class activityV2.ActivityDataInfo
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public leftCount System.Int32
---@field public leftCountSpecified System.Boolean
---@field public roleGoalInfo activityV2.RoleActivityInfo
---@field public serverGoalInfo activityV2.ServerActivityInfo
---@field public dataType System.Int32
---@field public dataTypeSpecified System.Boolean
local m = {};

activityV2.ActivityDataInfo=m
return m;