---@class BaseEventCallback : System.MulticastDelegate
local m = {};

---@param uiEvtID System.UInt32
---@param data System.Object
function m:Invoke(uiEvtID, data) end
---@param uiEvtID System.UInt32
---@param data System.Object
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(uiEvtID, data, callback, object) end
---@param result System.IAsyncResult
function m:EndInvoke(result) end
BaseEventCallback=m
return m;