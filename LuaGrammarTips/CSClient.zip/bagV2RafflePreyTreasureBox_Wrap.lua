---@class bagV2.RafflePreyTreasureBox
---instance properties
---@field public lid System.Int64
---@field public lidSpecified System.Boolean
local m = {};

bagV2.RafflePreyTreasureBox=m
return m;