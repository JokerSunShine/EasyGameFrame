---@class ICSharpCode.NRefactory.Ast.MemberNode : ICSharpCode.NRefactory.Ast.ParametrizedNode
---instance properties
---@field public InterfaceImplementations System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.InterfaceImplementation]
---@field public TypeReference ICSharpCode.NRefactory.Ast.TypeReference
local m = {};
ICSharpCode.NRefactory.Ast.MemberNode=m
return m;