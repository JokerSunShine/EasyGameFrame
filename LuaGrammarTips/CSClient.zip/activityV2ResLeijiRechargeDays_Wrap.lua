---@class activityV2.ResLeijiRechargeDays
---instance properties
---@field public days System.Int32
---@field public daysSpecified System.Boolean
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
local m = {};

activityV2.ResLeijiRechargeDays=m
return m;