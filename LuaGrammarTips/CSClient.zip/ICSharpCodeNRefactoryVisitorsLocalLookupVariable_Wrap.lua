---@class ICSharpCodeNRefactoryVisitorsLocalLookupVariable
---instance fields
---@field public Name SystemString
---@field public TypeRef ICSharpCodeNRefactoryAstTypeReference
---@field public StartPos ICSharpCodeNRefactoryLocation
---@field public EndPos ICSharpCodeNRefactoryLocation
---@field public IsConst SystemBoolean
---@field public IsLoopVariable SystemBoolean
---@field public Initializer ICSharpCodeNRefactoryAstExpression
---@field public ParentLambdaExpression ICSharpCodeNRefactoryAstLambdaExpression
---@field public IsQueryContinuation SystemBoolean
local m = {};
ICSharpCodeNRefactoryVisitorsLocalLookupVariable=m
return m;