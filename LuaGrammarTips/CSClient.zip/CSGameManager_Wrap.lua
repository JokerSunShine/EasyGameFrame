---@class CSGameManager : UnityEngineMonoBehaviour
---instance fields
---@field public managerList SystemCollectionsGenericList1AbstractManager
---@field public OpenLog SystemBoolean
---@field public updateFrequency SystemInt32
local m = {};
CSGameManager=m
return m;