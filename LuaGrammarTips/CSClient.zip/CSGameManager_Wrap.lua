---@class CSGameManager : UnityEngine.MonoBehaviour
---instance fields
---@field public managerList System.Collections.Generic.List`1[AbstractManager]
---@field public OpenLog System.Boolean
---@field public updateFrequency System.Int32
local m = {};
CSGameManager=m
return m;