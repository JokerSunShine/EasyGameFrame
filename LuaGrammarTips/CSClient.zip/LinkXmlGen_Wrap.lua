---@class LinkXmlGen : UnityEngineScriptableObject
---instance fields
---@field public Template UnityEngineTextAsset
local m = {};
---@param lua_env XLuaLuaEnv
---@param user_cfg CSObjectWrapEditorUserConfig
---@return SystemCollectionsGenericIEnumerable1CSObjectWrapEditorCustomGenTask
function m.GetTasks(lua_env, user_cfg) end
function m.GenLinkXml() end
LinkXmlGen=m
return m;