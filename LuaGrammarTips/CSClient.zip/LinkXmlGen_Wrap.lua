---@class LinkXmlGen : UnityEngine.ScriptableObject
---instance fields
---@field public Template UnityEngine.TextAsset
local m = {};
---@param lua_env XLua.LuaEnv
---@param user_cfg CSObjectWrapEditor.UserConfig
---@return System.Collections.Generic.IEnumerable`1[CSObjectWrapEditor.CustomGenTask]
function m.GetTasks(lua_env, user_cfg) end
function m.GenLinkXml() end
LinkXmlGen=m
return m;