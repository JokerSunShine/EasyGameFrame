---@class EasyHookHelperServiceInterfaceInjectionWait
---instance fields
---@field public ThreadLock SystemThreadingMutex
---@field public Completion SystemThreadingManualResetEvent
---@field public Error SystemException
local m = {};
EasyHookHelperServiceInterfaceInjectionWait=m
return m;