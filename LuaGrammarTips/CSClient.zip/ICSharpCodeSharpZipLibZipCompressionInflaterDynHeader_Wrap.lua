---@class ICSharpCodeSharpZipLibZipCompressionInflaterDynHeader
local m = {};
---@param input ICSharpCodeSharpZipLibZipCompressionStreamsStreamManipulator
---@return SystemBoolean
function m:Decode(input) end
---@return ICSharpCodeSharpZipLibZipCompressionInflaterHuffmanTree
function m:BuildLitLenTree() end
---@return ICSharpCodeSharpZipLibZipCompressionInflaterHuffmanTree
function m:BuildDistTree() end
ICSharpCodeSharpZipLibZipCompressionInflaterDynHeader=m
return m;