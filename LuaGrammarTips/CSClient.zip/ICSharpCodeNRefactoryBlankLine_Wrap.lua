---@class ICSharpCodeNRefactoryBlankLine : ICSharpCodeNRefactoryAbstractSpecial
local m = {};
---@param visitor ICSharpCodeNRefactoryISpecialVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
ICSharpCodeNRefactoryBlankLine=m
return m;