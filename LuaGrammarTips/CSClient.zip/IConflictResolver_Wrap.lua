---@class IConflictResolver
local m = {};
---@param keyCombinationSequence System.Collections.Generic.IEnumerable`1[UnityEditor.ShortcutManagement.KeyCombination]
---@param entries System.Collections.Generic.IEnumerable`1[UnityEditor.ShortcutManagement.ShortcutEntry]
function m:ResolveConflict(keyCombinationSequence, entries) end
function m:Cancel() end
---@param entry UnityEditor.ShortcutManagement.ShortcutEntry
function m:ExecuteOnce(entry) end
---@param entry UnityEditor.ShortcutManagement.ShortcutEntry
function m:ExecuteAlways(entry) end
function m:GoToShortcutManagerConflictCategory() end
IConflictResolver=m
return m;