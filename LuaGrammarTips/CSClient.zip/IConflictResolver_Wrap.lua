---@class IConflictResolver
local m = {};
---@param keyCombinationSequence SystemCollectionsGenericIEnumerable1UnityEditorShortcutManagementKeyCombination
---@param entries SystemCollectionsGenericIEnumerable1UnityEditorShortcutManagementShortcutEntry
function m:ResolveConflict(keyCombinationSequence, entries) end
function m:Cancel() end
---@param entry UnityEditorShortcutManagementShortcutEntry
function m:ExecuteOnce(entry) end
---@param entry UnityEditorShortcutManagementShortcutEntry
function m:ExecuteAlways(entry) end
function m:GoToShortcutManagerConflictCategory() end
IConflictResolver=m
return m;