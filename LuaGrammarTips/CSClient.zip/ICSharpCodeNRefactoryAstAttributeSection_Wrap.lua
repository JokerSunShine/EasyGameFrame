---@class ICSharpCodeNRefactoryAstAttributeSection : ICSharpCodeNRefactoryAstAbstractNode
---instance properties
---@field public AttributeTarget SystemString
---@field public Attributes SystemCollectionsGenericList1ICSharpCodeNRefactoryAstAttribute
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstAttributeSection=m
return m;