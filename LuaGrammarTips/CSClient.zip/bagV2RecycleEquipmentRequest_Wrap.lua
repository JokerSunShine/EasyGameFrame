---@class bagV2.RecycleEquipmentRequest
---instance properties
---@field public recycleList System.Collections.Generic.List1System.Int64
---@field public intensifyLv System.Int32
---@field public intensifyLvSpecified System.Boolean
---@field public recycleData System.Collections.Generic.List1System.Int32
local m = {};

bagV2.RecycleEquipmentRequest=m
return m;