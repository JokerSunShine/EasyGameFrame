---@class HashPrimeNumbers
local m = {};
---@param x SystemInt32
---@return SystemBoolean
function m.TestPrime(x) end
---@param x SystemInt32
---@return SystemInt32
function m.CalcPrime(x) end
---@param x SystemInt32
---@return SystemInt32
function m.ToPrime(x) end
HashPrimeNumbers=m
return m;