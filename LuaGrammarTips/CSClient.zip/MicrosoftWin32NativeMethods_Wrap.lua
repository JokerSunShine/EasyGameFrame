---@class MicrosoftWin32NativeMethods
---fields
---@field public E_ABORT SystemInt32
---@field public PROCESS_TERMINATE SystemInt32
---@field public PROCESS_CREATE_THREAD SystemInt32
---@field public PROCESS_SET_SESSIONID SystemInt32
---@field public PROCESS_VM_OPERATION SystemInt32
---@field public PROCESS_VM_READ SystemInt32
---@field public PROCESS_VM_WRITE SystemInt32
---@field public PROCESS_DUP_HANDLE SystemInt32
---@field public PROCESS_CREATE_PROCESS SystemInt32
---@field public PROCESS_SET_QUOTA SystemInt32
---@field public PROCESS_SET_INFORMATION SystemInt32
---@field public PROCESS_QUERY_INFORMATION SystemInt32
---@field public PROCESS_QUERY_LIMITED_INFORMATION SystemInt32
---@field public STANDARD_RIGHTS_REQUIRED SystemInt32
---@field public SYNCHRONIZE SystemInt32
---@field public PROCESS_ALL_ACCESS SystemInt32
---@field public DUPLICATE_CLOSE_SOURCE SystemInt32
---@field public DUPLICATE_SAME_ACCESS SystemInt32
---@field public STILL_ACTIVE SystemInt32
---@field public WAIT_OBJECT_0 SystemInt32
---@field public WAIT_FAILED SystemInt32
---@field public WAIT_TIMEOUT SystemInt32
---@field public WAIT_ABANDONED SystemInt32
---@field public WAIT_ABANDONED_0 SystemInt32
---@field public ERROR_FILE_NOT_FOUND SystemInt32
---@field public ERROR_PATH_NOT_FOUND SystemInt32
---@field public ERROR_ACCESS_DENIED SystemInt32
---@field public ERROR_INVALID_HANDLE SystemInt32
---@field public ERROR_SHARING_VIOLATION SystemInt32
---@field public ERROR_INVALID_NAME SystemInt32
---@field public ERROR_ALREADY_EXISTS SystemInt32
---@field public ERROR_FILENAME_EXCED_RANGE SystemInt32
local m = {};
---@param hSourceProcessHandle SystemRuntimeInteropServicesHandleRef
---@param hSourceHandle SystemRuntimeInteropServicesSafeHandle
---@param hTargetProcess SystemRuntimeInteropServicesHandleRef
---@param targetHandle MicrosoftWin32SafeHandlesSafeWaitHandle @out
---@param dwDesiredAccess SystemInt32
---@param bInheritHandle SystemBoolean
---@param dwOptions SystemInt32
---@return SystemBoolean
function m.DuplicateHandle(hSourceProcessHandle, hSourceHandle, hTargetProcess, targetHandle, dwDesiredAccess, bInheritHandle, dwOptions) end
---@param hSourceProcessHandle SystemRuntimeInteropServicesHandleRef
---@param hSourceHandle SystemRuntimeInteropServicesHandleRef
---@param hTargetProcess SystemRuntimeInteropServicesHandleRef
---@param targetHandle MicrosoftWin32SafeHandlesSafeProcessHandle @out
---@param dwDesiredAccess SystemInt32
---@param bInheritHandle SystemBoolean
---@param dwOptions SystemInt32
---@return SystemBoolean
function m.DuplicateHandle(hSourceProcessHandle, hSourceHandle, hTargetProcess, targetHandle, dwDesiredAccess, bInheritHandle, dwOptions) end
---@return SystemIntPtr
function m.GetCurrentProcess() end
---@param processHandle SystemIntPtr
---@param exitCode SystemInt32 @out
---@return SystemBoolean
function m.GetExitCodeProcess(processHandle, exitCode) end
---@param processHandle MicrosoftWin32SafeHandlesSafeProcessHandle
---@param exitCode SystemInt32 @out
---@return SystemBoolean
function m.GetExitCodeProcess(processHandle, exitCode) end
---@param processHandle SystemIntPtr
---@param exitCode SystemInt32
---@return SystemBoolean
function m.TerminateProcess(processHandle, exitCode) end
---@param processHandle MicrosoftWin32SafeHandlesSafeProcessHandle
---@param exitCode SystemInt32
---@return SystemBoolean
function m.TerminateProcess(processHandle, exitCode) end
---@param handle SystemIntPtr
---@param milliseconds SystemInt32
---@return SystemInt32
function m.WaitForInputIdle(handle, milliseconds) end
---@param handle MicrosoftWin32SafeHandlesSafeProcessHandle
---@param milliseconds SystemInt32
---@return SystemInt32
function m.WaitForInputIdle(handle, milliseconds) end
---@param handle SystemIntPtr
---@param min SystemIntPtr @out
---@param max SystemIntPtr @out
---@return SystemBoolean
function m.GetProcessWorkingSetSize(handle, min, max) end
---@param handle MicrosoftWin32SafeHandlesSafeProcessHandle
---@param min SystemIntPtr @out
---@param max SystemIntPtr @out
---@return SystemBoolean
function m.GetProcessWorkingSetSize(handle, min, max) end
---@param handle SystemIntPtr
---@param min SystemIntPtr
---@param max SystemIntPtr
---@return SystemBoolean
function m.SetProcessWorkingSetSize(handle, min, max) end
---@param handle MicrosoftWin32SafeHandlesSafeProcessHandle
---@param min SystemIntPtr
---@param max SystemIntPtr
---@return SystemBoolean
function m.SetProcessWorkingSetSize(handle, min, max) end
---@param handle SystemIntPtr
---@param creation SystemInt64 @out
---@param exit SystemInt64 @out
---@param kernel SystemInt64 @out
---@param user SystemInt64 @out
---@return SystemBoolean
function m.GetProcessTimes(handle, creation, exit, kernel, user) end
---@param handle MicrosoftWin32SafeHandlesSafeProcessHandle
---@param creation SystemInt64 @out
---@param exit SystemInt64 @out
---@param kernel SystemInt64 @out
---@param user SystemInt64 @out
---@return SystemBoolean
function m.GetProcessTimes(handle, creation, exit, kernel, user) end
---@return SystemInt32
function m.GetCurrentProcessId() end
---@param handle SystemIntPtr
---@return SystemInt32
function m.GetPriorityClass(handle) end
---@param handle MicrosoftWin32SafeHandlesSafeProcessHandle
---@return SystemInt32
function m.GetPriorityClass(handle) end
---@param handle SystemIntPtr
---@param priorityClass SystemInt32
---@return SystemBoolean
function m.SetPriorityClass(handle, priorityClass) end
---@param handle MicrosoftWin32SafeHandlesSafeProcessHandle
---@param priorityClass SystemInt32
---@return SystemBoolean
function m.SetPriorityClass(handle, priorityClass) end
---@param handle SystemIntPtr
---@return SystemBoolean
function m.CloseProcess(handle) end
MicrosoftWin32NativeMethods=m
return m;