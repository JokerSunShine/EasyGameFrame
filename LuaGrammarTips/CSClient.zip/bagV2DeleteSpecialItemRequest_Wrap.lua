---@class bagV2.DeleteSpecialItemRequest
---instance properties
---@field public uniqueId System.Int64
local m = {};

bagV2.DeleteSpecialItemRequest=m
return m;