---@class AssetBundles.AssetBundleManager : UnityEngine.MonoBehaviour
---fields
---@field public m_AssetBundleManifest UnityEngine.AssetBundleManifest
---@field public preDealDic System.Collections.Generic.Dictionary2System.StringSystem.Boolean
---properties
---@field public logMode AssetBundles.AssetBundleManagerLogMode
---@field public BaseDownloadingURL System.String
---@field public AssetBundleManifestObject UnityEngine.AssetBundleManifest
local m = {};
---@param assetBundleName System.String
---@param error System.String @out
---@return AssetBundles.LoadedAssetBundle
function m.GetLoadedAssetBundle(assetBundleName, error) end
---@return AssetBundles.AssetBundleLoadManifestOperation
function m.Initialize() end
function m.InitializeMaifest() end
---@param manifestAssetBundleName System.String
---@return AssetBundles.AssetBundleLoadManifestOperation
function m.Initialize(manifestAssetBundleName) end
---@param assetBundleName System.String
function m.UnloadAssetBundle(assetBundleName) end
---@param assetBundleName System.String
---@param assetName System.String
---@param type System.Type
---@return AssetBundles.AssetBundleLoadAssetOperation
function m.LoadAssetAsync(assetBundleName, assetName, type) end
---@param assetname System.String
function m.AddPreDeal(assetname) end
---@param assetBundleName System.String
---@return AssetBundles.LoadedAssetBundle
function m.LoadUIAssetAsync(assetBundleName) end
---@param assetBundleName System.String
---@return System.Boolean
function m.CheckAssetBundle(assetBundleName) end
---@param relatePath System.String
function m.CallbackFromLoadedAssetBundle(relatePath) end
---@param assetBundleName System.String
---@return System.String
function m.GetAssetBundlePath(assetBundleName) end
---@param assetBundleName System.String
---@return System.String
function m.GetAssetBundleRelatePath(assetBundleName) end
---@param assetBundleName System.String
---@return AssetBundles.LoadedAssetBundle
function m.LoadUIAssetBundleInternal(assetBundleName) end
---@param assetName System.String
---@param parent UnityEngine.Transform
---@return UnityEngine.GameObject
function m.LoadUIAsset(assetName, parent) end

AssetBundles.AssetBundleManager=m
return m;