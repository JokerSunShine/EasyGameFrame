---@class ICSharpCodeNRefactoryPrettyPrinterAbstractPrettyPrintOptions
---instance properties
---@field public IndentationChar SystemChar
---@field public TabSize SystemInt32
---@field public IndentSize SystemInt32
local m = {};
ICSharpCodeNRefactoryPrettyPrinterAbstractPrettyPrintOptions=m
return m;