---@class ICSharpCode.NRefactory.Ast.UsingStatement : ICSharpCode.NRefactory.Ast.StatementWithEmbeddedStatement
---instance properties
---@field public ResourceAcquisition ICSharpCode.NRefactory.Ast.Statement
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.UsingStatement=m
return m;