---@class ActiveEliteRewardMission : ActiveMissionVo
---properties
---@field public ConditionIndex System.Int32
---instance properties
---@field public getCount System.Int32
local m = {};

---@return System.Collections.Generic.List1System.UInt32
function m:GetEliteRewardMissionTargetRecommend() end
---@return System.Boolean
function m:IsComplete() end
---@return System.Int32
function m:GetTaskCanBuyCount() end
---@return System.Collections.Generic.List1TaskShowInfo
function m:GetDailyTaskShowInfo() end
ActiveEliteRewardMission=m
return m;