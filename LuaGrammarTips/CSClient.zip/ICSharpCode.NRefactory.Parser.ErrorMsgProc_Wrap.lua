---@class ICSharpCode.NRefactory.Parser.ErrorMsgProc : System.MulticastDelegate
local m = {};
---@param line System.Int32
---@param col System.Int32
---@param msg System.String
function m:Invoke(line, col, msg) end
---@param line System.Int32
---@param col System.Int32
---@param msg System.String
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(line, col, msg, callback, object) end
---@param result System.IAsyncResult
function m:EndInvoke(result) end
ICSharpCode.NRefactory.Parser.ErrorMsgProc=m
return m;