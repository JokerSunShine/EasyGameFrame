---@class auctionV2.PushType
---@field PUTONPUSH @1
---@field BUYPUSH @2
local m = {};
auctionV2.PushType=m
return m;