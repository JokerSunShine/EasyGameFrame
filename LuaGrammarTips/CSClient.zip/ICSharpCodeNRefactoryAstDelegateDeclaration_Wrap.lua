---@class ICSharpCodeNRefactoryAstDelegateDeclaration : ICSharpCodeNRefactoryAstAttributedNode
---instance properties
---@field public Name SystemString
---@field public ReturnType ICSharpCodeNRefactoryAstTypeReference
---@field public Parameters SystemCollectionsGenericList1ICSharpCodeNRefactoryAstParameterDeclarationExpression
---@field public Templates SystemCollectionsGenericList1ICSharpCodeNRefactoryAstTemplateDefinition
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstDelegateDeclaration=m
return m;