---@class backV2.ReqSendServerMail
---instance properties
---@field public title System.String
---@field public titleSpecified System.Boolean
---@field public content System.String
---@field public contentSpecified System.Boolean
---@field public itemStr System.String
---@field public itemStrSpecified System.Boolean
---@field public type System.Int32
---@field public typeSpecified System.Boolean
---@field public filterParam System.Int32
---@field public filterParamSpecified System.Boolean
---@field public itemTime System.Int32
---@field public itemTimeSpecified System.Boolean
local m = {};

backV2.ReqSendServerMail=m
return m;