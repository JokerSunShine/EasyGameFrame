---@class CSObjectWrapEditor.Generator+ParameterInfoSimulation
---instance fields
---@field public Name System.String
---@field public IsOut System.Boolean
---@field public IsIn System.Boolean
---@field public ParameterType System.Type
---@field public IsParamArray System.Boolean
local m = {};
CSObjectWrapEditor.Generator+ParameterInfoSimulation=m
return m;