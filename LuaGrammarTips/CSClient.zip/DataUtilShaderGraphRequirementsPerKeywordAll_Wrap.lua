---@class DataUtilShaderGraphRequirementsPerKeywordAll : SystemValueType
---instance properties
---@field public instanceCount SystemInt32
---@field public instances SystemCollectionsGenericIEnumerable1DataUtilShaderGraphRequirementsPerKeywordIRequirements
local m = {};
DataUtilShaderGraphRequirementsPerKeywordAll=m
return m;