---@class BaseFrame : UnityEngine.MonoBehaviour
---instance fields
---@field public onStart BaseFrameOnStart
---@field public onFinish BaseFrameOnFinish
---instance properties
---@field public StopFrame EActionStopFrameType
local m = {};

BaseFrame=m
return m;