---@class bagV2.Destruction
---instance properties
---@field public objId System.Int64
local m = {};

bagV2.Destruction=m
return m;