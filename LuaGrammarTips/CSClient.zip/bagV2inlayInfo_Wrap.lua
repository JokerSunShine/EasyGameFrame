---@class bagV2.inlayInfo
---instance properties
---@field public pos System.Int32
---@field public posSpecified System.Boolean
---@field public itemId System.Int32
---@field public itemIdSpecified System.Boolean
---@field public currentLasting System.Int32
---@field public currentLastingSpecified System.Boolean
---@field public id System.Int64
---@field public idSpecified System.Boolean
local m = {};

bagV2.inlayInfo=m
return m;