---@class GraphicsSphere
---instance fields
---@field public center _3DMathVector3
---@field public radius SystemSingle
local m = {};
GraphicsSphere=m
return m;