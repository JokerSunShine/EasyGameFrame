---@class activityV2.ActivityRankInfo
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public firstRoleBean activityV2.RoleSimpleInfo
---@field public secondRoleBean activityV2.RoleSimpleInfo
---@field public thirdRoleBean activityV2.RoleSimpleInfo
---@field public rankInfoList System.Collections.Generic.List1activityV2.RoleSimpleInfo
local m = {};

activityV2.ActivityRankInfo=m
return m;