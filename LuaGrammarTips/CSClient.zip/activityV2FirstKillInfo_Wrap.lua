---@class activityV2.FirstKillInfo
---instance properties
---@field public instanceId System.Int32
---@field public instanceIdSpecified System.Boolean
---@field public state System.Int32
---@field public stateSpecified System.Boolean
local m = {};

activityV2.FirstKillInfo=m
return m;