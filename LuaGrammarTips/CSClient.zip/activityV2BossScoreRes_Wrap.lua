---@class activityV2.BossScoreRes
---instance properties
---@field public score System.Int32
---@field public scoreSpecified System.Boolean
---@field public day System.Int32
---@field public daySpecified System.Boolean
---@field public rewards System.Collections.Generic.List1activityV2.BossScoreRewards
---@field public isCard System.Boolean
---@field public isCardSpecified System.Boolean
local m = {};

activityV2.BossScoreRes=m
return m;