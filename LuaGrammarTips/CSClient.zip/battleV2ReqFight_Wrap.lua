---@class battleV2.ReqFight
---instance properties
---@field public targetUid System.Int64
---@field public targetUidSpecified System.Boolean
---@field public fightType System.Int32
---@field public fightTypeSpecified System.Boolean
local m = {};

battleV2.ReqFight=m
return m;