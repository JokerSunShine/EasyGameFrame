---@class DesktopStandalonePostProcessorFilePathComparer
local m = {};
---@param left SystemString
---@param right SystemString
---@return SystemBoolean
function m:Equals(left, right) end
---@param path SystemString
---@return SystemInt32
function m:GetHashCode(path) end
DesktopStandalonePostProcessorFilePathComparer=m
return m;