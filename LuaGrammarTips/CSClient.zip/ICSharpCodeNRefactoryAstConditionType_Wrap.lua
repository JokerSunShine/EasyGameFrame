---@class ICSharpCodeNRefactoryAstConditionType
---@field None @0
---@field Until @1
---@field While @2
---@field DoWhile @3
ICSharpCodeNRefactoryAstConditionType=m
return m;