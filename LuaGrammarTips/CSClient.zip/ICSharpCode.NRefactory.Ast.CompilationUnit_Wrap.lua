---@class ICSharpCode.NRefactory.Ast.CompilationUnit : ICSharpCode.NRefactory.Ast.AbstractNode
---instance properties
---@field public CurrentBock ICSharpCode.NRefactory.Ast.INode
local m = {};
---@param block ICSharpCode.NRefactory.Ast.INode
function m:BlockStart(block) end
function m:BlockEnd() end
---@param childNode ICSharpCode.NRefactory.Ast.INode
function m:AddChild(childNode) end
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.CompilationUnit=m
return m;