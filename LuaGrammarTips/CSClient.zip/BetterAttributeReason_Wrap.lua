---@class BetterAttributeReason
---@field Null @0
---@field CareerAttack @1
---@field TotalDefence @2
local m = {};
BetterAttributeReason=m
return m;