---@class biqiV2.ResRoleScore
---instance properties
---@field public rank System.Int32
---@field public rankSpecified System.Boolean
---@field public score System.Int32
---@field public scoreSpecified System.Boolean
local m = {};

biqiV2.ResRoleScore=m
return m;