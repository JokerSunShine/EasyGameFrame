---@class bagV2.JiPinInfo
---instance properties
---@field public power System.Int32
---@field public powerSpecified System.Boolean
---@field public attributeType System.Collections.Generic.List1System.Byte
---@field public attributeValue System.Collections.Generic.List1System.Int32
local m = {};

bagV2.JiPinInfo=m
return m;