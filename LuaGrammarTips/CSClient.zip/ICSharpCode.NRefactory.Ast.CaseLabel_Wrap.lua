---@class ICSharpCode.NRefactory.Ast.CaseLabel : ICSharpCode.NRefactory.Ast.AbstractNode
---instance properties
---@field public Label ICSharpCode.NRefactory.Ast.Expression
---@field public BinaryOperatorType ICSharpCode.NRefactory.Ast.BinaryOperatorType
---@field public ToExpression ICSharpCode.NRefactory.Ast.Expression
---@field public IsDefault System.Boolean
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.CaseLabel=m
return m;