---@class bagV2.ReqUseCDKey
---instance properties
---@field public cdKey System.String
local m = {};

bagV2.ReqUseCDKey=m
return m;