---@class arenaV2.ResArenaRankWeekInfo
---instance properties
---@field public myRank System.Int32
---@field public myRankSpecified System.Boolean
---@field public arenaRanklist System.Collections.Generic.List1arenaV2.ArenaRankInfo
local m = {};

arenaV2.ResArenaRankWeekInfo=m
return m;