---@class ICSharpCode.NRefactory.Ast.OptionDeclaration : ICSharpCode.NRefactory.Ast.AbstractNode
---instance properties
---@field public OptionType ICSharpCode.NRefactory.Ast.OptionType
---@field public OptionValue System.Boolean
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.OptionDeclaration=m
return m;