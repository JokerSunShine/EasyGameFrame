---@class activityV2.ReqRoleActivityRankInfo
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
local m = {};

activityV2.ReqRoleActivityRankInfo=m
return m;