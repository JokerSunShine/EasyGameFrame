---@class ICSharpCodeNRefactoryLocation : SystemValueType
---fields
---@field public Empty ICSharpCodeNRefactoryLocation
---instance properties
---@field public X SystemInt32
---@field public Y SystemInt32
---@field public Line SystemInt32
---@field public Column SystemInt32
---@field public IsEmpty SystemBoolean
local m = {};
---@param a ICSharpCodeNRefactoryLocation
---@param b ICSharpCodeNRefactoryLocation
---@return SystemBoolean
function m.op_Equality(a, b) end
---@param a ICSharpCodeNRefactoryLocation
---@param b ICSharpCodeNRefactoryLocation
---@return SystemBoolean
function m.op_Inequality(a, b) end
---@param a ICSharpCodeNRefactoryLocation
---@param b ICSharpCodeNRefactoryLocation
---@return SystemBoolean
function m.op_LessThan(a, b) end
---@param a ICSharpCodeNRefactoryLocation
---@param b ICSharpCodeNRefactoryLocation
---@return SystemBoolean
function m.op_GreaterThan(a, b) end
---@param a ICSharpCodeNRefactoryLocation
---@param b ICSharpCodeNRefactoryLocation
---@return SystemBoolean
function m.op_LessThanOrEqual(a, b) end
---@param a ICSharpCodeNRefactoryLocation
---@param b ICSharpCodeNRefactoryLocation
---@return SystemBoolean
function m.op_GreaterThanOrEqual(a, b) end
---@return SystemString
function m:ToString() end
---@return SystemInt32
function m:GetHashCode() end
---@param obj SystemObject
---@return SystemBoolean
function m:Equals(obj) end
---@param other ICSharpCodeNRefactoryLocation
---@return SystemBoolean
function m:Equals(other) end
---@param other ICSharpCodeNRefactoryLocation
---@return SystemInt32
function m:CompareTo(other) end
ICSharpCodeNRefactoryLocation=m
return m;