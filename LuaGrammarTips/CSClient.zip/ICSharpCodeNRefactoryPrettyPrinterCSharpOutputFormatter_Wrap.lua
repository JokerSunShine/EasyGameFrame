---@class ICSharpCodeNRefactoryPrettyPrinterCSharpOutputFormatter : ICSharpCodeNRefactoryPrettyPrinterAbstractOutputFormatter
---instance properties
---@field public EmitSemicolon SystemBoolean
local m = {};
---@param token SystemInt32
function m:PrintToken(token) end
---@param style ICSharpCodeNRefactoryPrettyPrinterBraceStyle
---@param indent SystemBoolean
function m:BeginBrace(style, indent) end
---@param indent SystemBoolean
function m:EndBrace(indent) end
---@param indent SystemBoolean
---@param emitNewLine SystemBoolean
function m:EndBrace(indent, emitNewLine) end
---@param identifier SystemString
function m:PrintIdentifier(identifier) end
---@param comment ICSharpCodeNRefactoryComment
---@param forceWriteInPreviousBlock SystemBoolean
function m:PrintComment(comment, forceWriteInPreviousBlock) end
ICSharpCodeNRefactoryPrettyPrinterCSharpOutputFormatter=m
return m;