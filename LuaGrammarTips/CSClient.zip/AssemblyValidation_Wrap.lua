---@class AssemblyValidation
local m = {};
---@param platform UnityEngineRuntimePlatform
---@param userAssemblies SystemCollectionsGenericIEnumerable1SystemString
---@param options SystemObject
---@return ValidationResult
function m.Validate(platform, userAssemblies, options) end
AssemblyValidation=m
return m;