---@class AssemblyValidation
local m = {};
---@param platform UnityEngine.RuntimePlatform
---@param userAssemblies System.Collections.Generic.IEnumerable`1[System.String]
---@param options System.Object[]
---@return ValidationResult
function m.Validate(platform, userAssemblies, options) end
AssemblyValidation=m
return m;