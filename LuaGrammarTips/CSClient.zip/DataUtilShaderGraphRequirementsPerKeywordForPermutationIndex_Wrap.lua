---@class DataUtilShaderGraphRequirementsPerKeywordForPermutationIndex : SystemValueType
---instance properties
---@field public type DataUtilKeywordDependentCollectionKeywordPermutationInstanceType
---@field public instances SystemCollectionsGenericIEnumerable1DataUtilShaderGraphRequirementsPerKeywordIRequirements
---@field public instanceCount SystemInt32
---@field public permutationIndex SystemInt32
---@field public requirements UnityEditorShaderGraphInternalShaderGraphRequirements
local m = {};
---@param value UnityEditorShaderGraphInternalShaderGraphRequirements
function m:SetRequirements(value) end
DataUtilShaderGraphRequirementsPerKeywordForPermutationIndex=m
return m;