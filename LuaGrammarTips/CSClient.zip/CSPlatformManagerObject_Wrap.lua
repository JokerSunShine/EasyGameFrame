---@class CSPlatformManagerObject : ManagerObject
---properties
---@field public Instance CSPlatformManagerObject
---instance properties
---@field public GameManager Main
---@field public RunTimePlatform UnityEngineRuntimePlatform
---@field public BuildTargetGroup UnityEditorBuildTargetGroup
---@field public OperationPlatform OperationPlatform
---@field public PlatformInfo AbstractPlatformInfo
local m = {};
CSPlatformManagerObject=m
return m;