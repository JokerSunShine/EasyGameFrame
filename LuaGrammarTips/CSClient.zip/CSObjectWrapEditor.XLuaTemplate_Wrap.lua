---@class CSObjectWrapEditor.XLuaTemplate : System.ValueType
---instance fields
---@field public name System.String
---@field public text System.String
local m = {};
CSObjectWrapEditor.XLuaTemplate=m
return m;