---@class auctionV2.OpenTradeBeforeResponse
---instance properties
---@field public bagItemState System.Collections.Generic.List1auctionV2.BagItemState
local m = {};

auctionV2.OpenTradeBeforeResponse=m
return m;