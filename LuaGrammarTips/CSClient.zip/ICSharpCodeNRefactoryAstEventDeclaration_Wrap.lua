---@class ICSharpCodeNRefactoryAstEventDeclaration : ICSharpCodeNRefactoryAstMemberNode
---instance properties
---@field public AddRegion ICSharpCodeNRefactoryAstEventAddRegion
---@field public RemoveRegion ICSharpCodeNRefactoryAstEventRemoveRegion
---@field public RaiseRegion ICSharpCodeNRefactoryAstEventRaiseRegion
---@field public BodyStart ICSharpCodeNRefactoryLocation
---@field public BodyEnd ICSharpCodeNRefactoryLocation
---@field public Initializer ICSharpCodeNRefactoryAstExpression
---@field public HasRemoveRegion SystemBoolean
---@field public HasRaiseRegion SystemBoolean
---@field public HasAddRegion SystemBoolean
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstEventDeclaration=m
return m;