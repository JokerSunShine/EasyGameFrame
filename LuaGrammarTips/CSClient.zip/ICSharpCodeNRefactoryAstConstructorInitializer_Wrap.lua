---@class ICSharpCodeNRefactoryAstConstructorInitializer : ICSharpCodeNRefactoryAstAbstractNode
---properties
---@field public Null ICSharpCodeNRefactoryAstConstructorInitializer
---instance properties
---@field public ConstructorInitializerType ICSharpCodeNRefactoryAstConstructorInitializerType
---@field public Arguments SystemCollectionsGenericList1ICSharpCodeNRefactoryAstExpression
---@field public IsNull SystemBoolean
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstConstructorInitializer=m
return m;