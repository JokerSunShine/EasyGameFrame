---@class ExampleConfig
---fields
---@field public BlackList SystemCollectionsGenericList1SystemCollectionsGenericList1SystemString
local m = {};
ExampleConfig=m
return m;