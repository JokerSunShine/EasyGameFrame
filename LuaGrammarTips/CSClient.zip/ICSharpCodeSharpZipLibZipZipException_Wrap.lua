---@class ICSharpCodeSharpZipLibZipZipException : ICSharpCodeSharpZipLibSharpZipBaseException
local m = {};
ICSharpCodeSharpZipLibZipZipException=m
return m;