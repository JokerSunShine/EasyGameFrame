---@class ExCSSModelTextBlocksNumericBlock : ExCSSModelTextBlocksBlock
---instance properties
---@field public Value SystemSingle
local m = {};
---@return SystemString
function m:ToString() end
ExCSSModelTextBlocksNumericBlock=m
return m;