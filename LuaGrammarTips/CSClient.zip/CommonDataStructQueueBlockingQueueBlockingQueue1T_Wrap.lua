---@class CommonDataStructQueueBlockingQueueBlockingQueue1T
---instance properties
---@field public Count SystemInt32
local m = {};
---@param item T
function m:Enqueue(item) end
---@param value T @out
---@return SystemBoolean
function m:TryDequeue(value) end
function m:Close() end
CommonDataStructQueueBlockingQueueBlockingQueue1T=m
return m;