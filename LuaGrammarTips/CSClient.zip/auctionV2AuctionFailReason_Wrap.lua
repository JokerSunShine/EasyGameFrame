---@class auctionV2.AuctionFailReason
---instance properties
---@field public failReason System.Int32
---@field public failReasonSpecified System.Boolean
local m = {};

auctionV2.AuctionFailReason=m
return m;