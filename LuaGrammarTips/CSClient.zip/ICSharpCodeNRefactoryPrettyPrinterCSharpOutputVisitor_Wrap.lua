---@class ICSharpCodeNRefactoryPrettyPrinterCSharpOutputVisitor : ICSharpCodeNRefactoryVisitorsNodeTrackingAstVisitor
---instance properties
---@field public Text SystemString
---@field public Errors ICSharpCodeNRefactoryParserErrors
---@field public Options ICSharpCodeNRefactoryPrettyPrinterPrettyPrintOptions
---@field public OutputFormatter ICSharpCodeNRefactoryPrettyPrinterIOutputFormatter
local m = {};
---@param value SystemAction1ICSharpCodeNRefactoryAstINode
function m:add_BeforeNodeVisit(value) end
---@param value SystemAction1ICSharpCodeNRefactoryAstINode
function m:remove_BeforeNodeVisit(value) end
---@param value SystemAction1ICSharpCodeNRefactoryAstINode
function m:add_AfterNodeVisit(value) end
---@param value SystemAction1ICSharpCodeNRefactoryAstINode
function m:remove_AfterNodeVisit(value) end
---@param compilationUnit ICSharpCodeNRefactoryAstCompilationUnit
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitCompilationUnit(compilationUnit, data) end
---@param typeReference ICSharpCodeNRefactoryAstTypeReference
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitTypeReference(typeReference, data) end
---@param innerClassTypeReference ICSharpCodeNRefactoryAstInnerClassTypeReference
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitInnerClassTypeReference(innerClassTypeReference, data) end
---@param attributeSection ICSharpCodeNRefactoryAstAttributeSection
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitAttributeSection(attributeSection, data) end
---@param attribute ICSharpCodeNRefactoryAstAttribute
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitAttribute(attribute, data) end
---@param namedArgumentExpression ICSharpCodeNRefactoryAstNamedArgumentExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitNamedArgumentExpression(namedArgumentExpression, data) end
---@param using ICSharpCodeNRefactoryAstUsing
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitUsing(using, data) end
---@param usingDeclaration ICSharpCodeNRefactoryAstUsingDeclaration
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitUsingDeclaration(usingDeclaration, data) end
---@param externAliasDirective ICSharpCodeNRefactoryAstExternAliasDirective
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitExternAliasDirective(externAliasDirective, data) end
---@param namespaceDeclaration ICSharpCodeNRefactoryAstNamespaceDeclaration
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitNamespaceDeclaration(namespaceDeclaration, data) end
---@param typeDeclaration ICSharpCodeNRefactoryAstTypeDeclaration
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitTypeDeclaration(typeDeclaration, data) end
---@param templateDefinition ICSharpCodeNRefactoryAstTemplateDefinition
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitTemplateDefinition(templateDefinition, data) end
---@param delegateDeclaration ICSharpCodeNRefactoryAstDelegateDeclaration
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitDelegateDeclaration(delegateDeclaration, data) end
---@param optionDeclaration ICSharpCodeNRefactoryAstOptionDeclaration
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitOptionDeclaration(optionDeclaration, data) end
---@param fieldDeclaration ICSharpCodeNRefactoryAstFieldDeclaration
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitFieldDeclaration(fieldDeclaration, data) end
---@param variableDeclaration ICSharpCodeNRefactoryAstVariableDeclaration
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitVariableDeclaration(variableDeclaration, data) end
---@param propertyDeclaration ICSharpCodeNRefactoryAstPropertyDeclaration
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitPropertyDeclaration(propertyDeclaration, data) end
---@param propertyGetRegion ICSharpCodeNRefactoryAstPropertyGetRegion
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitPropertyGetRegion(propertyGetRegion, data) end
---@param propertySetRegion ICSharpCodeNRefactoryAstPropertySetRegion
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitPropertySetRegion(propertySetRegion, data) end
---@param eventDeclaration ICSharpCodeNRefactoryAstEventDeclaration
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitEventDeclaration(eventDeclaration, data) end
---@param eventAddRegion ICSharpCodeNRefactoryAstEventAddRegion
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitEventAddRegion(eventAddRegion, data) end
---@param eventRemoveRegion ICSharpCodeNRefactoryAstEventRemoveRegion
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitEventRemoveRegion(eventRemoveRegion, data) end
---@param eventRaiseRegion ICSharpCodeNRefactoryAstEventRaiseRegion
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitEventRaiseRegion(eventRaiseRegion, data) end
---@param parameterDeclarationExpression ICSharpCodeNRefactoryAstParameterDeclarationExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitParameterDeclarationExpression(parameterDeclarationExpression, data) end
---@param methodDeclaration ICSharpCodeNRefactoryAstMethodDeclaration
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitMethodDeclaration(methodDeclaration, data) end
---@param operatorDeclaration ICSharpCodeNRefactoryAstOperatorDeclaration
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitOperatorDeclaration(operatorDeclaration, data) end
---@param interfaceImplementation ICSharpCodeNRefactoryAstInterfaceImplementation
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitInterfaceImplementation(interfaceImplementation, data) end
---@param constructorDeclaration ICSharpCodeNRefactoryAstConstructorDeclaration
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitConstructorDeclaration(constructorDeclaration, data) end
---@param constructorInitializer ICSharpCodeNRefactoryAstConstructorInitializer
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitConstructorInitializer(constructorInitializer, data) end
---@param indexerDeclaration ICSharpCodeNRefactoryAstIndexerDeclaration
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitIndexerDeclaration(indexerDeclaration, data) end
---@param destructorDeclaration ICSharpCodeNRefactoryAstDestructorDeclaration
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitDestructorDeclaration(destructorDeclaration, data) end
---@param declareDeclaration ICSharpCodeNRefactoryAstDeclareDeclaration
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitDeclareDeclaration(declareDeclaration, data) end
---@param blockStatement ICSharpCodeNRefactoryAstBlockStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitBlockStatement(blockStatement, data) end
---@param addHandlerStatement ICSharpCodeNRefactoryAstAddHandlerStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitAddHandlerStatement(addHandlerStatement, data) end
---@param removeHandlerStatement ICSharpCodeNRefactoryAstRemoveHandlerStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitRemoveHandlerStatement(removeHandlerStatement, data) end
---@param raiseEventStatement ICSharpCodeNRefactoryAstRaiseEventStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitRaiseEventStatement(raiseEventStatement, data) end
---@param eraseStatement ICSharpCodeNRefactoryAstEraseStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitEraseStatement(eraseStatement, data) end
---@param errorStatement ICSharpCodeNRefactoryAstErrorStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitErrorStatement(errorStatement, data) end
---@param onErrorStatement ICSharpCodeNRefactoryAstOnErrorStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitOnErrorStatement(onErrorStatement, data) end
---@param reDimStatement ICSharpCodeNRefactoryAstReDimStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitReDimStatement(reDimStatement, data) end
---@param expressionStatement ICSharpCodeNRefactoryAstExpressionStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitExpressionStatement(expressionStatement, data) end
---@param localVariableDeclaration ICSharpCodeNRefactoryAstLocalVariableDeclaration
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitLocalVariableDeclaration(localVariableDeclaration, data) end
---@param emptyStatement ICSharpCodeNRefactoryAstEmptyStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitEmptyStatement(emptyStatement, data) end
---@param yieldStatement ICSharpCodeNRefactoryAstYieldStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitYieldStatement(yieldStatement, data) end
---@param returnStatement ICSharpCodeNRefactoryAstReturnStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitReturnStatement(returnStatement, data) end
---@param ifElseStatement ICSharpCodeNRefactoryAstIfElseStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitIfElseStatement(ifElseStatement, data) end
---@param elseIfSection ICSharpCodeNRefactoryAstElseIfSection
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitElseIfSection(elseIfSection, data) end
---@param forStatement ICSharpCodeNRefactoryAstForStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitForStatement(forStatement, data) end
---@param labelStatement ICSharpCodeNRefactoryAstLabelStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitLabelStatement(labelStatement, data) end
---@param gotoStatement ICSharpCodeNRefactoryAstGotoStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitGotoStatement(gotoStatement, data) end
---@param switchStatement ICSharpCodeNRefactoryAstSwitchStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitSwitchStatement(switchStatement, data) end
---@param switchSection ICSharpCodeNRefactoryAstSwitchSection
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitSwitchSection(switchSection, data) end
---@param caseLabel ICSharpCodeNRefactoryAstCaseLabel
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitCaseLabel(caseLabel, data) end
---@param breakStatement ICSharpCodeNRefactoryAstBreakStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitBreakStatement(breakStatement, data) end
---@param stopStatement ICSharpCodeNRefactoryAstStopStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitStopStatement(stopStatement, data) end
---@param resumeStatement ICSharpCodeNRefactoryAstResumeStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitResumeStatement(resumeStatement, data) end
---@param endStatement ICSharpCodeNRefactoryAstEndStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitEndStatement(endStatement, data) end
---@param continueStatement ICSharpCodeNRefactoryAstContinueStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitContinueStatement(continueStatement, data) end
---@param gotoCaseStatement ICSharpCodeNRefactoryAstGotoCaseStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitGotoCaseStatement(gotoCaseStatement, data) end
---@param doLoopStatement ICSharpCodeNRefactoryAstDoLoopStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitDoLoopStatement(doLoopStatement, data) end
---@param foreachStatement ICSharpCodeNRefactoryAstForeachStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitForeachStatement(foreachStatement, data) end
---@param lockStatement ICSharpCodeNRefactoryAstLockStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitLockStatement(lockStatement, data) end
---@param usingStatement ICSharpCodeNRefactoryAstUsingStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitUsingStatement(usingStatement, data) end
---@param withStatement ICSharpCodeNRefactoryAstWithStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitWithStatement(withStatement, data) end
---@param tryCatchStatement ICSharpCodeNRefactoryAstTryCatchStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitTryCatchStatement(tryCatchStatement, data) end
---@param catchClause ICSharpCodeNRefactoryAstCatchClause
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitCatchClause(catchClause, data) end
---@param throwStatement ICSharpCodeNRefactoryAstThrowStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitThrowStatement(throwStatement, data) end
---@param fixedStatement ICSharpCodeNRefactoryAstFixedStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitFixedStatement(fixedStatement, data) end
---@param unsafeStatement ICSharpCodeNRefactoryAstUnsafeStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitUnsafeStatement(unsafeStatement, data) end
---@param checkedStatement ICSharpCodeNRefactoryAstCheckedStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitCheckedStatement(checkedStatement, data) end
---@param uncheckedStatement ICSharpCodeNRefactoryAstUncheckedStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitUncheckedStatement(uncheckedStatement, data) end
---@param exitStatement ICSharpCodeNRefactoryAstExitStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitExitStatement(exitStatement, data) end
---@param forNextStatement ICSharpCodeNRefactoryAstForNextStatement
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitForNextStatement(forNextStatement, data) end
---@param classReferenceExpression ICSharpCodeNRefactoryAstClassReferenceExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitClassReferenceExpression(classReferenceExpression, data) end
---@param primitiveExpression ICSharpCodeNRefactoryAstPrimitiveExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitPrimitiveExpression(primitiveExpression, data) end
---@param binaryOperatorExpression ICSharpCodeNRefactoryAstBinaryOperatorExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitBinaryOperatorExpression(binaryOperatorExpression, data) end
---@param parenthesizedExpression ICSharpCodeNRefactoryAstParenthesizedExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitParenthesizedExpression(parenthesizedExpression, data) end
---@param invocationExpression ICSharpCodeNRefactoryAstInvocationExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitInvocationExpression(invocationExpression, data) end
---@param identifierExpression ICSharpCodeNRefactoryAstIdentifierExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitIdentifierExpression(identifierExpression, data) end
---@param typeReferenceExpression ICSharpCodeNRefactoryAstTypeReferenceExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitTypeReferenceExpression(typeReferenceExpression, data) end
---@param unaryOperatorExpression ICSharpCodeNRefactoryAstUnaryOperatorExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitUnaryOperatorExpression(unaryOperatorExpression, data) end
---@param assignmentExpression ICSharpCodeNRefactoryAstAssignmentExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitAssignmentExpression(assignmentExpression, data) end
---@param sizeOfExpression ICSharpCodeNRefactoryAstSizeOfExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitSizeOfExpression(sizeOfExpression, data) end
---@param typeOfExpression ICSharpCodeNRefactoryAstTypeOfExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitTypeOfExpression(typeOfExpression, data) end
---@param defaultValueExpression ICSharpCodeNRefactoryAstDefaultValueExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitDefaultValueExpression(defaultValueExpression, data) end
---@param typeOfIsExpression ICSharpCodeNRefactoryAstTypeOfIsExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitTypeOfIsExpression(typeOfIsExpression, data) end
---@param addressOfExpression ICSharpCodeNRefactoryAstAddressOfExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitAddressOfExpression(addressOfExpression, data) end
---@param anonymousMethodExpression ICSharpCodeNRefactoryAstAnonymousMethodExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitAnonymousMethodExpression(anonymousMethodExpression, data) end
---@param lambdaExpression ICSharpCodeNRefactoryAstLambdaExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitLambdaExpression(lambdaExpression, data) end
---@param checkedExpression ICSharpCodeNRefactoryAstCheckedExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitCheckedExpression(checkedExpression, data) end
---@param uncheckedExpression ICSharpCodeNRefactoryAstUncheckedExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitUncheckedExpression(uncheckedExpression, data) end
---@param pointerReferenceExpression ICSharpCodeNRefactoryAstPointerReferenceExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitPointerReferenceExpression(pointerReferenceExpression, data) end
---@param castExpression ICSharpCodeNRefactoryAstCastExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitCastExpression(castExpression, data) end
---@param stackAllocExpression ICSharpCodeNRefactoryAstStackAllocExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitStackAllocExpression(stackAllocExpression, data) end
---@param indexerExpression ICSharpCodeNRefactoryAstIndexerExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitIndexerExpression(indexerExpression, data) end
---@param thisReferenceExpression ICSharpCodeNRefactoryAstThisReferenceExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitThisReferenceExpression(thisReferenceExpression, data) end
---@param baseReferenceExpression ICSharpCodeNRefactoryAstBaseReferenceExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitBaseReferenceExpression(baseReferenceExpression, data) end
---@param objectCreateExpression ICSharpCodeNRefactoryAstObjectCreateExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitObjectCreateExpression(objectCreateExpression, data) end
---@param arrayCreateExpression ICSharpCodeNRefactoryAstArrayCreateExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitArrayCreateExpression(arrayCreateExpression, data) end
---@param memberReferenceExpression ICSharpCodeNRefactoryAstMemberReferenceExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitMemberReferenceExpression(memberReferenceExpression, data) end
---@param directionExpression ICSharpCodeNRefactoryAstDirectionExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitDirectionExpression(directionExpression, data) end
---@param arrayInitializerExpression ICSharpCodeNRefactoryAstCollectionInitializerExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitCollectionInitializerExpression(arrayInitializerExpression, data) end
---@param conditionalExpression ICSharpCodeNRefactoryAstConditionalExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitConditionalExpression(conditionalExpression, data) end
function m:Reset() end
---@param queryExpression ICSharpCodeNRefactoryAstQueryExpression
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitQueryExpression(queryExpression, data) end
---@param fromClause ICSharpCodeNRefactoryAstQueryExpressionFromClause
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitQueryExpressionFromClause(fromClause, data) end
---@param joinClause ICSharpCodeNRefactoryAstQueryExpressionJoinClause
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitQueryExpressionJoinClause(joinClause, data) end
---@param letClause ICSharpCodeNRefactoryAstQueryExpressionLetClause
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitQueryExpressionLetClause(letClause, data) end
---@param groupClause ICSharpCodeNRefactoryAstQueryExpressionGroupClause
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitQueryExpressionGroupClause(groupClause, data) end
---@param queryExpressionOrderClause ICSharpCodeNRefactoryAstQueryExpressionOrderClause
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitQueryExpressionOrderClause(queryExpressionOrderClause, data) end
---@param ordering ICSharpCodeNRefactoryAstQueryExpressionOrdering
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitQueryExpressionOrdering(ordering, data) end
---@param selectClause ICSharpCodeNRefactoryAstQueryExpressionSelectClause
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitQueryExpressionSelectClause(selectClause, data) end
---@param whereClause ICSharpCodeNRefactoryAstQueryExpressionWhereClause
---@param data SystemObject
---@return SystemObject
function m:TrackedVisitQueryExpressionWhereClause(whereClause, data) end
ICSharpCodeNRefactoryPrettyPrinterCSharpOutputVisitor=m
return m;