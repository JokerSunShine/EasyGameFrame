---@class CSObjectWrapEditor.Generator+GetTasks : System.MulticastDelegate
local m = {};
---@param lua_env XLua.LuaEnv
---@param user_cfg CSObjectWrapEditor.UserConfig
---@return System.Collections.Generic.IEnumerable`1[CSObjectWrapEditor.CustomGenTask]
function m:Invoke(lua_env, user_cfg) end
---@param lua_env XLua.LuaEnv
---@param user_cfg CSObjectWrapEditor.UserConfig
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(lua_env, user_cfg, callback, object) end
---@param result System.IAsyncResult
---@return System.Collections.Generic.IEnumerable`1[CSObjectWrapEditor.CustomGenTask]
function m:EndInvoke(result) end
CSObjectWrapEditor.Generator+GetTasks=m
return m;