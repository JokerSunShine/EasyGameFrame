---@class auctionV2.AuctionItemList
---instance properties
---@field public items System.Collections.Generic.List1auctionV2.AuctionItemInfo
---@field public page System.Int32
---@field public pageSpecified System.Boolean
---@field public toatlPageCount System.Int32
---@field public toatlPageCountSpecified System.Boolean
---@field public isUnionSmelt System.Boolean
---@field public isUnionSmeltSpecified System.Boolean
local m = {};

auctionV2.AuctionItemList=m
return m;