---@class ICSharpCodeNRefactoryAstQueryExpressionSelectVBClause : ICSharpCodeNRefactoryAstQueryExpressionClause
---instance properties
---@field public Variables SystemCollectionsGenericList1ICSharpCodeNRefactoryAstExpressionRangeVariable
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstQueryExpressionSelectVBClause=m
return m;