---@class DataUtilShaderGraphRequirementsPerKeywordBase : SystemValueType
---instance properties
---@field public instanceCount SystemInt32
---@field public permutationIndex SystemInt32
---@field public type DataUtilKeywordDependentCollectionKeywordPermutationInstanceType
---@field public instances SystemCollectionsGenericIEnumerable1DataUtilShaderGraphRequirementsPerKeywordIRequirements
---@field public requirements UnityEditorShaderGraphInternalShaderGraphRequirements
local m = {};
---@param value UnityEditorShaderGraphInternalShaderGraphRequirements
function m:SetRequirements(value) end
DataUtilShaderGraphRequirementsPerKeywordBase=m
return m;