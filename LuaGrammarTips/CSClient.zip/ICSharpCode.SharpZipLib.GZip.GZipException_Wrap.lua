---@class ICSharpCode.SharpZipLib.GZip.GZipException : ICSharpCode.SharpZipLib.SharpZipBaseException
local m = {};
ICSharpCode.SharpZipLib.GZip.GZipException=m
return m;