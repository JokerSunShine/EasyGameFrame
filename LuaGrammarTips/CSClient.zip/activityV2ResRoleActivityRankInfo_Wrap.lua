---@class activityV2.ResRoleActivityRankInfo
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public rankParam System.Int32
---@field public rankParamSpecified System.Boolean
local m = {};

activityV2.ResRoleActivityRankInfo=m
return m;