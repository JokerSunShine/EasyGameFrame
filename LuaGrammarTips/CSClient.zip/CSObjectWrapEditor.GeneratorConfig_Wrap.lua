---@class CSObjectWrapEditor.GeneratorConfig
---fields
---@field public common_path System.String
local m = {};
CSObjectWrapEditor.GeneratorConfig=m
return m;