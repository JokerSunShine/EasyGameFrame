---@class ICSharpCode.NRefactory.Ast.DestructorDeclaration : ICSharpCode.NRefactory.Ast.AttributedNode
---instance properties
---@field public Name System.String
---@field public Body ICSharpCode.NRefactory.Ast.BlockStatement
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.DestructorDeclaration=m
return m;