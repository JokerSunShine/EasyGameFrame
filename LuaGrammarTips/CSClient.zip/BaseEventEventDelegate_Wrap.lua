---@class BaseEventEventDelegate
---instance properties
---@field public EvtID System.UInt32
local m = {};

---@return System.Int32
function m:GetCallBackCount() end
---@param cb BaseEventCallback
function m:AddCallBack(cb) end
---@param cb BaseEventCallback
function m:RemoveCallBack(cb) end
---@param objData System.Object
function m:ProcEvent(objData) end
---@return System.Single
function m:GetStopwatchTime() end
BaseEventEventDelegate=m
return m;