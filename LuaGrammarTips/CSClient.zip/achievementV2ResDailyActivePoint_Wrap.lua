---@class achievementV2.ResDailyActivePoint
---instance properties
---@field public dailyActivePoint System.Int32
---@field public dailyActivePointSpecified System.Boolean
local m = {};

achievementV2.ResDailyActivePoint=m
return m;