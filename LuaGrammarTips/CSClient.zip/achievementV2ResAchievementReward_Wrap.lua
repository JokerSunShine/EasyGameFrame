---@class achievementV2.ResAchievementReward
---instance properties
---@field public achievementInfo achievementV2.AchievementInfo
---@field public point System.Int32
---@field public pointSpecified System.Boolean
local m = {};

achievementV2.ResAchievementReward=m
return m;