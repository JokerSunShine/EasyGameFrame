---@class ICSharpCode.SharpZipLib.BZip2.BZip2Constants
---fields
---@field public rNums System.Int32[]
---@field public baseBlockSize System.Int32
---@field public MAX_ALPHA_SIZE System.Int32
---@field public MAX_CODE_LEN System.Int32
---@field public RUNA System.Int32
---@field public RUNB System.Int32
---@field public N_GROUPS System.Int32
---@field public G_SIZE System.Int32
---@field public N_ITERS System.Int32
---@field public MAX_SELECTORS System.Int32
---@field public NUM_OVERSHOOT_BYTES System.Int32
local m = {};
ICSharpCode.SharpZipLib.BZip2.BZip2Constants=m
return m;