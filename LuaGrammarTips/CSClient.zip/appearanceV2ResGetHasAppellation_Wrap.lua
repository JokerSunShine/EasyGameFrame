---@class appearanceV2.ResGetHasAppellation
---instance properties
---@field public titleInfo System.Collections.Generic.List1appearanceV2.TitleInfo
local m = {};

appearanceV2.ResGetHasAppellation=m
return m;