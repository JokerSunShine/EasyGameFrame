---@class ICSharpCodeNRefactoryParserToken
---instance properties
---@field public Kind SystemInt32
---@field public LiteralFormat ICSharpCodeNRefactoryParserLiteralFormat
---@field public LiteralValue SystemObject
---@field public Value SystemString
---@field public EndLocation ICSharpCodeNRefactoryLocation
---@field public Location ICSharpCodeNRefactoryLocation
local m = {};
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryParserToken=m
return m;