---@class appearanceV2.FashionType
---instance properties
---@field public subType System.Int32
---@field public subTypeSpecified System.Boolean
---@field public itemList System.Collections.Generic.List1bagV2.BagItemInfo
local m = {};

appearanceV2.FashionType=m
return m;