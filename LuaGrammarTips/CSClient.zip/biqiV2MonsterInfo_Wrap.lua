---@class biqiV2.MonsterInfo
---instance properties
---@field public lid System.Int64
---@field public lidSpecified System.Boolean
---@field public mid System.Int32
---@field public midSpecified System.Boolean
---@field public x System.Int32
---@field public xSpecified System.Boolean
---@field public y System.Int32
---@field public ySpecified System.Boolean
local m = {};

biqiV2.MonsterInfo=m
return m;