---@class ExCSS.NamespaceRule : ExCSS.RuleSet
---instance properties
---@field public Uri System.String
---@field public Prefix System.String
local m = {};
---@return System.String
function m:ToString() end
---@param friendlyFormat System.Boolean
---@param indentation System.Int32 @default_value:0
---@return System.String
function m:ToString(friendlyFormat, indentation) end
ExCSS.NamespaceRule=m
return m;