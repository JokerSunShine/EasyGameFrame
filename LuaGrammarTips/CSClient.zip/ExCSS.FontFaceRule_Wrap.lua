---@class ExCSS.FontFaceRule : ExCSS.RuleSet
---instance properties
---@field public Declarations ExCSS.StyleDeclaration
---@field public FontFamily System.String
---@field public Src System.String
---@field public FontStyle System.String
---@field public FontWeight System.String
---@field public Stretch System.String
---@field public UnicodeRange System.String
---@field public FontVariant System.String
---@field public FeatureSettings System.String
local m = {};
---@return System.String
function m:ToString() end
---@param friendlyFormat System.Boolean
---@param indentation System.Int32 @default_value:0
---@return System.String
function m:ToString(friendlyFormat, indentation) end
ExCSS.FontFaceRule=m
return m;