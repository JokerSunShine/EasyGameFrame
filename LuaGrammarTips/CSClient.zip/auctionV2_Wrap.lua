auctionV2 = {};
