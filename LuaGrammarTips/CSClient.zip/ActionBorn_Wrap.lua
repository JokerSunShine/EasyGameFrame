---@class ActionBorn : BehaviorState
---instance properties
---@field public Behavior System.Int32
local m = {};

---@param avater ISFAvater
---@param lastBehv BehaviorState
function m:Start(avater, lastBehv) end
---@param avater ISFAvater
---@param nextBehv BehaviorState
function m:End(avater, nextBehv) end
---@param avater ISFAvater
---@return System.Int32
function m:Update(avater) end
ActionBorn=m
return m;