---@class auctionV2.AddToShelfRequest
---instance properties
---@field public lid System.Int64
---@field public lidSpecified System.Boolean
---@field public count System.Int32
---@field public countSpecified System.Boolean
---@field public price bagV2.CoinInfo
---@field public itemType System.Int32
---@field public itemTypeSpecified System.Boolean
---@field public isPublicity System.Boolean
---@field public isPublicitySpecified System.Boolean
---@field public fixedPrice System.Int64
---@field public fixedPriceSpecified System.Boolean
local m = {};

auctionV2.AddToShelfRequest=m
return m;