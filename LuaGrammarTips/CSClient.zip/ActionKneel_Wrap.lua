---@class ActionKneel : BehaviorState
---instance properties
---@field public Behavior System.Int32
local m = {};

---@param avater ISFAvater
---@param lastBehv BehaviorState
function m:Start(avater, lastBehv) end
---@param avater ISFAvater
---@return System.Int32
function m:Update(avater) end
---@param avater ISFAvater
---@param next BehaviorState
function m:End(avater, next) end
ActionKneel=m
return m;