---@class appearanceV2.wearPosition
---instance properties
---@field public index System.Int32
---@field public indexSpecified System.Boolean
---@field public id System.Int32
---@field public idSpecified System.Boolean
local m = {};

appearanceV2.wearPosition=m
return m;