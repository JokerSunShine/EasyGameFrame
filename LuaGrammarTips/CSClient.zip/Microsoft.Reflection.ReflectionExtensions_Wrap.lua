---@class Microsoft.Reflection.ReflectionExtensions
local m = {};
---@param type System.Type
---@return System.Boolean
function m.IsEnum(type) end
---@param type System.Type
---@return System.Boolean
function m.IsAbstract(type) end
---@param type System.Type
---@return System.Boolean
function m.IsSealed(type) end
---@param type System.Type
---@return System.Type
function m.BaseType(type) end
---@param type System.Type
---@return System.Reflection.Assembly
function m.Assembly(type) end
---@param type System.Type
---@return System.TypeCode
function m.GetTypeCode(type) end
---@param assm System.Reflection.Assembly
---@return System.Boolean
function m.ReflectionOnly(assm) end
Microsoft.Reflection.ReflectionExtensions=m
return m;