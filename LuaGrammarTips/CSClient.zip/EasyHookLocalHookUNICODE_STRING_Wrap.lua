---@class EasyHookLocalHookUNICODE_STRING
---instance fields
---@field public Length SystemInt16
---@field public MaximumLength SystemInt16
---@field public Buffer SystemString
local m = {};
EasyHookLocalHookUNICODE_STRING=m
return m;