---@class bossDigV2.ResSendWorldBossInfo
---instance properties
---@field public worldBossInfo System.Collections.Generic.List1bossDigV2.WorldBossInfo
local m = {};

bossDigV2.ResSendWorldBossInfo=m
return m;