---@class BagWrapContent : UnityEngine.MonoBehaviour
---instance fields
---@field public itemSize System.Int32
---@field public maxIndex System.Int32
---@field public minIndex System.Int32
---@field public onInitializeItem BagWrapContentOnInitializeItem
local m = {};

---@param panel UIPanel
function m:WrapContent(panel) end
BagWrapContent=m
return m;