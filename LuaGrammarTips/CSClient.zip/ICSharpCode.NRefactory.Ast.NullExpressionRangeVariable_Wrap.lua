---@class ICSharpCode.NRefactory.Ast.NullExpressionRangeVariable : ICSharpCode.NRefactory.Ast.ExpressionRangeVariable
---instance properties
---@field public IsNull System.Boolean
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.NullExpressionRangeVariable=m
return m;