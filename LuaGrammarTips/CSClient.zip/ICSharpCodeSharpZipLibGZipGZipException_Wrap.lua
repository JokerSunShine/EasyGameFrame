---@class ICSharpCodeSharpZipLibGZipGZipException : ICSharpCodeSharpZipLibSharpZipBaseException
local m = {};
ICSharpCodeSharpZipLibGZipGZipException=m
return m;