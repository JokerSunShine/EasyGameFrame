---@class backV2.ReqBackLookRank
---instance properties
---@field public type System.Int32
---@field public typeSpecified System.Boolean
local m = {};

backV2.ReqBackLookRank=m
return m;