---@class activityV2.ReqDrawTimeLimitTaskReward
---instance properties
---@field public rate System.Int32
---@field public rateSpecified System.Boolean
---@field public taskId System.Int32
---@field public taskIdSpecified System.Boolean
local m = {};

activityV2.ReqDrawTimeLimitTaskReward=m
return m;