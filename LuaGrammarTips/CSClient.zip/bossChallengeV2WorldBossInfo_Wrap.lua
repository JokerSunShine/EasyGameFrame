---@class bossChallengeV2.WorldBossInfo
---instance properties
---@field public id System.Int32
---@field public idSpecified System.Boolean
---@field public state System.Int32
---@field public stateSpecified System.Boolean
---@field public nextRereshTime System.Int32
---@field public nextRereshTimeSpecified System.Boolean
local m = {};

bossChallengeV2.WorldBossInfo=m
return m;