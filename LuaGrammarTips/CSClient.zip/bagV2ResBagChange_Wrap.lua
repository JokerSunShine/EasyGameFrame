---@class bagV2.ResBagChange
---instance properties
---@field public action System.Int32
---@field public actionSpecified System.Boolean
---@field public itemList System.Collections.Generic.List1bagV2.BagItemInfo
---@field public coinList System.Collections.Generic.List1bagV2.CoinInfo
---@field public removedIdList System.Collections.Generic.List1System.Int64
---@field public removeItemList System.Collections.Generic.List1bagV2.BagItemInfo
local m = {};

bagV2.ResBagChange=m
return m;