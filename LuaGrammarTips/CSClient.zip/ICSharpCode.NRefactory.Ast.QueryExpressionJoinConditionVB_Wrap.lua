---@class ICSharpCode.NRefactory.Ast.QueryExpressionJoinConditionVB : ICSharpCode.NRefactory.Ast.AbstractNode
---instance properties
---@field public LeftSide ICSharpCode.NRefactory.Ast.Expression
---@field public RightSide ICSharpCode.NRefactory.Ast.Expression
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.QueryExpressionJoinConditionVB=m
return m;