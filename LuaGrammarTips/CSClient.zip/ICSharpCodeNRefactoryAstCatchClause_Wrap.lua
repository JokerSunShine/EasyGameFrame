---@class ICSharpCodeNRefactoryAstCatchClause : ICSharpCodeNRefactoryAstAbstractNode
---instance properties
---@field public TypeReference ICSharpCodeNRefactoryAstTypeReference
---@field public VariableName SystemString
---@field public StatementBlock ICSharpCodeNRefactoryAstStatement
---@field public Condition ICSharpCodeNRefactoryAstExpression
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstCatchClause=m
return m;