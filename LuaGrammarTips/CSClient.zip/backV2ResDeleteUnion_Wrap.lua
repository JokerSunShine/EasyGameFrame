---@class backV2.ResDeleteUnion
---instance properties
---@field public unionId System.Int32
---@field public unionIdSpecified System.Boolean
local m = {};

backV2.ResDeleteUnion=m
return m;