---@class BonfireModelLoad : ModelLoadBase3D2BonfireModelLoadCSBonfireGo
local m = {};

function m:Analyze() end
BonfireModelLoad=m
return m;