---@class MicrosoftWin32ExpandString
local m = {};
---@return SystemString
function m:ToString() end
---@return SystemString
function m:Expand() end
MicrosoftWin32ExpandString=m
return m;