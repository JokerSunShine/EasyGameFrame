---@class DesktopStandaloneUserBuildSettings
local m = {};
DesktopStandaloneUserBuildSettings=m
return m;