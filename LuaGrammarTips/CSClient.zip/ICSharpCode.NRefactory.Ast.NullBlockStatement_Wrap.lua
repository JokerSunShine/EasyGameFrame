---@class ICSharpCode.NRefactory.Ast.NullBlockStatement : ICSharpCode.NRefactory.Ast.BlockStatement
---fields
---@field public Instance ICSharpCode.NRefactory.Ast.NullBlockStatement
---instance properties
---@field public IsNull System.Boolean
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptChildren(visitor, data) end
---@param childNode ICSharpCode.NRefactory.Ast.INode
function m:AddChild(childNode) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.NullBlockStatement=m
return m;