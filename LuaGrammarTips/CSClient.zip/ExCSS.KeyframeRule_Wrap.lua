---@class ExCSS.KeyframeRule : ExCSS.RuleSet
---instance properties
---@field public Declarations ExCSS.StyleDeclaration
local m = {};
---@param value System.String
function m:AddValue(value) end
---@return System.String
function m:ToString() end
---@param friendlyFormat System.Boolean
---@param indentation System.Int32 @default_value:0
---@return System.String
function m:ToString(friendlyFormat, indentation) end
ExCSS.KeyframeRule=m
return m;