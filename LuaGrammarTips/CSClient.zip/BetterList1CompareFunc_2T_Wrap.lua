---@class BetterList1CompareFunc_2T : System.MulticastDelegate
local m = {};

---@param t T
---@param obj System.Object
---@return System.Boolean
function m:Invoke(t, obj) end
---@param t T
---@param obj System.Object
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(t, obj, callback, object) end
---@param result System.IAsyncResult
---@return System.Boolean
function m:EndInvoke(result) end
BetterList1CompareFunc_2T=m
return m;