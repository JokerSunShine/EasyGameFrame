---@class ExCSSComplexSelector : ExCSSBaseSelector
---instance properties
---@field public Length SystemInt32
local m = {};
---@param selector ExCSSBaseSelector
---@param combinator ExCSSCombinator
---@return ExCSSComplexSelector
function m:AppendSelector(selector, combinator) end
---@return SystemCollectionsGenericIEnumerator1ExCSSCombinatorSelector
function m:GetEnumerator() end
---@param friendlyFormat SystemBoolean
---@param indentation SystemInt32 @default_value:0
---@return SystemString
function m:ToString(friendlyFormat, indentation) end
ExCSSComplexSelector=m
return m;