---@class ICSharpCodeSharpZipLibZipFastZip
---instance properties
---@field public CreateEmptyDirectories SystemBoolean
---@field public NameTransform ICSharpCodeSharpZipLibZipZipNameTransform
local m = {};
---@param zipFileName SystemString
---@param sourceDirectory SystemString
---@param recurse SystemBoolean
---@param fileFilter SystemString
---@param directoryFilter SystemString
function m:CreateZip(zipFileName, sourceDirectory, recurse, fileFilter, directoryFilter) end
---@param zipFileName SystemString
---@param sourceDirectory SystemString
---@param recurse SystemBoolean
---@param fileFilter SystemString
function m:CreateZip(zipFileName, sourceDirectory, recurse, fileFilter) end
---@param zipFileName SystemString
---@param targetDirectory SystemString
---@param fileFilter SystemString
function m:ExtractZip(zipFileName, targetDirectory, fileFilter) end
---@param zipFileName SystemString
---@param targetDirectory SystemString
---@param overwrite ICSharpCodeSharpZipLibZipFastZipOverwrite
---@param confirmDelegate ICSharpCodeSharpZipLibZipFastZipConfirmOverwriteDelegate
---@param fileFilter SystemString
---@param directoryFilter SystemString
function m:ExtractZip(zipFileName, targetDirectory, overwrite, confirmDelegate, fileFilter, directoryFilter) end
ICSharpCodeSharpZipLibZipFastZip=m
return m;