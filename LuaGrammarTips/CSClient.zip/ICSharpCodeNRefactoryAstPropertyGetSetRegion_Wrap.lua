---@class ICSharpCodeNRefactoryAstPropertyGetSetRegion : ICSharpCodeNRefactoryAstAttributedNode
---instance properties
---@field public Block ICSharpCodeNRefactoryAstBlockStatement
---@field public IsNull SystemBoolean
local m = {};
ICSharpCodeNRefactoryAstPropertyGetSetRegion=m
return m;