---@class activityV2.GroupInfoOfDay
---instance properties
---@field public group System.Int32
---@field public groupSpecified System.Boolean
---@field public indexInfo System.Collections.Generic.List1activityV2.IndexInfoOfDay
local m = {};

activityV2.GroupInfoOfDay=m
return m;