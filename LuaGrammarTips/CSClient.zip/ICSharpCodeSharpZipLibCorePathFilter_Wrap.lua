---@class ICSharpCodeSharpZipLibCorePathFilter
local m = {};
---@param name SystemString
---@return SystemBoolean
function m:IsMatch(name) end
ICSharpCodeSharpZipLibCorePathFilter=m
return m;