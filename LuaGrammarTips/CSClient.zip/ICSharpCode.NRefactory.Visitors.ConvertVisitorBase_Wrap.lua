---@class ICSharpCode.NRefactory.Visitors.ConvertVisitorBase : ICSharpCode.NRefactory.Visitors.AbstractAstTransformer
local m = {};
---@param typeDeclaration ICSharpCode.NRefactory.Ast.TypeDeclaration
---@param data System.Object
---@return System.Object
function m:VisitTypeDeclaration(typeDeclaration, data) end
ICSharpCode.NRefactory.Visitors.ConvertVisitorBase=m
return m;