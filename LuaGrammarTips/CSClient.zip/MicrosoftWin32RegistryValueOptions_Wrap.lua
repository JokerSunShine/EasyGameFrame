---@class MicrosoftWin32RegistryValueOptions
---@field None @0
---@field DoNotExpandEnvironmentNames @1
MicrosoftWin32RegistryValueOptions=m
return m;