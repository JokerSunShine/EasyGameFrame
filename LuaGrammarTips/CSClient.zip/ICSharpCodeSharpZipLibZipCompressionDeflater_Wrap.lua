---@class ICSharpCodeSharpZipLibZipCompressionDeflater
---fields
---@field public BEST_COMPRESSION SystemInt32
---@field public BEST_SPEED SystemInt32
---@field public DEFAULT_COMPRESSION SystemInt32
---@field public NO_COMPRESSION SystemInt32
---@field public DEFLATED SystemInt32
---instance properties
---@field public Adler SystemInt32
---@field public TotalIn SystemInt32
---@field public TotalOut SystemInt64
---@field public IsFinished SystemBoolean
---@field public IsNeedingInput SystemBoolean
local m = {};
function m:Reset() end
function m:Flush() end
function m:Finish() end
---@param input SystemByte
function m:SetInput(input) end
---@param input SystemByte
---@param off SystemInt32
---@param len SystemInt32
function m:SetInput(input, off, len) end
---@param lvl SystemInt32
function m:SetLevel(lvl) end
---@return SystemInt32
function m:GetLevel() end
---@param strategy ICSharpCodeSharpZipLibZipCompressionDeflateStrategy
function m:SetStrategy(strategy) end
---@param output SystemByte
---@return SystemInt32
function m:Deflate(output) end
---@param output SystemByte
---@param offset SystemInt32
---@param length SystemInt32
---@return SystemInt32
function m:Deflate(output, offset, length) end
---@param dict SystemByte
function m:SetDictionary(dict) end
---@param dict SystemByte
---@param offset SystemInt32
---@param length SystemInt32
function m:SetDictionary(dict, offset, length) end
ICSharpCodeSharpZipLibZipCompressionDeflater=m
return m;