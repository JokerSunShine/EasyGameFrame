---@class Microsoft.Win32.NativeMethods
---fields
---@field public E_ABORT System.Int32
---@field public PROCESS_TERMINATE System.Int32
---@field public PROCESS_CREATE_THREAD System.Int32
---@field public PROCESS_SET_SESSIONID System.Int32
---@field public PROCESS_VM_OPERATION System.Int32
---@field public PROCESS_VM_READ System.Int32
---@field public PROCESS_VM_WRITE System.Int32
---@field public PROCESS_DUP_HANDLE System.Int32
---@field public PROCESS_CREATE_PROCESS System.Int32
---@field public PROCESS_SET_QUOTA System.Int32
---@field public PROCESS_SET_INFORMATION System.Int32
---@field public PROCESS_QUERY_INFORMATION System.Int32
---@field public PROCESS_QUERY_LIMITED_INFORMATION System.Int32
---@field public STANDARD_RIGHTS_REQUIRED System.Int32
---@field public SYNCHRONIZE System.Int32
---@field public PROCESS_ALL_ACCESS System.Int32
---@field public DUPLICATE_CLOSE_SOURCE System.Int32
---@field public DUPLICATE_SAME_ACCESS System.Int32
---@field public STILL_ACTIVE System.Int32
---@field public WAIT_OBJECT_0 System.Int32
---@field public WAIT_FAILED System.Int32
---@field public WAIT_TIMEOUT System.Int32
---@field public WAIT_ABANDONED System.Int32
---@field public WAIT_ABANDONED_0 System.Int32
---@field public ERROR_FILE_NOT_FOUND System.Int32
---@field public ERROR_PATH_NOT_FOUND System.Int32
---@field public ERROR_ACCESS_DENIED System.Int32
---@field public ERROR_INVALID_HANDLE System.Int32
---@field public ERROR_SHARING_VIOLATION System.Int32
---@field public ERROR_INVALID_NAME System.Int32
---@field public ERROR_ALREADY_EXISTS System.Int32
---@field public ERROR_FILENAME_EXCED_RANGE System.Int32
local m = {};
---@param hSourceProcessHandle System.Runtime.InteropServices.HandleRef
---@param hSourceHandle System.Runtime.InteropServices.SafeHandle
---@param hTargetProcess System.Runtime.InteropServices.HandleRef
---@param targetHandle Microsoft.Win32.SafeHandles.SafeWaitHandle& @out
---@param dwDesiredAccess System.Int32
---@param bInheritHandle System.Boolean
---@param dwOptions System.Int32
---@return System.Boolean
function m.DuplicateHandle(hSourceProcessHandle, hSourceHandle, hTargetProcess, targetHandle, dwDesiredAccess, bInheritHandle, dwOptions) end
---@param hSourceProcessHandle System.Runtime.InteropServices.HandleRef
---@param hSourceHandle System.Runtime.InteropServices.HandleRef
---@param hTargetProcess System.Runtime.InteropServices.HandleRef
---@param targetHandle Microsoft.Win32.SafeHandles.SafeProcessHandle& @out
---@param dwDesiredAccess System.Int32
---@param bInheritHandle System.Boolean
---@param dwOptions System.Int32
---@return System.Boolean
function m.DuplicateHandle(hSourceProcessHandle, hSourceHandle, hTargetProcess, targetHandle, dwDesiredAccess, bInheritHandle, dwOptions) end
---@return System.IntPtr
function m.GetCurrentProcess() end
---@param processHandle System.IntPtr
---@param exitCode System.Int32& @out
---@return System.Boolean
function m.GetExitCodeProcess(processHandle, exitCode) end
---@param processHandle Microsoft.Win32.SafeHandles.SafeProcessHandle
---@param exitCode System.Int32& @out
---@return System.Boolean
function m.GetExitCodeProcess(processHandle, exitCode) end
---@param processHandle System.IntPtr
---@param exitCode System.Int32
---@return System.Boolean
function m.TerminateProcess(processHandle, exitCode) end
---@param processHandle Microsoft.Win32.SafeHandles.SafeProcessHandle
---@param exitCode System.Int32
---@return System.Boolean
function m.TerminateProcess(processHandle, exitCode) end
---@param handle System.IntPtr
---@param milliseconds System.Int32
---@return System.Int32
function m.WaitForInputIdle(handle, milliseconds) end
---@param handle Microsoft.Win32.SafeHandles.SafeProcessHandle
---@param milliseconds System.Int32
---@return System.Int32
function m.WaitForInputIdle(handle, milliseconds) end
---@param handle System.IntPtr
---@param min System.IntPtr& @out
---@param max System.IntPtr& @out
---@return System.Boolean
function m.GetProcessWorkingSetSize(handle, min, max) end
---@param handle Microsoft.Win32.SafeHandles.SafeProcessHandle
---@param min System.IntPtr& @out
---@param max System.IntPtr& @out
---@return System.Boolean
function m.GetProcessWorkingSetSize(handle, min, max) end
---@param handle System.IntPtr
---@param min System.IntPtr
---@param max System.IntPtr
---@return System.Boolean
function m.SetProcessWorkingSetSize(handle, min, max) end
---@param handle Microsoft.Win32.SafeHandles.SafeProcessHandle
---@param min System.IntPtr
---@param max System.IntPtr
---@return System.Boolean
function m.SetProcessWorkingSetSize(handle, min, max) end
---@param handle System.IntPtr
---@param creation System.Int64& @out
---@param exit System.Int64& @out
---@param kernel System.Int64& @out
---@param user System.Int64& @out
---@return System.Boolean
function m.GetProcessTimes(handle, creation, exit, kernel, user) end
---@param handle Microsoft.Win32.SafeHandles.SafeProcessHandle
---@param creation System.Int64& @out
---@param exit System.Int64& @out
---@param kernel System.Int64& @out
---@param user System.Int64& @out
---@return System.Boolean
function m.GetProcessTimes(handle, creation, exit, kernel, user) end
---@return System.Int32
function m.GetCurrentProcessId() end
---@param handle System.IntPtr
---@return System.Int32
function m.GetPriorityClass(handle) end
---@param handle Microsoft.Win32.SafeHandles.SafeProcessHandle
---@return System.Int32
function m.GetPriorityClass(handle) end
---@param handle System.IntPtr
---@param priorityClass System.Int32
---@return System.Boolean
function m.SetPriorityClass(handle, priorityClass) end
---@param handle Microsoft.Win32.SafeHandles.SafeProcessHandle
---@param priorityClass System.Int32
---@return System.Boolean
function m.SetPriorityClass(handle, priorityClass) end
---@param handle System.IntPtr
---@return System.Boolean
function m.CloseProcess(handle) end
Microsoft.Win32.NativeMethods=m
return m;