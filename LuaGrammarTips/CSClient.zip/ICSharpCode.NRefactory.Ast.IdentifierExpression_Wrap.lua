---@class ICSharpCode.NRefactory.Ast.IdentifierExpression : ICSharpCode.NRefactory.Ast.Expression
---instance properties
---@field public Identifier System.String
---@field public TypeArguments System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.TypeReference]
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.IdentifierExpression=m
return m;