---@class achievementV2.ResAddAchievement
---instance properties
---@field public achievementInfo achievementV2.AchievementInfo
local m = {};

achievementV2.ResAddAchievement=m
return m;