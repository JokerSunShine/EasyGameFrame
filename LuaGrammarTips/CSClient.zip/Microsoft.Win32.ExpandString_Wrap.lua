---@class Microsoft.Win32.ExpandString
local m = {};
---@return System.String
function m:ToString() end
---@return System.String
function m:Expand() end
Microsoft.Win32.ExpandString=m
return m;