---@class ICSharpCodeSharpZipLibBZip2BZip2OutputStream : SystemIOStream
---instance properties
---@field public CanRead SystemBoolean
---@field public CanSeek SystemBoolean
---@field public CanWrite SystemBoolean
---@field public Length SystemInt64
---@field public Position SystemInt64
local m = {};
---@param offset SystemInt64
---@param origin SystemIOSeekOrigin
---@return SystemInt64
function m:Seek(offset, origin) end
---@param val SystemInt64
function m:SetLength(val) end
---@return SystemInt32
function m:ReadByte() end
---@param b SystemByte
---@param off SystemInt32
---@param len SystemInt32
---@return SystemInt32
function m:Read(b, off, len) end
---@param buf SystemByte
---@param off SystemInt32
---@param len SystemInt32
function m:Write(buf, off, len) end
---@param bv SystemByte
function m:WriteByte(bv) end
function m:Close() end
function m:Flush() end
ICSharpCodeSharpZipLibBZip2BZip2OutputStream=m
return m;