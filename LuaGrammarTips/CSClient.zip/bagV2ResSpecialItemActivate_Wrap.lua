---@class bagV2.ResSpecialItemActivate
---instance properties
---@field public itemIdList System.Collections.Generic.List1System.Int32
local m = {};

bagV2.ResSpecialItemActivate=m
return m;