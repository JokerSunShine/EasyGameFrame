---@class ICSharpCode.SharpZipLib.Zip.FastZip+Overwrite
---@field Prompt @0
---@field Never @1
---@field Always @2
ICSharpCode.SharpZipLib.Zip.FastZip+Overwrite=m
return m;