---@class ICSharpCodeNRefactoryOperatorPrecedence
local m = {};
---@param op1 ICSharpCodeNRefactoryAstBinaryOperatorType
---@param op2 ICSharpCodeNRefactoryAstBinaryOperatorType
---@return SystemInt32
function m.ComparePrecedenceVB(op1, op2) end
---@param op1 ICSharpCodeNRefactoryAstBinaryOperatorType
---@param op2 ICSharpCodeNRefactoryAstBinaryOperatorType
---@return SystemInt32
function m.ComparePrecedenceCSharp(op1, op2) end
ICSharpCodeNRefactoryOperatorPrecedence=m
return m;