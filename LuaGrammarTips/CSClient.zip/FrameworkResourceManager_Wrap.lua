---@class FrameworkResourceManager
---fields
---@field public ASSET_CACHE_DEFAULT_TIME SystemSingle
local m = {};
---@param path SystemString
---@param type SystemType
---@return ScriptPackagesFW_ResourceBaseAssetRequest
function m.LoadAsset(path, type) end
---@param path SystemString
---@param type SystemType
---@return ScriptPackagesFW_ResourceBaseAssetRequest
function m.LoadAssetAsync(path, type) end
---@param path SystemString
---@param parent UnityEngineTransform @default_value:
---@param worldPositionStays SystemBoolean @default_value:True
---@return UnityEngineGameObject
function m.Instantiate(path, parent, worldPositionStays) end
---@param path SystemString
---@param position UnityEngineVector3
---@param quaternion UnityEngineQuaternion
---@param parent UnityEngineTransform @default_value:
---@param worldPositionStays SystemBoolean @default_value:True
---@return UnityEngineGameObject
function m.Instantiate(path, position, quaternion, parent, worldPositionStays) end
---@param path SystemString
---@param parent UnityEngineTransform @default_value:
---@param worldPositionStays SystemBoolean @default_value:True
---@return ScriptPackagesFW_ResourceBaseInstantieteRequest
function m.InstantiateAsync(path, parent, worldPositionStays) end
---@param path SystemString
---@param position UnityEngineVector3
---@param quaternion UnityEngineQuaternion
---@param parent UnityEngineTransform @default_value:
---@param worldPositionStays SystemBoolean @default_value:True
---@return ScriptPackagesFW_ResourceBaseInstantieteRequest
function m.InstantiateAsync(path, position, quaternion, parent, worldPositionStays) end
FrameworkResourceManager=m
return m;