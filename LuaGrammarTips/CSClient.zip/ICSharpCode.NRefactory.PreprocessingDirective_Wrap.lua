---@class ICSharpCode.NRefactory.PreprocessingDirective : ICSharpCode.NRefactory.AbstractSpecial
---instance properties
---@field public Cmd System.String
---@field public Arg System.String
---@field public Expression ICSharpCode.NRefactory.Ast.Expression
---@field public LastLineEnd ICSharpCode.NRefactory.Location
local m = {};
---@param list System.Collections.Generic.IList`1[ICSharpCode.NRefactory.ISpecial]
function m.VBToCSharp(list) end
---@param dir ICSharpCode.NRefactory.PreprocessingDirective
---@return ICSharpCode.NRefactory.PreprocessingDirective
function m.VBToCSharp(dir) end
---@param list System.Collections.Generic.List`1[ICSharpCode.NRefactory.ISpecial]
function m.CSharpToVB(list) end
---@param dir ICSharpCode.NRefactory.PreprocessingDirective
---@return ICSharpCode.NRefactory.PreprocessingDirective
function m.CSharpToVB(dir) end
---@return System.String
function m:ToString() end
---@param visitor ICSharpCode.NRefactory.ISpecialVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
ICSharpCode.NRefactory.PreprocessingDirective=m
return m;