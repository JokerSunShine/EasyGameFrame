---@class DynamicTerrainHeightMapData : UnityEngineScriptableObject
---instance fields
---@field public heightMap UnityEngineTexture2D
---@field public heightScale SystemSingle
---@field public heightOffset SystemSingle
local m = {};
---@param coordX SystemInt32
---@param coordY SystemInt32
---@return SystemSingle
function m:GetHeight(coordX, coordY) end
DynamicTerrainHeightMapData=m
return m;