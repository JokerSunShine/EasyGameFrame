---@class CSObjectWrapEditor.Generator+MethodInfoSimulation
---instance fields
---@field public ReturnType System.Type
---@field public ParameterInfos CSObjectWrapEditor.Generator+ParameterInfoSimulation[]
---@field public HashCode System.Int32
---@field public DeclaringType System.Type
---@field public DeclaringTypeName System.String
local m = {};
---@return CSObjectWrapEditor.Generator+ParameterInfoSimulation[]
function m:GetParameters() end
CSObjectWrapEditor.Generator+MethodInfoSimulation=m
return m;