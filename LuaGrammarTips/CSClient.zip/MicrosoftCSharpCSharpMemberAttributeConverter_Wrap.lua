---@class MicrosoftCSharpCSharpMemberAttributeConverter : MicrosoftCSharpCSharpModifierAttributeConverter
---properties
---@field public Default MicrosoftCSharpCSharpMemberAttributeConverter
local m = {};
MicrosoftCSharpCSharpMemberAttributeConverter=m
return m;