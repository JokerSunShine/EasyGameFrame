---@class ICSharpCode.NRefactory.Ast.NullTypeReference : ICSharpCode.NRefactory.Ast.TypeReference
---fields
---@field public Instance ICSharpCode.NRefactory.Ast.NullTypeReference
---instance properties
---@field public IsNull System.Boolean
local m = {};
---@return ICSharpCode.NRefactory.Ast.TypeReference
function m:Clone() end
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.NullTypeReference=m
return m;