---@class ExCSSSelectorList : ExCSSBaseSelector
---instance properties
---@field public Length SystemInt32
---@field public Item ExCSSBaseSelector
local m = {};
---@param selector ExCSSBaseSelector
---@return ExCSSSelectorList
function m:AppendSelector(selector) end
---@param selector ExCSSSimpleSelector
---@return ExCSSSelectorList
function m:RemoveSelector(selector) end
---@return ExCSSSelectorList
function m:ClearSelectors() end
---@return SystemCollectionsGenericIEnumerator1ExCSSBaseSelector
function m:GetEnumerator() end
---@param friendlyFormat SystemBoolean
---@param indentation SystemInt32 @default_value:0
---@return SystemString
function m:ToString(friendlyFormat, indentation) end
ExCSSSelectorList=m
return m;