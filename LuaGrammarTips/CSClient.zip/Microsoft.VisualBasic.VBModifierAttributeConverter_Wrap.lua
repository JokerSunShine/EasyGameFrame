---@class Microsoft.VisualBasic.VBModifierAttributeConverter : System.ComponentModel.TypeConverter
local m = {};
---@param context System.ComponentModel.ITypeDescriptorContext
---@param sourceType System.Type
---@return System.Boolean
function m:CanConvertFrom(context, sourceType) end
---@param context System.ComponentModel.ITypeDescriptorContext
---@param culture System.Globalization.CultureInfo
---@param value System.Object
---@return System.Object
function m:ConvertFrom(context, culture, value) end
---@param context System.ComponentModel.ITypeDescriptorContext
---@param culture System.Globalization.CultureInfo
---@param value System.Object
---@param destinationType System.Type
---@return System.Object
function m:ConvertTo(context, culture, value, destinationType) end
---@param context System.ComponentModel.ITypeDescriptorContext
---@return System.Boolean
function m:GetStandardValuesExclusive(context) end
---@param context System.ComponentModel.ITypeDescriptorContext
---@return System.Boolean
function m:GetStandardValuesSupported(context) end
---@param context System.ComponentModel.ITypeDescriptorContext
---@return System.ComponentModel.TypeConverter+StandardValuesCollection
function m:GetStandardValues(context) end
Microsoft.VisualBasic.VBModifierAttributeConverter=m
return m;