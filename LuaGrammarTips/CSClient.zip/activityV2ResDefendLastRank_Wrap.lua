---@class activityV2.ResDefendLastRank
---instance properties
---@field public rank activityV2.DefendRank
local m = {};

activityV2.ResDefendLastRank=m
return m;