---@class ICSharpCode.SharpZipLib.Core.NameFilter
local m = {};
---@param e System.String
---@return System.Boolean
function m.IsValidExpression(e) end
---@param toTest System.String
---@return System.Boolean
function m.IsValidFilterExpression(toTest) end
---@return System.String
function m:ToString() end
---@param testValue System.String
---@return System.Boolean
function m:IsIncluded(testValue) end
---@param testValue System.String
---@return System.Boolean
function m:IsExcluded(testValue) end
---@param testValue System.String
---@return System.Boolean
function m:IsMatch(testValue) end
ICSharpCode.SharpZipLib.Core.NameFilter=m
return m;