---@class ICSharpCode.NRefactory.Visitors.CSharpConstructsConvertVisitor : ICSharpCode.NRefactory.Visitors.ConvertVisitorBase
local m = {};
---@param binaryOperatorExpression ICSharpCode.NRefactory.Ast.BinaryOperatorExpression
---@param data System.Object
---@return System.Object
function m:VisitBinaryOperatorExpression(binaryOperatorExpression, data) end
---@param expressionStatement ICSharpCode.NRefactory.Ast.ExpressionStatement
---@param data System.Object
---@return System.Object
function m:VisitExpressionStatement(expressionStatement, data) end
---@param ifElseStatement ICSharpCode.NRefactory.Ast.IfElseStatement
---@param data System.Object
---@return System.Object
function m:VisitIfElseStatement(ifElseStatement, data) end
---@param forStatement ICSharpCode.NRefactory.Ast.ForStatement
---@param data System.Object
---@return System.Object
function m:VisitForStatement(forStatement, data) end
---@param castExpression ICSharpCode.NRefactory.Ast.CastExpression
---@param data System.Object
---@return System.Object
function m:VisitCastExpression(castExpression, data) end
ICSharpCode.NRefactory.Visitors.CSharpConstructsConvertVisitor=m
return m;