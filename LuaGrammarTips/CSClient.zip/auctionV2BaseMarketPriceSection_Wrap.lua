---@class auctionV2.BaseMarketPriceSection
---instance properties
---@field public priceItemId System.Int32
---@field public priceItemIdSpecified System.Boolean
---@field public lowPrice System.Int64
---@field public lowPriceSpecified System.Boolean
---@field public topPrice System.Int64
---@field public topPriceSpecified System.Boolean
---@field public itemType System.Int32
---@field public itemTypeSpecified System.Boolean
---@field public defaultPrice System.Int64
---@field public defaultPriceSpecified System.Boolean
---@field public ratio System.Int32
---@field public ratioSpecified System.Boolean
local m = {};

auctionV2.BaseMarketPriceSection=m
return m;