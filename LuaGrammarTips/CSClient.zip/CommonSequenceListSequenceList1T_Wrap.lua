---@class CommonSequenceListSequenceList1T
---instance properties
---@field public Item T
---@field public Count SystemInt32
local m = {};
function m:Clear() end
---@return SystemBoolean
function m:IsEmpty() end
---@param item T
function m:Append(item) end
---@param item T
---@param index SystemInt32
function m:Insert(item, index) end
---@param index SystemInt32
function m:Delete(index) end
---@param index SystemInt32
---@return T
function m:GetElem(index) end
---@param value T
---@return SystemInt32
function m:locate(value) end
function m:ReverList() end
---@param mergeList CommonSequenceListSequenceList1T
function m:Merge(mergeList) end
CommonSequenceListSequenceList1T=m
return m;