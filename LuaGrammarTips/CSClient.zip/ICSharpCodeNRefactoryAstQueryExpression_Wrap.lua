---@class ICSharpCodeNRefactoryAstQueryExpression : ICSharpCodeNRefactoryAstExpression
---properties
---@field public Null ICSharpCodeNRefactoryAstQueryExpression
---instance properties
---@field public FromClause ICSharpCodeNRefactoryAstQueryExpressionFromClause
---@field public IsQueryContinuation SystemBoolean
---@field public MiddleClauses SystemCollectionsGenericList1ICSharpCodeNRefactoryAstQueryExpressionClause
---@field public SelectOrGroupClause ICSharpCodeNRefactoryAstQueryExpressionClause
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstQueryExpression=m
return m;