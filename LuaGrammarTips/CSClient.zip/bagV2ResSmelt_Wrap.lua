---@class bagV2.ResSmelt
---instance properties
---@field public idList System.Collections.Generic.List1System.Int64
---@field public rewards System.Collections.Generic.List1bagV2.ItemOutput
local m = {};

bagV2.ResSmelt=m
return m;