---@class activityV2.ResLuckTreasure
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public day System.Int32
---@field public daySpecified System.Boolean
---@field public openState System.Int32
---@field public openStateSpecified System.Boolean
---@field public luckyName System.String
---@field public luckyNameSpecified System.Boolean
---@field public luckyNum System.Int32
---@field public luckyNumSpecified System.Boolean
---@field public luckNumberList System.Collections.Generic.List1System.Int32
local m = {};

activityV2.ResLuckTreasure=m
return m;