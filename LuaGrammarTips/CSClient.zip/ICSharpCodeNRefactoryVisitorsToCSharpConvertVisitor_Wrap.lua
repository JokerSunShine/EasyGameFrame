---@class ICSharpCodeNRefactoryVisitorsToCSharpConvertVisitor : ICSharpCodeNRefactoryVisitorsConvertVisitorBase
local m = {};
---@param typeDeclaration ICSharpCodeNRefactoryAstTypeDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitTypeDeclaration(typeDeclaration, data) end
---@param eventDeclaration ICSharpCodeNRefactoryAstEventDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitEventDeclaration(eventDeclaration, data) end
---@param methodDeclaration ICSharpCodeNRefactoryAstMethodDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitMethodDeclaration(methodDeclaration, data) end
---@param propertyDeclaration ICSharpCodeNRefactoryAstPropertyDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitPropertyDeclaration(propertyDeclaration, data) end
---@param localVariableDeclaration ICSharpCodeNRefactoryAstLocalVariableDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitLocalVariableDeclaration(localVariableDeclaration, data) end
---@param withStatement ICSharpCodeNRefactoryAstWithStatement
---@param data SystemObject
---@return SystemObject
function m:VisitWithStatement(withStatement, data) end
---@param switchSection ICSharpCodeNRefactoryAstSwitchSection
---@param data SystemObject
---@return SystemObject
function m:VisitSwitchSection(switchSection, data) end
---@param castExpression ICSharpCodeNRefactoryAstCastExpression
---@param data SystemObject
---@return SystemObject
function m:VisitCastExpression(castExpression, data) end
ICSharpCodeNRefactoryVisitorsToCSharpConvertVisitor=m
return m;