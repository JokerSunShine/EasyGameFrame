---@class DataStructTreeHeapBinomialHeapNode1T
---instance fields
---@field public data T
---@field public degree SystemInt32
---@field public child DataStructTreeHeapBinomialHeapNode1T
---@field public parent DataStructTreeHeapBinomialHeapNode1T
---@field public next DataStructTreeHeapBinomialHeapNode1T
local m = {};
DataStructTreeHeapBinomialHeapNode1T=m
return m;