---@class Microsoft.Win32.RegistryView
---@field Default @0
---@field Registry64 @256
---@field Registry32 @512
Microsoft.Win32.RegistryView=m
return m;