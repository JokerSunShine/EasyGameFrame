---@class ICSharpCodeNRefactoryAstBuilderExpressionBuilder
local m = {};
---@param identifier SystemString
---@return ICSharpCodeNRefactoryAstIdentifierExpression
function m.Identifier(identifier) end
---@param targetObject ICSharpCodeNRefactoryAstExpression
---@param memberName SystemString
---@return ICSharpCodeNRefactoryAstMemberReferenceExpression
function m.Member(targetObject, memberName) end
---@param callTarget ICSharpCodeNRefactoryAstExpression
---@param methodName SystemString
---@param arguments ICSharpCodeNRefactoryAstExpression
---@return ICSharpCodeNRefactoryAstInvocationExpression
function m.Call(callTarget, methodName, arguments) end
---@param callTarget ICSharpCodeNRefactoryAstExpression
---@param arguments ICSharpCodeNRefactoryAstExpression
---@return ICSharpCodeNRefactoryAstInvocationExpression
function m.Call(callTarget, arguments) end
---@param createType ICSharpCodeNRefactoryAstTypeReference
---@param arguments ICSharpCodeNRefactoryAstExpression
---@return ICSharpCodeNRefactoryAstObjectCreateExpression
function m.New(createType, arguments) end
---@param type ICSharpCodeNRefactoryAstTypeReference
---@return ICSharpCodeNRefactoryAstExpression
function m.CreateDefaultValueForType(type) end
---@param left ICSharpCodeNRefactoryAstExpression
---@param op ICSharpCodeNRefactoryAstBinaryOperatorType
---@param right ICSharpCodeNRefactoryAstExpression
---@return ICSharpCodeNRefactoryAstBinaryOperatorExpression
function m.Operator(left, op, right) end
ICSharpCodeNRefactoryAstBuilderExpressionBuilder=m
return m;