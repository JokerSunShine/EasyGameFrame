---@class ICSharpCode.NRefactory.Parser.LookupTable
---instance properties
---@field public Count System.Int32
---@field public Item System.Int32
local m = {};
ICSharpCode.NRefactory.Parser.LookupTable=m
return m;