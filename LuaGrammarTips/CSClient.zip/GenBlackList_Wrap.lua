---@class GenBlackList
local m = {};
---@param mb System.Reflection.MemberInfo
---@return System.Boolean
function m.isMemberInBlackList(mb) end
GenBlackList=m
return m;