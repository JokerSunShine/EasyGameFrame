---@class GenBlackList
local m = {};
---@param mb SystemReflectionMemberInfo
---@return SystemBoolean
function m.isMemberInBlackList(mb) end
GenBlackList=m
return m;