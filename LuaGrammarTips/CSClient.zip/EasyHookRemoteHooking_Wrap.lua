---@class EasyHookRemoteHooking
---properties
---@field public IsAdministrator SystemBoolean
---@field public IsX64System SystemBoolean
local m = {};
function m.WakeUpProcess() end
---@param RefChannelName SystemString
---@param InObjectMode SystemRuntimeRemotingWellKnownObjectMode
---@param ipcInterface TRemoteObject
---@param InAllowedClientSIDs SystemSecurityPrincipalWellKnownSidType
---@return SystemRuntimeRemotingChannelsIpcIpcServerChannel
function m.IpcCreateServer(RefChannelName, InObjectMode, ipcInterface, InAllowedClientSIDs) end
---@param InTargetPID SystemInt32
---@param InOptions EasyHookInjectionOptions
---@param InLibraryPath_x86 SystemString
---@param InLibraryPath_x64 SystemString
---@param InPassThruArgs SystemObject
function m.Inject(InTargetPID, InOptions, InLibraryPath_x86, InLibraryPath_x64, InPassThruArgs) end
---@param InTargetPID SystemInt32
---@param InLibraryPath_x86 SystemString
---@param InLibraryPath_x64 SystemString
---@param InPassThruArgs SystemObject
function m.Inject(InTargetPID, InLibraryPath_x86, InLibraryPath_x64, InPassThruArgs) end
---@param InTargetPID SystemInt32
---@return SystemBoolean
function m.IsX64Process(InTargetPID) end
---@param InTargetPID SystemInt32
---@return SystemSecurityPrincipalWindowsIdentity
function m.GetProcessIdentity(InTargetPID) end
---@return SystemInt32
function m.GetCurrentProcessId() end
---@return SystemInt32
function m.GetCurrentThreadId() end
---@param InEXEPath SystemString
---@param InCommandLine SystemString
---@param InProcessCreationFlags SystemInt32
---@param InOptions EasyHookInjectionOptions
---@param InLibraryPath_x86 SystemString
---@param InLibraryPath_x64 SystemString
---@param OutProcessId SystemInt32 @out
---@param InPassThruArgs SystemObject
function m.CreateAndInject(InEXEPath, InCommandLine, InProcessCreationFlags, InOptions, InLibraryPath_x86, InLibraryPath_x64, OutProcessId, InPassThruArgs) end
---@param InEXEPath SystemString
---@param InCommandLine SystemString
---@param InProcessCreationFlags SystemInt32
---@param InLibraryPath_x86 SystemString
---@param InLibraryPath_x64 SystemString
---@param OutProcessId SystemInt32 @out
---@param InPassThruArgs SystemObject
function m.CreateAndInject(InEXEPath, InCommandLine, InProcessCreationFlags, InLibraryPath_x86, InLibraryPath_x64, OutProcessId, InPassThruArgs) end
function m.InstallSupportDriver() end
---@param InDriverPath SystemString
---@param InDriverName SystemString
function m.InstallDriver(InDriverPath, InDriverName) end
EasyHookRemoteHooking=m
return m;