---@class battleV2.ResBattle
---instance properties
---@field public result System.Int64
---@field public resultSpecified System.Boolean
---@field public attackId System.Int64
---@field public attackIdSpecified System.Boolean
---@field public isFresh System.Boolean
---@field public isFreshSpecified System.Boolean
---@field public selfTeam battleV2.TeamInfo
---@field public teamInfo battleV2.TeamInfo
---@field public battleData battleV2.BattleDataInfo
local m = {};

battleV2.ResBattle=m
return m;