---@class battleV2.RoleTargetInfo
---instance properties
---@field public target battleV2.RoleTarget
---@field public uid System.Int64
---@field public uidSpecified System.Boolean
local m = {};

battleV2.RoleTargetInfo=m
return m;