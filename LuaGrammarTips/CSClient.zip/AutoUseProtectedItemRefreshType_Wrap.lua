---@class AutoUseProtectedItemRefreshType
---@field AutoRefresh @1
---@field BeAttack @2
local m = {};
AutoUseProtectedItemRefreshType=m
return m;