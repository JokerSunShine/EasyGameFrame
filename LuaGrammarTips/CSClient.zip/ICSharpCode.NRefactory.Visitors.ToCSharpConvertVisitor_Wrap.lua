---@class ICSharpCode.NRefactory.Visitors.ToCSharpConvertVisitor : ICSharpCode.NRefactory.Visitors.ConvertVisitorBase
local m = {};
---@param typeDeclaration ICSharpCode.NRefactory.Ast.TypeDeclaration
---@param data System.Object
---@return System.Object
function m:VisitTypeDeclaration(typeDeclaration, data) end
---@param eventDeclaration ICSharpCode.NRefactory.Ast.EventDeclaration
---@param data System.Object
---@return System.Object
function m:VisitEventDeclaration(eventDeclaration, data) end
---@param methodDeclaration ICSharpCode.NRefactory.Ast.MethodDeclaration
---@param data System.Object
---@return System.Object
function m:VisitMethodDeclaration(methodDeclaration, data) end
---@param propertyDeclaration ICSharpCode.NRefactory.Ast.PropertyDeclaration
---@param data System.Object
---@return System.Object
function m:VisitPropertyDeclaration(propertyDeclaration, data) end
---@param localVariableDeclaration ICSharpCode.NRefactory.Ast.LocalVariableDeclaration
---@param data System.Object
---@return System.Object
function m:VisitLocalVariableDeclaration(localVariableDeclaration, data) end
---@param withStatement ICSharpCode.NRefactory.Ast.WithStatement
---@param data System.Object
---@return System.Object
function m:VisitWithStatement(withStatement, data) end
---@param switchSection ICSharpCode.NRefactory.Ast.SwitchSection
---@param data System.Object
---@return System.Object
function m:VisitSwitchSection(switchSection, data) end
---@param castExpression ICSharpCode.NRefactory.Ast.CastExpression
---@param data System.Object
---@return System.Object
function m:VisitCastExpression(castExpression, data) end
ICSharpCode.NRefactory.Visitors.ToCSharpConvertVisitor=m
return m;