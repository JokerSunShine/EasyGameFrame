---@class bagV2.ExtraEquip
---instance properties
---@field public type System.Int32
---@field public typeSpecified System.Boolean
---@field public itemId System.Int32
---@field public itemIdSpecified System.Boolean
local m = {};

bagV2.ExtraEquip=m
return m;