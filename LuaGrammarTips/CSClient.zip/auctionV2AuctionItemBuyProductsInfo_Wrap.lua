---@class auctionV2.AuctionItemBuyProductsInfo
---instance properties
---@field public count System.Int32
---@field public countSpecified System.Boolean
---@field public minLevel System.Int64
---@field public minLevelSpecified System.Boolean
---@field public maxLevel System.Int64
---@field public maxLevelSpecified System.Boolean
---@field public sex System.Int32
---@field public sexSpecified System.Boolean
---@field public carreer System.Int32
---@field public carreerSpecified System.Boolean
---@field public screenCondition System.Collections.Generic.List1System.Int32
---@field public name System.String
---@field public nameSpecified System.Boolean
---@field public propertyTendency System.Int32
---@field public propertyTendencySpecified System.Boolean
local m = {};

auctionV2.AuctionItemBuyProductsInfo=m
return m;