---@class activityV2.ReqLianZhi
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public times System.Int32
---@field public timesSpecified System.Boolean
local m = {};

activityV2.ReqLianZhi=m
return m;