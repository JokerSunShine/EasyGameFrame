---@class AnimationOrTween.DisableCondition
---@field DoNotDisable @0
---@field DisableAfterForward @1
---@field DisableAfterReverse @-1
local m = {};
AnimationOrTween.DisableCondition=m
return m;