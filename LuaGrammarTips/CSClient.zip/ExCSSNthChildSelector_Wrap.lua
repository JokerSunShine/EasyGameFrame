---@class ExCSSNthChildSelector : ExCSSBaseSelector
---instance fields
---@field public Step SystemInt32
---@field public Offset SystemInt32
local m = {};
---@param friendlyFormat SystemBoolean
---@param indentation SystemInt32 @default_value:0
---@return SystemString
function m:ToString(friendlyFormat, indentation) end
ExCSSNthChildSelector=m
return m;