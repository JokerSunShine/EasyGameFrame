---@class EasyHookInjectionLoader
local m = {};
---@param inParam SystemString
---@return SystemInt32
function m.Main(inParam) end
EasyHookInjectionLoader=m
return m;