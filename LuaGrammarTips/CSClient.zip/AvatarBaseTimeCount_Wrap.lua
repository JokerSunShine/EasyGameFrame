---@class AvatarBaseTimeCount : UIHeadItemBase
local m = {};

AvatarBaseTimeCount=m
return m;