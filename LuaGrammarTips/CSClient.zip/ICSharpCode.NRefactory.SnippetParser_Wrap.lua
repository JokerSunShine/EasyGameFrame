---@class ICSharpCode.NRefactory.SnippetParser
---instance properties
---@field public Errors ICSharpCode.NRefactory.Parser.Errors
---@field public Specials System.Collections.Generic.List`1[ICSharpCode.NRefactory.ISpecial]
---@field public SnippetType ICSharpCode.NRefactory.SnippetType
local m = {};
---@param code System.String
---@return ICSharpCode.NRefactory.Ast.INode
function m:Parse(code) end
ICSharpCode.NRefactory.SnippetParser=m
return m;