---@class MicrosoftReflectionReflectionExtensions
local m = {};
---@param type SystemType
---@return SystemBoolean
function m.IsEnum(type) end
---@param type SystemType
---@return SystemBoolean
function m.IsAbstract(type) end
---@param type SystemType
---@return SystemBoolean
function m.IsSealed(type) end
---@param type SystemType
---@return SystemType
function m.BaseType(type) end
---@param type SystemType
---@return SystemReflectionAssembly
function m.Assembly(type) end
---@param type SystemType
---@return SystemTypeCode
function m.GetTypeCode(type) end
---@param assm SystemReflectionAssembly
---@return SystemBoolean
function m.ReflectionOnly(assm) end
MicrosoftReflectionReflectionExtensions=m
return m;