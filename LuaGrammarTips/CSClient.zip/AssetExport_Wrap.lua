---@class AssetExport : UnityEditorExperimentalAssetsModifiedProcessor
local m = {};
AssetExport=m
return m;