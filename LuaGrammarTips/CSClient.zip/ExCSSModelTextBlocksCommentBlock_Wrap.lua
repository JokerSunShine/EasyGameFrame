---@class ExCSSModelTextBlocksCommentBlock : ExCSSModelTextBlocksBlock
local m = {};
---@return SystemString
function m:ToString() end
ExCSSModelTextBlocksCommentBlock=m
return m;