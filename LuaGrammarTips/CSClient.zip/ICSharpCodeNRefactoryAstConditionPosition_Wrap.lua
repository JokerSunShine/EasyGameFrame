---@class ICSharpCodeNRefactoryAstConditionPosition
---@field None @0
---@field Start @1
---@field End @2
ICSharpCodeNRefactoryAstConditionPosition=m
return m;