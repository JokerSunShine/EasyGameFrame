---@class DataStructTreeBinaryTreeRedBlackTreeRedBalckTree_Chain1T : DataStructTreeBinaryTreeAVLTreeAVLTree_Chain1T
local m = {};
---@param value T
---@return DataStructTreeBinaryTreeNode1T
function m:InsertNode(value) end
---@param node DataStructTreeBinaryTreeNode1T
function m:RedBlackInsertAdjust(node) end
---@param data T
---@param changeCount SystemBoolean @default_value:True
---@return DataStructTreeBinaryTreeNode1T
function m:DeleteNode(data, changeCount) end
---@param node DataStructTreeBinaryTreeNode1T
function m:RedBlackDeleteAdjust(node) end
DataStructTreeBinaryTreeRedBlackTreeRedBalckTree_Chain1T=m
return m;