---@class AlgorithmShortPathShortPath1T
local m = {};
---@param graph DataStructGraphMatrixGraphMatrixGraph1T
---@param startIndex SystemInt32
---@return AlgorithmShortPathShortPath1DJSNodeT
function m.Dijkstra_ShortPath(graph, startIndex) end
---@param graph DataStructGraphMatrixGraphMatrixGraph1T
---@return AlgorithmShortPathShortPath1FloydNodeT
function m.Floyd_ShortPath(graph) end
---@param edgeMatrix SystemInt32
---@param vertexNum SystemInt32
---@return AlgorithmShortPathShortPath1FloydNodeT
function m.TransformFloyNodeMatrix(edgeMatrix, vertexNum) end
AlgorithmShortPathShortPath1T=m
return m;