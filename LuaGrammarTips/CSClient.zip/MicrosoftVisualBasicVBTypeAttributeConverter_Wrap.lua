---@class MicrosoftVisualBasicVBTypeAttributeConverter : MicrosoftVisualBasicVBModifierAttributeConverter
---properties
---@field public Default MicrosoftVisualBasicVBTypeAttributeConverter
local m = {};
MicrosoftVisualBasicVBTypeAttributeConverter=m
return m;