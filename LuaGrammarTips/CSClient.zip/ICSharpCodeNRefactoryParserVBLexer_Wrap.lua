---@class ICSharpCodeNRefactoryParserVBLexer : ICSharpCodeNRefactoryParserAbstractLexer
local m = {};
---@return ICSharpCodeNRefactoryParserToken
function m:NextToken() end
---@param targetToken SystemInt32
function m:SkipCurrentBlock(targetToken) end
ICSharpCodeNRefactoryParserVBLexer=m
return m;