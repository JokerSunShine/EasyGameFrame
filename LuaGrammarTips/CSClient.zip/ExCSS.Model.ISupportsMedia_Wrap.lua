---@class ExCSS.Model.ISupportsMedia
---instance properties
---@field public Media ExCSS.MediaTypeList
local m = {};
ExCSS.Model.ISupportsMedia=m
return m;