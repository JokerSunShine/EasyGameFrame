---@class ICSharpCode.NRefactory.Ast.ParametrizedNode : ICSharpCode.NRefactory.Ast.AttributedNode
---instance properties
---@field public Name System.String
---@field public Parameters System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.ParameterDeclarationExpression]
local m = {};
ICSharpCode.NRefactory.Ast.ParametrizedNode=m
return m;