---@class ExCSS.Model.FunctionBuffer
---instance properties
---@field public TermList System.Collections.Generic.List`1[ExCSS.Term]
---@field public Term ExCSS.Term
local m = {};
function m:Include() end
---@return ExCSS.Term
function m:Done() end
ExCSS.Model.FunctionBuffer=m
return m;