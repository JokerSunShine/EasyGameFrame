---@class ICSharpCodeNRefactoryAstReDimStatement : ICSharpCodeNRefactoryAstStatement
---instance properties
---@field public ReDimClauses SystemCollectionsGenericList1ICSharpCodeNRefactoryAstInvocationExpression
---@field public IsPreserve SystemBoolean
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstReDimStatement=m
return m;