---@class backV2.ResCloseServer
---instance properties
---@field public code System.Int32
---@field public codeSpecified System.Boolean
---@field public info System.String
---@field public infoSpecified System.Boolean
local m = {};

backV2.ResCloseServer=m
return m;