---@class ICSharpCodeSharpZipLibZipZipOutputStream : ICSharpCodeSharpZipLibZipCompressionStreamsDeflaterOutputStream
---instance properties
---@field public IsFinished SystemBoolean
local m = {};
---@param comment SystemString
function m:SetComment(comment) end
---@param level SystemInt32
function m:SetLevel(level) end
---@return SystemInt32
function m:GetLevel() end
---@param entry ICSharpCodeSharpZipLibZipZipEntry
function m:PutNextEntry(entry) end
function m:CloseEntry() end
---@param b SystemByte
---@param off SystemInt32
---@param len SystemInt32
function m:Write(b, off, len) end
function m:Finish() end
ICSharpCodeSharpZipLibZipZipOutputStream=m
return m;