---@class backV2.ReqSendUnionInfo
---instance properties
---@field public uid System.Int64
---@field public uidSpecified System.Boolean
local m = {};

backV2.ReqSendUnionInfo=m
return m;