---@class auctionV2.UnionSmeltGoodsChange
---instance properties
---@field public items System.Collections.Generic.List1auctionV2.AuctionItemInfo
---@field public changeType System.Int32
---@field public changeTypeSpecified System.Boolean
local m = {};

auctionV2.UnionSmeltGoodsChange=m
return m;