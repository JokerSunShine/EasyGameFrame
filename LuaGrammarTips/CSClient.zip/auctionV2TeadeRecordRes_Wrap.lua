---@class auctionV2.TeadeRecordRes
---instance properties
---@field public records auctionV2.tradeRecordList
---@field public toatlPageCount System.Int32
---@field public toatlPageCountSpecified System.Boolean
---@field public page System.Int32
---@field public pageSpecified System.Boolean
---@field public firstCanReceive System.Int32
---@field public firstCanReceiveSpecified System.Boolean
---@field public totalCount System.Int32
---@field public totalCountSpecified System.Boolean
local m = {};

auctionV2.TeadeRecordRes=m
return m;