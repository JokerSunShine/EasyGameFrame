---@class ExCSSLexer
local m = {};
ExCSSLexer=m
return m;