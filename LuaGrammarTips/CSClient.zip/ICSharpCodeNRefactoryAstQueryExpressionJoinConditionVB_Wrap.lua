---@class ICSharpCodeNRefactoryAstQueryExpressionJoinConditionVB : ICSharpCodeNRefactoryAstAbstractNode
---instance properties
---@field public LeftSide ICSharpCodeNRefactoryAstExpression
---@field public RightSide ICSharpCodeNRefactoryAstExpression
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstQueryExpressionJoinConditionVB=m
return m;