---@class backV2.ReqBackLogin
---instance properties
---@field public loginName System.String
---@field public loginNameSpecified System.Boolean
local m = {};

backV2.ReqBackLogin=m
return m;