---@class EnvMapAnimator : UnityEngineMonoBehaviour
---instance fields
---@field public RotationSpeeds UnityEngineVector3
local m = {};
EnvMapAnimator=m
return m;