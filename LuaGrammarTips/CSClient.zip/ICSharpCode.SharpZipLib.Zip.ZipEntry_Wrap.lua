---@class ICSharpCode.SharpZipLib.Zip.ZipEntry
---instance properties
---@field public IsCrypted System.Boolean
---@field public Flags System.Int32
---@field public ZipFileIndex System.Int32
---@field public Offset System.Int32
---@field public ExternalFileAttributes System.Int32
---@field public VersionMadeBy System.Int32
---@field public HostSystem System.Int32
---@field public Version System.Int32
---@field public RequiresZip64 System.Boolean
---@field public DosTime System.Int64
---@field public DateTime System.DateTime
---@field public Name System.String
---@field public Size System.Int64
---@field public CompressedSize System.Int64
---@field public Crc System.Int64
---@field public CompressionMethod ICSharpCode.SharpZipLib.Zip.CompressionMethod
---@field public ExtraData System.Byte[]
---@field public Comment System.String
---@field public IsDirectory System.Boolean
---@field public IsFile System.Boolean
local m = {};
---@param name System.String
---@param relativePath System.Boolean
---@return System.String
function m.CleanName(name, relativePath) end
---@param name System.String
---@return System.String
function m.CleanName(name) end
---@return System.Object
function m:Clone() end
---@return System.String
function m:ToString() end
ICSharpCode.SharpZipLib.Zip.ZipEntry=m
return m;