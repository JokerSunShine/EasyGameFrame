---@class ExCSSKeyframesRule : ExCSSRuleSet
---instance properties
---@field public Identifier SystemString
---@field public Declarations SystemCollectionsGenericList1ExCSSRuleSet
local m = {};
---@return SystemString
function m:ToString() end
---@param friendlyFormat SystemBoolean
---@param indentation SystemInt32 @default_value:0
---@return SystemString
function m:ToString(friendlyFormat, indentation) end
ExCSSKeyframesRule=m
return m;