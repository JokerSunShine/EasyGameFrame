---@class ICSharpCode.SharpZipLib.Zip.Compression.DeflaterHuffman
---instance fields
---@field public pending ICSharpCode.SharpZipLib.Zip.Compression.DeflaterPending
local m = {};
---@param toReverse System.Int32
---@return System.Int16
function m.BitReverse(toReverse) end
function m:Reset() end
---@param blTreeCodes System.Int32
function m:SendAllTrees(blTreeCodes) end
function m:CompressBlock() end
---@param stored System.Byte[]
---@param storedOffset System.Int32
---@param storedLength System.Int32
---@param lastBlock System.Boolean
function m:FlushStoredBlock(stored, storedOffset, storedLength, lastBlock) end
---@param stored System.Byte[]
---@param storedOffset System.Int32
---@param storedLength System.Int32
---@param lastBlock System.Boolean
function m:FlushBlock(stored, storedOffset, storedLength, lastBlock) end
---@return System.Boolean
function m:IsFull() end
---@param lit System.Int32
---@return System.Boolean
function m:TallyLit(lit) end
---@param dist System.Int32
---@param len System.Int32
---@return System.Boolean
function m:TallyDist(dist, len) end
ICSharpCode.SharpZipLib.Zip.Compression.DeflaterHuffman=m
return m;