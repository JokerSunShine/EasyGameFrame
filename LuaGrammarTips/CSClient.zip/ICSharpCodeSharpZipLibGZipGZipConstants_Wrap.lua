---@class ICSharpCodeSharpZipLibGZipGZipConstants
---fields
---@field public FTEXT SystemInt32
---@field public FHCRC SystemInt32
---@field public FEXTRA SystemInt32
---@field public FNAME SystemInt32
---@field public FCOMMENT SystemInt32
---@field public GZIP_MAGIC SystemInt32
local m = {};
ICSharpCodeSharpZipLibGZipGZipConstants=m
return m;