---@class auctionV2.TeadeRecordReq
---instance properties
---@field public type System.Int32
---@field public typeSpecified System.Boolean
---@field public page System.Int32
---@field public pageSpecified System.Boolean
---@field public countPerPage System.Int32
---@field public countPerPageSpecified System.Boolean
---@field public pageNumber System.Int32
---@field public pageNumberSpecified System.Boolean
local m = {};

auctionV2.TeadeRecordReq=m
return m;