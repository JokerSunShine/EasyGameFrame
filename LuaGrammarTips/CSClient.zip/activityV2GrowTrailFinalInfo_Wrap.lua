---@class activityV2.GrowTrailFinalInfo
---instance properties
---@field public index System.Int32
---@field public indexSpecified System.Boolean
---@field public rewardState System.Int32
---@field public rewardStateSpecified System.Boolean
local m = {};

activityV2.GrowTrailFinalInfo=m
return m;