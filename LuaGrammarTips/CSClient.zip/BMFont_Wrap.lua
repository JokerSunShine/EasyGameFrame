---@class BMFont
---instance properties
---@field public isValid System.Boolean
---@field public charSize System.Int32
---@field public baseOffset System.Int32
---@field public texWidth System.Int32
---@field public texHeight System.Int32
---@field public glyphCount System.Int32
---@field public spriteName System.String
---@field public glyphs System.Collections.Generic.List1BMGlyph
local m = {};

---@param index System.Int32
---@param createIfMissing System.Boolean
---@return BMGlyph
function m:GetGlyph(index, createIfMissing) end
---@param index System.Int32
---@return BMGlyph
function m:GetGlyph(index) end
function m:Clear() end
---@param xMin System.Int32
---@param yMin System.Int32
---@param xMax System.Int32
---@param yMax System.Int32
function m:Trim(xMin, yMin, xMax, yMax) end
BMFont=m
return m;