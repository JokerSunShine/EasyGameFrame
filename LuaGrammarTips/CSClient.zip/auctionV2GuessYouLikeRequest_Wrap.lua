---@class auctionV2.GuessYouLikeRequest
---instance properties
---@field public itemType System.Int32
---@field public itemTypeSpecified System.Boolean
---@field public page System.Int32
---@field public pageSpecified System.Boolean
---@field public countPerPage System.Int32
---@field public countPerPageSpecified System.Boolean
---@field public pageNumber System.Int32
---@field public pageNumberSpecified System.Boolean
---@field public type System.Int32
---@field public typeSpecified System.Boolean
local m = {};

auctionV2.GuessYouLikeRequest=m
return m;