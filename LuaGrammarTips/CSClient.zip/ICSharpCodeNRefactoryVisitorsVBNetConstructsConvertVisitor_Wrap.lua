---@class ICSharpCodeNRefactoryVisitorsVBNetConstructsConvertVisitor : ICSharpCodeNRefactoryVisitorsConvertVisitorBase
---fields
---@field public FunctionReturnValueName SystemString
---@field public VBAssemblyName SystemString
---instance fields
---@field public AddDefaultValueInitializerToLocalVariableDeclarations SystemBoolean
local m = {};
---@param compilationUnit ICSharpCodeNRefactoryAstCompilationUnit
---@param data SystemObject
---@return SystemObject
function m:VisitCompilationUnit(compilationUnit, data) end
---@param using ICSharpCodeNRefactoryAstUsing
---@param data SystemObject
---@return SystemObject
function m:VisitUsing(using, data) end
---@param typeDeclaration ICSharpCodeNRefactoryAstTypeDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitTypeDeclaration(typeDeclaration, data) end
---@param delegateDeclaration ICSharpCodeNRefactoryAstDelegateDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitDelegateDeclaration(delegateDeclaration, data) end
---@param constructorDeclaration ICSharpCodeNRefactoryAstConstructorDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitConstructorDeclaration(constructorDeclaration, data) end
---@param declareDeclaration ICSharpCodeNRefactoryAstDeclareDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitDeclareDeclaration(declareDeclaration, data) end
---@param methodDeclaration ICSharpCodeNRefactoryAstMethodDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitMethodDeclaration(methodDeclaration, data) end
---@param fieldDeclaration ICSharpCodeNRefactoryAstFieldDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitFieldDeclaration(fieldDeclaration, data) end
---@param eventDeclaration ICSharpCodeNRefactoryAstEventDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitEventDeclaration(eventDeclaration, data) end
---@param propertyDeclaration ICSharpCodeNRefactoryAstPropertyDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitPropertyDeclaration(propertyDeclaration, data) end
---@param identifierExpression ICSharpCodeNRefactoryAstIdentifierExpression
---@param data SystemObject
---@return SystemObject
function m:VisitIdentifierExpression(identifierExpression, data) end
---@param invocationExpression ICSharpCodeNRefactoryAstInvocationExpression
---@param data SystemObject
---@return SystemObject
function m:VisitInvocationExpression(invocationExpression, data) end
---@param unaryOperatorExpression ICSharpCodeNRefactoryAstUnaryOperatorExpression
---@param data SystemObject
---@return SystemObject
function m:VisitUnaryOperatorExpression(unaryOperatorExpression, data) end
---@param usingStatement ICSharpCodeNRefactoryAstUsingStatement
---@param data SystemObject
---@return SystemObject
function m:VisitUsingStatement(usingStatement, data) end
---@param arrayCreateExpression ICSharpCodeNRefactoryAstArrayCreateExpression
---@param data SystemObject
---@return SystemObject
function m:VisitArrayCreateExpression(arrayCreateExpression, data) end
---@param binaryOperatorExpression ICSharpCodeNRefactoryAstBinaryOperatorExpression
---@param data SystemObject
---@return SystemObject
function m:VisitBinaryOperatorExpression(binaryOperatorExpression, data) end
---@param localVariableDeclaration ICSharpCodeNRefactoryAstLocalVariableDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitLocalVariableDeclaration(localVariableDeclaration, data) end
ICSharpCodeNRefactoryVisitorsVBNetConstructsConvertVisitor=m
return m;