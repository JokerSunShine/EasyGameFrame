---@class bagV2.ResGetNextSoulJade
---instance properties
---@field public isSuccess System.Int32
---@field public isSuccessSpecified System.Boolean
local m = {};

bagV2.ResGetNextSoulJade=m
return m;