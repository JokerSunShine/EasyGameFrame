---@class ICSharpCode.NRefactory.Visitors.ToVBNetRenameConflictingVariablesVisitor+FindIdentifiersVisitor : ICSharpCode.NRefactory.Visitors.AbstractAstVisitor
local m = {};
---@param identifierExpression ICSharpCode.NRefactory.Ast.IdentifierExpression
---@param data System.Object
---@return System.Object
function m:VisitIdentifierExpression(identifierExpression, data) end
ICSharpCode.NRefactory.Visitors.ToVBNetRenameConflictingVariablesVisitor+FindIdentifiersVisitor=m
return m;