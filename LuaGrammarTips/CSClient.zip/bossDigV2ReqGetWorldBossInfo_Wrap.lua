---@class bossDigV2.ReqGetWorldBossInfo
---instance properties
---@field public bossIdList System.Collections.Generic.List1System.Int32
local m = {};

bossDigV2.ReqGetWorldBossInfo=m
return m;