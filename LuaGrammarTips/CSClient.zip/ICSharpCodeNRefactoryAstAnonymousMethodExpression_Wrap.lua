---@class ICSharpCodeNRefactoryAstAnonymousMethodExpression : ICSharpCodeNRefactoryAstExpression
---instance properties
---@field public Parameters SystemCollectionsGenericList1ICSharpCodeNRefactoryAstParameterDeclarationExpression
---@field public Body ICSharpCodeNRefactoryAstBlockStatement
---@field public HasParameterList SystemBoolean
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstAnonymousMethodExpression=m
return m;