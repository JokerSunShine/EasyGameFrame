---@class auctionV2.tradeRecordList
---instance properties
---@field public record System.Collections.Generic.List1auctionV2.TransactionRecord
local m = {};

auctionV2.tradeRecordList=m
return m;