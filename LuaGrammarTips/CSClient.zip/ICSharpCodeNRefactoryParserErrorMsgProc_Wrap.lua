---@class ICSharpCodeNRefactoryParserErrorMsgProc : SystemMulticastDelegate
local m = {};
---@param line SystemInt32
---@param col SystemInt32
---@param msg SystemString
function m:Invoke(line, col, msg) end
---@param line SystemInt32
---@param col SystemInt32
---@param msg SystemString
---@param callback SystemAsyncCallback
---@param object SystemObject
---@return SystemIAsyncResult
function m:BeginInvoke(line, col, msg, callback, object) end
---@param result SystemIAsyncResult
function m:EndInvoke(result) end
ICSharpCodeNRefactoryParserErrorMsgProc=m
return m;