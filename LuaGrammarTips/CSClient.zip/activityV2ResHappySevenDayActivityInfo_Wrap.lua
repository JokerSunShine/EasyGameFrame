---@class activityV2.ResHappySevenDayActivityInfo
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public dayInfoList System.Collections.Generic.List1activityV2.DayInfoOfHappySevenDay
local m = {};

activityV2.ResHappySevenDayActivityInfo=m
return m;