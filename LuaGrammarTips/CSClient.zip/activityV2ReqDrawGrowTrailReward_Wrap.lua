---@class activityV2.ReqDrawGrowTrailReward
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public dayNo System.Int32
---@field public dayNoSpecified System.Boolean
---@field public group System.Int32
---@field public groupSpecified System.Boolean
---@field public index System.Int32
---@field public indexSpecified System.Boolean
local m = {};

activityV2.ReqDrawGrowTrailReward=m
return m;