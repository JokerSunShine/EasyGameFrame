---@class BaseEvent
---instance fields
---@field public callbackBindWarningMaxCount System.Int32
---@field public callbackBindWarningCallBack System.Action2System.Int32System.Int32
---@field public mDicEvtDelegate System.Collections.Generic.Dictionary2System.UInt32BaseEventEventDelegate
local m = {};

---@param uiEvtID System.UInt32
---@param callBack BaseEventCallback
function m:Reg(uiEvtID, callBack) end
---@param uiEvtID System.UInt32
---@param callBack BaseEventCallback
function m:UnReg(uiEvtID, callBack) end
---@param avoidList System.Collections.Generic.List1System.UInt32 @default_value:
function m:Clear(avoidList) end
---@param uiEvtId System.UInt32
function m:UnReg(uiEvtId) end
---@param uiEvtID System.UInt32
---@param objData System.Object
function m:ProcEvent(uiEvtID, objData) end
---@param uiEvtID System.UInt32
---@return System.Boolean
function m:IsHaveEvent(uiEvtID) end
BaseEvent=m
return m;