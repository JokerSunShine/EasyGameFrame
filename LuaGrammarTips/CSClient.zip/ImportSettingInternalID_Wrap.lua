---@class ImportSettingInternalID
local m = {};
---@param serializedObject UnityEditor.SerializedObject
---@param type UnityEditor.UnityType
---@param id System.Int64
---@param name System.String
function m.RegisterInternalID(serializedObject, type, id, name) end
---@param serializedObject UnityEditor.SerializedObject
---@param type UnityEditor.UnityType
---@param id System.Int64
---@param name System.String
---@return System.Boolean
function m.RemoveEntryFromInternalIDTable(serializedObject, type, id, name) end
---@param serializedObject UnityEditor.SerializedObject
---@param type UnityEditor.UnityType
---@param name System.String
---@return System.Int64
function m.FindInternalID(serializedObject, type, name) end
---@param serializedObject UnityEditor.SerializedObject
---@param type UnityEditor.UnityType
---@param name System.String
---@return System.Int64
function m.MakeInternalID(serializedObject, type, name) end
---@param serializedObject UnityEditor.SerializedObject
---@param type UnityEditor.UnityType
---@param oldName System.String
---@param newName System.String
function m.Rename(serializedObject, type, oldName, newName) end
---@param serializedObject UnityEditor.SerializedObject
---@param type UnityEditor.UnityType
---@param oldNames System.String[]
---@param newNames System.String[]
function m.RenameMultiple(serializedObject, type, oldNames, newNames) end
ImportSettingInternalID=m
return m;