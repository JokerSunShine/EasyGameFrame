---@class ImportSettingInternalID
local m = {};
---@param serializedObject UnityEditorSerializedObject
---@param type UnityEditorUnityType
---@param id SystemInt64
---@param name SystemString
function m.RegisterInternalID(serializedObject, type, id, name) end
---@param serializedObject UnityEditorSerializedObject
---@param type UnityEditorUnityType
---@param id SystemInt64
---@param name SystemString
---@return SystemBoolean
function m.RemoveEntryFromInternalIDTable(serializedObject, type, id, name) end
---@param serializedObject UnityEditorSerializedObject
---@param type UnityEditorUnityType
---@param name SystemString
---@return SystemInt64
function m.FindInternalID(serializedObject, type, name) end
---@param serializedObject UnityEditorSerializedObject
---@param type UnityEditorUnityType
---@param name SystemString
---@return SystemInt64
function m.MakeInternalID(serializedObject, type, name) end
---@param serializedObject UnityEditorSerializedObject
---@param type UnityEditorUnityType
---@param oldName SystemString
---@param newName SystemString
function m.Rename(serializedObject, type, oldName, newName) end
---@param serializedObject UnityEditorSerializedObject
---@param type UnityEditorUnityType
---@param oldNames SystemString
---@param newNames SystemString
function m.RenameMultiple(serializedObject, type, oldNames, newNames) end
ImportSettingInternalID=m
return m;