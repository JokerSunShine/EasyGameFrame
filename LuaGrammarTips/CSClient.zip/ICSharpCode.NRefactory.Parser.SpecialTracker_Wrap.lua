---@class ICSharpCode.NRefactory.Parser.SpecialTracker
---instance properties
---@field public CurrentSpecials System.Collections.Generic.List`1[ICSharpCode.NRefactory.ISpecial]
local m = {};
---@param kind System.Int32
function m:InformToken(kind) end
---@return System.Collections.Generic.List`1[ICSharpCode.NRefactory.ISpecial]
function m:RetrieveSpecials() end
---@param point ICSharpCode.NRefactory.Location
function m:AddEndOfLine(point) end
---@param directive ICSharpCode.NRefactory.PreprocessingDirective
function m:AddPreprocessingDirective(directive) end
---@param commentType ICSharpCode.NRefactory.CommentType
---@param commentStartsLine System.Boolean
---@param startPosition ICSharpCode.NRefactory.Location
function m:StartComment(commentType, commentStartsLine, startPosition) end
---@param c System.Char
function m:AddChar(c) end
---@param s System.String
function m:AddString(s) end
---@param endPosition ICSharpCode.NRefactory.Location
function m:FinishComment(endPosition) end
ICSharpCode.NRefactory.Parser.SpecialTracker=m
return m;