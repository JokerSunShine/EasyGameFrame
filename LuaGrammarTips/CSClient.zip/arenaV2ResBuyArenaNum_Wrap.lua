---@class arenaV2.ResBuyArenaNum
---instance properties
---@field public count System.Int32
---@field public countSpecified System.Boolean
---@field public nowCount System.Int32
---@field public nowCountSpecified System.Boolean
---@field public limit System.Int32
---@field public limitSpecified System.Boolean
---@field public needAddTime System.Int32
---@field public needAddTimeSpecified System.Boolean
local m = {};

arenaV2.ResBuyArenaNum=m
return m;