---@class MicrosoftWin32RegistryView
---@field Default @0
---@field Registry64 @256
---@field Registry32 @512
MicrosoftWin32RegistryView=m
return m;