---@class CSObjectWrapEditorGenerator
---fields
---@field public LuaCallCSharp SystemCollectionsGenericList1SystemType
---@field public CSharpCallLua SystemCollectionsGenericList1SystemType
---@field public BlackList SystemCollectionsGenericList1SystemCollectionsGenericList1SystemString
---@field public GCOptimizeList SystemCollectionsGenericList1SystemType
---@field public AdditionalProperties SystemCollectionsGenericDictionary2SystemTypeSystemCollectionsGenericList1SystemString
---@field public ReflectionUse SystemCollectionsGenericList1SystemType
---@field public HotfixCfg SystemCollectionsGenericDictionary2SystemTypeXLuaHotfixFlag
---@field public OptimizeCfg SystemCollectionsGenericDictionary2SystemTypeXLuaOptimizeFlag
---@field public DoNotGen SystemCollectionsGenericDictionary2SystemTypeSystemCollectionsGenericHashSet1SystemString
---@field public assemblyList SystemCollectionsGenericList1SystemString
---@field public memberFilters SystemCollectionsGenericList1SystemFunc2SystemReflectionMemberInfoSystemBoolean
local m = {};
---@param hotfix_check_types SystemCollectionsGenericIEnumerable1SystemType
function m.GenDelegateBridges(hotfix_check_types) end
function m.GenEnumWraps() end
---@param minimum SystemBoolean @default_value:False
function m.GenLuaRegister(minimum) end
---@param type SystemType
---@param cb SystemAction1SystemType
function m.AllSubStruct(type, cb) end
---@param types SystemCollectionsGenericIEnumerable1SystemType
---@param save_path SystemString
function m.GenPackUnpack(types, save_path) end
---@param check_types SystemCollectionsGenericIEnumerable1SystemType
function m.GetGenConfig(check_types) end
---@param wraps SystemCollectionsGenericIEnumerable1SystemType
---@param gc_optimze_list SystemCollectionsGenericIEnumerable1SystemType
---@param itf_bridges SystemCollectionsGenericIEnumerable1SystemType
---@param save_path SystemString
function m.Gen(wraps, gc_optimze_list, itf_bridges, save_path) end
---@param minimum SystemBoolean @default_value:False
function m.GenCodeForClass(minimum) end
function m.GenAll() end
function m.GenUsingCLI() end
function m.ClearAll() end
---@param template_src SystemString
---@param get_tasks CSObjectWrapEditorGeneratorGetTasks
function m.CustomGen(template_src, get_tasks) end
---@param target UnityEditorBuildTarget
---@param pathToBuiltProject SystemString
function m.CheckGenrate(target, pathToBuiltProject) end
CSObjectWrapEditorGenerator=m
return m;