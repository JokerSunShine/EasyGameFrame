---@class ICSharpCode.NRefactory.Ast.ObjectCreateExpression : ICSharpCode.NRefactory.Ast.Expression
---instance properties
---@field public CreateType ICSharpCode.NRefactory.Ast.TypeReference
---@field public Parameters System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.Expression]
---@field public ObjectInitializer ICSharpCode.NRefactory.Ast.CollectionInitializerExpression
---@field public IsAnonymousType System.Boolean
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.ObjectCreateExpression=m
return m;