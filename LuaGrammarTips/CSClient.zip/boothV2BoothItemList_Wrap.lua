---@class boothV2.BoothItemList
---instance properties
---@field public items System.Collections.Generic.List1auctionV2.AuctionItemInfo
local m = {};

boothV2.BoothItemList=m
return m;