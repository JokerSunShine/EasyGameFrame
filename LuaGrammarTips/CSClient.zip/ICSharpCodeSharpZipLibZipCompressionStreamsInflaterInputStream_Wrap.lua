---@class ICSharpCodeSharpZipLibZipCompressionStreamsInflaterInputStream : SystemIOStream
---instance properties
---@field public IsStreamOwner SystemBoolean
---@field public CanRead SystemBoolean
---@field public CanSeek SystemBoolean
---@field public CanWrite SystemBoolean
---@field public Length SystemInt64
---@field public Position SystemInt64
---@field public Available SystemInt32
local m = {};
function m:Flush() end
---@param offset SystemInt64
---@param origin SystemIOSeekOrigin
---@return SystemInt64
function m:Seek(offset, origin) end
---@param val SystemInt64
function m:SetLength(val) end
---@param array SystemByte
---@param offset SystemInt32
---@param count SystemInt32
function m:Write(array, offset, count) end
---@param val SystemByte
function m:WriteByte(val) end
---@param buffer SystemByte
---@param offset SystemInt32
---@param count SystemInt32
---@param callback SystemAsyncCallback
---@param state SystemObject
---@return SystemIAsyncResult
function m:BeginWrite(buffer, offset, count, callback, state) end
function m:Close() end
---@param b SystemByte
---@param off SystemInt32
---@param len SystemInt32
---@return SystemInt32
function m:Read(b, off, len) end
---@param n SystemInt64
---@return SystemInt64
function m:Skip(n) end
ICSharpCodeSharpZipLibZipCompressionStreamsInflaterInputStream=m
return m;