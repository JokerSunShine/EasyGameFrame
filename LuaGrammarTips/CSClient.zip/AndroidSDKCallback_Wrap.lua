---@class AndroidSDKCallback : UnityEngine.MonoBehaviour
---fields
---@field public Name System.String
---instance fields
---@field public ServerConfigData System.String
---@field public OpenLoginStatisticsTime System.Boolean
---@field public LoginStatisticsTime System.Single
---@field public IsOpenLogin System.Boolean
---@field public CheckProgressTime System.Single
---@field public IsGameLogoutAccout System.Boolean
---@field public payjsonData System.Collections.Generic.List1System.String
---@field public IsLoginFromGameCenter System.Boolean
---@field public SSOID System.String
---@field public isShowOppoCommunity System.Boolean
---properties
---@field public Instance AndroidSDKCallback
local m = {};
---@return AndroidSDKCallback
function m.InitCallback() end

---@param open System.Boolean
function m:OpenOnlineStatistics(open) end
function m:OnInitSuc() end
---@return System.Boolean
function m:CheckLoginCahce() end
function m:ClearLoginCache() end
---@param jsonData System.String
function m:OnAndroidLoginSuccess(jsonData) end
function m:OnChangeAccount() end
function m:OnLogout() end
function m:OnLogoutAccount() end
---@param totalSize System.String
function m:CopyFileComplete(totalSize) end
---@param data System.String
function m:GetConfigDataSuc(data) end
---@param data System.String
function m:OnUnZIPFinish(data) end
---@param percent System.String
function m:OnMovingFile(percent) end
---@param percent System.String
function m:DownLoading(percent) end
---@param isSuccess System.String
function m:BindPhone(isSuccess) end
---@param jsonData System.String
function m:OnPaySuccess(jsonData) end
---@param jsonData System.String
function m:OnPayError(jsonData) end
function m:QuitGame() end
---@param data System.String
function m:ACTION_BATTERY_CHANGED(data) end
---@param isLoginFromGameCenter System.String
function m:LoginFormGameCenter(isLoginFromGameCenter) end
---@param ssoid System.String
function m:GetOppoSSOID(ssoid) end
---@param jsonData System.String
function m:JunHaiGetPlayerInfo(jsonData) end
---@param isShow System.String
function m:ISOPENOPPOCOMMUNITY(isShow) end
---@param Orientation System.String
function m:onOrientationChanged(Orientation) end
function m:IL2CPPDownloaded() end
AndroidSDKCallback=m
return m;