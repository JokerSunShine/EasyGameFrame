---@class CSObjectWrapEditorGeneratorXluaTypeInfo
---instance fields
---@field public Type SystemType
---@field public FieldInfos SystemCollectionsGenericList1CSObjectWrapEditorGeneratorXluaFieldInfo
---@field public FieldGroup SystemCollectionsGenericList1SystemCollectionsGenericList1CSObjectWrapEditorGeneratorXluaFieldInfo
---@field public IsRoot SystemBoolean
local m = {};
CSObjectWrapEditorGeneratorXluaTypeInfo=m
return m;