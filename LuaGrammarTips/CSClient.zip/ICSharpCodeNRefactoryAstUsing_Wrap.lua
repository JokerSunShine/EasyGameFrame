---@class ICSharpCodeNRefactoryAstUsing : ICSharpCodeNRefactoryAstAbstractNode
---instance properties
---@field public Name SystemString
---@field public Alias ICSharpCodeNRefactoryAstTypeReference
---@field public IsAlias SystemBoolean
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstUsing=m
return m;