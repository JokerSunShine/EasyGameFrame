---@class ICSharpCodeSharpZipLibChecksumsCrc32
---instance properties
---@field public Value SystemInt64
local m = {};
function m:Reset() end
---@param bval SystemInt32
function m:Update(bval) end
---@param buffer SystemByte
function m:Update(buffer) end
---@param buf SystemByte
---@param off SystemInt32
---@param len SystemInt32
function m:Update(buf, off, len) end
ICSharpCodeSharpZipLibChecksumsCrc32=m
return m;