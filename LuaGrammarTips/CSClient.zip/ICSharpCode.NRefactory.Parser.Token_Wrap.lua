---@class ICSharpCode.NRefactory.Parser.Token
---instance properties
---@field public Kind System.Int32
---@field public LiteralFormat ICSharpCode.NRefactory.Parser.LiteralFormat
---@field public LiteralValue System.Object
---@field public Value System.String
---@field public EndLocation ICSharpCode.NRefactory.Location
---@field public Location ICSharpCode.NRefactory.Location
local m = {};
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Parser.Token=m
return m;