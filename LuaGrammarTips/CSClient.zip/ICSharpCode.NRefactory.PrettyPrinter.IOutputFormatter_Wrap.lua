---@class ICSharpCode.NRefactory.PrettyPrinter.IOutputFormatter
---instance properties
---@field public IndentationLevel System.Int32
---@field public Text System.String
---@field public IsInMemberBody System.Boolean
local m = {};
function m:NewLine() end
function m:Indent() end
---@param comment ICSharpCode.NRefactory.Comment
---@param forceWriteInPreviousBlock System.Boolean
function m:PrintComment(comment, forceWriteInPreviousBlock) end
---@param directive ICSharpCode.NRefactory.PreprocessingDirective
---@param forceWriteInPreviousBlock System.Boolean
function m:PrintPreprocessingDirective(directive, forceWriteInPreviousBlock) end
---@param forceWriteInPreviousBlock System.Boolean
function m:PrintBlankLine(forceWriteInPreviousBlock) end
ICSharpCode.NRefactory.PrettyPrinter.IOutputFormatter=m
return m;