---@class biqiV2.EnemyInfo
---instance properties
---@field public num System.Int32
---@field public numSpecified System.Boolean
---@field public rid System.Int64
---@field public ridSpecified System.Boolean
---@field public name System.String
---@field public nameSpecified System.Boolean
---@field public career System.Int32
---@field public careerSpecified System.Boolean
---@field public sex System.Int32
---@field public sexSpecified System.Boolean
---@field public x System.Int32
---@field public xSpecified System.Boolean
---@field public y System.Int32
---@field public ySpecified System.Boolean
local m = {};

biqiV2.EnemyInfo=m
return m;