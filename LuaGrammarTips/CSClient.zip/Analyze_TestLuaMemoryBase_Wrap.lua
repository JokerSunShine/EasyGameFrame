---@class Analyze_TestLuaMemoryBase : UnityEngine.MonoBehaviour
local m = {};

Analyze_TestLuaMemoryBase=m
return m;