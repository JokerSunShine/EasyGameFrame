---@class backV2.ReqExecGM
---instance properties
---@field public command System.String
---@field public commandSpecified System.Boolean
local m = {};

backV2.ReqExecGM=m
return m;