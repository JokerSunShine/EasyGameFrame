---@class backV2.ReqSendEmail
---instance properties
---@field public targetId System.Int64
---@field public targetIdSpecified System.Boolean
---@field public title System.String
---@field public titleSpecified System.Boolean
---@field public content System.String
---@field public contentSpecified System.Boolean
---@field public itemStr System.String
---@field public itemStrSpecified System.Boolean
---@field public itemTime System.Int32
---@field public itemTimeSpecified System.Boolean
local m = {};

backV2.ReqSendEmail=m
return m;