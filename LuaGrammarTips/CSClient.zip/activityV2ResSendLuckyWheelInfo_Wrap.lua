---@class activityV2.ResSendLuckyWheelInfo
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public count System.Int32
---@field public countSpecified System.Boolean
---@field public wheelNum System.Int32
---@field public wheelNumSpecified System.Boolean
---@field public totalNum System.Int32
---@field public totalNumSpecified System.Boolean
local m = {};

activityV2.ResSendLuckyWheelInfo=m
return m;