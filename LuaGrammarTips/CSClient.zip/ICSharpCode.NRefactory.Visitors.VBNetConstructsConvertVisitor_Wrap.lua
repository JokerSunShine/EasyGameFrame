---@class ICSharpCode.NRefactory.Visitors.VBNetConstructsConvertVisitor : ICSharpCode.NRefactory.Visitors.ConvertVisitorBase
---fields
---@field public FunctionReturnValueName System.String
---@field public VBAssemblyName System.String
---instance fields
---@field public AddDefaultValueInitializerToLocalVariableDeclarations System.Boolean
local m = {};
---@param compilationUnit ICSharpCode.NRefactory.Ast.CompilationUnit
---@param data System.Object
---@return System.Object
function m:VisitCompilationUnit(compilationUnit, data) end
---@param using ICSharpCode.NRefactory.Ast.Using
---@param data System.Object
---@return System.Object
function m:VisitUsing(using, data) end
---@param typeDeclaration ICSharpCode.NRefactory.Ast.TypeDeclaration
---@param data System.Object
---@return System.Object
function m:VisitTypeDeclaration(typeDeclaration, data) end
---@param delegateDeclaration ICSharpCode.NRefactory.Ast.DelegateDeclaration
---@param data System.Object
---@return System.Object
function m:VisitDelegateDeclaration(delegateDeclaration, data) end
---@param constructorDeclaration ICSharpCode.NRefactory.Ast.ConstructorDeclaration
---@param data System.Object
---@return System.Object
function m:VisitConstructorDeclaration(constructorDeclaration, data) end
---@param declareDeclaration ICSharpCode.NRefactory.Ast.DeclareDeclaration
---@param data System.Object
---@return System.Object
function m:VisitDeclareDeclaration(declareDeclaration, data) end
---@param methodDeclaration ICSharpCode.NRefactory.Ast.MethodDeclaration
---@param data System.Object
---@return System.Object
function m:VisitMethodDeclaration(methodDeclaration, data) end
---@param fieldDeclaration ICSharpCode.NRefactory.Ast.FieldDeclaration
---@param data System.Object
---@return System.Object
function m:VisitFieldDeclaration(fieldDeclaration, data) end
---@param eventDeclaration ICSharpCode.NRefactory.Ast.EventDeclaration
---@param data System.Object
---@return System.Object
function m:VisitEventDeclaration(eventDeclaration, data) end
---@param propertyDeclaration ICSharpCode.NRefactory.Ast.PropertyDeclaration
---@param data System.Object
---@return System.Object
function m:VisitPropertyDeclaration(propertyDeclaration, data) end
---@param identifierExpression ICSharpCode.NRefactory.Ast.IdentifierExpression
---@param data System.Object
---@return System.Object
function m:VisitIdentifierExpression(identifierExpression, data) end
---@param invocationExpression ICSharpCode.NRefactory.Ast.InvocationExpression
---@param data System.Object
---@return System.Object
function m:VisitInvocationExpression(invocationExpression, data) end
---@param unaryOperatorExpression ICSharpCode.NRefactory.Ast.UnaryOperatorExpression
---@param data System.Object
---@return System.Object
function m:VisitUnaryOperatorExpression(unaryOperatorExpression, data) end
---@param usingStatement ICSharpCode.NRefactory.Ast.UsingStatement
---@param data System.Object
---@return System.Object
function m:VisitUsingStatement(usingStatement, data) end
---@param arrayCreateExpression ICSharpCode.NRefactory.Ast.ArrayCreateExpression
---@param data System.Object
---@return System.Object
function m:VisitArrayCreateExpression(arrayCreateExpression, data) end
---@param binaryOperatorExpression ICSharpCode.NRefactory.Ast.BinaryOperatorExpression
---@param data System.Object
---@return System.Object
function m:VisitBinaryOperatorExpression(binaryOperatorExpression, data) end
---@param localVariableDeclaration ICSharpCode.NRefactory.Ast.LocalVariableDeclaration
---@param data System.Object
---@return System.Object
function m:VisitLocalVariableDeclaration(localVariableDeclaration, data) end
ICSharpCode.NRefactory.Visitors.VBNetConstructsConvertVisitor=m
return m;