---@class ExCSSImportRule : ExCSSRuleSet
---instance properties
---@field public Href SystemString
---@field public Media ExCSSMediaTypeList
local m = {};
---@return SystemString
function m:ToString() end
---@param friendlyFormat SystemBoolean
---@param indentation SystemInt32 @default_value:0
---@return SystemString
function m:ToString(friendlyFormat, indentation) end
ExCSSImportRule=m
return m;