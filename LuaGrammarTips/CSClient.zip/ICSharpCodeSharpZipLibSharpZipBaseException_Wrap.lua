---@class ICSharpCodeSharpZipLibSharpZipBaseException : SystemApplicationException
local m = {};
ICSharpCodeSharpZipLibSharpZipBaseException=m
return m;