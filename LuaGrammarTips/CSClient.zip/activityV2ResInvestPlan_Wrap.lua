---@class activityV2.ResInvestPlan
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public beginTime System.Int32
---@field public beginTimeSpecified System.Boolean
---@field public endTime System.Int32
---@field public endTimeSpecified System.Boolean
---@field public hasAttend System.Boolean
---@field public hasAttendSpecified System.Boolean
---@field public hasDrawList System.Collections.Generic.List1System.Int32
local m = {};

activityV2.ResInvestPlan=m
return m;