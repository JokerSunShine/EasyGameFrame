---@class DesktopStandalonePostProcessor+FilePathComparer
local m = {};
---@param left System.String
---@param right System.String
---@return System.Boolean
function m:Equals(left, right) end
---@param path System.String
---@return System.Int32
function m:GetHashCode(path) end
DesktopStandalonePostProcessor+FilePathComparer=m
return m;