---@class ExCSS.CombinatorSelector : System.ValueType
---instance fields
---@field public Selector ExCSS.BaseSelector
---@field public Delimiter ExCSS.Combinator
---instance properties
---@field public Character System.Char
local m = {};
ExCSS.CombinatorSelector=m
return m;