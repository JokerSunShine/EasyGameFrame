---@class ICSharpCode.NRefactory.Parser.LookupTable+Node
---instance fields
---@field public word System.String
---@field public val System.Int32
---@field public leaf ICSharpCode.NRefactory.Parser.LookupTable+Node[]
local m = {};
ICSharpCode.NRefactory.Parser.LookupTable+Node=m
return m;