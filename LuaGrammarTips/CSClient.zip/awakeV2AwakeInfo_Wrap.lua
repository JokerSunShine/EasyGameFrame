---@class awakeV2.AwakeInfo
---instance properties
---@field public power System.Int32
---@field public powerSpecified System.Boolean
---@field public slotList System.Collections.Generic.List1awakeV2.SlotInfo
---@field public equipList System.Collections.Generic.List1awakeV2.EquipInfo
local m = {};

awakeV2.AwakeInfo=m
return m;