---@class ICSharpCode.NRefactory.Ast.ExternAliasDirective : ICSharpCode.NRefactory.Ast.AbstractNode
---instance properties
---@field public Name System.String
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.ExternAliasDirective=m
return m;