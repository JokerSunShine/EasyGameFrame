---@class ActiveAnimation : UnityEngine.MonoBehaviour
---fields
---@field public current ActiveAnimation
---instance fields
---@field public onFinished System.Collections.Generic.List1EventDelegate
---@field public eventReceiver UnityEngine.GameObject
---@field public callWhenFinished System.String
---instance properties
---@field public isPlaying System.Boolean
local m = {};
---@param anim UnityEngine.Animation
---@param clipName System.String
---@param playDirection AnimationOrTween.Direction
---@param enableBeforePlay AnimationOrTween.EnableCondition
---@param disableCondition AnimationOrTween.DisableCondition
---@return ActiveAnimation
function m.Play(anim, clipName, playDirection, enableBeforePlay, disableCondition) end
---@param anim UnityEngine.Animation
---@param clipName System.String
---@param playDirection AnimationOrTween.Direction
---@return ActiveAnimation
function m.Play(anim, clipName, playDirection) end
---@param anim UnityEngine.Animation
---@param playDirection AnimationOrTween.Direction
---@return ActiveAnimation
function m.Play(anim, playDirection) end
---@param anim UnityEngine.Animator
---@param clipName System.String
---@param playDirection AnimationOrTween.Direction
---@param enableBeforePlay AnimationOrTween.EnableCondition
---@param disableCondition AnimationOrTween.DisableCondition
---@return ActiveAnimation
function m.Play(anim, clipName, playDirection, enableBeforePlay, disableCondition) end

function m:Finish() end
function m:Reset() end
ActiveAnimation=m
return m;