---@class DynamicTerrainTerrainMesh
local m = {};
---@param coord UnityEngineVector2Int
---@param attachGo UnityEngineGameObject
function m:InitMesh(coord, attachGo) end
---@param coord UnityEngineVector2Int
function m:RefreshMesh(coord) end
DynamicTerrainTerrainMesh=m
return m;