---@class ICSharpCodeNRefactoryAstQueryExpressionPartitionType
---@field Take @0
---@field TakeWhile @1
---@field Skip @2
---@field SkipWhile @3
ICSharpCodeNRefactoryAstQueryExpressionPartitionType=m
return m;