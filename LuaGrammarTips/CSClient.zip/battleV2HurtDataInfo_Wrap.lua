---@class battleV2.HurtDataInfo
---instance properties
---@field public targetId System.Int64
---@field public targetIdSpecified System.Boolean
---@field public name System.String
---@field public nameSpecified System.Boolean
---@field public targetHp System.Int64
---@field public targetHpSpecified System.Boolean
---@field public targetInner System.Int64
---@field public targetInnerSpecified System.Boolean
---@field public magic System.Int64
---@field public magicSpecified System.Boolean
---@field public hurtType System.Int32
---@field public hurtTypeSpecified System.Boolean
---@field public attackType System.Int32
---@field public attackTypeSpecified System.Boolean
---@field public effect System.Collections.Generic.List1System.Int32
---@field public buffers System.Collections.Generic.List1battleV2.BufferAdd
local m = {};

battleV2.HurtDataInfo=m
return m;