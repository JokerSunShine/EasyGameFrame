---@class DataStructTreeBinaryTreeNode1T
---instance fields
---@field public DepthChange SystemBoolean
---@field public color SystemBoolean
---instance properties
---@field public Tree DataStructTreeBinaryTreeChainBinaryTreeAbstract1T
---@field public Data T
---@field public LeftNode DataStructTreeBinaryTreeNode1T
---@field public RightNode DataStructTreeBinaryTreeNode1T
---@field public Parent DataStructTreeBinaryTreeNode1T
---@field public PointType DataStructTreeBinaryTreeNode1ParentPointTypeT
---@field public Degree SystemInt32
---@field public Depth SystemInt32
---@field public BalanceFactor SystemInt32
local m = {};
---@param data T
---@return SystemBoolean
function m:IsEqual(data) end
function m:NoticeDataChange() end
DataStructTreeBinaryTreeNode1T=m
return m;