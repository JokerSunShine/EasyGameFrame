---@class ExCSS.AggregateRule : ExCSS.RuleSet
---instance properties
---@field public RuleSets System.Collections.Generic.List`1[ExCSS.RuleSet]
local m = {};
ExCSS.AggregateRule=m
return m;