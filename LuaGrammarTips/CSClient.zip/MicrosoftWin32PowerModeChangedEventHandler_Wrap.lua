---@class MicrosoftWin32PowerModeChangedEventHandler : SystemMulticastDelegate
local m = {};
---@param sender SystemObject
---@param e MicrosoftWin32PowerModeChangedEventArgs
function m:Invoke(sender, e) end
---@param sender SystemObject
---@param e MicrosoftWin32PowerModeChangedEventArgs
---@param callback SystemAsyncCallback
---@param object SystemObject
---@return SystemIAsyncResult
function m:BeginInvoke(sender, e, callback, object) end
---@param result SystemIAsyncResult
function m:EndInvoke(result) end
MicrosoftWin32PowerModeChangedEventHandler=m
return m;