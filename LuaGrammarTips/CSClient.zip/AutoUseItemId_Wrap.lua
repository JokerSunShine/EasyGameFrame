---@class AutoUseItemId
---@field AutoUseAllItems @20456
local m = {};
AutoUseItemId=m
return m;