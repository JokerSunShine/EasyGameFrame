---@class activityV2.ResRaffCount
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public totalCount System.Int32
---@field public totalCountSpecified System.Boolean
local m = {};

activityV2.ResRaffCount=m
return m;