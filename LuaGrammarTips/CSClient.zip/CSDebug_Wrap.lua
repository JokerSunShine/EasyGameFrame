---@class CSDebug
---fields
---@field public LogSwitch System.Boolean
local m = {};
---@param message System.Object
function m.Log(message) end
---@param message System.Object
---@param context UnityEngine.Object
function m.Log(message, context) end
---@param message System.Object
function m.LogWarning(message) end
---@param message System.Object
---@param context UnityEngine.Object
function m.LogWarning(message, context) end
---@param message System.Object
function m.LogError(message) end
---@param message System.Object
---@param context UnityEngine.Object
function m.LogError(message, context) end
---@param format System.String
---@param args System.Object[]
function m.LogFormat(format, args) end
---@param context UnityEngine.Object
---@param format System.String
---@param args System.Object[]
function m.LogFormat(context, format, args) end
---@param logType UnityEngine.LogType
---@param logOptions UnityEngine.LogOption
---@param context UnityEngine.Object
---@param format System.String
---@param args System.Object[]
function m.LogFormat(logType, logOptions, context, format, args) end
---@param format System.String
---@param args System.Object[]
function m.LogWarningFormat(format, args) end
---@param context UnityEngine.Object
---@param format System.String
---@param args System.Object[]
function m.LogWarningFormat(context, format, args) end
---@param format System.String
---@param args System.Object[]
function m.LogErrorFormat(format, args) end
---@param context UnityEngine.Object
---@param format System.String
---@param args System.Object[]
function m.LogErrorFormat(context, format, args) end
---@param ex System.Exception
function m.LogException(ex) end
---@param exception System.Exception
---@param context UnityEngine.Object
function m.LogException(exception, context) end
function m.Break() end
CSDebug=m
return m;