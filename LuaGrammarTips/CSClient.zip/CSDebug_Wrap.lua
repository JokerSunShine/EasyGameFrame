---@class CSDebug
---fields
---@field public LogSwitch SystemBoolean
local m = {};
---@param message SystemObject
function m.Log(message) end
---@param message SystemObject
---@param context UnityEngineObject
function m.Log(message, context) end
---@param message SystemObject
function m.LogWarning(message) end
---@param message SystemObject
---@param context UnityEngineObject
function m.LogWarning(message, context) end
---@param message SystemObject
function m.LogError(message) end
---@param message SystemObject
---@param context UnityEngineObject
function m.LogError(message, context) end
---@param format SystemString
---@param args SystemObject
function m.LogFormat(format, args) end
---@param context UnityEngineObject
---@param format SystemString
---@param args SystemObject
function m.LogFormat(context, format, args) end
---@param logType UnityEngineLogType
---@param logOptions UnityEngineLogOption
---@param context UnityEngineObject
---@param format SystemString
---@param args SystemObject
function m.LogFormat(logType, logOptions, context, format, args) end
---@param format SystemString
---@param args SystemObject
function m.LogWarningFormat(format, args) end
---@param context UnityEngineObject
---@param format SystemString
---@param args SystemObject
function m.LogWarningFormat(context, format, args) end
---@param format SystemString
---@param args SystemObject
function m.LogErrorFormat(format, args) end
---@param context UnityEngineObject
---@param format SystemString
---@param args SystemObject
function m.LogErrorFormat(context, format, args) end
---@param ex SystemException
function m.LogException(ex) end
---@param exception SystemException
---@param context UnityEngineObject
function m.LogException(exception, context) end
function m.Break() end
CSDebug=m
return m;