---@class MicrosoftWin32KeyHandler
---instance fields
---@field public Dir SystemString
---@field public IsVolatile SystemBoolean
---instance properties
---@field public ValueCount SystemInt32
---@field public IsMarkedForDeletion SystemBoolean
local m = {};
---@param dir SystemString
---@return SystemBoolean
function m.VolatileKeyExists(dir) end
---@param dir SystemString
---@return SystemString
function m.GetVolatileDir(dir) end
---@param rkey MicrosoftWin32RegistryKey
---@param createNonExisting SystemBoolean
---@return MicrosoftWin32KeyHandler
function m.Lookup(rkey, createNonExisting) end
---@param rkey MicrosoftWin32RegistryKey
function m.Drop(rkey) end
---@param dir SystemString
function m.Drop(dir) end
---@param dir SystemString
---@return SystemBoolean
function m.Delete(dir) end
function m:Load() end
---@param rkey MicrosoftWin32RegistryKey
---@param extra SystemString
---@param writable SystemBoolean
---@return MicrosoftWin32RegistryKey
function m:Ensure(rkey, extra, writable) end
---@param rkey MicrosoftWin32RegistryKey
---@param extra SystemString
---@param writable SystemBoolean
---@param is_volatile SystemBoolean
---@return MicrosoftWin32RegistryKey
function m:Ensure(rkey, extra, writable, is_volatile) end
---@param rkey MicrosoftWin32RegistryKey
---@param extra SystemString
---@param writable SystemBoolean
---@return MicrosoftWin32RegistryKey
function m:Probe(rkey, extra, writable) end
---@param name SystemString
---@return MicrosoftWin32RegistryValueKind
function m:GetValueKind(name) end
---@param name SystemString
---@param options MicrosoftWin32RegistryValueOptions
---@return SystemObject
function m:GetValue(name, options) end
---@param name SystemString
---@param value SystemObject
function m:SetValue(name, value) end
---@return SystemString
function m:GetValueNames() end
---@return SystemInt32
function m:GetSubKeyCount() end
---@return SystemString
function m:GetSubKeyNames() end
---@param name SystemString
---@param value SystemObject
---@param valueKind MicrosoftWin32RegistryValueKind
function m:SetValue(name, value, valueKind) end
---@param state SystemObject
function m:DirtyTimeout(state) end
function m:Flush() end
---@param name SystemString
---@return SystemBoolean
function m:ValueExists(name) end
---@param name SystemString
function m:RemoveValue(name) end
MicrosoftWin32KeyHandler=m
return m;