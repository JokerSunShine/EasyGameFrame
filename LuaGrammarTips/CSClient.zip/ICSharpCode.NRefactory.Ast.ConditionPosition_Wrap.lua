---@class ICSharpCode.NRefactory.Ast.ConditionPosition
---@field None @0
---@field Start @1
---@field End @2
ICSharpCode.NRefactory.Ast.ConditionPosition=m
return m;