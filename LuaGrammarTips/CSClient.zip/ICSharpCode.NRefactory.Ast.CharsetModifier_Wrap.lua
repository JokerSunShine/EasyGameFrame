---@class ICSharpCode.NRefactory.Ast.CharsetModifier
---@field None @0
---@field Auto @1
---@field Unicode @2
---@field Ansi @3
ICSharpCode.NRefactory.Ast.CharsetModifier=m
return m;