---@class ICSharpCodeNRefactoryAstSwitchStatement : ICSharpCodeNRefactoryAstStatement
---instance properties
---@field public SwitchExpression ICSharpCodeNRefactoryAstExpression
---@field public SwitchSections SystemCollectionsGenericList1ICSharpCodeNRefactoryAstSwitchSection
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstSwitchStatement=m
return m;