---@class ExCSS.ParserError
---@field EndOfFile @0
---@field UnexpectedLineBreak @1
---@field InvalidCharacter @2
---@field UnexpectedCommentToken @3
ExCSS.ParserError=m
return m;