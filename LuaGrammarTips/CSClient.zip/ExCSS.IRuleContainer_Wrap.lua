---@class ExCSS.IRuleContainer
---instance properties
---@field public Declarations System.Collections.Generic.List`1[ExCSS.RuleSet]
local m = {};
ExCSS.IRuleContainer=m
return m;