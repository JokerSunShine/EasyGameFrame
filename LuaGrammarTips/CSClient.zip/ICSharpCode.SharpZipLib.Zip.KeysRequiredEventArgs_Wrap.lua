---@class ICSharpCode.SharpZipLib.Zip.KeysRequiredEventArgs : System.EventArgs
---instance properties
---@field public FileName System.String
---@field public Key System.Byte[]
local m = {};
ICSharpCode.SharpZipLib.Zip.KeysRequiredEventArgs=m
return m;