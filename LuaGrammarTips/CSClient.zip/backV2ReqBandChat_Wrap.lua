---@class backV2.ReqBandChat
---instance properties
---@field public uid System.String
---@field public uidSpecified System.Boolean
---@field public banReason System.String
---@field public banReasonSpecified System.Boolean
---@field public bandTime System.Int32
---@field public bandTimeSpecified System.Boolean
local m = {};

backV2.ReqBandChat=m
return m;