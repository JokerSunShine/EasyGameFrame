---@class activityV2.ReqOpenPanel
---instance properties
---@field public activityType System.Int32
---@field public activityTypeSpecified System.Boolean
local m = {};

activityV2.ReqOpenPanel=m
return m;