---@class backV2.ResAutoBanList
---instance properties
---@field public autoBanInfo System.Collections.Generic.List1backV2.AutoBanInfo
local m = {};

backV2.ResAutoBanList=m
return m;