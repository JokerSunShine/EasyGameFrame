---@class ICSharpCode.SharpZipLib.BZip2.BZip2OutputStream : System.IO.Stream
---instance properties
---@field public CanRead System.Boolean
---@field public CanSeek System.Boolean
---@field public CanWrite System.Boolean
---@field public Length System.Int64
---@field public Position System.Int64
local m = {};
---@param offset System.Int64
---@param origin System.IO.SeekOrigin
---@return System.Int64
function m:Seek(offset, origin) end
---@param val System.Int64
function m:SetLength(val) end
---@return System.Int32
function m:ReadByte() end
---@param b System.Byte[]
---@param off System.Int32
---@param len System.Int32
---@return System.Int32
function m:Read(b, off, len) end
---@param buf System.Byte[]
---@param off System.Int32
---@param len System.Int32
function m:Write(buf, off, len) end
---@param bv System.Byte
function m:WriteByte(bv) end
function m:Close() end
function m:Flush() end
ICSharpCode.SharpZipLib.BZip2.BZip2OutputStream=m
return m;