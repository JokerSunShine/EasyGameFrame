---@class backV2.ResSendEmail
---instance properties
---@field public targetId System.Int64
---@field public targetIdSpecified System.Boolean
---@field public title System.String
---@field public titleSpecified System.Boolean
---@field public content System.String
---@field public contentSpecified System.Boolean
---@field public itemStr System.String
---@field public itemStrSpecified System.Boolean
local m = {};

backV2.ResSendEmail=m
return m;