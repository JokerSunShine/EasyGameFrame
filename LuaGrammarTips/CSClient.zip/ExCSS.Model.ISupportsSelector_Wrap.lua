---@class ExCSS.Model.ISupportsSelector
---instance properties
---@field public Selector ExCSS.BaseSelector
local m = {};
ExCSS.Model.ISupportsSelector=m
return m;