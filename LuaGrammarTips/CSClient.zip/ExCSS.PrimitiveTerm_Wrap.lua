---@class ExCSS.PrimitiveTerm : ExCSS.Term
---instance properties
---@field public Value System.Object
---@field public PrimitiveType ExCSS.UnitType
local m = {};
---@param unit ExCSS.UnitType
---@return System.Nullable`1[System.Single]
function m:GetFloatValue(unit) end
---@return System.String
function m:ToString() end
ExCSS.PrimitiveTerm=m
return m;