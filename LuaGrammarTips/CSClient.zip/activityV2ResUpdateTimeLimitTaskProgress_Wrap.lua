---@class activityV2.ResUpdateTimeLimitTaskProgress
---instance properties
---@field public taskId System.Int32
---@field public taskIdSpecified System.Boolean
---@field public count System.Int32
---@field public countSpecified System.Boolean
local m = {};

activityV2.ResUpdateTimeLimitTaskProgress=m
return m;