---@class ExCSSProperty
---instance properties
---@field public Name SystemString
---@field public Term ExCSSTerm
---@field public Important SystemBoolean
---@field public Line SystemInt32
local m = {};
---@return SystemString
function m:ToString() end
---@param friendlyFormat SystemBoolean
---@param indentation SystemInt32 @default_value:0
---@return SystemString
function m:ToString(friendlyFormat, indentation) end
ExCSSProperty=m
return m;