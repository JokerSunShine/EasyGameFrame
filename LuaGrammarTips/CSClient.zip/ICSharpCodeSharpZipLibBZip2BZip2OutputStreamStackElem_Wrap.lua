---@class ICSharpCodeSharpZipLibBZip2BZip2OutputStreamStackElem
---instance fields
---@field public ll SystemInt32
---@field public hh SystemInt32
---@field public dd SystemInt32
local m = {};
ICSharpCodeSharpZipLibBZip2BZip2OutputStreamStackElem=m
return m;