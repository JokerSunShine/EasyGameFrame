---@class ICSharpCodeNRefactoryAstStatement : ICSharpCodeNRefactoryAstAbstractNode
---properties
---@field public Null ICSharpCodeNRefactoryAstStatement
---instance properties
---@field public IsNull SystemBoolean
local m = {};
---@param statement ICSharpCodeNRefactoryAstStatement
---@return ICSharpCodeNRefactoryAstStatement
function m.CheckNull(statement) end
ICSharpCodeNRefactoryAstStatement=m
return m;