---@class MicrosoftWin32RegistryKey : SystemMarshalByRefObject
---instance properties
---@field public Name SystemString
---@field public SubKeyCount SystemInt32
---@field public ValueCount SystemInt32
---@field public Handle MicrosoftWin32SafeHandlesSafeRegistryHandle
---@field public View MicrosoftWin32RegistryView
local m = {};
---@param handle MicrosoftWin32SafeHandlesSafeRegistryHandle
---@return MicrosoftWin32RegistryKey
function m.FromHandle(handle) end
---@param handle MicrosoftWin32SafeHandlesSafeRegistryHandle
---@param view MicrosoftWin32RegistryView
---@return MicrosoftWin32RegistryKey
function m.FromHandle(handle, view) end
---@param hKey MicrosoftWin32RegistryHive
---@param machineName SystemString
---@return MicrosoftWin32RegistryKey
function m.OpenRemoteBaseKey(hKey, machineName) end
---@param hKey MicrosoftWin32RegistryHive
---@param machineName SystemString
---@param view MicrosoftWin32RegistryView
---@return MicrosoftWin32RegistryKey
function m.OpenRemoteBaseKey(hKey, machineName, view) end
---@param hKey MicrosoftWin32RegistryHive
---@param view MicrosoftWin32RegistryView
---@return MicrosoftWin32RegistryKey
function m.OpenBaseKey(hKey, view) end
function m:Dispose() end
function m:Flush() end
function m:Close() end
---@param name SystemString
---@param value SystemObject
function m:SetValue(name, value) end
---@param name SystemString
---@param value SystemObject
---@param valueKind MicrosoftWin32RegistryValueKind
function m:SetValue(name, value, valueKind) end
---@param name SystemString
---@return MicrosoftWin32RegistryKey
function m:OpenSubKey(name) end
---@param name SystemString
---@param writable SystemBoolean
---@return MicrosoftWin32RegistryKey
function m:OpenSubKey(name, writable) end
---@param name SystemString
---@return SystemObject
function m:GetValue(name) end
---@param name SystemString
---@param defaultValue SystemObject
---@return SystemObject
function m:GetValue(name, defaultValue) end
---@param name SystemString
---@param defaultValue SystemObject
---@param options MicrosoftWin32RegistryValueOptions
---@return SystemObject
function m:GetValue(name, defaultValue, options) end
---@param name SystemString
---@return MicrosoftWin32RegistryValueKind
function m:GetValueKind(name) end
---@param subkey SystemString
---@return MicrosoftWin32RegistryKey
function m:CreateSubKey(subkey) end
---@param subkey SystemString
---@param permissionCheck MicrosoftWin32RegistryKeyPermissionCheck
---@return MicrosoftWin32RegistryKey
function m:CreateSubKey(subkey, permissionCheck) end
---@param subkey SystemString
---@param permissionCheck MicrosoftWin32RegistryKeyPermissionCheck
---@param registrySecurity SystemSecurityAccessControlRegistrySecurity
---@return MicrosoftWin32RegistryKey
function m:CreateSubKey(subkey, permissionCheck, registrySecurity) end
---@param subkey SystemString
---@param permissionCheck MicrosoftWin32RegistryKeyPermissionCheck
---@param options MicrosoftWin32RegistryOptions
---@return MicrosoftWin32RegistryKey
function m:CreateSubKey(subkey, permissionCheck, options) end
---@param subkey SystemString
---@param permissionCheck MicrosoftWin32RegistryKeyPermissionCheck
---@param registryOptions MicrosoftWin32RegistryOptions
---@param registrySecurity SystemSecurityAccessControlRegistrySecurity
---@return MicrosoftWin32RegistryKey
function m:CreateSubKey(subkey, permissionCheck, registryOptions, registrySecurity) end
---@param subkey SystemString
---@param writable SystemBoolean
---@return MicrosoftWin32RegistryKey
function m:CreateSubKey(subkey, writable) end
---@param subkey SystemString
---@param writable SystemBoolean
---@param options MicrosoftWin32RegistryOptions
---@return MicrosoftWin32RegistryKey
function m:CreateSubKey(subkey, writable, options) end
---@param subkey SystemString
function m:DeleteSubKey(subkey) end
---@param subkey SystemString
---@param throwOnMissingSubKey SystemBoolean
function m:DeleteSubKey(subkey, throwOnMissingSubKey) end
---@param subkey SystemString
function m:DeleteSubKeyTree(subkey) end
---@param subkey SystemString
---@param throwOnMissingSubKey SystemBoolean
function m:DeleteSubKeyTree(subkey, throwOnMissingSubKey) end
---@param name SystemString
function m:DeleteValue(name) end
---@param name SystemString
---@param throwOnMissingValue SystemBoolean
function m:DeleteValue(name, throwOnMissingValue) end
---@return SystemSecurityAccessControlRegistrySecurity
function m:GetAccessControl() end
---@param includeSections SystemSecurityAccessControlAccessControlSections
---@return SystemSecurityAccessControlRegistrySecurity
function m:GetAccessControl(includeSections) end
---@return SystemString
function m:GetSubKeyNames() end
---@return SystemString
function m:GetValueNames() end
---@param name SystemString
---@param permissionCheck MicrosoftWin32RegistryKeyPermissionCheck
---@return MicrosoftWin32RegistryKey
function m:OpenSubKey(name, permissionCheck) end
---@param name SystemString
---@param rights SystemSecurityAccessControlRegistryRights
---@return MicrosoftWin32RegistryKey
function m:OpenSubKey(name, rights) end
---@param name SystemString
---@param permissionCheck MicrosoftWin32RegistryKeyPermissionCheck
---@param rights SystemSecurityAccessControlRegistryRights
---@return MicrosoftWin32RegistryKey
function m:OpenSubKey(name, permissionCheck, rights) end
---@param registrySecurity SystemSecurityAccessControlRegistrySecurity
function m:SetAccessControl(registrySecurity) end
---@return SystemString
function m:ToString() end
MicrosoftWin32RegistryKey=m
return m;