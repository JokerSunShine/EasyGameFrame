---@class ExCSSStyleSheet
---instance properties
---@field public Rules SystemCollectionsGenericList1ExCSSRuleSet
---@field public StyleRules SystemCollectionsGenericIList1ExCSSStyleRule
---@field public CharsetDirectives SystemCollectionsGenericIList1ExCSSCharacterSetRule
---@field public ImportDirectives SystemCollectionsGenericIList1ExCSSImportRule
---@field public FontFaceDirectives SystemCollectionsGenericIList1ExCSSFontFaceRule
---@field public KeyframeDirectives SystemCollectionsGenericIList1ExCSSKeyframesRule
---@field public MediaDirectives SystemCollectionsGenericIList1ExCSSMediaRule
---@field public PageDirectives SystemCollectionsGenericIList1ExCSSPageRule
---@field public SupportsDirectives SystemCollectionsGenericIList1ExCSSSupportsRule
---@field public NamespaceDirectives SystemCollectionsGenericIList1ExCSSNamespaceRule
---@field public Errors SystemCollectionsGenericList1ExCSSStylesheetParseError
local m = {};
---@param index SystemInt32
---@return ExCSSStyleSheet
function m:RemoveRule(index) end
---@param rule SystemString
---@param index SystemInt32
---@return ExCSSStyleSheet
function m:InsertRule(rule, index) end
---@return SystemString
function m:ToString() end
---@param friendlyFormat SystemBoolean
---@param indentation SystemInt32 @default_value:0
---@return SystemString
function m:ToString(friendlyFormat, indentation) end
ExCSSStyleSheet=m
return m;