---@class appearanceV2.ResModifyTitle
---instance properties
---@field public titleId System.Int32
---@field public titleIdSpecified System.Boolean
---@field public modifyTitle System.String
---@field public modifyTitleSpecified System.Boolean
---@field public rid System.Int64
---@field public ridSpecified System.Boolean
local m = {};

appearanceV2.ResModifyTitle=m
return m;