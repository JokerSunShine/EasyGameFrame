---@class ExCSS.DocumentFunction
---@field Url @0
---@field UrlPrefix @1
---@field Domain @2
---@field RegExp @3
ExCSS.DocumentFunction=m
return m;