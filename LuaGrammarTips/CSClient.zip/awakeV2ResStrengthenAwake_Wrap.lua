---@class awakeV2.ResStrengthenAwake
---instance properties
---@field public index System.Int32
---@field public indexSpecified System.Boolean
---@field public level System.Int32
---@field public levelSpecified System.Boolean
---@field public bless System.Int32
---@field public blessSpecified System.Boolean
---@field public power System.Int32
---@field public powerSpecified System.Boolean
local m = {};

awakeV2.ResStrengthenAwake=m
return m;