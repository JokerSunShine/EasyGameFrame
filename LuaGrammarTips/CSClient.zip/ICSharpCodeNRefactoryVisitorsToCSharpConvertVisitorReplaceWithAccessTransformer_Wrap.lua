---@class ICSharpCodeNRefactoryVisitorsToCSharpConvertVisitorReplaceWithAccessTransformer : ICSharpCodeNRefactoryVisitorsAbstractAstTransformer
local m = {};
---@param fieldReferenceExpression ICSharpCodeNRefactoryAstMemberReferenceExpression
---@param data SystemObject
---@return SystemObject
function m:VisitMemberReferenceExpression(fieldReferenceExpression, data) end
---@param withStatement ICSharpCodeNRefactoryAstWithStatement
---@param data SystemObject
---@return SystemObject
function m:VisitWithStatement(withStatement, data) end
ICSharpCodeNRefactoryVisitorsToCSharpConvertVisitorReplaceWithAccessTransformer=m
return m;