---@class ActivityRankTopInfo
---instance fields
---@field public str System.String
---@field public posX System.Single
---@field public featureType System.Int32
---@field public iconName System.String
local m = {};

ActivityRankTopInfo=m
return m;