---@class DataStructTreeBinaryTreeBinaryTreeReBuild1T
local m = {};
---@param preList DataStructTreeBinaryTreeNode1T
---@param MiddleList DataStructTreeBinaryTreeNode1T
---@param preStart SystemInt32
---@param preEnd SystemInt32
---@param middleStart SystemInt32
---@param middleEnd SystemInt32
---@return DataStructTreeBinaryTreeNode1T
function m.PreAndMiddleToBinaryTree(preList, MiddleList, preStart, preEnd, middleStart, middleEnd) end
---@param middleList DataStructTreeBinaryTreeNode1T
---@param behindList DataStructTreeBinaryTreeNode1T
---@param middleStart SystemInt32
---@param middleEnd SystemInt32
---@param behindStart SystemInt32
---@param behindEnd SystemInt32
---@return DataStructTreeBinaryTreeNode1T
function m.MiddleAndBehindToBinaryTree(middleList, behindList, middleStart, middleEnd, behindStart, behindEnd) end
DataStructTreeBinaryTreeBinaryTreeReBuild1T=m
return m;