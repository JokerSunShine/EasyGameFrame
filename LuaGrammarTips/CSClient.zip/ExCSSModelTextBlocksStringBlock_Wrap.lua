---@class ExCSSModelTextBlocksStringBlock : ExCSSModelTextBlocksBlock
local m = {};
---@return SystemString
function m:ToString() end
ExCSSModelTextBlocksStringBlock=m
return m;