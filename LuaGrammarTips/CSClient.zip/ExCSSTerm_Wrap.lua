---@class ExCSSTerm
---fields
---@field public Inherit ExCSSInheritTerm
local m = {};
ExCSSTerm=m
return m;