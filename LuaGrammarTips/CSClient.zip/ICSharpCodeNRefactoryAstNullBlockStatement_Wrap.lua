---@class ICSharpCodeNRefactoryAstNullBlockStatement : ICSharpCodeNRefactoryAstBlockStatement
---fields
---@field public Instance ICSharpCodeNRefactoryAstNullBlockStatement
---instance properties
---@field public IsNull SystemBoolean
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptChildren(visitor, data) end
---@param childNode ICSharpCodeNRefactoryAstINode
function m:AddChild(childNode) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstNullBlockStatement=m
return m;