---@class ICSharpCode.SharpZipLib.Zip.Compression.InflaterDynHeader
local m = {};
---@param input ICSharpCode.SharpZipLib.Zip.Compression.Streams.StreamManipulator
---@return System.Boolean
function m:Decode(input) end
---@return ICSharpCode.SharpZipLib.Zip.Compression.InflaterHuffmanTree
function m:BuildLitLenTree() end
---@return ICSharpCode.SharpZipLib.Zip.Compression.InflaterHuffmanTree
function m:BuildDistTree() end
ICSharpCode.SharpZipLib.Zip.Compression.InflaterDynHeader=m
return m;