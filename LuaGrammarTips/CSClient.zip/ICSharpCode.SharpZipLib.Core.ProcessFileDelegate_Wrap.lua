---@class ICSharpCode.SharpZipLib.Core.ProcessFileDelegate : System.MulticastDelegate
local m = {};
---@param sender System.Object
---@param e ICSharpCode.SharpZipLib.Core.ScanEventArgs
function m:Invoke(sender, e) end
---@param sender System.Object
---@param e ICSharpCode.SharpZipLib.Core.ScanEventArgs
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(sender, e, callback, object) end
---@param result System.IAsyncResult
function m:EndInvoke(result) end
ICSharpCode.SharpZipLib.Core.ProcessFileDelegate=m
return m;