---@class MicrosoftWin32PowerModeChangedEventArgs : SystemEventArgs
---instance properties
---@field public Mode MicrosoftWin32PowerModes
local m = {};
MicrosoftWin32PowerModeChangedEventArgs=m
return m;