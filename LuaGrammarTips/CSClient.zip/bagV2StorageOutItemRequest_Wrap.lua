---@class bagV2.StorageOutItemRequest
---instance properties
---@field public objId System.Int64
local m = {};

bagV2.StorageOutItemRequest=m
return m;