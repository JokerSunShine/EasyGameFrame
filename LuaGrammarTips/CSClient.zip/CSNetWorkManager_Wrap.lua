---@class CSNetWorkManager : ManagerObject
---properties
---@field public Instance CSNetWorkManager
---instance properties
---@field public UnpackMsgThreadIsAlive SystemBoolean
local m = {};
---@param host SystemString
---@param port SystemInt32
---@param loginServerType LoginServerType @default_value:GameServer
function m:Connect(host, port, loginServerType) end
function m:ServerConnectedSuccess() end
---@param e SystemException
function m:ServerConnectedFailed(e) end
---@param msgId SystemInt32
---@param msg SystemObject @default_value:
function m:SendMsg(msgId, msg) end
---@param msgId SystemInt32
---@param msgData SystemByte
function m:SendMsgByte(msgId, msgData) end
CSNetWorkManager=m
return m;