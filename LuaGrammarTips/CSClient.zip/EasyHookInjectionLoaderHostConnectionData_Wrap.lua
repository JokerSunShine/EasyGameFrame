---@class EasyHookInjectionLoaderHostConnectionData
---instance properties
---@field public State EasyHookInjectionLoaderHostConnectionDataConnectionState
---@field public UnmanagedInfo EasyHookInjectionLoaderREMOTE_ENTRY_INFO
---@field public HelperInterface EasyHookHelperServiceInterface
---@field public RemoteInfo EasyHookManagedRemoteInfo
local m = {};
---@param unmanagedInfoPointer SystemIntPtr
---@return EasyHookInjectionLoaderHostConnectionData
function m.LoadData(unmanagedInfoPointer) end
EasyHookInjectionLoaderHostConnectionData=m
return m;