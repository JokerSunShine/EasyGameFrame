---@class achievementV2.ReqAllAchievementReward
---instance properties
---@field public rewardId System.Int32
---@field public rewardIdSpecified System.Boolean
local m = {};

achievementV2.ReqAllAchievementReward=m
return m;