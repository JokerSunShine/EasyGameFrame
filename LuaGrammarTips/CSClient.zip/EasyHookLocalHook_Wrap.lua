---@class EasyHookLocalHook : SystemRuntimeConstrainedExecutionCriticalFinalizerObject
---properties
---@field public GlobalThreadACL EasyHookHookAccessControl
---instance properties
---@field public Callback SystemObject
---@field public ThreadACL EasyHookHookAccessControl
---@field public HookBypassAddress SystemIntPtr
local m = {};
function m.EnableRIPRelocation() end
---@param InThreadHandle SystemIntPtr
---@return SystemInt32
function m.GetThreadIdByHandle(InThreadHandle) end
---@param InProcessHandle SystemIntPtr
---@return SystemInt32
function m.GetProcessIdByHandle(InProcessHandle) end
---@param InHandle SystemIntPtr
---@return SystemString
function m.GetNameByHandle(InHandle) end
---@param InTargetProc SystemIntPtr
---@param InNewProc SystemDelegate
---@param InCallback SystemObject
---@return EasyHookLocalHook
function m.Create(InTargetProc, InNewProc, InCallback) end
---@param InTargetProc SystemIntPtr
---@param InNewProc SystemIntPtr
---@param InCallback SystemIntPtr
---@return EasyHookLocalHook
function m.CreateUnmanaged(InTargetProc, InNewProc, InCallback) end
---@param InModule SystemString
---@param InSymbolName SystemString
---@return SystemIntPtr
function m.GetProcAddress(InModule, InSymbolName) end
function m.Release() end
---@param InThreadID SystemInt32
---@return SystemBoolean
function m:IsThreadIntercepted(InThreadID) end
function m:Dispose() end
EasyHookLocalHook=m
return m;