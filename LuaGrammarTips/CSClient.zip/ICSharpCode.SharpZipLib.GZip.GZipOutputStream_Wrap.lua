---@class ICSharpCode.SharpZipLib.GZip.GZipOutputStream : ICSharpCode.SharpZipLib.Zip.Compression.Streams.DeflaterOutputStream
local m = {};
---@param buf System.Byte[]
---@param off System.Int32
---@param len System.Int32
function m:Write(buf, off, len) end
function m:Close() end
---@param level System.Int32
function m:SetLevel(level) end
---@return System.Int32
function m:GetLevel() end
function m:Finish() end
ICSharpCode.SharpZipLib.GZip.GZipOutputStream=m
return m;