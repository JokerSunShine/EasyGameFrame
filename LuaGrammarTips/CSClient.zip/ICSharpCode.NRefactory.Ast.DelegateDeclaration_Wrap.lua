---@class ICSharpCode.NRefactory.Ast.DelegateDeclaration : ICSharpCode.NRefactory.Ast.AttributedNode
---instance properties
---@field public Name System.String
---@field public ReturnType ICSharpCode.NRefactory.Ast.TypeReference
---@field public Parameters System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.ParameterDeclarationExpression]
---@field public Templates System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.TemplateDefinition]
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.DelegateDeclaration=m
return m;