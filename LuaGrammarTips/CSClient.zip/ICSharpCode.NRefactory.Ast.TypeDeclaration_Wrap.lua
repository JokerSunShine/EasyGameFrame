---@class ICSharpCode.NRefactory.Ast.TypeDeclaration : ICSharpCode.NRefactory.Ast.AttributedNode
---instance properties
---@field public Name System.String
---@field public Type ICSharpCode.NRefactory.Ast.ClassType
---@field public BaseTypes System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.TypeReference]
---@field public Templates System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.TemplateDefinition]
---@field public BodyStartLocation ICSharpCode.NRefactory.Location
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.TypeDeclaration=m
return m;