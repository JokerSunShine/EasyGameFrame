---@class ActivityRankComponentSystemInfo : RankComponentSystemInfo
---instance fields
---@field public iconName System.String
local m = {};

ActivityRankComponentSystemInfo=m
return m;