---@class ICSharpCodeNRefactoryAstLambdaExpression : ICSharpCodeNRefactoryAstExpression
---instance properties
---@field public Parameters SystemCollectionsGenericList1ICSharpCodeNRefactoryAstParameterDeclarationExpression
---@field public StatementBody ICSharpCodeNRefactoryAstBlockStatement
---@field public ExpressionBody ICSharpCodeNRefactoryAstExpression
---@field public ExtendedEndLocation ICSharpCodeNRefactoryLocation
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstLambdaExpression=m
return m;