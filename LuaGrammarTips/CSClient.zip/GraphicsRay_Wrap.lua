---@class GraphicsRay
---instance fields
---@field public Origin _3DMathVector3
---@field public Delta _3DMathVector3
local m = {};
GraphicsRay=m
return m;