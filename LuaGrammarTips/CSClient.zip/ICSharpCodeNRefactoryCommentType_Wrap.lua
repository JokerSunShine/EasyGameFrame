---@class ICSharpCodeNRefactoryCommentType
---@field Block @0
---@field SingleLine @1
---@field Documentation @2
ICSharpCodeNRefactoryCommentType=m
return m;