---@class ICSharpCode.NRefactory.Ast.CollectionInitializerExpression : ICSharpCode.NRefactory.Ast.Expression
---properties
---@field public Null ICSharpCode.NRefactory.Ast.CollectionInitializerExpression
---instance properties
---@field public CreateExpressions System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.Expression]
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.CollectionInitializerExpression=m
return m;