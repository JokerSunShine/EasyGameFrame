---@class ArrowType
---@field Left @1
---@field Down @2
---@field LeftUp @3
---@field Top @4
---@field TopLeft @5
---@field TopRight @6
local m = {};
ArrowType=m
return m;