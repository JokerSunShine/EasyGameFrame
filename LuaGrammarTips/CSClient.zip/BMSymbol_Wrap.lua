---@class BMSymbol
---instance fields
---@field public sequence System.String
---@field public spriteName System.String
---instance properties
---@field public length System.Int32
---@field public offsetX System.Int32
---@field public offsetY System.Int32
---@field public width System.Int32
---@field public height System.Int32
---@field public advance System.Int32
---@field public uvRect UnityEngine.Rect
local m = {};

function m:MarkAsChanged() end
---@param atlas UIAtlas
---@return System.Boolean
function m:Validate(atlas) end
BMSymbol=m
return m;