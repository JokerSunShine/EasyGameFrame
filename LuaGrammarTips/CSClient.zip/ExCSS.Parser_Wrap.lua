---@class ExCSS.Parser
local m = {};
---@param css System.String
---@return ExCSS.StyleSheet
function m:Parse(css) end
ExCSS.Parser=m
return m;