---@class ICSharpCodeNRefactoryAstINullable
---instance properties
---@field public IsNull SystemBoolean
local m = {};
ICSharpCodeNRefactoryAstINullable=m
return m;