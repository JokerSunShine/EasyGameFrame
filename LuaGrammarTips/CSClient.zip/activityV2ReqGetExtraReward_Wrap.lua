---@class activityV2.ReqGetExtraReward
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public goalType System.Int32
---@field public goalTypeSpecified System.Boolean
local m = {};

activityV2.ReqGetExtraReward=m
return m;