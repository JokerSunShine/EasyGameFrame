---@class AlgorithmGraphArithmeticGraphArithmetic1T
local m = {};
---@param graph DataStructGraphMatrixGraphMatrixGraph1T
---@return CommonOneWayChainListOneWayChainList1SystemInt32
function m.TopologicalSort(graph) end
---@param graph DataStructGraphALGraphALGraph1T
---@return CommonOneWayChainListOneWayChainList1SystemInt32
function m.TopologicalSort(graph) end
---@param graph DataStructGraphALGraphALGraph1T
function m.CriticalPath(graph) end
AlgorithmGraphArithmeticGraphArithmetic1T=m
return m;