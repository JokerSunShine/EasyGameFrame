---@class bagV2.ReqUseSpyBrand
---instance properties
---@field public itemLid System.Int64
---@field public itemLidSpecified System.Boolean
---@field public roleLid System.Int64
---@field public roleLidSpecified System.Boolean
local m = {};

bagV2.ReqUseSpyBrand=m
return m;