---@class ICSharpCodeSharpZipLibZipCompressionDeflaterHuffmanTree
---instance fields
---@field public freqs SystemInt16
---@field public length SystemByte
---@field public minNumCodes SystemInt32
---@field public numCodes SystemInt32
local m = {};
function m:Reset() end
---@param code SystemInt32
function m:WriteSymbol(code) end
function m:CheckEmpty() end
---@param stCodes SystemInt16
---@param stLength SystemByte
function m:SetStaticCodes(stCodes, stLength) end
function m:BuildCodes() end
function m:BuildTree() end
---@return SystemInt32
function m:GetEncodedLength() end
---@param blTree ICSharpCodeSharpZipLibZipCompressionDeflaterHuffmanTree
function m:CalcBLFreq(blTree) end
---@param blTree ICSharpCodeSharpZipLibZipCompressionDeflaterHuffmanTree
function m:WriteTree(blTree) end
ICSharpCodeSharpZipLibZipCompressionDeflaterHuffmanTree=m
return m;