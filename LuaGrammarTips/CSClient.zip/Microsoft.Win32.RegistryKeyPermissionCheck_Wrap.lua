---@class Microsoft.Win32.RegistryKeyPermissionCheck
---@field Default @0
---@field ReadSubTree @1
---@field ReadWriteSubTree @2
Microsoft.Win32.RegistryKeyPermissionCheck=m
return m;