---@class ExCSS.RuleSet
---instance properties
---@field public RuleType ExCSS.RuleType
local m = {};
---@param friendlyFormat System.Boolean
---@param indentation System.Int32 @default_value:0
---@return System.String
function m:ToString(friendlyFormat, indentation) end
ExCSS.RuleSet=m
return m;