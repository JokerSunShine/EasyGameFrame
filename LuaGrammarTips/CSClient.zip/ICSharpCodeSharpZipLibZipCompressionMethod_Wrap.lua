---@class ICSharpCodeSharpZipLibZipCompressionMethod
---@field Stored @0
---@field Deflated @8
---@field Deflate64 @9
---@field BZip2 @11
---@field WinZipAES @99
ICSharpCodeSharpZipLibZipCompressionMethod=m
return m;