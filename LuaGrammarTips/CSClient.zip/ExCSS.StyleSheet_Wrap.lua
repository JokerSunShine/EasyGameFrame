---@class ExCSS.StyleSheet
---instance properties
---@field public Rules System.Collections.Generic.List`1[ExCSS.RuleSet]
---@field public StyleRules System.Collections.Generic.IList`1[ExCSS.StyleRule]
---@field public CharsetDirectives System.Collections.Generic.IList`1[ExCSS.CharacterSetRule]
---@field public ImportDirectives System.Collections.Generic.IList`1[ExCSS.ImportRule]
---@field public FontFaceDirectives System.Collections.Generic.IList`1[ExCSS.FontFaceRule]
---@field public KeyframeDirectives System.Collections.Generic.IList`1[ExCSS.KeyframesRule]
---@field public MediaDirectives System.Collections.Generic.IList`1[ExCSS.MediaRule]
---@field public PageDirectives System.Collections.Generic.IList`1[ExCSS.PageRule]
---@field public SupportsDirectives System.Collections.Generic.IList`1[ExCSS.SupportsRule]
---@field public NamespaceDirectives System.Collections.Generic.IList`1[ExCSS.NamespaceRule]
---@field public Errors System.Collections.Generic.List`1[ExCSS.StylesheetParseError]
local m = {};
---@param index System.Int32
---@return ExCSS.StyleSheet
function m:RemoveRule(index) end
---@param rule System.String
---@param index System.Int32
---@return ExCSS.StyleSheet
function m:InsertRule(rule, index) end
---@return System.String
function m:ToString() end
---@param friendlyFormat System.Boolean
---@param indentation System.Int32 @default_value:0
---@return System.String
function m:ToString(friendlyFormat, indentation) end
ExCSS.StyleSheet=m
return m;