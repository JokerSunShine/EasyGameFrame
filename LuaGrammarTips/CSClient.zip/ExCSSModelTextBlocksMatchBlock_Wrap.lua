---@class ExCSSModelTextBlocksMatchBlock : ExCSSModelTextBlocksBlock
local m = {};
---@return SystemString
function m:ToString() end
ExCSSModelTextBlocksMatchBlock=m
return m;