---@class ICSharpCode.SharpZipLib.Zip.ZipNameTransform
---instance properties
---@field public TrimPrefix System.String
local m = {};
---@param name System.String
---@return System.String
function m:TransformDirectory(name) end
---@param name System.String
---@return System.String
function m:TransformFile(name) end
ICSharpCode.SharpZipLib.Zip.ZipNameTransform=m
return m;