---@class bagV2.AwardPreyTreasureBoxMulti
---instance properties
---@field public itemId System.Int32
---@field public itemIdSpecified System.Boolean
---@field public count System.Int32
---@field public countSpecified System.Boolean
local m = {};

bagV2.AwardPreyTreasureBoxMulti=m
return m;