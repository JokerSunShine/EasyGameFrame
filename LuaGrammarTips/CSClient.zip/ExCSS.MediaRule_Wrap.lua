---@class ExCSS.MediaRule : ExCSS.ConditionalRule
---instance properties
---@field public Condition System.String
---@field public Media ExCSS.MediaTypeList
local m = {};
---@return System.String
function m:ToString() end
---@param friendlyFormat System.Boolean
---@param indentation System.Int32 @default_value:0
---@return System.String
function m:ToString(friendlyFormat, indentation) end
ExCSS.MediaRule=m
return m;