---@class ExCSS.Model.TextBlocks.PipeBlock : ExCSS.Model.TextBlocks.Block
local m = {};
---@return System.String
function m:ToString() end
ExCSS.Model.TextBlocks.PipeBlock=m
return m;