---@class DataUtilIActiveFieldsSet
local m = {};
---@param field SystemString
function m:AddAll(field) end
DataUtilIActiveFieldsSet=m
return m;