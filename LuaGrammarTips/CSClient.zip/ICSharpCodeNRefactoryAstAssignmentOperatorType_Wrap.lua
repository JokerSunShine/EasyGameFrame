---@class ICSharpCodeNRefactoryAstAssignmentOperatorType
---@field None @0
---@field Assign @1
---@field Add @2
---@field Subtract @3
---@field Multiply @4
---@field Divide @5
---@field Modulus @6
---@field Power @7
---@field DivideInteger @8
---@field ConcatString @9
---@field ShiftLeft @10
---@field ShiftRight @11
---@field BitwiseAnd @12
---@field BitwiseOr @13
---@field ExclusiveOr @14
ICSharpCodeNRefactoryAstAssignmentOperatorType=m
return m;