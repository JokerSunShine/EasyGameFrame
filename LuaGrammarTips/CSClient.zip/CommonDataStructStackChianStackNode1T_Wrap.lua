---@class CommonDataStructStackChianStackNode1T
---instance fields
---@field public Data T
---@field public Next CommonDataStructStackChianStackNode1T
local m = {};
CommonDataStructStackChianStackNode1T=m
return m;