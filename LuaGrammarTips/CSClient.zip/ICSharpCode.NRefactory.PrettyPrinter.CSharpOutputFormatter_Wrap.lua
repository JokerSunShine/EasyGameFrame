---@class ICSharpCode.NRefactory.PrettyPrinter.CSharpOutputFormatter : ICSharpCode.NRefactory.PrettyPrinter.AbstractOutputFormatter
---instance properties
---@field public EmitSemicolon System.Boolean
local m = {};
---@param token System.Int32
function m:PrintToken(token) end
---@param style ICSharpCode.NRefactory.PrettyPrinter.BraceStyle
---@param indent System.Boolean
function m:BeginBrace(style, indent) end
---@param indent System.Boolean
function m:EndBrace(indent) end
---@param indent System.Boolean
---@param emitNewLine System.Boolean
function m:EndBrace(indent, emitNewLine) end
---@param identifier System.String
function m:PrintIdentifier(identifier) end
---@param comment ICSharpCode.NRefactory.Comment
---@param forceWriteInPreviousBlock System.Boolean
function m:PrintComment(comment, forceWriteInPreviousBlock) end
ICSharpCode.NRefactory.PrettyPrinter.CSharpOutputFormatter=m
return m;