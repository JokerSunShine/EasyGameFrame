---@class Analyze_TestLuaMemoryBaseTableType
---@field Global @1
---@field UpValue @2
---@field Registry @3
local m = {};
Analyze_TestLuaMemoryBaseTableType=m
return m;