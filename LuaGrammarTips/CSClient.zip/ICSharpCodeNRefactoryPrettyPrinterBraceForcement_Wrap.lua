---@class ICSharpCodeNRefactoryPrettyPrinterBraceForcement
---@field DoNotChange @0
---@field RemoveBraces @1
---@field AddBraces @2
---@field RemoveBracesForSingleLine @3
ICSharpCodeNRefactoryPrettyPrinterBraceForcement=m
return m;