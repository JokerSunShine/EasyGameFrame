---@class EditorCoroutineRunner
local m = {};
---@param iEnumerator SystemCollectionsIEnumerator
---@return SystemCollectionsIEnumerator
function m.StartEditorCoroutine(iEnumerator) end
EditorCoroutineRunner=m
return m;