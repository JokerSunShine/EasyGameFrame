---@class EditorCoroutineRunner
local m = {};
---@param iEnumerator System.Collections.IEnumerator
---@return System.Collections.IEnumerator
function m.StartEditorCoroutine(iEnumerator) end
EditorCoroutineRunner=m
return m;