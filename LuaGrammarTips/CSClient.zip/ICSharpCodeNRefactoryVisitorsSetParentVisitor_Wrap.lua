---@class ICSharpCodeNRefactoryVisitorsSetParentVisitor : ICSharpCodeNRefactoryVisitorsNodeTrackingAstVisitor
local m = {};
ICSharpCodeNRefactoryVisitorsSetParentVisitor=m
return m;