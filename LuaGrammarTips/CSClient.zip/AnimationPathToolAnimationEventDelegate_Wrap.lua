---@class AnimationPathToolAnimationEventDelegate : System.MulticastDelegate
local m = {};

---@param data UnityEngine.AnimationEvent
function m:Invoke(data) end
---@param data UnityEngine.AnimationEvent
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(data, callback, object) end
---@param result System.IAsyncResult
function m:EndInvoke(result) end
AnimationPathToolAnimationEventDelegate=m
return m;