---@class bagV2.ReqCanUseGatherSpiritBead
---instance properties
---@field public itemId System.Int32
---@field public itemIdSpecified System.Boolean
local m = {};

bagV2.ReqCanUseGatherSpiritBead=m
return m;