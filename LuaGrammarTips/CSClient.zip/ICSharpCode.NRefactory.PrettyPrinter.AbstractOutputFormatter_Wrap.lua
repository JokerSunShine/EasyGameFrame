---@class ICSharpCode.NRefactory.PrettyPrinter.AbstractOutputFormatter
---instance properties
---@field public IsInMemberBody System.Boolean
---@field public IndentationLevel System.Int32
---@field public Text System.String
---@field public TextLength System.Int32
---@field public DoIndent System.Boolean
---@field public DoNewLine System.Boolean
---@field public LastCharacterIsNewLine System.Boolean
---@field public LastCharacterIsWhiteSpace System.Boolean
local m = {};
function m:Indent() end
function m:Reset() end
function m:Space() end
function m:NewLine() end
function m:EndFile() end
---@param tokenList System.Collections.ArrayList
function m:PrintTokenList(tokenList) end
---@param comment ICSharpCode.NRefactory.Comment
---@param forceWriteInPreviousBlock System.Boolean
function m:PrintComment(comment, forceWriteInPreviousBlock) end
---@param directive ICSharpCode.NRefactory.PreprocessingDirective
---@param forceWriteInPreviousBlock System.Boolean
function m:PrintPreprocessingDirective(directive, forceWriteInPreviousBlock) end
---@param forceWriteInPreviousBlock System.Boolean
function m:PrintBlankLine(forceWriteInPreviousBlock) end
---@param token System.Int32
function m:PrintToken(token) end
---@param text System.String
function m:PrintText(text) end
---@param identifier System.String
function m:PrintIdentifier(identifier) end
ICSharpCode.NRefactory.PrettyPrinter.AbstractOutputFormatter=m
return m;