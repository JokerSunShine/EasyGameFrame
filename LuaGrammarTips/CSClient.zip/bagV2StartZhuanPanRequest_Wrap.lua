---@class bagV2.StartZhuanPanRequest
---instance properties
---@field public itemId System.Int32
local m = {};

bagV2.StartZhuanPanRequest=m
return m;