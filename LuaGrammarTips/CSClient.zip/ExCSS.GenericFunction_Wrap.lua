---@class ExCSS.GenericFunction : ExCSS.Term
---instance properties
---@field public Name System.String
---@field public Arguments ExCSS.TermList
local m = {};
---@return System.String
function m:ToString() end
ExCSS.GenericFunction=m
return m;