---@class auctionV2.BuyProductsMarketPriceSectionRequest
---instance properties
---@field public condition auctionV2.BuyProductsCondition
---@field public MarketPriceSectionType System.Int32
---@field public MarketPriceSectionTypeSpecified System.Boolean
---@field public itemType System.Int32
---@field public itemTypeSpecified System.Boolean
---@field public lid System.Int64
---@field public lidSpecified System.Boolean
---@field public name System.String
---@field public nameSpecified System.Boolean
local m = {};

auctionV2.BuyProductsMarketPriceSectionRequest=m
return m;