---@class GraphicsLine
---instance fields
---@field public origin _3DMathVector3
---@field public end _3DMathVector3
local m = {};
GraphicsLine=m
return m;