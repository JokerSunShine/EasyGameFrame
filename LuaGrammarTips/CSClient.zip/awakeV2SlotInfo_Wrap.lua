---@class awakeV2.SlotInfo
---instance properties
---@field public index System.Int32
---@field public indexSpecified System.Boolean
---@field public level System.Int32
---@field public levelSpecified System.Boolean
---@field public bless System.Int32
---@field public blessSpecified System.Boolean
local m = {};

awakeV2.SlotInfo=m
return m;