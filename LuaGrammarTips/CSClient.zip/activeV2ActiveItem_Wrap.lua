---@class activeV2.ActiveItem
---instance properties
---@field public id System.Int32
---@field public idSpecified System.Boolean
---@field public completeCount System.Int32
---@field public completeCountSpecified System.Boolean
---@field public hasCompleteItem System.Boolean
---@field public hasCompleteItemSpecified System.Boolean
---@field public clientActiveNum System.Int32
---@field public clientActiveNumSpecified System.Boolean
local m = {};

activeV2.ActiveItem=m
return m;