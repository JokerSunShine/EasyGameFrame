---@class auctionV2.pushResponse
---instance properties
---@field public PushType System.Int32
---@field public PushTypeSpecified System.Boolean
---@field public item bagV2.BagItemInfo
---@field public priceItemId System.Int32
---@field public priceItemIdSpecified System.Boolean
---@field public price System.Int64
---@field public priceSpecified System.Boolean
local m = {};

auctionV2.pushResponse=m
return m;