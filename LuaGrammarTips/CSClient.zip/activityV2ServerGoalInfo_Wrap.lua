---@class activityV2.ServerGoalInfo
---instance properties
---@field public goalId System.Int32
---@field public goalIdSpecified System.Boolean
---@field public ok System.Boolean
---@field public okSpecified System.Boolean
---@field public count System.Int32
---@field public countSpecified System.Boolean
---@field public no System.Int32
---@field public noSpecified System.Boolean
---@field public finishRoleId System.Int64
---@field public finishRoleIdSpecified System.Boolean
---@field public finishName System.String
---@field public finishNameSpecified System.Boolean
---@field public award System.Boolean
---@field public awardSpecified System.Boolean
---@field public finishSex System.Int32
---@field public finishSexSpecified System.Boolean
---@field public finishCarrer System.Int32
---@field public finishCarrerSpecified System.Boolean
local m = {};

activityV2.ServerGoalInfo=m
return m;