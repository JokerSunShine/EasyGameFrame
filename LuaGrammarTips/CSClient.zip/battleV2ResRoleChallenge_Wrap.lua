---@class battleV2.ResRoleChallenge
---instance properties
---@field public count System.Int32
---@field public countSpecified System.Boolean
local m = {};

battleV2.ResRoleChallenge=m
return m;