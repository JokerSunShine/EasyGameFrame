---@class ICSharpCodeSharpZipLibZipCompressionDeflaterEngine : ICSharpCodeSharpZipLibZipCompressionDeflaterConstants
---instance properties
---@field public Adler SystemInt32
---@field public TotalIn SystemInt32
---@field public Strategy ICSharpCodeSharpZipLibZipCompressionDeflateStrategy
local m = {};
function m:Reset() end
function m:ResetAdler() end
---@param lvl SystemInt32
function m:SetLevel(lvl) end
function m:FillWindow() end
---@param buffer SystemByte
---@param offset SystemInt32
---@param length SystemInt32
function m:SetDictionary(buffer, offset, length) end
---@param flush SystemBoolean
---@param finish SystemBoolean
---@return SystemBoolean
function m:Deflate(flush, finish) end
---@param buf SystemByte
---@param off SystemInt32
---@param len SystemInt32
function m:SetInput(buf, off, len) end
---@return SystemBoolean
function m:NeedsInput() end
ICSharpCodeSharpZipLibZipCompressionDeflaterEngine=m
return m;