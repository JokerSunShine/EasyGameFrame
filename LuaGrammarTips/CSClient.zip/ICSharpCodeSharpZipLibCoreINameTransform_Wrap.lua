---@class ICSharpCodeSharpZipLibCoreINameTransform
local m = {};
---@param name SystemString
---@return SystemString
function m:TransformFile(name) end
---@param name SystemString
---@return SystemString
function m:TransformDirectory(name) end
ICSharpCodeSharpZipLibCoreINameTransform=m
return m;