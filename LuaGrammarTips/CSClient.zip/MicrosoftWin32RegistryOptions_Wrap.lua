---@class MicrosoftWin32RegistryOptions
---@field None @0
---@field Volatile @1
MicrosoftWin32RegistryOptions=m
return m;