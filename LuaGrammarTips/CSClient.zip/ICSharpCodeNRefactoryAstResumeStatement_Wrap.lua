---@class ICSharpCodeNRefactoryAstResumeStatement : ICSharpCodeNRefactoryAstStatement
---instance properties
---@field public LabelName SystemString
---@field public IsResumeNext SystemBoolean
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstResumeStatement=m
return m;