---@class BehaviourProviderOnRunOverDoSmoethingEnd : System.MulticastDelegate
local m = {};

---@param avatar ISFAvater
---@return System.Boolean
function m:Invoke(avatar) end
---@param avatar ISFAvater
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(avatar, callback, object) end
---@param result System.IAsyncResult
---@return System.Boolean
function m:EndInvoke(result) end
BehaviourProviderOnRunOverDoSmoethingEnd=m
return m;