---@class ICSharpCode.NRefactory.OperatorPrecedence
local m = {};
---@param op1 ICSharpCode.NRefactory.Ast.BinaryOperatorType
---@param op2 ICSharpCode.NRefactory.Ast.BinaryOperatorType
---@return System.Int32
function m.ComparePrecedenceVB(op1, op2) end
---@param op1 ICSharpCode.NRefactory.Ast.BinaryOperatorType
---@param op2 ICSharpCode.NRefactory.Ast.BinaryOperatorType
---@return System.Int32
function m.ComparePrecedenceCSharp(op1, op2) end
ICSharpCode.NRefactory.OperatorPrecedence=m
return m;