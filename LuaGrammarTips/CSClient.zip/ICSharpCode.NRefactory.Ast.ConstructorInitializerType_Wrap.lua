---@class ICSharpCode.NRefactory.Ast.ConstructorInitializerType
---@field None @0
---@field Base @1
---@field This @2
ICSharpCode.NRefactory.Ast.ConstructorInitializerType=m
return m;