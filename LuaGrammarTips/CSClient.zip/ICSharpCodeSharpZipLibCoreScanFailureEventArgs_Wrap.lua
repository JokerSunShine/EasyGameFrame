---@class ICSharpCodeSharpZipLibCoreScanFailureEventArgs
---instance properties
---@field public Name SystemString
---@field public Exception SystemException
---@field public ContinueRunning SystemBoolean
local m = {};
ICSharpCodeSharpZipLibCoreScanFailureEventArgs=m
return m;