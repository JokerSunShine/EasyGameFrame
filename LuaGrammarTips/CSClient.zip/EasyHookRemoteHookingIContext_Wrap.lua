---@class EasyHookRemoteHookingIContext
---instance properties
---@field public HostPID SystemInt32
local m = {};
EasyHookRemoteHookingIContext=m
return m;