---@class ICSharpCodeSharpZipLibZipZipFileZipEntryEnumeration
---instance properties
---@field public Current SystemObject
local m = {};
function m:Reset() end
---@return SystemBoolean
function m:MoveNext() end
ICSharpCodeSharpZipLibZipZipFileZipEntryEnumeration=m
return m;