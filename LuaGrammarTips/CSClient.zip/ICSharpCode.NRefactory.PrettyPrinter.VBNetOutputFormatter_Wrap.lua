---@class ICSharpCode.NRefactory.PrettyPrinter.VBNetOutputFormatter : ICSharpCode.NRefactory.PrettyPrinter.AbstractOutputFormatter
local m = {};
---@param token System.Int32
function m:PrintToken(token) end
---@param identifier System.String
function m:PrintIdentifier(identifier) end
---@param comment ICSharpCode.NRefactory.Comment
---@param forceWriteInPreviousBlock System.Boolean
function m:PrintComment(comment, forceWriteInPreviousBlock) end
---@param directive ICSharpCode.NRefactory.PreprocessingDirective
---@param forceWriteInPreviousBlock System.Boolean
function m:PrintPreprocessingDirective(directive, forceWriteInPreviousBlock) end
function m:PrintLineContinuation() end
ICSharpCode.NRefactory.PrettyPrinter.VBNetOutputFormatter=m
return m;