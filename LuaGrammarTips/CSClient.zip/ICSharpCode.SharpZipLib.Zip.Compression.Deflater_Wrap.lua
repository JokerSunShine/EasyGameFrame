---@class ICSharpCode.SharpZipLib.Zip.Compression.Deflater
---fields
---@field public BEST_COMPRESSION System.Int32
---@field public BEST_SPEED System.Int32
---@field public DEFAULT_COMPRESSION System.Int32
---@field public NO_COMPRESSION System.Int32
---@field public DEFLATED System.Int32
---instance properties
---@field public Adler System.Int32
---@field public TotalIn System.Int32
---@field public TotalOut System.Int64
---@field public IsFinished System.Boolean
---@field public IsNeedingInput System.Boolean
local m = {};
function m:Reset() end
function m:Flush() end
function m:Finish() end
---@param input System.Byte[]
function m:SetInput(input) end
---@param input System.Byte[]
---@param off System.Int32
---@param len System.Int32
function m:SetInput(input, off, len) end
---@param lvl System.Int32
function m:SetLevel(lvl) end
---@return System.Int32
function m:GetLevel() end
---@param strategy ICSharpCode.SharpZipLib.Zip.Compression.DeflateStrategy
function m:SetStrategy(strategy) end
---@param output System.Byte[]
---@return System.Int32
function m:Deflate(output) end
---@param output System.Byte[]
---@param offset System.Int32
---@param length System.Int32
---@return System.Int32
function m:Deflate(output, offset, length) end
---@param dict System.Byte[]
function m:SetDictionary(dict) end
---@param dict System.Byte[]
---@param offset System.Int32
---@param length System.Int32
function m:SetDictionary(dict, offset, length) end
ICSharpCode.SharpZipLib.Zip.Compression.Deflater=m
return m;