---@class bagV2.ResSuccessBuyBindlitem
---instance properties
---@field public lid System.Collections.Generic.List1System.Int64
local m = {};

bagV2.ResSuccessBuyBindlitem=m
return m;