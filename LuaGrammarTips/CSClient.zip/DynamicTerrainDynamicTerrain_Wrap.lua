---@class DynamicTerrainDynamicTerrain
---properties
---@field public Instance DynamicTerrainDynamicTerrain
---instance properties
---@field public TerrainGo UnityEngineGameObject
local m = {};
---@param detector UnityEngineTransform
---@param blockWidth SystemInt32
---@param blockHeight SystemInt32
---@param viewWidth SystemInt32
---@param viewHight SystemInt32
function m:Init(detector, blockWidth, blockHeight, viewWidth, viewHight) end
---@param terrainData DynamicTerrainTerrainData
function m:RefreshTerrain(terrainData) end
function m:Destroy() end
---@param bShow SystemBoolean
function m:Show(bShow) end
function m:Update() end
DynamicTerrainDynamicTerrain=m
return m;