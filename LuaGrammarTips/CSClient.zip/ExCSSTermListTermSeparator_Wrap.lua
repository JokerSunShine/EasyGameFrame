---@class ExCSSTermListTermSeparator
---@field Comma @0
---@field Space @1
---@field Colon @2
ExCSSTermListTermSeparator=m
return m;