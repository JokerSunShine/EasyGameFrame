---@class backV2.ResSenUnionInfo
---instance properties
---@field public unionName System.String
---@field public unionNameSpecified System.Boolean
---@field public memberList System.Collections.Generic.List1backV2.UnionMemberInfo
local m = {};

backV2.ResSenUnionInfo=m
return m;