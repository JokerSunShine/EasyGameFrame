---@class AssetBundles.AssetBundleLoadOperation
---instance properties
---@field public Current System.Object
local m = {};

---@return System.Boolean
function m:MoveNext() end
function m:Reset() end
---@return System.Boolean
function m:Update() end
---@return System.Boolean
function m:IsDone() end
AssetBundles.AssetBundleLoadOperation=m
return m;