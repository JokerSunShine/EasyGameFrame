---@class ExtendEditorFileUtility
local m = {};
---@param obj UnityEngineObject
---@return SystemString
function m.GetDirectory(obj) end
---@param path SystemString
---@return SystemString
function m.GetDirectory(path) end
ExtendEditorFileUtility=m
return m;