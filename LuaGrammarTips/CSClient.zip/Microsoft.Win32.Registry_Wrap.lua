---@class Microsoft.Win32.Registry
---fields
---@field public ClassesRoot Microsoft.Win32.RegistryKey
---@field public CurrentConfig Microsoft.Win32.RegistryKey
---@field public CurrentUser Microsoft.Win32.RegistryKey
---@field public LocalMachine Microsoft.Win32.RegistryKey
---@field public PerformanceData Microsoft.Win32.RegistryKey
---@field public Users Microsoft.Win32.RegistryKey
local m = {};
---@param keyName System.String
---@param valueName System.String
---@param value System.Object
function m.SetValue(keyName, valueName, value) end
---@param keyName System.String
---@param valueName System.String
---@param value System.Object
---@param valueKind Microsoft.Win32.RegistryValueKind
function m.SetValue(keyName, valueName, value, valueKind) end
---@param keyName System.String
---@param valueName System.String
---@param defaultValue System.Object
---@return System.Object
function m.GetValue(keyName, valueName, defaultValue) end
Microsoft.Win32.Registry=m
return m;