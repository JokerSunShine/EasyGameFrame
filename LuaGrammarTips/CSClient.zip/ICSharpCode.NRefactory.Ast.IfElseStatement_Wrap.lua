---@class ICSharpCode.NRefactory.Ast.IfElseStatement : ICSharpCode.NRefactory.Ast.Statement
---instance properties
---@field public Condition ICSharpCode.NRefactory.Ast.Expression
---@field public TrueStatement System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.Statement]
---@field public FalseStatement System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.Statement]
---@field public ElseIfSections System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.ElseIfSection]
---@field public HasElseStatements System.Boolean
---@field public HasElseIfSections System.Boolean
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.IfElseStatement=m
return m;