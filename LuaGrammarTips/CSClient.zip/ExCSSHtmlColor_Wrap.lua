---@class ExCSSHtmlColor : ExCSSTerm
---instance fields
---@field public A SystemByte
---@field public R SystemByte
---@field public G SystemByte
---@field public B SystemByte
---instance properties
---@field public Alpha SystemDouble
local m = {};
---@param r SystemByte
---@param g SystemByte
---@param b SystemByte
---@param a SystemSingle
---@return ExCSSHtmlColor
function m.FromRgba(r, g, b, a) end
---@param r SystemByte
---@param g SystemByte
---@param b SystemByte
---@param a SystemDouble
---@return ExCSSHtmlColor
function m.FromRgba(r, g, b, a) end
---@param r SystemByte
---@param g SystemByte
---@param b SystemByte
---@return ExCSSHtmlColor
function m.FromRgb(r, g, b) end
---@param h SystemSingle
---@param s SystemSingle
---@param l SystemSingle
---@return ExCSSHtmlColor
function m.FromHsl(h, s, l) end
---@param color SystemString
---@return ExCSSHtmlColor
function m.FromHex(color) end
---@param color SystemString
---@param htmlColor ExCSSHtmlColor @out
---@return SystemBoolean
function m.TryFromHex(color, htmlColor) end
---@param a ExCSSHtmlColor
---@param b ExCSSHtmlColor
---@return SystemBoolean
function m.op_Equality(a, b) end
---@param a ExCSSHtmlColor
---@param b ExCSSHtmlColor
---@return SystemBoolean
function m.op_Inequality(a, b) end
---@param obj SystemObject
---@return SystemBoolean
function m:Equals(obj) end
---@return SystemInt32
function m:GetHashCode() end
---@return SystemString
function m:ToString() end
---@param friendlyFormat SystemBoolean
---@param indentation SystemInt32 @default_value:0
---@return SystemString
function m:ToString(friendlyFormat, indentation) end
---@param forceLong SystemBoolean
---@param friendlyFormat SystemBoolean
---@param indentation SystemInt32 @default_value:0
---@return SystemString
function m:ToString(forceLong, friendlyFormat, indentation) end
---@param other ExCSSHtmlColor
---@return SystemBoolean
function m:Equals(other) end
ExCSSHtmlColor=m
return m;