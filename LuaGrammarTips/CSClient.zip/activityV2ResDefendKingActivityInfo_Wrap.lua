---@class activityV2.ResDefendKingActivityInfo
---instance properties
---@field public list System.Collections.Generic.List1activityV2.DefendUnionInfo
---@field public myScore System.Int32
---@field public myScoreSpecified System.Boolean
---@field public spyScore System.Int32
---@field public spyScoreSpecified System.Boolean
---@field public endTime System.Int64
---@field public endTimeSpecified System.Boolean
---@field public kingHpPer System.Int32
---@field public kingHpPerSpecified System.Boolean
---@field public unionId System.Int64
---@field public unionIdSpecified System.Boolean
---@field public unionName System.String
---@field public unionNameSpecified System.Boolean
local m = {};

activityV2.ResDefendKingActivityInfo=m
return m;