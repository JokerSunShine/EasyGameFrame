---@class ICSharpCode.NRefactory.PrettyPrinter.BraceForcement
---@field DoNotChange @0
---@field RemoveBraces @1
---@field AddBraces @2
---@field RemoveBracesForSingleLine @3
ICSharpCode.NRefactory.PrettyPrinter.BraceForcement=m
return m;