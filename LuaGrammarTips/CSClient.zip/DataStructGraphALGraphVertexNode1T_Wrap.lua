---@class DataStructGraphALGraphVertexNode1T : DataStructGraphBaseNodeAbstract1T
---instance fields
---@field public first_edge DataStructGraphALGraphEdgeNode
---@field public count SystemInt32
---@field public earliestStartTime SystemInt32
---@field public lastestStartTime SystemInt32
---@field public isCriticalPath SystemBoolean
---@field public inDegreeNum SystemInt32
local m = {};
---@param vertexIndex SystemInt32
---@param len SystemInt32
function m:AddEdge(vertexIndex, len) end
---@param index SystemInt32
function m:RemoveEdge(index) end
function m:RefreshCriticalPathState() end
---@return SystemCollectionsIEnumerator
function m:GetEnumerator() end
DataStructGraphALGraphVertexNode1T=m
return m;