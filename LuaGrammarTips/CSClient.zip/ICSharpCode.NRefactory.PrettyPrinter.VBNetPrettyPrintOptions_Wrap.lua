---@class ICSharpCode.NRefactory.PrettyPrinter.VBNetPrettyPrintOptions : ICSharpCode.NRefactory.PrettyPrinter.AbstractPrettyPrintOptions
---instance properties
---@field public OutputByValModifier System.Boolean
local m = {};
ICSharpCode.NRefactory.PrettyPrinter.VBNetPrettyPrintOptions=m
return m;