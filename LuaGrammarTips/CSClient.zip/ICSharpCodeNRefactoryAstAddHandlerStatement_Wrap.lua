---@class ICSharpCodeNRefactoryAstAddHandlerStatement : ICSharpCodeNRefactoryAstStatement
---instance properties
---@field public EventExpression ICSharpCodeNRefactoryAstExpression
---@field public HandlerExpression ICSharpCodeNRefactoryAstExpression
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstAddHandlerStatement=m
return m;