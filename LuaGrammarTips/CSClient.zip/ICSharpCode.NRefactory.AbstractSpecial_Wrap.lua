---@class ICSharpCode.NRefactory.AbstractSpecial
---instance properties
---@field public StartPosition ICSharpCode.NRefactory.Location
---@field public EndPosition ICSharpCode.NRefactory.Location
local m = {};
---@param visitor ICSharpCode.NRefactory.ISpecialVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.AbstractSpecial=m
return m;