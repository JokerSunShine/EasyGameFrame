---@class ExCSSGenericFunction : ExCSSTerm
---instance properties
---@field public Name SystemString
---@field public Arguments ExCSSTermList
local m = {};
---@return SystemString
function m:ToString() end
ExCSSGenericFunction=m
return m;