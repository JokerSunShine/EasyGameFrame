---@class auctionV2.BuyAuction
---instance properties
---@field public lid System.Int64
---@field public lidSpecified System.Boolean
---@field public count System.Int32
---@field public countSpecified System.Boolean
---@field public buyType System.Int32
---@field public buyTypeSpecified System.Boolean
local m = {};

auctionV2.BuyAuction=m
return m;