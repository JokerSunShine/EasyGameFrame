---@class EasyHookHookRuntimeInfoStackTraceBuffer : SystemRuntimeConstrainedExecutionCriticalFinalizerObject
---instance fields
---@field public Unmanaged SystemIntPtr
---@field public Managed SystemIntPtr
---@field public Modules SystemDiagnosticsProcessModule
local m = {};
---@param InCount SystemInt32
function m:Synchronize(InCount) end
EasyHookHookRuntimeInfoStackTraceBuffer=m
return m;