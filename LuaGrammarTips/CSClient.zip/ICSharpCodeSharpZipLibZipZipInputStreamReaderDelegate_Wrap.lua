---@class ICSharpCodeSharpZipLibZipZipInputStreamReaderDelegate : SystemMulticastDelegate
local m = {};
---@param b SystemByte
---@param offset SystemInt32
---@param length SystemInt32
---@return SystemInt32
function m:Invoke(b, offset, length) end
---@param b SystemByte
---@param offset SystemInt32
---@param length SystemInt32
---@param callback SystemAsyncCallback
---@param object SystemObject
---@return SystemIAsyncResult
function m:BeginInvoke(b, offset, length, callback, object) end
---@param result SystemIAsyncResult
---@return SystemInt32
function m:EndInvoke(result) end
ICSharpCodeSharpZipLibZipZipInputStreamReaderDelegate=m
return m;