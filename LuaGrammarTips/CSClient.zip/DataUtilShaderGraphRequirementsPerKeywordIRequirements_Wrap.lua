---@class DataUtilShaderGraphRequirementsPerKeywordIRequirements
---instance properties
---@field public requirements UnityEditorShaderGraphInternalShaderGraphRequirements
local m = {};
---@param value UnityEditorShaderGraphInternalShaderGraphRequirements
function m:SetRequirements(value) end
DataUtilShaderGraphRequirementsPerKeywordIRequirements=m
return m;