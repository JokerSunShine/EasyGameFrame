---@class ICSharpCode.NRefactory.Visitors.ToVBNetRenameConflictingVariablesVisitor
local m = {};
---@param method ICSharpCode.NRefactory.Ast.ParametrizedNode
function m.RenameConflicting(method) end
ICSharpCode.NRefactory.Visitors.ToVBNetRenameConflictingVariablesVisitor=m
return m;