---@class ICSharpCode.SharpZipLib.Tar.TarException : ICSharpCode.SharpZipLib.SharpZipBaseException
local m = {};
ICSharpCode.SharpZipLib.Tar.TarException=m
return m;