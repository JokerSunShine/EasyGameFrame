---@class activityV2.RaffleItem
---instance properties
---@field public itemId System.Int32
---@field public itemIdSpecified System.Boolean
---@field public count System.Int32
---@field public countSpecified System.Boolean
local m = {};

activityV2.RaffleItem=m
return m;