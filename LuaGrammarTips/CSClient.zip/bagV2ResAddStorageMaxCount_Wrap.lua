---@class bagV2.ResAddStorageMaxCount
---instance properties
---@field public emptyGridCount System.Int32
---@field public maxGridCount System.Int32
local m = {};

bagV2.ResAddStorageMaxCount=m
return m;