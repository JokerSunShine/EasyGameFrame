---@class backV2.ReqReloadCfg
---instance properties
---@field public type System.Int32
---@field public typeSpecified System.Boolean
---@field public cfgName System.String
---@field public cfgNameSpecified System.Boolean
---@field public cacheName System.String
---@field public cacheNameSpecified System.Boolean
local m = {};

backV2.ReqReloadCfg=m
return m;