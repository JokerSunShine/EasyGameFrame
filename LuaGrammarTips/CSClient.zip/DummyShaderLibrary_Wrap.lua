---@class DummyShaderLibrary
local m = {};
DummyShaderLibrary=m
return m;