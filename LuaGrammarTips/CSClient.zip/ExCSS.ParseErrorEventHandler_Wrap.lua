---@class ExCSS.ParseErrorEventHandler : System.MulticastDelegate
local m = {};
---@param e ExCSS.StylesheetParseError
function m:Invoke(e) end
---@param e ExCSS.StylesheetParseError
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(e, callback, object) end
---@param result System.IAsyncResult
function m:EndInvoke(result) end
ExCSS.ParseErrorEventHandler=m
return m;