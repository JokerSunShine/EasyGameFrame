---@class Microsoft.CSharp.CSharpCodeGenerator
local m = {};
---@param member System.CodeDom.CodeTypeMember
---@param writer System.IO.TextWriter
---@param options System.CodeDom.Compiler.CodeGeneratorOptions
function m:GenerateCodeFromMember(member, writer, options) end
---@param support System.CodeDom.Compiler.GeneratorSupport
---@return System.Boolean
function m:Supports(support) end
---@param value System.String
---@return System.Boolean
function m:IsValidIdentifier(value) end
---@param value System.String
function m:ValidateIdentifier(value) end
---@param name System.String
---@return System.String
function m:CreateValidIdentifier(name) end
---@param name System.String
---@return System.String
function m:CreateEscapedIdentifier(name) end
---@param typeRef System.CodeDom.CodeTypeReference
---@return System.String
function m:GetTypeOutput(typeRef) end
Microsoft.CSharp.CSharpCodeGenerator=m
return m;