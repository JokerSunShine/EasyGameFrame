---@class bagV2.ReqBuyMaterialWay
---instance properties
---@field public itemId System.Int32
---@field public itemIdSpecified System.Boolean
---@field public count System.Int32
---@field public countSpecified System.Boolean
---@field public materialId System.Int32
---@field public materialIdSpecified System.Boolean
---@field public materialCount System.Int32
---@field public materialCountSpecified System.Boolean
local m = {};

bagV2.ReqBuyMaterialWay=m
return m;