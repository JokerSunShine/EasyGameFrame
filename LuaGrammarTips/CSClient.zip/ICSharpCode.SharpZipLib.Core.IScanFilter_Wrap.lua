---@class ICSharpCode.SharpZipLib.Core.IScanFilter
local m = {};
---@param name System.String
---@return System.Boolean
function m:IsMatch(name) end
ICSharpCode.SharpZipLib.Core.IScanFilter=m
return m;