---@class appearanceV2.ReqEnableTitle
---instance properties
---@field public titleId System.Int32
---@field public titleIdSpecified System.Boolean
---@field public close System.Int32
---@field public closeSpecified System.Boolean
local m = {};

appearanceV2.ReqEnableTitle=m
return m;