---@class CSObjectWrapEditorXLuaTemplates : SystemValueType
---instance fields
---@field public LuaClassWrap CSObjectWrapEditorXLuaTemplate
---@field public LuaDelegateBridge CSObjectWrapEditorXLuaTemplate
---@field public LuaDelegateWrap CSObjectWrapEditorXLuaTemplate
---@field public LuaEnumWrap CSObjectWrapEditorXLuaTemplate
---@field public LuaInterfaceBridge CSObjectWrapEditorXLuaTemplate
---@field public LuaRegister CSObjectWrapEditorXLuaTemplate
---@field public LuaWrapPusher CSObjectWrapEditorXLuaTemplate
---@field public PackUnpack CSObjectWrapEditorXLuaTemplate
---@field public TemplateCommon CSObjectWrapEditorXLuaTemplate
local m = {};
CSObjectWrapEditorXLuaTemplates=m
return m;