---@class ICSharpCode.SharpZipLib.Zip.FastZip
---instance properties
---@field public CreateEmptyDirectories System.Boolean
---@field public NameTransform ICSharpCode.SharpZipLib.Zip.ZipNameTransform
local m = {};
---@param zipFileName System.String
---@param sourceDirectory System.String
---@param recurse System.Boolean
---@param fileFilter System.String
---@param directoryFilter System.String
function m:CreateZip(zipFileName, sourceDirectory, recurse, fileFilter, directoryFilter) end
---@param zipFileName System.String
---@param sourceDirectory System.String
---@param recurse System.Boolean
---@param fileFilter System.String
function m:CreateZip(zipFileName, sourceDirectory, recurse, fileFilter) end
---@param zipFileName System.String
---@param targetDirectory System.String
---@param fileFilter System.String
function m:ExtractZip(zipFileName, targetDirectory, fileFilter) end
---@param zipFileName System.String
---@param targetDirectory System.String
---@param overwrite ICSharpCode.SharpZipLib.Zip.FastZip+Overwrite
---@param confirmDelegate ICSharpCode.SharpZipLib.Zip.FastZip+ConfirmOverwriteDelegate
---@param fileFilter System.String
---@param directoryFilter System.String
function m:ExtractZip(zipFileName, targetDirectory, overwrite, confirmDelegate, fileFilter, directoryFilter) end
ICSharpCode.SharpZipLib.Zip.FastZip=m
return m;