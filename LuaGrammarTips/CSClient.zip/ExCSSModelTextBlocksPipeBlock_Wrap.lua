---@class ExCSSModelTextBlocksPipeBlock : ExCSSModelTextBlocksBlock
local m = {};
---@return SystemString
function m:ToString() end
ExCSSModelTextBlocksPipeBlock=m
return m;