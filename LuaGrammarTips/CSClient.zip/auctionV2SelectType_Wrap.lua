---@class auctionV2.SelectType
---@field ALL @1
---@field AUCTION @2
---@field SALEDIAMOND @3
---@field JOINAUCTION @4
local m = {};
auctionV2.SelectType=m
return m;