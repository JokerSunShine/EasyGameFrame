---@class MicrosoftWin32RegistryKeyComparer
local m = {};
---@param x SystemObject
---@param y SystemObject
---@return SystemBoolean
function m:Equals(x, y) end
---@param obj SystemObject
---@return SystemInt32
function m:GetHashCode(obj) end
MicrosoftWin32RegistryKeyComparer=m
return m;