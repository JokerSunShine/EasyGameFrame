---@class activityV2.ShouHuLimitBuyInfo
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public lifeCount System.Int32
---@field public lifeCountSpecified System.Boolean
---@field public leftCount System.Int32
---@field public leftCountSpecified System.Boolean
local m = {};

activityV2.ShouHuLimitBuyInfo=m
return m;