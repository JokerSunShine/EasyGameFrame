---@class backV2.ReqRecharge
---instance properties
---@field public loginName System.String
---@field public loginNameSpecified System.Boolean
---@field public count System.Int32
---@field public countSpecified System.Boolean
---@field public sid System.Int32
---@field public sidSpecified System.Boolean
---@field public order_sn System.String
---@field public order_snSpecified System.Boolean
---@field public order_id System.Int64
---@field public order_idSpecified System.Boolean
---@field public goodsId System.Int32
---@field public goodsIdSpecified System.Boolean
---@field public type System.Int32
---@field public typeSpecified System.Boolean
---@field public productId System.String
---@field public productIdSpecified System.Boolean
---@field public qudao System.Int32
---@field public qudaoSpecified System.Boolean
local m = {};

backV2.ReqRecharge=m
return m;