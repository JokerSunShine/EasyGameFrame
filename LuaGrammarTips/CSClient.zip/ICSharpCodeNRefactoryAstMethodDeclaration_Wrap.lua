---@class ICSharpCodeNRefactoryAstMethodDeclaration : ICSharpCodeNRefactoryAstMemberNode
---instance properties
---@field public Body ICSharpCodeNRefactoryAstBlockStatement
---@field public HandlesClause SystemCollectionsGenericList1SystemString
---@field public Templates SystemCollectionsGenericList1ICSharpCodeNRefactoryAstTemplateDefinition
---@field public IsExtensionMethod SystemBoolean
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstMethodDeclaration=m
return m;