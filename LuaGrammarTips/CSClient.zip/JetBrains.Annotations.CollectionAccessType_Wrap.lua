---@class JetBrains.Annotations.CollectionAccessType
---@field None @0
---@field Read @1
---@field ModifyExistingContent @2
---@field UpdatedContent @6
JetBrains.Annotations.CollectionAccessType=m
return m;