---@class backV2.ReqBackBan
---instance properties
---@field public banType System.Int32
---@field public banTypeSpecified System.Boolean
---@field public banParam System.String
---@field public banParamSpecified System.Boolean
---@field public banReason System.String
---@field public banReasonSpecified System.Boolean
---@field public time System.Int32
---@field public timeSpecified System.Boolean
local m = {};

backV2.ReqBackBan=m
return m;