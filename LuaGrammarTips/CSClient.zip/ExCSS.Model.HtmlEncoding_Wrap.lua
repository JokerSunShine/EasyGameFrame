---@class ExCSS.Model.HtmlEncoding
local m = {};
ExCSS.Model.HtmlEncoding=m
return m;