---@class ExCSS.ComplexSelector : ExCSS.BaseSelector
---instance properties
---@field public Length System.Int32
local m = {};
---@param selector ExCSS.BaseSelector
---@param combinator ExCSS.Combinator
---@return ExCSS.ComplexSelector
function m:AppendSelector(selector, combinator) end
---@return System.Collections.Generic.IEnumerator`1[ExCSS.CombinatorSelector]
function m:GetEnumerator() end
---@param friendlyFormat System.Boolean
---@param indentation System.Int32 @default_value:0
---@return System.String
function m:ToString(friendlyFormat, indentation) end
ExCSS.ComplexSelector=m
return m;