---@class EasyHookHookRuntimeInfo
---properties
---@field public IsHandlerContext SystemBoolean
---@field public Callback SystemObject
---@field public Handle EasyHookLocalHook
---@field public CallingUnmanagedModule SystemDiagnosticsProcessModule
---@field public CallingManagedModule SystemReflectionAssembly
---@field public ReturnAddress SystemIntPtr
---@field public AddressOfReturnAddress SystemIntPtr
---@field public UnmanagedStackTrace SystemDiagnosticsProcessModule
---@field public ManagedStackTrace SystemReflectionModule
local m = {};
function m.UpdateUnmanagedModuleList() end
---@param InPointer SystemIntPtr
---@return SystemDiagnosticsProcessModule
function m.PointerToModule(InPointer) end
EasyHookHookRuntimeInfo=m
return m;