---@class ICSharpCodeSharpZipLibCoreFileFailureDelegate : SystemMulticastDelegate
local m = {};
---@param sender SystemObject
---@param e ICSharpCodeSharpZipLibCoreScanFailureEventArgs
function m:Invoke(sender, e) end
---@param sender SystemObject
---@param e ICSharpCodeSharpZipLibCoreScanFailureEventArgs
---@param callback SystemAsyncCallback
---@param object SystemObject
---@return SystemIAsyncResult
function m:BeginInvoke(sender, e, callback, object) end
---@param result SystemIAsyncResult
function m:EndInvoke(result) end
ICSharpCodeSharpZipLibCoreFileFailureDelegate=m
return m;