---@class activityV2.ReqRaffle
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public count System.Int32
---@field public countSpecified System.Boolean
---@field public costType System.Int32
---@field public costTypeSpecified System.Boolean
local m = {};

activityV2.ReqRaffle=m
return m;