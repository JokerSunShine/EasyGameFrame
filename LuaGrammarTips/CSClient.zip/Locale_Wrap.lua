---@class Locale
local m = {};
---@param msg SystemString
---@return SystemString
function m.GetText(msg) end
---@param fmt SystemString
---@param args SystemObject
---@return SystemString
function m.GetText(fmt, args) end
Locale=m
return m;