---@class Locale
local m = {};
---@param msg System.String
---@return System.String
function m.GetText(msg) end
---@param fmt System.String
---@param args System.Object[]
---@return System.String
function m.GetText(fmt, args) end
Locale=m
return m;