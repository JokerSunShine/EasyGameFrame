---@class Microsoft.Win32.RegistryHive
---@field ClassesRoot @-2147483648
---@field CurrentUser @-2147483647
---@field LocalMachine @-2147483646
---@field Users @-2147483645
---@field PerformanceData @-2147483644
---@field CurrentConfig @-2147483643
---@field DynData @-2147483642
Microsoft.Win32.RegistryHive=m
return m;