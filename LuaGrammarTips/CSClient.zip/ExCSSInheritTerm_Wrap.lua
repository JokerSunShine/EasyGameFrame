---@class ExCSSInheritTerm : ExCSSTerm
local m = {};
---@return SystemString
function m:ToString() end
ExCSSInheritTerm=m
return m;