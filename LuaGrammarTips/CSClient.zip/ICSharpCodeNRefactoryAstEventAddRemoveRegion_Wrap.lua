---@class ICSharpCodeNRefactoryAstEventAddRemoveRegion : ICSharpCodeNRefactoryAstAttributedNode
---instance properties
---@field public Block ICSharpCodeNRefactoryAstBlockStatement
---@field public Parameters SystemCollectionsGenericList1ICSharpCodeNRefactoryAstParameterDeclarationExpression
---@field public IsNull SystemBoolean
local m = {};
ICSharpCodeNRefactoryAstEventAddRemoveRegion=m
return m;