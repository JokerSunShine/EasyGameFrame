---@class AppearanceInfoBasic
---instance properties
---@field public Avatar CSAvater
---@field public IsAnyAppearanceEnabled System.Boolean
local m = {};

function m:Clear() end
---@param equipPartIndex System.Int32
---@param appearance TABLE.CFG_APPEARANCE @out
---@return System.Boolean
function m:GetAppearance(equipPartIndex, appearance) end
---@param equipPartIndex System.Int32
---@param modelID System.Int32 @out
---@return System.Boolean
function m:GetAppearanceModelID(equipPartIndex, modelID) end
---@return System.Boolean
function m:IsNullAppearance() end
---@param equipPartIndex System.Int32
---@param appearance TABLE.CFG_APPEARANCE
---@return System.Boolean
function m:SetAppearance(equipPartIndex, appearance) end
function m:Refresh() end
AppearanceInfoBasic=m
return m;