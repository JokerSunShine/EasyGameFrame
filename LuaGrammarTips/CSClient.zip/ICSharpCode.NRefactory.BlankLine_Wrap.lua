---@class ICSharpCode.NRefactory.BlankLine : ICSharpCode.NRefactory.AbstractSpecial
local m = {};
---@param visitor ICSharpCode.NRefactory.ISpecialVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
ICSharpCode.NRefactory.BlankLine=m
return m;