---@class bagV2.LingBaoInfo
---instance properties
---@field public level System.Int32
---@field public nowExp System.Int32
---@field public nowExpSpecified System.Boolean
---@field public totalExp System.Int32
---@field public totalExpSpecified System.Boolean
---@field public refineLv System.Int32
---@field public refineLvSpecified System.Boolean
---@field public power System.Int32
---@field public powerSpecified System.Boolean
local m = {};

bagV2.LingBaoInfo=m
return m;