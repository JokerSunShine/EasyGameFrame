---@class ICSharpCode.SharpZipLib.Tar.TarArchive
---instance properties
---@field public PathPrefix System.String
---@field public RootPath System.String
---@field public ApplyUserInfoOverrides System.Boolean
---@field public UserId System.Int32
---@field public UserName System.String
---@field public GroupId System.Int32
---@field public GroupName System.String
---@field public RecordSize System.Int32
local m = {};
---@param inputStream System.IO.Stream
---@return ICSharpCode.SharpZipLib.Tar.TarArchive
function m.CreateInputTarArchive(inputStream) end
---@param inputStream System.IO.Stream
---@param blockFactor System.Int32
---@return ICSharpCode.SharpZipLib.Tar.TarArchive
function m.CreateInputTarArchive(inputStream, blockFactor) end
---@param outputStream System.IO.Stream
---@return ICSharpCode.SharpZipLib.Tar.TarArchive
function m.CreateOutputTarArchive(outputStream) end
---@param outputStream System.IO.Stream
---@param blockFactor System.Int32
---@return ICSharpCode.SharpZipLib.Tar.TarArchive
function m.CreateOutputTarArchive(outputStream, blockFactor) end
---@param value ICSharpCode.SharpZipLib.Tar.ProgressMessageHandler
function m:add_ProgressMessageEvent(value) end
---@param value ICSharpCode.SharpZipLib.Tar.ProgressMessageHandler
function m:remove_ProgressMessageEvent(value) end
---@param keepOldFiles System.Boolean
function m:SetKeepOldFiles(keepOldFiles) end
---@param asciiTranslate System.Boolean
function m:SetAsciiTranslation(asciiTranslate) end
---@param userId System.Int32
---@param userName System.String
---@param groupId System.Int32
---@param groupName System.String
function m:SetUserInfo(userId, userName, groupId, groupName) end
function m:CloseArchive() end
function m:ListContents() end
---@param destDir System.String
function m:ExtractContents(destDir) end
---@param sourceEntry ICSharpCode.SharpZipLib.Tar.TarEntry
---@param recurse System.Boolean
function m:WriteEntry(sourceEntry, recurse) end
ICSharpCode.SharpZipLib.Tar.TarArchive=m
return m;