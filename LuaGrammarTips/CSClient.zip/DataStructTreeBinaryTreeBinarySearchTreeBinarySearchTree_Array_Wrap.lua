---@class DataStructTreeBinaryTreeBinarySearchTreeBinarySearchTree_Array
local m = {};
DataStructTreeBinaryTreeBinarySearchTreeBinarySearchTree_Array=m
return m;