---@class ICSharpCodeNRefactoryAstPointerReferenceExpression : ICSharpCodeNRefactoryAstExpression
---instance properties
---@field public TargetObject ICSharpCodeNRefactoryAstExpression
---@field public MemberName SystemString
---@field public TypeArguments SystemCollectionsGenericList1ICSharpCodeNRefactoryAstTypeReference
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstPointerReferenceExpression=m
return m;