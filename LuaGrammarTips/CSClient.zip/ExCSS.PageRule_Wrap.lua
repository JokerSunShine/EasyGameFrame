---@class ExCSS.PageRule : ExCSS.RuleSet
---instance properties
---@field public Selector ExCSS.BaseSelector
---@field public Declarations ExCSS.StyleDeclaration
local m = {};
---@return System.String
function m:ToString() end
---@param friendlyFormat System.Boolean
---@param indentation System.Int32 @default_value:0
---@return System.String
function m:ToString(friendlyFormat, indentation) end
ExCSS.PageRule=m
return m;