---@class ICSharpCode.NRefactory.Ast.QueryExpressionJoinVBClause : ICSharpCode.NRefactory.Ast.QueryExpressionClause
---properties
---@field public Null ICSharpCode.NRefactory.Ast.QueryExpressionJoinVBClause
---instance properties
---@field public JoinVariable ICSharpCode.NRefactory.Ast.QueryExpressionFromClause
---@field public SubJoin ICSharpCode.NRefactory.Ast.QueryExpressionJoinVBClause
---@field public Conditions System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.QueryExpressionJoinConditionVB]
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.QueryExpressionJoinVBClause=m
return m;