---@class ICSharpCode.SharpZipLib.Tar.TarInputStream+IEntryFactory
local m = {};
---@param name System.String
---@return ICSharpCode.SharpZipLib.Tar.TarEntry
function m:CreateEntry(name) end
---@param fileName System.String
---@return ICSharpCode.SharpZipLib.Tar.TarEntry
function m:CreateEntryFromFile(fileName) end
---@param headerBuf System.Byte[]
---@return ICSharpCode.SharpZipLib.Tar.TarEntry
function m:CreateEntry(headerBuf) end
ICSharpCode.SharpZipLib.Tar.TarInputStream+IEntryFactory=m
return m;