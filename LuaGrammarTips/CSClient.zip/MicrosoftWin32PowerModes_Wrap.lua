---@class MicrosoftWin32PowerModes
---@field Resume @1
---@field StatusChange @2
---@field Suspend @3
MicrosoftWin32PowerModes=m
return m;