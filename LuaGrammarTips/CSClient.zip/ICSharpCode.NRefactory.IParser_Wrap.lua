---@class ICSharpCode.NRefactory.IParser
---instance properties
---@field public Errors ICSharpCode.NRefactory.Parser.Errors
---@field public Lexer ICSharpCode.NRefactory.Parser.ILexer
---@field public CompilationUnit ICSharpCode.NRefactory.Ast.CompilationUnit
---@field public ParseMethodBodies System.Boolean
local m = {};
function m:Parse() end
---@return ICSharpCode.NRefactory.Ast.Expression
function m:ParseExpression() end
---@return ICSharpCode.NRefactory.Ast.TypeReference
function m:ParseTypeReference() end
---@return ICSharpCode.NRefactory.Ast.BlockStatement
function m:ParseBlock() end
---@return System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.INode]
function m:ParseTypeMembers() end
ICSharpCode.NRefactory.IParser=m
return m;