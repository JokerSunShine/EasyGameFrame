---@class CommonLoadPath
---properties
---@field public LocalProjectName SystemString
---@field public LoadRootPath SystemString
---@field public CreateLuaGrammarTipPath SystemString
---@field public CreateCSClientTipPath SystemString
---@field public LoadVideoPath SystemString
local m = {};
CommonLoadPath=m
return m;