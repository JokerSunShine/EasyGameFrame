---@class CommonLoadPath
---properties
---@field public LocalProjectName System.String
---@field public LoadRootPath System.String
---@field public CreateLuaGrammarTipPath System.String
---@field public CreateCSClientTipPath System.String
---@field public LoadVideoPath System.String
local m = {};
CommonLoadPath=m
return m;