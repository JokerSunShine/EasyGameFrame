---@class ExCSS.Term
---fields
---@field public Inherit ExCSS.InheritTerm
local m = {};
ExCSS.Term=m
return m;