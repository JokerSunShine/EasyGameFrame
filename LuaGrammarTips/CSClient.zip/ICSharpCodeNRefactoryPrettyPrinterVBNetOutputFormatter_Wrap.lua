---@class ICSharpCodeNRefactoryPrettyPrinterVBNetOutputFormatter : ICSharpCodeNRefactoryPrettyPrinterAbstractOutputFormatter
local m = {};
---@param token SystemInt32
function m:PrintToken(token) end
---@param identifier SystemString
function m:PrintIdentifier(identifier) end
---@param comment ICSharpCodeNRefactoryComment
---@param forceWriteInPreviousBlock SystemBoolean
function m:PrintComment(comment, forceWriteInPreviousBlock) end
---@param directive ICSharpCodeNRefactoryPreprocessingDirective
---@param forceWriteInPreviousBlock SystemBoolean
function m:PrintPreprocessingDirective(directive, forceWriteInPreviousBlock) end
function m:PrintLineContinuation() end
ICSharpCodeNRefactoryPrettyPrinterVBNetOutputFormatter=m
return m;