---@class ExCSS.Model.TextBlocks.NumericBlock : ExCSS.Model.TextBlocks.Block
---instance properties
---@field public Value System.Single
local m = {};
---@return System.String
function m:ToString() end
ExCSS.Model.TextBlocks.NumericBlock=m
return m;