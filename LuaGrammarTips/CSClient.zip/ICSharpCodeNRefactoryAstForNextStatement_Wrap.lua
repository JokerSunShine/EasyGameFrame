---@class ICSharpCodeNRefactoryAstForNextStatement : ICSharpCodeNRefactoryAstStatementWithEmbeddedStatement
---instance properties
---@field public Start ICSharpCodeNRefactoryAstExpression
---@field public End ICSharpCodeNRefactoryAstExpression
---@field public Step ICSharpCodeNRefactoryAstExpression
---@field public NextExpressions SystemCollectionsGenericList1ICSharpCodeNRefactoryAstExpression
---@field public TypeReference ICSharpCodeNRefactoryAstTypeReference
---@field public VariableName SystemString
---@field public LoopVariableExpression ICSharpCodeNRefactoryAstExpression
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstForNextStatement=m
return m;