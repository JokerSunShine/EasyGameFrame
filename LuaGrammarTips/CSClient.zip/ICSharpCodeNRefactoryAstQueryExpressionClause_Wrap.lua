---@class ICSharpCodeNRefactoryAstQueryExpressionClause : ICSharpCodeNRefactoryAstAbstractNode
---properties
---@field public Null ICSharpCodeNRefactoryAstQueryExpressionClause
---instance properties
---@field public IsNull SystemBoolean
local m = {};
ICSharpCodeNRefactoryAstQueryExpressionClause=m
return m;