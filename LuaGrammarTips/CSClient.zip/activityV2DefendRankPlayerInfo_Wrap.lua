---@class activityV2.DefendRankPlayerInfo
---instance properties
---@field public rid System.Int64
---@field public ridSpecified System.Boolean
---@field public name System.String
---@field public nameSpecified System.Boolean
---@field public career System.Int32
---@field public careerSpecified System.Boolean
---@field public sex System.Int32
---@field public sexSpecified System.Boolean
---@field public level System.Int32
---@field public levelSpecified System.Boolean
---@field public killSmall System.Int32
---@field public killSmallSpecified System.Boolean
---@field public killBig System.Int32
---@field public killBigSpecified System.Boolean
---@field public killNum System.Int32
---@field public killNumSpecified System.Boolean
---@field public diedNum System.Int32
---@field public diedNumSpecified System.Boolean
---@field public grade System.Int32
---@field public gradeSpecified System.Boolean
---@field public unionId System.Int64
---@field public unionIdSpecified System.Boolean
---@field public unionName System.String
---@field public unionNameSpecified System.Boolean
---@field public titleType System.Int32
---@field public titleTypeSpecified System.Boolean
---@field public like System.Collections.Generic.List1System.Int64
local m = {};

activityV2.DefendRankPlayerInfo=m
return m;