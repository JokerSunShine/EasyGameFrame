---@class InteropLibraries
local m = {};
InteropLibraries=m
return m;