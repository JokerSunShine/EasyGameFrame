---@class CollabProxyUIBootstrap
local m = {};
CollabProxyUIBootstrap=m
return m;