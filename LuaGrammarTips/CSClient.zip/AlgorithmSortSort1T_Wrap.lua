---@class AlgorithmSortSort1T
local m = {};
---@param array T
---@param compareFunc SystemFunc3TTSystemInt32
function m.BubbleSort(array, compareFunc) end
---@param array T
---@param compareFunc SystemFunc3TTSystemInt32
function m.SelectSort(array, compareFunc) end
---@param array T
---@param compareFunc SystemFunc3TTSystemInt32
function m.InsertSort(array, compareFunc) end
---@param array T
---@param compareFunc SystemFunc3TTSystemInt32
function m.ShellSort(array, compareFunc) end
---@param array T
---@param compareFunc SystemFunc3TTSystemInt32
---@return T
function m.MergeSort(array, compareFunc) end
---@param array T
---@param compareFunc SystemFunc3TTSystemInt32
---@return T
function m.HeapSortByMinHeap(array, compareFunc) end
---@param array T
---@param compareFunc SystemFunc3TTSystemInt32
---@return T
function m.HeapSortByMaxHeap(array, compareFunc) end
---@param array T
---@param compareFunc SystemFunc3TTSystemInt32
---@return T
function m.HeapSort(array, compareFunc) end
---@param array T
---@param compareFunc SystemFunc3TTSystemInt32
---@param left SystemInt32 @default_value:-1
---@param right SystemInt32 @default_value:-1
---@return T
function m.QuickSort(array, compareFunc, left, right) end
---@param array SystemInt32
---@return SystemInt32
function m.CountingSort(array) end
---@param array SystemInt32
---@return SystemInt32
function m.RadixSort(array) end
---@param array SystemInt32
---@return SystemInt32
function m.BucketSort(array) end
AlgorithmSortSort1T=m
return m;