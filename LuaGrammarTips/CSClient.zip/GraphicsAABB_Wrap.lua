---@class GraphicsAABB
---instance fields
---@field public min _3DMathVector3
---@field public max _3DMathVector3
local m = {};
---@param aabb GraphicsAABB
---@param ray GraphicsRay
---@param returnNormal _3DMathVector3
---@return SystemSingle
function m.CrossForRay(aabb, ray, returnNormal) end
---@param aabb1 GraphicsAABB
---@param aabb2 GraphicsAABB
---@param crossAABB GraphicsAABB @out
---@return SystemBoolean
function m.StaticCrossAABBs(aabb1, aabb2, crossAABB) end
---@param stationaryBox GraphicsAABB
---@param movingBox GraphicsAABB
---@param d _3DMathVector3
---@return SystemSingle
function m.DynamicCrossAABBs(stationaryBox, movingBox, d) end
---@return _3DMathVector3
function m:Size() end
---@return SystemSingle
function m:xSize() end
---@return SystemSingle
function m:YSize() end
---@return SystemSingle
function m:ZSize() end
---@return _3DMathVector3
function m:Center() end
---@param type GraphicsAABBPointType
---@return _3DMathVector3
function m:GetCoordPoint(type) end
function m:Empty() end
---@return SystemBoolean
function m:IsEmpty() end
---@param v _3DMathVector3
function m:Add(v) end
---@param aabb GraphicsAABB
function m:Add(aabb) end
---@param v _3DMathVector3
---@return SystemBoolean
function m:IsContain(v) end
---@param aabb GraphicsAABB
---@param matrix _3DMathMatrix4x3
function m:SetToTransformBox(aabb, matrix) end
---@param v _3DMathVector3
---@return _3DMathVector3
function m:GetClosestPoint(v) end
GraphicsAABB=m
return m;