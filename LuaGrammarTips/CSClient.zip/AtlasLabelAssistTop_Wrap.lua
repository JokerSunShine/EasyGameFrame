---@class AtlasLabelAssistTop
---instance fields
---@field public Damage AtlasLabelAssistData
---@field public Strike AtlasLabelAssistData
---@field public YLDamage AtlasLabelAssistData
---@field public YLStrike AtlasLabelAssistData
---@field public Restore AtlasLabelAssistData
---@field public lv AtlasLabelAssistData
---@field public huang AtlasLabelAssistData
---@field public cheng AtlasLabelAssistData
---@field public lan AtlasLabelAssistData
---@field public nightfighting AtlasLabelAssistData
---@field public self AtlasLabelAssistData
---@field public prestige AtlasLabelAssistData
local m = {};

AtlasLabelAssistTop=m
return m;