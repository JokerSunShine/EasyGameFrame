---@class ICSharpCodeNRefactoryAstBuilderStatementBuilder
local m = {};
---@param block ICSharpCodeNRefactoryAstBlockStatement
---@param statement ICSharpCodeNRefactoryAstStatement
function m.AddStatement(block, statement) end
---@param block ICSharpCodeNRefactoryAstBlockStatement
---@param expressionStatement ICSharpCodeNRefactoryAstExpression
function m.AddStatement(block, expressionStatement) end
---@param block ICSharpCodeNRefactoryAstBlockStatement
---@param expression ICSharpCodeNRefactoryAstExpression
function m.Throw(block, expression) end
---@param block ICSharpCodeNRefactoryAstBlockStatement
---@param expression ICSharpCodeNRefactoryAstExpression
function m.Return(block, expression) end
---@param block ICSharpCodeNRefactoryAstBlockStatement
---@param left ICSharpCodeNRefactoryAstExpression
---@param right ICSharpCodeNRefactoryAstExpression
function m.Assign(block, left, right) end
ICSharpCodeNRefactoryAstBuilderStatementBuilder=m
return m;