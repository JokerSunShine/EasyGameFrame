---@class Microsoft.CSharp.CSharpTypeAttributeConverter : Microsoft.CSharp.CSharpModifierAttributeConverter
---properties
---@field public Default Microsoft.CSharp.CSharpTypeAttributeConverter
local m = {};
Microsoft.CSharp.CSharpTypeAttributeConverter=m
return m;