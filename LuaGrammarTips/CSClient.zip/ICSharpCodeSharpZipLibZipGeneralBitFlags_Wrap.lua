---@class ICSharpCodeSharpZipLibZipGeneralBitFlags
---@field Encrypted @1
---@field Method @6
---@field Descriptor @8
---@field Reserved @16
---@field Patched @32
---@field StrongEncryption @64
---@field EnhancedCompress @4096
---@field HeaderMasked @8192
ICSharpCodeSharpZipLibZipGeneralBitFlags=m
return m;