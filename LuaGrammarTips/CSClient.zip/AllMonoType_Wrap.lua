---@class AllMonoType
---fields
---@field public dic System.Collections.Generic.Dictionary2System.StringSystem.Type
local m = {};

AllMonoType=m
return m;