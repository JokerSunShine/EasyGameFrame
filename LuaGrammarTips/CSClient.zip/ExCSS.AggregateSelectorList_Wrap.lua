---@class ExCSS.AggregateSelectorList : ExCSS.SelectorList
---instance fields
---@field public Delimiter System.String
local m = {};
---@param friendlyFormat System.Boolean
---@param indentation System.Int32 @default_value:0
---@return System.String
function m:ToString(friendlyFormat, indentation) end
ExCSS.AggregateSelectorList=m
return m;