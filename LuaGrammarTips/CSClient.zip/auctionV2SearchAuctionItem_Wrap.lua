---@class auctionV2.SearchAuctionItem
---instance properties
---@field public matchesString System.String
---@field public matchesStringSpecified System.Boolean
---@field public condition auctionV2.GetAuctionItemsRequest
local m = {};

auctionV2.SearchAuctionItem=m
return m;