---@class achievementV2.ResOpenAchievementPanel
---instance properties
---@field public achievementInfo System.Collections.Generic.List1achievementV2.AchievementInfo
---@field public point System.Int32
---@field public pointSpecified System.Boolean
local m = {};

achievementV2.ResOpenAchievementPanel=m
return m;