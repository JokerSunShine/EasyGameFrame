---@class ICSharpCode.NRefactory.Ast.PropertySetRegion : ICSharpCode.NRefactory.Ast.PropertyGetSetRegion
---properties
---@field public Null ICSharpCode.NRefactory.Ast.PropertySetRegion
---instance properties
---@field public Parameters System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.ParameterDeclarationExpression]
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.PropertySetRegion=m
return m;