---@class ActionWalk : BehaviorState
---instance properties
---@field public Behavior System.Int32
local m = {};

---@param avater ISFAvater
---@param last BehaviorState
function m:Start(avater, last) end
---@param avater ISFAvater
---@return System.Int32
function m:Update(avater) end
---@param avater ISFAvater
---@param next BehaviorState
function m:End(avater, next) end
---@param data TouchData
---@return EFSMState
function m:getActionOfAfterTheWalk(data) end
ActionWalk=m
return m;