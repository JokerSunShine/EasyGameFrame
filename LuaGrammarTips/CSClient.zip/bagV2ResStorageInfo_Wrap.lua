---@class bagV2.ResStorageInfo
---instance properties
---@field public emptyGridCount System.Int32
---@field public emptyGridCountSpecified System.Boolean
---@field public maxGridCount System.Int32
---@field public maxGridCountSpecified System.Boolean
---@field public itemList System.Collections.Generic.List1bagV2.BagItemInfo
local m = {};

bagV2.ResStorageInfo=m
return m;