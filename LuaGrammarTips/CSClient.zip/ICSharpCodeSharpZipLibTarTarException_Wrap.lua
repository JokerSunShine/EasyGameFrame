---@class ICSharpCodeSharpZipLibTarTarException : ICSharpCodeSharpZipLibSharpZipBaseException
local m = {};
ICSharpCodeSharpZipLibTarTarException=m
return m;