---@class ICSharpCodeNRefactoryVisitorsCodeDomVisitor : ICSharpCodeNRefactoryVisitorsAbstractAstVisitor
---instance fields
---@field public codeCompileUnit SystemCodeDomCodeCompileUnit
---instance properties
---@field public EnvironmentInformationProvider ICSharpCodeNRefactoryIEnvironmentInformationProvider
local m = {};
---@param compilationUnit ICSharpCodeNRefactoryAstCompilationUnit
---@param data SystemObject
---@return SystemObject
function m:VisitCompilationUnit(compilationUnit, data) end
---@param namespaceDeclaration ICSharpCodeNRefactoryAstNamespaceDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitNamespaceDeclaration(namespaceDeclaration, data) end
---@param usingDeclaration ICSharpCodeNRefactoryAstUsingDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitUsingDeclaration(usingDeclaration, data) end
---@param eventDeclaration ICSharpCodeNRefactoryAstEventDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitEventDeclaration(eventDeclaration, data) end
---@param attributeSection ICSharpCodeNRefactoryAstAttributeSection
---@param data SystemObject
---@return SystemObject
function m:VisitAttributeSection(attributeSection, data) end
---@param typeReferenceExpression ICSharpCodeNRefactoryAstTypeReferenceExpression
---@param data SystemObject
---@return SystemObject
function m:VisitTypeReferenceExpression(typeReferenceExpression, data) end
---@param typeDeclaration ICSharpCodeNRefactoryAstTypeDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitTypeDeclaration(typeDeclaration, data) end
---@param delegateDeclaration ICSharpCodeNRefactoryAstDelegateDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitDelegateDeclaration(delegateDeclaration, data) end
---@param variableDeclaration ICSharpCodeNRefactoryAstVariableDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitVariableDeclaration(variableDeclaration, data) end
---@param fieldDeclaration ICSharpCodeNRefactoryAstFieldDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitFieldDeclaration(fieldDeclaration, data) end
---@param methodDeclaration ICSharpCodeNRefactoryAstMethodDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitMethodDeclaration(methodDeclaration, data) end
---@param propertyDeclaration ICSharpCodeNRefactoryAstPropertyDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitPropertyDeclaration(propertyDeclaration, data) end
---@param constructorDeclaration ICSharpCodeNRefactoryAstConstructorDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitConstructorDeclaration(constructorDeclaration, data) end
---@param blockStatement ICSharpCodeNRefactoryAstBlockStatement
---@param data SystemObject
---@return SystemObject
function m:VisitBlockStatement(blockStatement, data) end
---@param expressionStatement ICSharpCodeNRefactoryAstExpressionStatement
---@param data SystemObject
---@return SystemObject
function m:VisitExpressionStatement(expressionStatement, data) end
---@param localVariableDeclaration ICSharpCodeNRefactoryAstLocalVariableDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitLocalVariableDeclaration(localVariableDeclaration, data) end
---@param emptyStatement ICSharpCodeNRefactoryAstEmptyStatement
---@param data SystemObject
---@return SystemObject
function m:VisitEmptyStatement(emptyStatement, data) end
---@param returnStatement ICSharpCodeNRefactoryAstReturnStatement
---@param data SystemObject
---@return SystemObject
function m:VisitReturnStatement(returnStatement, data) end
---@param ifElseStatement ICSharpCodeNRefactoryAstIfElseStatement
---@param data SystemObject
---@return SystemObject
function m:VisitIfElseStatement(ifElseStatement, data) end
---@param foreachStatement ICSharpCodeNRefactoryAstForeachStatement
---@param data SystemObject
---@return SystemObject
function m:VisitForeachStatement(foreachStatement, data) end
---@param doLoopStatement ICSharpCodeNRefactoryAstDoLoopStatement
---@param data SystemObject
---@return SystemObject
function m:VisitDoLoopStatement(doLoopStatement, data) end
---@param forStatement ICSharpCodeNRefactoryAstForStatement
---@param data SystemObject
---@return SystemObject
function m:VisitForStatement(forStatement, data) end
---@param labelStatement ICSharpCodeNRefactoryAstLabelStatement
---@param data SystemObject
---@return SystemObject
function m:VisitLabelStatement(labelStatement, data) end
---@param gotoStatement ICSharpCodeNRefactoryAstGotoStatement
---@param data SystemObject
---@return SystemObject
function m:VisitGotoStatement(gotoStatement, data) end
---@param switchStatement ICSharpCodeNRefactoryAstSwitchStatement
---@param data SystemObject
---@return SystemObject
function m:VisitSwitchStatement(switchStatement, data) end
---@param tryCatchStatement ICSharpCodeNRefactoryAstTryCatchStatement
---@param data SystemObject
---@return SystemObject
function m:VisitTryCatchStatement(tryCatchStatement, data) end
---@param throwStatement ICSharpCodeNRefactoryAstThrowStatement
---@param data SystemObject
---@return SystemObject
function m:VisitThrowStatement(throwStatement, data) end
---@param fixedStatement ICSharpCodeNRefactoryAstFixedStatement
---@param data SystemObject
---@return SystemObject
function m:VisitFixedStatement(fixedStatement, data) end
---@param primitiveExpression ICSharpCodeNRefactoryAstPrimitiveExpression
---@param data SystemObject
---@return SystemObject
function m:VisitPrimitiveExpression(primitiveExpression, data) end
---@param binaryOperatorExpression ICSharpCodeNRefactoryAstBinaryOperatorExpression
---@param data SystemObject
---@return SystemObject
function m:VisitBinaryOperatorExpression(binaryOperatorExpression, data) end
---@param parenthesizedExpression ICSharpCodeNRefactoryAstParenthesizedExpression
---@param data SystemObject
---@return SystemObject
function m:VisitParenthesizedExpression(parenthesizedExpression, data) end
---@param invocationExpression ICSharpCodeNRefactoryAstInvocationExpression
---@param data SystemObject
---@return SystemObject
function m:VisitInvocationExpression(invocationExpression, data) end
---@param identifierExpression ICSharpCodeNRefactoryAstIdentifierExpression
---@param data SystemObject
---@return SystemObject
function m:VisitIdentifierExpression(identifierExpression, data) end
---@param unaryOperatorExpression ICSharpCodeNRefactoryAstUnaryOperatorExpression
---@param data SystemObject
---@return SystemObject
function m:VisitUnaryOperatorExpression(unaryOperatorExpression, data) end
---@param assignmentExpression ICSharpCodeNRefactoryAstAssignmentExpression
---@param data SystemObject
---@return SystemObject
function m:VisitAssignmentExpression(assignmentExpression, data) end
---@param addHandlerStatement ICSharpCodeNRefactoryAstAddHandlerStatement
---@param data SystemObject
---@return SystemObject
function m:VisitAddHandlerStatement(addHandlerStatement, data) end
---@param addressOfExpression ICSharpCodeNRefactoryAstAddressOfExpression
---@param data SystemObject
---@return SystemObject
function m:VisitAddressOfExpression(addressOfExpression, data) end
---@param using ICSharpCodeNRefactoryAstUsing
---@param data SystemObject
---@return SystemObject
function m:VisitUsing(using, data) end
---@param usingStatement ICSharpCodeNRefactoryAstUsingStatement
---@param data SystemObject
---@return SystemObject
function m:VisitUsingStatement(usingStatement, data) end
---@param typeOfExpression ICSharpCodeNRefactoryAstTypeOfExpression
---@param data SystemObject
---@return SystemObject
function m:VisitTypeOfExpression(typeOfExpression, data) end
---@param castExpression ICSharpCodeNRefactoryAstCastExpression
---@param data SystemObject
---@return SystemObject
function m:VisitCastExpression(castExpression, data) end
---@param indexerExpression ICSharpCodeNRefactoryAstIndexerExpression
---@param data SystemObject
---@return SystemObject
function m:VisitIndexerExpression(indexerExpression, data) end
---@param thisReferenceExpression ICSharpCodeNRefactoryAstThisReferenceExpression
---@param data SystemObject
---@return SystemObject
function m:VisitThisReferenceExpression(thisReferenceExpression, data) end
---@param baseReferenceExpression ICSharpCodeNRefactoryAstBaseReferenceExpression
---@param data SystemObject
---@return SystemObject
function m:VisitBaseReferenceExpression(baseReferenceExpression, data) end
---@param arrayCreateExpression ICSharpCodeNRefactoryAstArrayCreateExpression
---@param data SystemObject
---@return SystemObject
function m:VisitArrayCreateExpression(arrayCreateExpression, data) end
---@param objectCreateExpression ICSharpCodeNRefactoryAstObjectCreateExpression
---@param data SystemObject
---@return SystemObject
function m:VisitObjectCreateExpression(objectCreateExpression, data) end
---@param parameterDeclarationExpression ICSharpCodeNRefactoryAstParameterDeclarationExpression
---@param data SystemObject
---@return SystemObject
function m:VisitParameterDeclarationExpression(parameterDeclarationExpression, data) end
---@param breakStatement ICSharpCodeNRefactoryAstBreakStatement
---@param data SystemObject
---@return SystemObject
function m:VisitBreakStatement(breakStatement, data) end
---@param continueStatement ICSharpCodeNRefactoryAstContinueStatement
---@param data SystemObject
---@return SystemObject
function m:VisitContinueStatement(continueStatement, data) end
---@param fieldReferenceExpression ICSharpCodeNRefactoryAstMemberReferenceExpression
---@param data SystemObject
---@return SystemObject
function m:VisitMemberReferenceExpression(fieldReferenceExpression, data) end
ICSharpCodeNRefactoryVisitorsCodeDomVisitor=m
return m;