---@class ICSharpCodeNRefactorySnippetParser
---instance properties
---@field public Errors ICSharpCodeNRefactoryParserErrors
---@field public Specials SystemCollectionsGenericList1ICSharpCodeNRefactoryISpecial
---@field public SnippetType ICSharpCodeNRefactorySnippetType
local m = {};
---@param code SystemString
---@return ICSharpCodeNRefactoryAstINode
function m:Parse(code) end
ICSharpCodeNRefactorySnippetParser=m
return m;