---@class ICSharpCodeNRefactoryAstConstructorInitializerType
---@field None @0
---@field Base @1
---@field This @2
ICSharpCodeNRefactoryAstConstructorInitializerType=m
return m;