---@class DataUtilKeywordDependentCollectionKeywordPermutationInstanceType
---@field Base @0
---@field Permutation @1
DataUtilKeywordDependentCollectionKeywordPermutationInstanceType=m
return m;