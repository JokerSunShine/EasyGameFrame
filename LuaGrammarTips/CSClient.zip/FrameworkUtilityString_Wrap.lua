---@class FrameworkUtilityString
local m = {};
---@param format SystemString
---@param arg0 SystemString
---@return SystemString
function m.Format(format, arg0) end
---@param format SystemString
---@param arg0 SystemString
---@param arg1 SystemString
---@return SystemString
function m.Format(format, arg0, arg1) end
---@param format SystemString
---@param arg0 SystemString
---@param arg1 SystemString
---@param arg2 SystemString
---@return SystemString
function m.Format(format, arg0, arg1, arg2) end
---@param format SystemString
---@param args SystemString
---@return SystemString
function m.Format(format, args) end
---@param dir SystemString
---@param time SystemInt32
---@return SystemString
function m.RemoveBackDir(dir, time) end
FrameworkUtilityString=m
return m;