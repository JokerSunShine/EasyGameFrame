---@class ICSharpCodeSharpZipLibGZipGZipInputStream : ICSharpCodeSharpZipLibZipCompressionStreamsInflaterInputStream
local m = {};
---@param buf SystemByte
---@param offset SystemInt32
---@param len SystemInt32
---@return SystemInt32
function m:Read(buf, offset, len) end
ICSharpCodeSharpZipLibGZipGZipInputStream=m
return m;