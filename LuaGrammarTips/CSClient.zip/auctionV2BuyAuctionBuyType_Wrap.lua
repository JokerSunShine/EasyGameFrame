---@class auctionV2.BuyAuctionBuyType
---@field AUCTION @1
---@field BOOTH @2
---@field SMELT @4
local m = {};
auctionV2.BuyAuctionBuyType=m
return m;