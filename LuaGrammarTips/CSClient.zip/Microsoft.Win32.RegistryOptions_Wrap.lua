---@class Microsoft.Win32.RegistryOptions
---@field None @0
---@field Volatile @1
Microsoft.Win32.RegistryOptions=m
return m;