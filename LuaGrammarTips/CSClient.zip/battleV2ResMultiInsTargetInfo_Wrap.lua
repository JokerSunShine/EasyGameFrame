---@class battleV2.ResMultiInsTargetInfo
---instance properties
---@field public roleTeam System.Collections.Generic.List1battleV2.RoleTeamInfo
---@field public attackPattern System.Int32
---@field public attackPatternSpecified System.Boolean
---@field public ownerId System.Int64
---@field public ownerIdSpecified System.Boolean
local m = {};

battleV2.ResMultiInsTargetInfo=m
return m;