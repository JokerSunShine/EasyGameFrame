---@class ICSharpCode.NRefactory.Parser.ILexer
---instance properties
---@field public Errors ICSharpCode.NRefactory.Parser.Errors
---@field public Token ICSharpCode.NRefactory.Parser.Token
---@field public LookAhead ICSharpCode.NRefactory.Parser.Token
---@field public SpecialCommentTags System.String[]
---@field public SkipAllComments System.Boolean
---@field public EvaluateConditionalCompilation System.Boolean
---@field public ConditionalCompilationSymbols System.Collections.Generic.IDictionary`2[System.String,System.Object]
---@field public TagComments System.Collections.Generic.List`1[ICSharpCode.NRefactory.Parser.TagComment]
---@field public SpecialTracker ICSharpCode.NRefactory.Parser.SpecialTracker
local m = {};
---@param symbols System.String
function m:SetConditionalCompilationSymbols(symbols) end
function m:StartPeek() end
---@return ICSharpCode.NRefactory.Parser.Token
function m:Peek() end
---@return ICSharpCode.NRefactory.Parser.Token
function m:NextToken() end
---@param targetToken System.Int32
function m:SkipCurrentBlock(targetToken) end
ICSharpCode.NRefactory.Parser.ILexer=m
return m;