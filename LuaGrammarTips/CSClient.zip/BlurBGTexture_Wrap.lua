---@class BlurBGTexture : UnityEngine.MonoBehaviour
---instance properties
---@field public Texture UITexture
local m = {};

BlurBGTexture=m
return m;