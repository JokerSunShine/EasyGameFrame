---@class ActionSwornSwornState
---@field None @0
---@field Start @1
---@field PlayEffect @2
---@field Drink @3
local m = {};
ActionSwornSwornState=m
return m;