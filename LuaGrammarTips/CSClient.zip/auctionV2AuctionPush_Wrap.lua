---@class auctionV2.AuctionPush
---instance properties
---@field public item bagV2.BagItemInfo
---@field public type System.Int32
---@field public typeSpecified System.Boolean
local m = {};

auctionV2.AuctionPush=m
return m;