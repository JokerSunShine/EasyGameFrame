---@class boothV2.BoothCoordinateIdMsg
---instance properties
---@field public boothCoordinateId System.Int32
---@field public boothCoordinateIdSpecified System.Boolean
local m = {};

boothV2.BoothCoordinateIdMsg=m
return m;