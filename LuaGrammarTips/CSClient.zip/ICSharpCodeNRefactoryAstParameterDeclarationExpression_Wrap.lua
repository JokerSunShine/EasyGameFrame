---@class ICSharpCodeNRefactoryAstParameterDeclarationExpression : ICSharpCodeNRefactoryAstExpression
---instance properties
---@field public Attributes SystemCollectionsGenericList1ICSharpCodeNRefactoryAstAttributeSection
---@field public ParameterName SystemString
---@field public TypeReference ICSharpCodeNRefactoryAstTypeReference
---@field public ParamModifier ICSharpCodeNRefactoryAstParameterModifiers
---@field public DefaultValue ICSharpCodeNRefactoryAstExpression
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstParameterDeclarationExpression=m
return m;