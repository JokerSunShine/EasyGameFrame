---@class ICSharpCodeNRefactoryAstDefaultValueExpression : ICSharpCodeNRefactoryAstExpression
---instance properties
---@field public TypeReference ICSharpCodeNRefactoryAstTypeReference
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstDefaultValueExpression=m
return m;