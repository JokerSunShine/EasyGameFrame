---@class ICSharpCodeSharpZipLibTarInvalidHeaderException : ICSharpCodeSharpZipLibTarTarException
local m = {};
ICSharpCodeSharpZipLibTarInvalidHeaderException=m
return m;