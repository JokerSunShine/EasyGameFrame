---@class FrameworkUtilityNum
local m = {};
---@param array SystemInt32
---@return SystemInt32
function m.GetMaxNum(array) end
---@param num SystemInt32
---@return SystemInt32
function m.GetMaxDigit(num) end
FrameworkUtilityNum=m
return m;