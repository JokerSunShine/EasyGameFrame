---@class appearanceV2.ResEnableAppellation
---instance properties
---@field public titleInfo appearanceV2.TitleInfo
local m = {};

appearanceV2.ResEnableAppellation=m
return m;