---@class bagV2.ReqBloodSmelt
---instance properties
---@field public equipId System.Int64
---@field public recycleList System.Collections.Generic.List1System.Int64
local m = {};

bagV2.ReqBloodSmelt=m
return m;