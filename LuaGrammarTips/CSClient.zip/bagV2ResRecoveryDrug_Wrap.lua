---@class bagV2.ResRecoveryDrug
---instance properties
---@field public itemId System.Int32
---@field public cdTime System.Int32
---@field public cdTimeSpecified System.Boolean
local m = {};

bagV2.ResRecoveryDrug=m
return m;