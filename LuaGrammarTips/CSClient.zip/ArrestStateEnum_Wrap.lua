---@class ArrestStateEnum
---@field None @0
---@field OnGoing @1
---@field Finish @2
---@field Expired @3
---@field Received @4
---@field Submit @5
local m = {};
ArrestStateEnum=m
return m;