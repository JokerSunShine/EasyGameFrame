---@class awakeV2.ReqStrengthenAwake
---instance properties
---@field public index System.Int32
---@field public indexSpecified System.Boolean
local m = {};

awakeV2.ReqStrengthenAwake=m
return m;