---@class ExCSS.ErrorMessages
local m = {};
ExCSS.ErrorMessages=m
return m;