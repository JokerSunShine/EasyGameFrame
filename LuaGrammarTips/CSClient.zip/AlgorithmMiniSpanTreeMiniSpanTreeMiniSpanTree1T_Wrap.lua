---@class AlgorithmMiniSpanTreeMiniSpanTreeMiniSpanTree1T
local m = {};
---@param graph DataStructGraphMatrixGraphMatrixGraph1T
---@return DataStructGraphBaseEdge
function m.Prim(graph) end
---@param graph DataStructGraphEGGraphEGGraph1T
---@return DataStructGraphBaseEdge
function m.Kruskal(graph) end
AlgorithmMiniSpanTreeMiniSpanTreeMiniSpanTree1T=m
return m;