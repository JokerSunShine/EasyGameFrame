---@class EasyHookNativeAPI_x86
local m = {};
---@return SystemString
function m.RtlGetLastErrorStringCopy() end
---@return SystemString
function m.RtlGetLastErrorString() end
---@return SystemInt32
function m.RtlGetLastError() end
function m.LhUninstallAllHooks() end
---@param InEntryPoint SystemIntPtr
---@param InHookProc SystemIntPtr
---@param InCallback SystemIntPtr
---@param OutHandle SystemIntPtr
---@return SystemInt32
function m.LhInstallHook(InEntryPoint, InHookProc, InCallback, OutHandle) end
---@param RefHandle SystemIntPtr
---@return SystemInt32
function m.LhUninstallHook(RefHandle) end
---@return SystemInt32
function m.LhWaitForPendingRemovals() end
---@param InThreadIdList SystemInt32
---@param InThreadCount SystemInt32
---@param InHandle SystemIntPtr
---@return SystemInt32
function m.LhSetInclusiveACL(InThreadIdList, InThreadCount, InHandle) end
---@param InThreadIdList SystemInt32
---@param InThreadCount SystemInt32
---@param InHandle SystemIntPtr
---@return SystemInt32
function m.LhSetExclusiveACL(InThreadIdList, InThreadCount, InHandle) end
---@param InThreadIdList SystemInt32
---@param InThreadCount SystemInt32
---@return SystemInt32
function m.LhSetGlobalInclusiveACL(InThreadIdList, InThreadCount) end
---@param InThreadIdList SystemInt32
---@param InThreadCount SystemInt32
---@return SystemInt32
function m.LhSetGlobalExclusiveACL(InThreadIdList, InThreadCount) end
---@param InHandle SystemIntPtr
---@param InThreadID SystemInt32
---@param OutResult SystemBoolean @out
---@return SystemInt32
function m.LhIsThreadIntercepted(InHandle, InThreadID, OutResult) end
---@param OutValue SystemIntPtr @out
---@return SystemInt32
function m.LhBarrierGetCallback(OutValue) end
---@param OutValue SystemIntPtr @out
---@return SystemInt32
function m.LhBarrierGetReturnAddress(OutValue) end
---@param OutValue SystemIntPtr @out
---@return SystemInt32
function m.LhBarrierGetAddressOfReturnAddress(OutValue) end
---@param OutBackup SystemIntPtr @out
---@return SystemInt32
function m.LhBarrierBeginStackTrace(OutBackup) end
---@param OutBackup SystemIntPtr
---@return SystemInt32
function m.LhBarrierEndStackTrace(OutBackup) end
---@param OutValue SystemIntPtr @out
---@return SystemInt32
function m.LhBarrierGetCallingModule(OutValue) end
---@return SystemInt32
function m.DbgAttachDebugger() end
---@param InThreadHandle SystemIntPtr
---@param OutThreadId SystemInt32 @out
---@return SystemInt32
function m.DbgGetThreadIdByHandle(InThreadHandle, OutThreadId) end
---@param InProcessHandle SystemIntPtr
---@param OutProcessId SystemInt32 @out
---@return SystemInt32
function m.DbgGetProcessIdByHandle(InProcessHandle, OutProcessId) end
---@param InNamedHandle SystemIntPtr
---@param OutNameBuffer SystemIntPtr
---@param InBufferSize SystemInt32
---@param OutRequiredSize SystemInt32 @out
---@return SystemInt32
function m.DbgHandleToObjectName(InNamedHandle, OutNameBuffer, InBufferSize, OutRequiredSize) end
---@param InTargetPID SystemInt32
---@param InWakeUpTID SystemInt32
---@param InInjectionOptions SystemInt32
---@param InLibraryPath_x86 SystemString
---@param InLibraryPath_x64 SystemString
---@param InPassThruBuffer SystemIntPtr
---@param InPassThruSize SystemInt32
---@return SystemInt32
function m.RhInjectLibrary(InTargetPID, InWakeUpTID, InInjectionOptions, InLibraryPath_x86, InLibraryPath_x64, InPassThruBuffer, InPassThruSize) end
---@param InProcessId SystemInt32
---@param OutResult SystemBoolean @out
---@return SystemInt32
function m.RhIsX64Process(InProcessId, OutResult) end
---@return SystemBoolean
function m.RhIsAdministrator() end
---@param InProcessId SystemInt32
---@param OutToken SystemIntPtr @out
---@return SystemInt32
function m.RhGetProcessToken(InProcessId, OutToken) end
---@param InServiceName SystemString
---@param InExePath SystemString
---@param InChannelName SystemString
---@return SystemInt32
function m.RtlInstallService(InServiceName, InExePath, InChannelName) end
---@return SystemInt32
function m.RhWakeUpProcess() end
---@param InEXEPath SystemString
---@param InCommandLine SystemString
---@param InProcessCreationFlags SystemInt32
---@param OutProcessId SystemInt32 @out
---@param OutThreadId SystemInt32 @out
---@return SystemInt32
function m.RtlCreateSuspendedProcess(InEXEPath, InCommandLine, InProcessCreationFlags, OutProcessId, OutThreadId) end
---@param InDriverPath SystemString
---@param InDriverName SystemString
---@return SystemInt32
function m.RhInstallDriver(InDriverPath, InDriverName) end
---@return SystemInt32
function m.RhInstallSupportDriver() end
---@return SystemBoolean
function m.RhIsX64System() end
---@return SystemIntPtr
function m.GacCreateContext() end
---@param RefContext SystemIntPtr
function m.GacReleaseContext(RefContext) end
---@param InContext SystemIntPtr
---@param InAssemblyPath SystemString
---@param InDescription SystemString
---@param InUniqueID SystemString
---@return SystemBoolean
function m.GacInstallAssembly(InContext, InAssemblyPath, InDescription, InUniqueID) end
---@param InContext SystemIntPtr
---@param InAssemblyName SystemString
---@param InDescription SystemString
---@param InUniqueID SystemString
---@return SystemBoolean
function m.GacUninstallAssembly(InContext, InAssemblyName, InDescription, InUniqueID) end
---@param handle SystemIntPtr
---@param address SystemIntPtr @out
---@return SystemInt32
function m.LhGetHookBypassAddress(handle, address) end
EasyHookNativeAPI_x86=m
return m;