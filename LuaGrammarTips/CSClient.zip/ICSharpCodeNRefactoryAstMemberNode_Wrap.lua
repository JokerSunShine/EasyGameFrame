---@class ICSharpCodeNRefactoryAstMemberNode : ICSharpCodeNRefactoryAstParametrizedNode
---instance properties
---@field public InterfaceImplementations SystemCollectionsGenericList1ICSharpCodeNRefactoryAstInterfaceImplementation
---@field public TypeReference ICSharpCodeNRefactoryAstTypeReference
local m = {};
ICSharpCodeNRefactoryAstMemberNode=m
return m;