---@class ExtendEditorSelectionEx
local m = {};
---@return SystemString
function m.GetSelectedFolders() end
---@return SystemString
function m.GetSelectedCurFolders() end
---@param patten SystemString @default_value:
---@return SystemString
function m.GetSelectedFiles(patten) end
ExtendEditorSelectionEx=m
return m;