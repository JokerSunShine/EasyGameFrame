---@class ICSharpCode.NRefactory.Ast.ForNextStatement : ICSharpCode.NRefactory.Ast.StatementWithEmbeddedStatement
---instance properties
---@field public Start ICSharpCode.NRefactory.Ast.Expression
---@field public End ICSharpCode.NRefactory.Ast.Expression
---@field public Step ICSharpCode.NRefactory.Ast.Expression
---@field public NextExpressions System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.Expression]
---@field public TypeReference ICSharpCode.NRefactory.Ast.TypeReference
---@field public VariableName System.String
---@field public LoopVariableExpression ICSharpCode.NRefactory.Ast.Expression
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.ForNextStatement=m
return m;