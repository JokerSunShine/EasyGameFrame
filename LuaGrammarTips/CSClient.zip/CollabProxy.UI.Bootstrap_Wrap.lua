---@class CollabProxy.UI.Bootstrap
local m = {};
CollabProxy.UI.Bootstrap=m
return m;