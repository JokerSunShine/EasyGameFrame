---@class ICSharpCodeSharpZipLibTarTarHeader
---fields
---@field public CHKSUMOFS SystemInt32
---@field public LF_OLDNORM SystemByte
---@field public LF_NORMAL SystemByte
---@field public LF_LINK SystemByte
---@field public LF_SYMLINK SystemByte
---@field public LF_CHR SystemByte
---@field public LF_BLK SystemByte
---@field public LF_DIR SystemByte
---@field public LF_FIFO SystemByte
---@field public LF_CONTIG SystemByte
---@field public LF_GHDR SystemByte
---@field public LF_ACL SystemByte
---@field public LF_GNU_DUMPDIR SystemByte
---@field public LF_EXTATTR SystemByte
---@field public LF_META SystemByte
---@field public LF_GNU_LONGLINK SystemByte
---@field public LF_GNU_LONGNAME SystemByte
---@field public LF_GNU_MULTIVOL SystemByte
---@field public LF_GNU_NAMES SystemByte
---@field public LF_GNU_SPARSE SystemByte
---@field public LF_GNU_VOLHDR SystemByte
---@field public NAMELEN SystemInt32
---@field public MODELEN SystemInt32
---@field public UIDLEN SystemInt32
---@field public GIDLEN SystemInt32
---@field public CHKSUMLEN SystemInt32
---@field public SIZELEN SystemInt32
---@field public MAGICLEN SystemInt32
---@field public VERSIONLEN SystemInt32
---@field public MODTIMELEN SystemInt32
---@field public UNAMELEN SystemInt32
---@field public GNAMELEN SystemInt32
---@field public DEVLEN SystemInt32
---@field public LF_XHDR SystemByte
---@field public TMAGIC SystemString
---@field public GNU_TMAGIC SystemString
---instance properties
---@field public Name SystemString
---@field public Mode SystemInt32
---@field public UserId SystemInt32
---@field public GroupId SystemInt32
---@field public Size SystemInt64
---@field public ModTime SystemDateTime
---@field public Checksum SystemInt32
---@field public IsChecksumValid SystemBoolean
---@field public TypeFlag SystemByte
---@field public LinkName SystemString
---@field public Magic SystemString
---@field public Version SystemString
---@field public UserName SystemString
---@field public GroupName SystemString
---@field public DevMajor SystemInt32
---@field public DevMinor SystemInt32
local m = {};
---@param userId SystemInt32
---@param userName SystemString
---@param groupId SystemInt32
---@param groupName SystemString
function m.SetValueDefaults(userId, userName, groupId, groupName) end
function m.ResetValueDefaults() end
---@param header SystemByte
---@param offset SystemInt32
---@param length SystemInt32
---@return SystemInt64
function m.ParseOctal(header, offset, length) end
---@param header SystemByte
---@param offset SystemInt32
---@param length SystemInt32
---@return SystemTextStringBuilder
function m.ParseName(header, offset, length) end
---@param name SystemTextStringBuilder
---@param nameOffset SystemInt32
---@param buf SystemByte
---@param bufferOffset SystemInt32
---@param length SystemInt32
---@return SystemInt32
function m.GetNameBytes(name, nameOffset, buf, bufferOffset, length) end
---@param name SystemString
---@param nameOffset SystemInt32
---@param buf SystemByte
---@param bufferOffset SystemInt32
---@param length SystemInt32
---@return SystemInt32
function m.GetNameBytes(name, nameOffset, buf, bufferOffset, length) end
---@param name SystemTextStringBuilder
---@param buf SystemByte
---@param offset SystemInt32
---@param length SystemInt32
---@return SystemInt32
function m.GetNameBytes(name, buf, offset, length) end
---@param name SystemString
---@param buf SystemByte
---@param offset SystemInt32
---@param length SystemInt32
---@return SystemInt32
function m.GetNameBytes(name, buf, offset, length) end
---@param toAdd SystemString
---@param nameOffset SystemInt32
---@param buffer SystemByte
---@param bufferOffset SystemInt32
---@param length SystemInt32
---@return SystemInt32
function m.GetAsciiBytes(toAdd, nameOffset, buffer, bufferOffset, length) end
---@param val SystemInt64
---@param buf SystemByte
---@param offset SystemInt32
---@param length SystemInt32
---@return SystemInt32
function m.GetOctalBytes(val, buf, offset, length) end
---@param val SystemInt64
---@param buf SystemByte
---@param offset SystemInt32
---@param length SystemInt32
---@return SystemInt32
function m.GetLongOctalBytes(val, buf, offset, length) end
---@return SystemObject
function m:Clone() end
---@return SystemInt32
function m:GetHashCode() end
---@param obj SystemObject
---@return SystemBoolean
function m:Equals(obj) end
---@param header SystemByte
function m:ParseBuffer(header) end
---@param outbuf SystemByte
function m:WriteHeader(outbuf) end
ICSharpCodeSharpZipLibTarTarHeader=m
return m;