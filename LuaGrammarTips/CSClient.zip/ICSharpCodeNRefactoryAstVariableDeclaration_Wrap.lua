---@class ICSharpCodeNRefactoryAstVariableDeclaration : ICSharpCodeNRefactoryAstAbstractNode
---instance properties
---@field public Name SystemString
---@field public Initializer ICSharpCodeNRefactoryAstExpression
---@field public TypeReference ICSharpCodeNRefactoryAstTypeReference
---@field public FixedArrayInitialization ICSharpCodeNRefactoryAstExpression
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstVariableDeclaration=m
return m;