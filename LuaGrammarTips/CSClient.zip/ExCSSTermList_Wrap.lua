---@class ExCSSTermList : ExCSSTerm
---instance properties
---@field public Length SystemInt32
---@field public ListItems ExCSSTerm
local m = {};
---@param term ExCSSTerm
function m:AddTerm(term) end
---@param termSepertor ExCSSTermListTermSeparator
function m:AddSeparator(termSepertor) end
---@param index SystemInt32
---@return ExCSSTerm
function m:Item(index) end
---@return SystemCollectionsGenericIEnumerator1ExCSSTerm
function m:GetEnumerator() end
---@return SystemString
function m:ToString() end
ExCSSTermList=m
return m;