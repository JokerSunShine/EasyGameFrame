---@class AssetBundles.AssetBundleManagerLogMode
---@field All @0
---@field JustErrors @1
local m = {};
AssetBundles.AssetBundleManagerLogMode=m
return m;