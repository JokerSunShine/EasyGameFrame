---@class Microsoft.Win32.KeyHandler
---instance fields
---@field public Dir System.String
---@field public IsVolatile System.Boolean
---instance properties
---@field public ValueCount System.Int32
---@field public IsMarkedForDeletion System.Boolean
local m = {};
---@param dir System.String
---@return System.Boolean
function m.VolatileKeyExists(dir) end
---@param dir System.String
---@return System.String
function m.GetVolatileDir(dir) end
---@param rkey Microsoft.Win32.RegistryKey
---@param createNonExisting System.Boolean
---@return Microsoft.Win32.KeyHandler
function m.Lookup(rkey, createNonExisting) end
---@param rkey Microsoft.Win32.RegistryKey
function m.Drop(rkey) end
---@param dir System.String
function m.Drop(dir) end
---@param dir System.String
---@return System.Boolean
function m.Delete(dir) end
function m:Load() end
---@param rkey Microsoft.Win32.RegistryKey
---@param extra System.String
---@param writable System.Boolean
---@return Microsoft.Win32.RegistryKey
function m:Ensure(rkey, extra, writable) end
---@param rkey Microsoft.Win32.RegistryKey
---@param extra System.String
---@param writable System.Boolean
---@param is_volatile System.Boolean
---@return Microsoft.Win32.RegistryKey
function m:Ensure(rkey, extra, writable, is_volatile) end
---@param rkey Microsoft.Win32.RegistryKey
---@param extra System.String
---@param writable System.Boolean
---@return Microsoft.Win32.RegistryKey
function m:Probe(rkey, extra, writable) end
---@param name System.String
---@return Microsoft.Win32.RegistryValueKind
function m:GetValueKind(name) end
---@param name System.String
---@param options Microsoft.Win32.RegistryValueOptions
---@return System.Object
function m:GetValue(name, options) end
---@param name System.String
---@param value System.Object
function m:SetValue(name, value) end
---@return System.String[]
function m:GetValueNames() end
---@return System.Int32
function m:GetSubKeyCount() end
---@return System.String[]
function m:GetSubKeyNames() end
---@param name System.String
---@param value System.Object
---@param valueKind Microsoft.Win32.RegistryValueKind
function m:SetValue(name, value, valueKind) end
---@param state System.Object
function m:DirtyTimeout(state) end
function m:Flush() end
---@param name System.String
---@return System.Boolean
function m:ValueExists(name) end
---@param name System.String
function m:RemoveValue(name) end
Microsoft.Win32.KeyHandler=m
return m;