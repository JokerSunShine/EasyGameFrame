---@class DataStructQueueCurrentQueueCurrentQueue
local m = {};
DataStructQueueCurrentQueueCurrentQueue=m
return m;