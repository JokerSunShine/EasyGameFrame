---@class arenaV2.ResHighestRankRemind
---instance properties
---@field public startRank System.Int32
---@field public startRankSpecified System.Boolean
local m = {};

arenaV2.ResHighestRankRemind=m
return m;