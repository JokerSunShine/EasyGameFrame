---@class activityV2.ResCrazyHappy
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public crazyHappyInfo System.Collections.Generic.List1activityV2.CrazyHappyInfo
---@field public crazyHappyValue System.Int32
---@field public crazyHappyValueSpecified System.Boolean
---@field public hasDrawIndexList System.Collections.Generic.List1System.Int32
local m = {};

activityV2.ResCrazyHappy=m
return m;