---@class DiagnosticListener
local m = {};
DiagnosticListener=m
return m;