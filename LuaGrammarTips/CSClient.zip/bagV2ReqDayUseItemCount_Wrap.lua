---@class bagV2.ReqDayUseItemCount
---instance properties
---@field public itemId System.Int32
---@field public itemIdSpecified System.Boolean
local m = {};

bagV2.ReqDayUseItemCount=m
return m;