---@class arenaV2.ResArenaInfo
---instance properties
---@field public nowRank System.Int32
---@field public nowRankSpecified System.Boolean
---@field public arenaDataList System.Collections.Generic.List1arenaV2.ArenaDataInfo
---@field public rankRewardList System.Collections.Generic.List1arenaV2.RankRewardInfo
local m = {};

arenaV2.ResArenaInfo=m
return m;