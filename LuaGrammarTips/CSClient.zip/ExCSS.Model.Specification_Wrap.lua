---@class ExCSS.Model.Specification
local m = {};
ExCSS.Model.Specification=m
return m;