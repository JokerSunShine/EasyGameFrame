---@class CSObjectWrapEditorXLuaTemplate : SystemValueType
---instance fields
---@field public name SystemString
---@field public text SystemString
local m = {};
CSObjectWrapEditorXLuaTemplate=m
return m;