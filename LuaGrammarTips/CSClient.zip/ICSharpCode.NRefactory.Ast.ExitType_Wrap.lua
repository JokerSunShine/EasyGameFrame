---@class ICSharpCode.NRefactory.Ast.ExitType
---@field None @0
---@field Sub @1
---@field Function @2
---@field Property @3
---@field Do @4
---@field For @5
---@field While @6
---@field Select @7
---@field Try @8
ICSharpCode.NRefactory.Ast.ExitType=m
return m;