---@class JetBrainsAnnotationsImplicitUseKindFlags
---@field Access @1
---@field Assign @2
---@field InstantiatedWithFixedConstructorSignature @4
---@field Default @7
---@field InstantiatedNoFixedConstructorSignature @8
JetBrainsAnnotationsImplicitUseKindFlags=m
return m;