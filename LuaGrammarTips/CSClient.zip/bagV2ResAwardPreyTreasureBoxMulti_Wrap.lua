---@class bagV2.ResAwardPreyTreasureBoxMulti
---instance properties
---@field public awardItems System.Collections.Generic.List1bagV2.BagItemInfo
local m = {};

bagV2.ResAwardPreyTreasureBoxMulti=m
return m;