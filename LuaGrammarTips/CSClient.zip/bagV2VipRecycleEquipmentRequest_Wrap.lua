---@class bagV2.VipRecycleEquipmentRequest
---instance properties
---@field public recycleList System.Collections.Generic.List1System.Int64
local m = {};

bagV2.VipRecycleEquipmentRequest=m
return m;