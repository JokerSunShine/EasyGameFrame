---@class Analyze_TestLuaMemory : Analyze_TestLuaMemoryBase
---instance properties
---@field public CurrentState Analyze_TestLuaMemoryState
---@field public IsDoingAutomatic System.Boolean
---@field public DiffResult Analyze_TestLuaMemoryBaseAnalyzeResult
local m = {};

function m:StartTest() end
function m:FinishTest() end
---@param tableAddr System.Int32
---@param writeToFile System.Boolean
---@return System.String
function m:FindTableAllocateInfoByAddr(tableAddr, writeToFile) end
Analyze_TestLuaMemory=m
return m;