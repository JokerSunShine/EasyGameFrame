---@class ICSharpCode.NRefactory.Ast.FieldDirection
---@field None @0
---@field In @1
---@field Out @2
---@field Ref @3
ICSharpCode.NRefactory.Ast.FieldDirection=m
return m;