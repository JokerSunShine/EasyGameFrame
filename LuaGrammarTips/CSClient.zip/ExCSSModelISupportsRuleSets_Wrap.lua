---@class ExCSSModelISupportsRuleSets
---instance properties
---@field public RuleSets SystemCollectionsGenericList1ExCSSRuleSet
local m = {};
ExCSSModelISupportsRuleSets=m
return m;