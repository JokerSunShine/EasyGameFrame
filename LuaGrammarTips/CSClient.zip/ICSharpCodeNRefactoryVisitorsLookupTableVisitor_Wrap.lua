---@class ICSharpCodeNRefactoryVisitorsLookupTableVisitor : ICSharpCodeNRefactoryVisitorsAbstractAstVisitor
---instance properties
---@field public Variables SystemCollectionsGenericDictionary2SystemStringSystemCollectionsGenericList1ICSharpCodeNRefactoryVisitorsLocalLookupVariable
---@field public WithStatements SystemCollectionsGenericList1ICSharpCodeNRefactoryAstWithStatement
local m = {};
---@param typeRef ICSharpCodeNRefactoryAstTypeReference
---@param name SystemString
---@param startPos ICSharpCodeNRefactoryLocation
---@param endPos ICSharpCodeNRefactoryLocation
---@param isConst SystemBoolean
---@param isLoopVariable SystemBoolean
---@param initializer ICSharpCodeNRefactoryAstExpression
---@param parentLambdaExpression ICSharpCodeNRefactoryAstLambdaExpression
---@param isQueryContinuation SystemBoolean
function m:AddVariable(typeRef, name, startPos, endPos, isConst, isLoopVariable, initializer, parentLambdaExpression, isQueryContinuation) end
---@param withStatement ICSharpCodeNRefactoryAstWithStatement
---@param data SystemObject
---@return SystemObject
function m:VisitWithStatement(withStatement, data) end
---@param compilationUnit ICSharpCodeNRefactoryAstCompilationUnit
---@param data SystemObject
---@return SystemObject
function m:VisitCompilationUnit(compilationUnit, data) end
---@param blockStatement ICSharpCodeNRefactoryAstBlockStatement
---@param data SystemObject
---@return SystemObject
function m:VisitBlockStatement(blockStatement, data) end
---@param localVariableDeclaration ICSharpCodeNRefactoryAstLocalVariableDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitLocalVariableDeclaration(localVariableDeclaration, data) end
---@param anonymousMethodExpression ICSharpCodeNRefactoryAstAnonymousMethodExpression
---@param data SystemObject
---@return SystemObject
function m:VisitAnonymousMethodExpression(anonymousMethodExpression, data) end
---@param lambdaExpression ICSharpCodeNRefactoryAstLambdaExpression
---@param data SystemObject
---@return SystemObject
function m:VisitLambdaExpression(lambdaExpression, data) end
---@param queryExpression ICSharpCodeNRefactoryAstQueryExpression
---@param data SystemObject
---@return SystemObject
function m:VisitQueryExpression(queryExpression, data) end
---@param fromClause ICSharpCodeNRefactoryAstQueryExpressionFromClause
---@param data SystemObject
---@return SystemObject
function m:VisitQueryExpressionFromClause(fromClause, data) end
---@param joinClause ICSharpCodeNRefactoryAstQueryExpressionJoinClause
---@param data SystemObject
---@return SystemObject
function m:VisitQueryExpressionJoinClause(joinClause, data) end
---@param letClause ICSharpCodeNRefactoryAstQueryExpressionLetClause
---@param data SystemObject
---@return SystemObject
function m:VisitQueryExpressionLetClause(letClause, data) end
---@param forNextStatement ICSharpCodeNRefactoryAstForNextStatement
---@param data SystemObject
---@return SystemObject
function m:VisitForNextStatement(forNextStatement, data) end
---@param fixedStatement ICSharpCodeNRefactoryAstFixedStatement
---@param data SystemObject
---@return SystemObject
function m:VisitFixedStatement(fixedStatement, data) end
---@param forStatement ICSharpCodeNRefactoryAstForStatement
---@param data SystemObject
---@return SystemObject
function m:VisitForStatement(forStatement, data) end
---@param usingStatement ICSharpCodeNRefactoryAstUsingStatement
---@param data SystemObject
---@return SystemObject
function m:VisitUsingStatement(usingStatement, data) end
---@param switchSection ICSharpCodeNRefactoryAstSwitchSection
---@param data SystemObject
---@return SystemObject
function m:VisitSwitchSection(switchSection, data) end
---@param foreachStatement ICSharpCodeNRefactoryAstForeachStatement
---@param data SystemObject
---@return SystemObject
function m:VisitForeachStatement(foreachStatement, data) end
---@param tryCatchStatement ICSharpCodeNRefactoryAstTryCatchStatement
---@param data SystemObject
---@return SystemObject
function m:VisitTryCatchStatement(tryCatchStatement, data) end
ICSharpCodeNRefactoryVisitorsLookupTableVisitor=m
return m;