---@class ICSharpCodeNRefactoryParserSpecialTracker
---instance properties
---@field public CurrentSpecials SystemCollectionsGenericList1ICSharpCodeNRefactoryISpecial
local m = {};
---@param kind SystemInt32
function m:InformToken(kind) end
---@return SystemCollectionsGenericList1ICSharpCodeNRefactoryISpecial
function m:RetrieveSpecials() end
---@param point ICSharpCodeNRefactoryLocation
function m:AddEndOfLine(point) end
---@param directive ICSharpCodeNRefactoryPreprocessingDirective
function m:AddPreprocessingDirective(directive) end
---@param commentType ICSharpCodeNRefactoryCommentType
---@param commentStartsLine SystemBoolean
---@param startPosition ICSharpCodeNRefactoryLocation
function m:StartComment(commentType, commentStartsLine, startPosition) end
---@param c SystemChar
function m:AddChar(c) end
---@param s SystemString
function m:AddString(s) end
---@param endPosition ICSharpCodeNRefactoryLocation
function m:FinishComment(endPosition) end
ICSharpCodeNRefactoryParserSpecialTracker=m
return m;