---@class ICSharpCodeNRefactoryAstPropertyDeclaration : ICSharpCodeNRefactoryAstMemberNode
---instance properties
---@field public BodyStart ICSharpCodeNRefactoryLocation
---@field public BodyEnd ICSharpCodeNRefactoryLocation
---@field public GetRegion ICSharpCodeNRefactoryAstPropertyGetRegion
---@field public SetRegion ICSharpCodeNRefactoryAstPropertySetRegion
---@field public HasGetRegion SystemBoolean
---@field public HasSetRegion SystemBoolean
---@field public IsReadOnly SystemBoolean
---@field public IsWriteOnly SystemBoolean
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstPropertyDeclaration=m
return m;