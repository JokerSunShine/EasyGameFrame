---@class ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputStream : System.IO.Stream
---instance properties
---@field public IsStreamOwner System.Boolean
---@field public CanRead System.Boolean
---@field public CanSeek System.Boolean
---@field public CanWrite System.Boolean
---@field public Length System.Int64
---@field public Position System.Int64
---@field public Available System.Int32
local m = {};
function m:Flush() end
---@param offset System.Int64
---@param origin System.IO.SeekOrigin
---@return System.Int64
function m:Seek(offset, origin) end
---@param val System.Int64
function m:SetLength(val) end
---@param array System.Byte[]
---@param offset System.Int32
---@param count System.Int32
function m:Write(array, offset, count) end
---@param val System.Byte
function m:WriteByte(val) end
---@param buffer System.Byte[]
---@param offset System.Int32
---@param count System.Int32
---@param callback System.AsyncCallback
---@param state System.Object
---@return System.IAsyncResult
function m:BeginWrite(buffer, offset, count, callback, state) end
function m:Close() end
---@param b System.Byte[]
---@param off System.Int32
---@param len System.Int32
---@return System.Int32
function m:Read(b, off, len) end
---@param n System.Int64
---@return System.Int64
function m:Skip(n) end
ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputStream=m
return m;