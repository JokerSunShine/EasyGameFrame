---@class InstanceBase1T
---properties
---@field public Instance T
local m = {};
function m:Dispose() end
InstanceBase1T=m
return m;