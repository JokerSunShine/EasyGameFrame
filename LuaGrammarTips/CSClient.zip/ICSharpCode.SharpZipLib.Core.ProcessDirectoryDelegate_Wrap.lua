---@class ICSharpCode.SharpZipLib.Core.ProcessDirectoryDelegate : System.MulticastDelegate
local m = {};
---@param Sender System.Object
---@param e ICSharpCode.SharpZipLib.Core.DirectoryEventArgs
function m:Invoke(Sender, e) end
---@param Sender System.Object
---@param e ICSharpCode.SharpZipLib.Core.DirectoryEventArgs
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(Sender, e, callback, object) end
---@param result System.IAsyncResult
function m:EndInvoke(result) end
ICSharpCode.SharpZipLib.Core.ProcessDirectoryDelegate=m
return m;