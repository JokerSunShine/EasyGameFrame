---@class activityV2.ResDefendOver
---instance properties
---@field public rank activityV2.DefendRank
---@field public showTime System.Int64
---@field public showTimeSpecified System.Boolean
local m = {};

activityV2.ResDefendOver=m
return m;