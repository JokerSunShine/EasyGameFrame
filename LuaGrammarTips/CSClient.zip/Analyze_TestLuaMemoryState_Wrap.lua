---@class Analyze_TestLuaMemoryState
---@field Idle @0
---@field Recording @1
---@field GCing @2
local m = {};
Analyze_TestLuaMemoryState=m
return m;