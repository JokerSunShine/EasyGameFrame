---@class activityV2.ResActivityConfigChange
---instance properties
---@field public changedActivityList System.Collections.Generic.List1System.String
---@field public changedGoalList System.Collections.Generic.List1System.String
local m = {};

activityV2.ResActivityConfigChange=m
return m;