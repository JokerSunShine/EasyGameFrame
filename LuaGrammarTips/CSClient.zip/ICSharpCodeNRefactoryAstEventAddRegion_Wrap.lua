---@class ICSharpCodeNRefactoryAstEventAddRegion : ICSharpCodeNRefactoryAstEventAddRemoveRegion
---properties
---@field public Null ICSharpCodeNRefactoryAstEventAddRegion
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstEventAddRegion=m
return m;