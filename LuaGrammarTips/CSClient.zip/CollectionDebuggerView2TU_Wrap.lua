---@class CollectionDebuggerView2TU
---instance properties
---@field public Items SystemCollectionsGenericKeyValuePair2TU
local m = {};
CollectionDebuggerView2TU=m
return m;