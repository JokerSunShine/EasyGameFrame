---@class BehaviorState
---instance fields
---@field public mIsResetTowardAttack System.Boolean
---instance properties
---@field public Behavior System.Int32
---@field public mIsStop System.Boolean
local m = {};

---@param avater ISFAvater
---@param lastBehv BehaviorState
function m:Start(avater, lastBehv) end
---@param avater ISFAvater
---@return System.Int32
function m:Update(avater) end
---@param avater ISFAvater
---@param nextBehv BehaviorState
function m:End(avater, nextBehv) end
function m:Reset() end
BehaviorState=m
return m;