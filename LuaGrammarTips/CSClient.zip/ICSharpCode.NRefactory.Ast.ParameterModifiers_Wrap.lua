---@class ICSharpCode.NRefactory.Ast.ParameterModifiers
---@field None @0
---@field In @1
---@field Out @2
---@field Ref @4
---@field Params @8
---@field Optional @16
ICSharpCode.NRefactory.Ast.ParameterModifiers=m
return m;