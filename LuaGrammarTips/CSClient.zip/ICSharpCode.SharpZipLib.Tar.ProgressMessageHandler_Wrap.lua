---@class ICSharpCode.SharpZipLib.Tar.ProgressMessageHandler : System.MulticastDelegate
local m = {};
---@param archive ICSharpCode.SharpZipLib.Tar.TarArchive
---@param entry ICSharpCode.SharpZipLib.Tar.TarEntry
---@param message System.String
function m:Invoke(archive, entry, message) end
---@param archive ICSharpCode.SharpZipLib.Tar.TarArchive
---@param entry ICSharpCode.SharpZipLib.Tar.TarEntry
---@param message System.String
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(archive, entry, message, callback, object) end
---@param result System.IAsyncResult
function m:EndInvoke(result) end
ICSharpCode.SharpZipLib.Tar.ProgressMessageHandler=m
return m;