---@class ICSharpCode.SharpZipLib.Core.PathFilter
local m = {};
---@param name System.String
---@return System.Boolean
function m:IsMatch(name) end
ICSharpCode.SharpZipLib.Core.PathFilter=m
return m;