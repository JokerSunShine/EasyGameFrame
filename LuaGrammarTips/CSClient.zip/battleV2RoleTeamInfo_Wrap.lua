---@class battleV2.RoleTeamInfo
---instance properties
---@field public teamInfo battleV2.TeamInfo
---@field public uid System.Int64
---@field public uidSpecified System.Boolean
local m = {};

battleV2.RoleTeamInfo=m
return m;