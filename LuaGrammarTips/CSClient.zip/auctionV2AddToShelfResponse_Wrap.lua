---@class auctionV2.AddToShelfResponse
---instance properties
---@field public lid System.Int64
---@field public lidSpecified System.Boolean
---@field public item auctionV2.AuctionItemInfo
local m = {};

auctionV2.AddToShelfResponse=m
return m;