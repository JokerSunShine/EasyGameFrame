---@class ICSharpCodeNRefactorySupportedLanguage
---@field CSharp @0
---@field VBNet @1
ICSharpCodeNRefactorySupportedLanguage=m
return m;