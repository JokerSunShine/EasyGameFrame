---@class ExCSSModelExtensionsCharacterExtensions
local m = {};
---@param character SystemChar
---@return SystemInt32
function m.FromHex(character) end
---@param array SystemChar
---@return SystemString
function m.TrimArray(array) end
---@param value SystemString
---@return SystemString
function m.SplitOnCommas(value) end
---@param num SystemByte
---@return SystemString
function m.ToHex(num) end
---@param num SystemByte
---@return SystemChar
function m.ToHexChar(num) end
ExCSSModelExtensionsCharacterExtensions=m
return m;