---@class ICSharpCodeNRefactoryParserAbstractParser
---instance properties
---@field public ParseMethodBodies SystemBoolean
---@field public Lexer ICSharpCodeNRefactoryParserILexer
---@field public Errors ICSharpCodeNRefactoryParserErrors
---@field public CompilationUnit ICSharpCodeNRefactoryAstCompilationUnit
local m = {};
function m:Parse() end
---@return ICSharpCodeNRefactoryAstTypeReference
function m:ParseTypeReference() end
---@return ICSharpCodeNRefactoryAstExpression
function m:ParseExpression() end
---@return ICSharpCodeNRefactoryAstBlockStatement
function m:ParseBlock() end
---@return SystemCollectionsGenericList1ICSharpCodeNRefactoryAstINode
function m:ParseTypeMembers() end
function m:Dispose() end
ICSharpCodeNRefactoryParserAbstractParser=m
return m;