---@class ICSharpCode.NRefactory.Ast.EventAddRemoveRegion : ICSharpCode.NRefactory.Ast.AttributedNode
---instance properties
---@field public Block ICSharpCode.NRefactory.Ast.BlockStatement
---@field public Parameters System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.ParameterDeclarationExpression]
---@field public IsNull System.Boolean
local m = {};
ICSharpCode.NRefactory.Ast.EventAddRemoveRegion=m
return m;