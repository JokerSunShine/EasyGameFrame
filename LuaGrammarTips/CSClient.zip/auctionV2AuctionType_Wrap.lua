---@class auctionV2.AuctionType
---@field BID @1
---@field ONEPRICE @2
local m = {};
auctionV2.AuctionType=m
return m;