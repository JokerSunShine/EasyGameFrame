---@class EasyHookInjectionOptions
---@field Default @0
---@field NoService @1
---@field NoWOW64Bypass @2
---@field DoNotRequireStrongName @4
EasyHookInjectionOptions=m
return m;