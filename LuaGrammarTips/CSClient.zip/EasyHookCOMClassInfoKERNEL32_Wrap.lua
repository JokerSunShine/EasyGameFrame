---@class EasyHookCOMClassInfoKERNEL32
local m = {};
---@param lpFileName SystemString
---@return SystemIntPtr
function m.LoadLibrary(lpFileName) end
---@param lpModuleName SystemString
---@return SystemIntPtr
function m.GetModuleHandle(lpModuleName) end
---@param hModule SystemIntPtr
---@param procName SystemString
---@return SystemIntPtr
function m.GetProcAddress(hModule, procName) end
EasyHookCOMClassInfoKERNEL32=m
return m;