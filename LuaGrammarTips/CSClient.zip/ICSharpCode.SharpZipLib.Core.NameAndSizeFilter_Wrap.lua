---@class ICSharpCode.SharpZipLib.Core.NameAndSizeFilter : ICSharpCode.SharpZipLib.Core.PathFilter
---instance properties
---@field public MinSize System.Int64
---@field public MaxSize System.Int64
local m = {};
---@param fileName System.String
---@return System.Boolean
function m:IsMatch(fileName) end
ICSharpCode.SharpZipLib.Core.NameAndSizeFilter=m
return m;