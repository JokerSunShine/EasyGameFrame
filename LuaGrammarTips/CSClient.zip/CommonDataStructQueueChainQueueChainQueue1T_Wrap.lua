---@class CommonDataStructQueueChainQueueChainQueue1T
---instance properties
---@field public Count SystemInt32
local m = {};
---@param list CommonDataStructQueueChainQueueChainQueue1T
---@return CommonDataStructQueueChainQueueChainQueue1T
function m.CreateNewQueueByQueue(list) end
---@param queue1 CommonDataStructQueueChainQueueChainQueue1T
---@param queue2 CommonDataStructQueueChainQueueChainQueue1T
---@return CommonDataStructQueueChainQueueChainQueue1T
function m.op_Addition(queue1, queue2) end
---@param item T
---@return CommonDataStructQueueChainQueueChainQueue1T
function m:Enqueue(item) end
---@return T
function m:Dequeue() end
---@return SystemBoolean
function m:IsEmpty() end
CommonDataStructQueueChainQueueChainQueue1T=m
return m;