---@class AlgorithmSearchSearch
local m = {};
AlgorithmSearchSearch=m
return m;