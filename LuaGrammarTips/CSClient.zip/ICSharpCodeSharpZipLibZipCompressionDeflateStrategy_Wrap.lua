---@class ICSharpCodeSharpZipLibZipCompressionDeflateStrategy
---@field Default @0
---@field Filtered @1
---@field HuffmanOnly @2
ICSharpCodeSharpZipLibZipCompressionDeflateStrategy=m
return m;