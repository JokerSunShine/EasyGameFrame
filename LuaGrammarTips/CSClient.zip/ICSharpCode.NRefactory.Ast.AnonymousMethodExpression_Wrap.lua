---@class ICSharpCode.NRefactory.Ast.AnonymousMethodExpression : ICSharpCode.NRefactory.Ast.Expression
---instance properties
---@field public Parameters System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.ParameterDeclarationExpression]
---@field public Body ICSharpCode.NRefactory.Ast.BlockStatement
---@field public HasParameterList System.Boolean
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.AnonymousMethodExpression=m
return m;