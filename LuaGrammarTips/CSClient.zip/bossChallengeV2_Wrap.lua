bossChallengeV2 = {};
