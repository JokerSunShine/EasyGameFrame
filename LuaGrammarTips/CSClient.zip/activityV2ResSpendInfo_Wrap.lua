---@class activityV2.ResSpendInfo
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public num System.Int32
---@field public numSpecified System.Boolean
local m = {};

activityV2.ResSpendInfo=m
return m;