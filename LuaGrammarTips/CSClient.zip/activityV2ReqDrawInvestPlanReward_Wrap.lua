---@class activityV2.ReqDrawInvestPlanReward
---instance properties
---@field public activityId System.Int32
---@field public activityIdSpecified System.Boolean
---@field public dayNo System.Int32
---@field public dayNoSpecified System.Boolean
local m = {};

activityV2.ReqDrawInvestPlanReward=m
return m;