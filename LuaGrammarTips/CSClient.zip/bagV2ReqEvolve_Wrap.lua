---@class bagV2.ReqEvolve
---instance properties
---@field public equipId System.Int64
---@field public equipIdSpecified System.Boolean
---@field public sacrifices System.Collections.Generic.List1System.Int64
---@field public type System.Int32
---@field public typeSpecified System.Boolean
local m = {};

bagV2.ReqEvolve=m
return m;