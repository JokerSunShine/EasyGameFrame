---@class ICSharpCodeSharpZipLibZipCompressionStreamsInflaterInputBuffer
---instance properties
---@field public RawLength SystemInt32
---@field public RawData SystemByte
---@field public ClearTextLength SystemInt32
---@field public ClearText SystemByte
---@field public Available SystemInt32
---@field public CryptoTransform SystemSecurityCryptographyICryptoTransform
local m = {};
---@param inflater ICSharpCodeSharpZipLibZipCompressionInflater
function m:SetInflaterInput(inflater) end
function m:Fill() end
---@param buffer SystemByte
---@return SystemInt32
function m:ReadRawBuffer(buffer) end
---@param outBuffer SystemByte
---@param offset SystemInt32
---@param length SystemInt32
---@return SystemInt32
function m:ReadRawBuffer(outBuffer, offset, length) end
---@param outBuffer SystemByte
---@param offset SystemInt32
---@param length SystemInt32
---@return SystemInt32
function m:ReadClearTextBuffer(outBuffer, offset, length) end
---@return SystemInt32
function m:ReadLeByte() end
---@return SystemInt32
function m:ReadLeShort() end
---@return SystemInt32
function m:ReadLeInt() end
---@return SystemInt64
function m:ReadLeLong() end
ICSharpCodeSharpZipLibZipCompressionStreamsInflaterInputBuffer=m
return m;