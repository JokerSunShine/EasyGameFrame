---@class bossChallengeV2.ReqGetWorldBossInfo
---instance properties
---@field public bossIdList System.Collections.Generic.List1System.Int32
local m = {};

bossChallengeV2.ReqGetWorldBossInfo=m
return m;