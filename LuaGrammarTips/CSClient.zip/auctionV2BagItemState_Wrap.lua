---@class auctionV2.BagItemState
---instance properties
---@field public lid System.Int64
---@field public lidSpecified System.Boolean
---@field public saleMoney System.Int32
---@field public saleMoneySpecified System.Boolean
---@field public saleDiamond System.Int32
---@field public saleDiamondSpecified System.Boolean
---@field public auctionDiamond System.Int32
---@field public auctionDiamondSpecified System.Boolean
local m = {};

auctionV2.BagItemState=m
return m;