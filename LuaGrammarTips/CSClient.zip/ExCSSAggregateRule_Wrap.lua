---@class ExCSSAggregateRule : ExCSSRuleSet
---instance properties
---@field public RuleSets SystemCollectionsGenericList1ExCSSRuleSet
local m = {};
ExCSSAggregateRule=m
return m;