---@class DataStructTreeBinaryTreePerfectBinaryTreePrefectChainBinaryTreeChain1T : DataStructTreeBinaryTreeChainBinaryTreeAbstract1T
---instance properties
---@field public Head DataStructTreeBinaryTreeNode1T
---@field public LeftLeaf DataStructTreeBinaryTreeNode1T
---@field public Count SystemInt32
local m = {};
---@param dataList T
---@param index SystemInt32 @default_value:1
---@return DataStructTreeBinaryTreeNode1T
function m:CreatePrefectTree(dataList, index) end
DataStructTreeBinaryTreePerfectBinaryTreePrefectChainBinaryTreeChain1T=m
return m;