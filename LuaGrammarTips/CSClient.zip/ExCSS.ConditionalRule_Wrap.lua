---@class ExCSS.ConditionalRule : ExCSS.AggregateRule
---instance properties
---@field public Condition System.String
local m = {};
ExCSS.ConditionalRule=m
return m;