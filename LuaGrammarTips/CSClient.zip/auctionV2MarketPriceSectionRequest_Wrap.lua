---@class auctionV2.MarketPriceSectionRequest
---instance properties
---@field public lid System.Int64
---@field public lidSpecified System.Boolean
---@field public MarketPriceSectionType System.Int32
---@field public MarketPriceSectionTypeSpecified System.Boolean
---@field public itemType System.Int32
---@field public itemTypeSpecified System.Boolean
---@field public priceItemId System.Int32
---@field public priceItemIdSpecified System.Boolean
local m = {};

auctionV2.MarketPriceSectionRequest=m
return m;