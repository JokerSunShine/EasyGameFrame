---@class ExCSS.KeyframesRule : ExCSS.RuleSet
---instance properties
---@field public Identifier System.String
---@field public Declarations System.Collections.Generic.List`1[ExCSS.RuleSet]
local m = {};
---@return System.String
function m:ToString() end
---@param friendlyFormat System.Boolean
---@param indentation System.Int32 @default_value:0
---@return System.String
function m:ToString(friendlyFormat, indentation) end
ExCSS.KeyframesRule=m
return m;