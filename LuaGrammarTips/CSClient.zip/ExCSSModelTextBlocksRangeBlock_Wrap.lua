---@class ExCSSModelTextBlocksRangeBlock : ExCSSModelTextBlocksBlock
local m = {};
---@return SystemString
function m:ToString() end
ExCSSModelTextBlocksRangeBlock=m
return m;