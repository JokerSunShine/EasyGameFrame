---@class activityV2.ResDefendUpdateScore
---instance properties
---@field public type System.Int32
---@field public typeSpecified System.Boolean
---@field public score System.Int32
---@field public scoreSpecified System.Boolean
---@field public kingId System.Int64
---@field public kingIdSpecified System.Boolean
local m = {};

activityV2.ResDefendUpdateScore=m
return m;