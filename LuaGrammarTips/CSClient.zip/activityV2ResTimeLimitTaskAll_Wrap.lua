---@class activityV2.ResTimeLimitTaskAll
---instance properties
---@field public taskList System.Collections.Generic.List1activityV2.limitTimeTaskInfo
local m = {};

activityV2.ResTimeLimitTaskAll=m
return m;