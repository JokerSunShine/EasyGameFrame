---@class ICSharpCodeSharpZipLibBZip2BZip2Constants
---fields
---@field public rNums SystemInt32
---@field public baseBlockSize SystemInt32
---@field public MAX_ALPHA_SIZE SystemInt32
---@field public MAX_CODE_LEN SystemInt32
---@field public RUNA SystemInt32
---@field public RUNB SystemInt32
---@field public N_GROUPS SystemInt32
---@field public G_SIZE SystemInt32
---@field public N_ITERS SystemInt32
---@field public MAX_SELECTORS SystemInt32
---@field public NUM_OVERSHOOT_BYTES SystemInt32
local m = {};
ICSharpCodeSharpZipLibBZip2BZip2Constants=m
return m;