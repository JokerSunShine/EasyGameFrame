---@class boothV2.BoothMapsResponse
---instance properties
---@field public MapIds System.Collections.Generic.List1System.Int32
---@field public lastRemoveBoothTime System.Int64
---@field public lastRemoveBoothTimeSpecified System.Boolean
local m = {};

boothV2.BoothMapsResponse=m
return m;