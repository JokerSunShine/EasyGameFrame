---@class ICSharpCode.SharpZipLib.Encryption.PkzipClassicCryptoBase
local m = {};
ICSharpCode.SharpZipLib.Encryption.PkzipClassicCryptoBase=m
return m;