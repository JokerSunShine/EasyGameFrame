---@class activityV2.GetBossScoreReward
---instance properties
---@field public id System.Int32
local m = {};

activityV2.GetBossScoreReward=m
return m;