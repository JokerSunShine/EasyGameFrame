---@class CSObjectWrapEditorGeneratorLazyMemberInfo
---instance fields
---@field public Index SystemString
---@field public Name SystemString
---@field public MemberType SystemString
---@field public IsStatic SystemString
local m = {};
CSObjectWrapEditorGeneratorLazyMemberInfo=m
return m;