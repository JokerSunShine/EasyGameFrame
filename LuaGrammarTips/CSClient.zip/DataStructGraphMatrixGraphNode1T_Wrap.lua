---@class DataStructGraphMatrixGraphNode1T : DataStructGraphBaseNodeAbstract1T
local m = {};
DataStructGraphMatrixGraphNode1T=m
return m;