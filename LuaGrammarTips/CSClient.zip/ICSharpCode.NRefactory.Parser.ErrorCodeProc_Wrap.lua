---@class ICSharpCode.NRefactory.Parser.ErrorCodeProc : System.MulticastDelegate
local m = {};
---@param line System.Int32
---@param col System.Int32
---@param n System.Int32
function m:Invoke(line, col, n) end
---@param line System.Int32
---@param col System.Int32
---@param n System.Int32
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(line, col, n, callback, object) end
---@param result System.IAsyncResult
function m:EndInvoke(result) end
ICSharpCode.NRefactory.Parser.ErrorCodeProc=m
return m;