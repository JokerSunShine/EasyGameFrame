---@class ICSharpCodeSharpZipLibZipZipFilePartialInputStream : ICSharpCodeSharpZipLibZipCompressionStreamsInflaterInputStream
---instance properties
---@field public Available SystemInt32
local m = {};
---@return SystemInt32
function m:ReadByte() end
function m:Close() end
---@param b SystemByte
---@param off SystemInt32
---@param len SystemInt32
---@return SystemInt32
function m:Read(b, off, len) end
---@param amount SystemInt64
---@return SystemInt64
function m:SkipBytes(amount) end
ICSharpCodeSharpZipLibZipZipFilePartialInputStream=m
return m;