---@class ICSharpCodeNRefactoryAstIdentifierExpression : ICSharpCodeNRefactoryAstExpression
---instance properties
---@field public Identifier SystemString
---@field public TypeArguments SystemCollectionsGenericList1ICSharpCodeNRefactoryAstTypeReference
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstIdentifierExpression=m
return m;