---@class CommonOneWayChainListNode1T
---instance properties
---@field public Data T
---@field public Next CommonOneWayChainListNode1T
local m = {};
---@param item T
---@return CommonOneWayChainListNode1T
function m:AddNext(item) end
---@param node CommonOneWayChainListNode1T
---@return CommonOneWayChainListNode1T
function m:AddNext(node) end
---@return SystemBoolean
function m:HaveData() end
---@return SystemBoolean
function m:HaveNextData() end
CommonOneWayChainListNode1T=m
return m;