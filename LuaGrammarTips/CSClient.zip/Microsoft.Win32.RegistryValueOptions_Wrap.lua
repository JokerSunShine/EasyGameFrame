---@class Microsoft.Win32.RegistryValueOptions
---@field None @0
---@field DoNotExpandEnvironmentNames @1
Microsoft.Win32.RegistryValueOptions=m
return m;