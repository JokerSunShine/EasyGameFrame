---@class ExCSSParseErrorEventHandler : SystemMulticastDelegate
local m = {};
---@param e ExCSSStylesheetParseError
function m:Invoke(e) end
---@param e ExCSSStylesheetParseError
---@param callback SystemAsyncCallback
---@param object SystemObject
---@return SystemIAsyncResult
function m:BeginInvoke(e, callback, object) end
---@param result SystemIAsyncResult
function m:EndInvoke(result) end
ExCSSParseErrorEventHandler=m
return m;