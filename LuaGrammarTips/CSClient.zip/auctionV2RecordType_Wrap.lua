---@class auctionV2.RecordType
---@field ENTIRE @0
---@field BUY @1
---@field SELL @2
local m = {};
auctionV2.RecordType=m
return m;