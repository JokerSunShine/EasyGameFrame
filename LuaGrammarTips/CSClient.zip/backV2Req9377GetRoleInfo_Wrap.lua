---@class backV2.Req9377GetRoleInfo
---instance properties
---@field public loginName System.String
---@field public loginNameSpecified System.Boolean
---@field public qudao System.Int32
---@field public qudaoSpecified System.Boolean
---@field public sid System.Int32
---@field public sidSpecified System.Boolean
local m = {};

backV2.Req9377GetRoleInfo=m
return m;