---@class CSEditorPlatformInfo : AbstractPlatformInfo
---fields
---@field public LuaRoot SystemString
---@field public XLuaMainPath SystemString
local m = {};
CSEditorPlatformInfo=m
return m;