---@class CSEditorPlatformInfo : AbstractPlatformInfo
---fields
---@field public LuaRoot System.String
---@field public XLuaMainPath System.String
local m = {};
CSEditorPlatformInfo=m
return m;