---@class Microsoft.Win32.RegistryKeyComparer
local m = {};
---@param x System.Object
---@param y System.Object
---@return System.Boolean
function m:Equals(x, y) end
---@param obj System.Object
---@return System.Int32
function m:GetHashCode(obj) end
Microsoft.Win32.RegistryKeyComparer=m
return m;