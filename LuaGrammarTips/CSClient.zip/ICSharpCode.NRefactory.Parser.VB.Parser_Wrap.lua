---@class ICSharpCode.NRefactory.Parser.VB.Parser : ICSharpCode.NRefactory.Parser.AbstractParser
local m = {};
---@param s System.String
function m:Error(s) end
function m:Parse() end
---@return ICSharpCode.NRefactory.Ast.TypeReference
function m:ParseTypeReference() end
---@return ICSharpCode.NRefactory.Ast.Expression
function m:ParseExpression() end
---@return ICSharpCode.NRefactory.Ast.BlockStatement
function m:ParseBlock() end
---@return System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.INode]
function m:ParseTypeMembers() end
ICSharpCode.NRefactory.Parser.VB.Parser=m
return m;