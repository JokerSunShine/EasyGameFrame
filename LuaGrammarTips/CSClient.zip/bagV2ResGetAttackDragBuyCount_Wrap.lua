---@class bagV2.ResGetAttackDragBuyCount
---instance properties
---@field public useInfo System.Collections.Generic.List1bagV2.InstanceItemInfo
local m = {};

bagV2.ResGetAttackDragBuyCount=m
return m;