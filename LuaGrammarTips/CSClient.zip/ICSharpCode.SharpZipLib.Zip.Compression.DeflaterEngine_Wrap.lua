---@class ICSharpCode.SharpZipLib.Zip.Compression.DeflaterEngine : ICSharpCode.SharpZipLib.Zip.Compression.DeflaterConstants
---instance properties
---@field public Adler System.Int32
---@field public TotalIn System.Int32
---@field public Strategy ICSharpCode.SharpZipLib.Zip.Compression.DeflateStrategy
local m = {};
function m:Reset() end
function m:ResetAdler() end
---@param lvl System.Int32
function m:SetLevel(lvl) end
function m:FillWindow() end
---@param buffer System.Byte[]
---@param offset System.Int32
---@param length System.Int32
function m:SetDictionary(buffer, offset, length) end
---@param flush System.Boolean
---@param finish System.Boolean
---@return System.Boolean
function m:Deflate(flush, finish) end
---@param buf System.Byte[]
---@param off System.Int32
---@param len System.Int32
function m:SetInput(buf, off, len) end
---@return System.Boolean
function m:NeedsInput() end
ICSharpCode.SharpZipLib.Zip.Compression.DeflaterEngine=m
return m;