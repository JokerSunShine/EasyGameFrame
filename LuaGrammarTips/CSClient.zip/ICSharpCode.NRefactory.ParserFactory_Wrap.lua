---@class ICSharpCode.NRefactory.ParserFactory
local m = {};
---@param language ICSharpCode.NRefactory.SupportedLanguage
---@param textReader System.IO.TextReader
---@return ICSharpCode.NRefactory.Parser.ILexer
function m.CreateLexer(language, textReader) end
---@param language ICSharpCode.NRefactory.SupportedLanguage
---@param textReader System.IO.TextReader
---@return ICSharpCode.NRefactory.IParser
function m.CreateParser(language, textReader) end
---@param fileName System.String
---@return ICSharpCode.NRefactory.IParser
function m.CreateParser(fileName) end
---@param fileName System.String
---@param encoding System.Text.Encoding
---@return ICSharpCode.NRefactory.IParser
function m.CreateParser(fileName, encoding) end
ICSharpCode.NRefactory.ParserFactory=m
return m;