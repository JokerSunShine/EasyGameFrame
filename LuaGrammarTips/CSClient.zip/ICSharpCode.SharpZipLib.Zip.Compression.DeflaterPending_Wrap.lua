---@class ICSharpCode.SharpZipLib.Zip.Compression.DeflaterPending : ICSharpCode.SharpZipLib.Zip.Compression.PendingBuffer
local m = {};
ICSharpCode.SharpZipLib.Zip.Compression.DeflaterPending=m
return m;