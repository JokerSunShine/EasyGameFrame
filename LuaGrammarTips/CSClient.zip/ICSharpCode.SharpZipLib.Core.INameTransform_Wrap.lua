---@class ICSharpCode.SharpZipLib.Core.INameTransform
local m = {};
---@param name System.String
---@return System.String
function m:TransformFile(name) end
---@param name System.String
---@return System.String
function m:TransformDirectory(name) end
ICSharpCode.SharpZipLib.Core.INameTransform=m
return m;