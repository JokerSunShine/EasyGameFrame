---@class DataStructTreeHeapFibHeapFibHeap1T
local m = {};
---@param node DataStructTreeHeapFibHeapNode1T
---@param root DataStructTreeHeapFibHeapNode1T
function m.AddNode(node, root) end
---@param node DataStructTreeHeapFibHeapNode1T
---@param root DataStructTreeHeapFibHeapNode1T
function m.Link(node, root) end
---@param node DataStructTreeHeapFibHeapNode1T
function m.RemoveNode(node) end
---@param heap DataStructTreeHeapFibHeapFibHeap1T
---@return DataStructTreeHeapFibHeapNode1T
function m.RemoveMinTree(heap) end
---@param heap DataStructTreeHeapFibHeapFibHeap1T
---@return DataStructTreeHeapFibHeapFibHeap1T
function m.UnionSameDegreeTree(heap) end
---@param heap DataStructTreeHeapFibHeapFibHeap1T
function m.RemoveMinNode(heap) end
---@param node DataStructTreeHeapFibHeapNode1T
function m:Insert(node) end
---@param data T
function m:Insert(data) end
---@param other DataStructTreeHeapFibHeapFibHeap1T
function m:Union(other) end
---@return T
function m:GetMinData() end
---@param a DataStructTreeHeapFibHeapNode1T
---@param b DataStructTreeHeapFibHeapNode1T
function m:CatList(a, b) end
DataStructTreeHeapFibHeapFibHeap1T=m
return m;