---@class auctionV2.BuyUnionSmeltItem
---instance properties
---@field public lid System.Int64
---@field public lidSpecified System.Boolean
---@field public count System.Int32
---@field public countSpecified System.Boolean
local m = {};

auctionV2.BuyUnionSmeltItem=m
return m;