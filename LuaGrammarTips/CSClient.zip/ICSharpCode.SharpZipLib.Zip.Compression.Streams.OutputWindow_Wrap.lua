---@class ICSharpCode.SharpZipLib.Zip.Compression.Streams.OutputWindow
local m = {};
---@param abyte System.Int32
function m:Write(abyte) end
---@param len System.Int32
---@param dist System.Int32
function m:Repeat(len, dist) end
---@param input ICSharpCode.SharpZipLib.Zip.Compression.Streams.StreamManipulator
---@param len System.Int32
---@return System.Int32
function m:CopyStored(input, len) end
---@param dict System.Byte[]
---@param offset System.Int32
---@param len System.Int32
function m:CopyDict(dict, offset, len) end
---@return System.Int32
function m:GetFreeSpace() end
---@return System.Int32
function m:GetAvailable() end
---@param output System.Byte[]
---@param offset System.Int32
---@param len System.Int32
---@return System.Int32
function m:CopyOutput(output, offset, len) end
function m:Reset() end
ICSharpCode.SharpZipLib.Zip.Compression.Streams.OutputWindow=m
return m;