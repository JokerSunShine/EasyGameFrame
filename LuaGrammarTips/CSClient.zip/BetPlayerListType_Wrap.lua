---@class BetPlayerListType
---@field PROMOTION @1
---@field CONTENTHEGEMONY @2
local m = {};
BetPlayerListType=m
return m;