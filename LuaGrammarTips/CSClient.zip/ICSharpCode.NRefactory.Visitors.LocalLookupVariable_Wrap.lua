---@class ICSharpCode.NRefactory.Visitors.LocalLookupVariable
---instance fields
---@field public Name System.String
---@field public TypeRef ICSharpCode.NRefactory.Ast.TypeReference
---@field public StartPos ICSharpCode.NRefactory.Location
---@field public EndPos ICSharpCode.NRefactory.Location
---@field public IsConst System.Boolean
---@field public IsLoopVariable System.Boolean
---@field public Initializer ICSharpCode.NRefactory.Ast.Expression
---@field public ParentLambdaExpression ICSharpCode.NRefactory.Ast.LambdaExpression
---@field public IsQueryContinuation System.Boolean
local m = {};
ICSharpCode.NRefactory.Visitors.LocalLookupVariable=m
return m;