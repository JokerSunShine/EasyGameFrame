---@class EasyHookManagedRemoteInfo
---instance fields
---@field public ChannelName SystemString
---@field public UserParams SystemObject
---@field public UserLibrary SystemString
---@field public UserLibraryName SystemString
---@field public HostPID SystemInt32
---@field public RequireStrongName SystemBoolean
local m = {};
EasyHookManagedRemoteInfo=m
return m;