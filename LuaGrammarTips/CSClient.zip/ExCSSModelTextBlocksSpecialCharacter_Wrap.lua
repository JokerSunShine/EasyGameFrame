---@class ExCSSModelTextBlocksSpecialCharacter : ExCSSModelTextBlocksCharacterBlock
local m = {};
---@return SystemString
function m:ToString() end
ExCSSModelTextBlocksSpecialCharacter=m
return m;