---@class ICSharpCode.NRefactory.Ast.PropertyDeclaration : ICSharpCode.NRefactory.Ast.MemberNode
---instance properties
---@field public BodyStart ICSharpCode.NRefactory.Location
---@field public BodyEnd ICSharpCode.NRefactory.Location
---@field public GetRegion ICSharpCode.NRefactory.Ast.PropertyGetRegion
---@field public SetRegion ICSharpCode.NRefactory.Ast.PropertySetRegion
---@field public HasGetRegion System.Boolean
---@field public HasSetRegion System.Boolean
---@field public IsReadOnly System.Boolean
---@field public IsWriteOnly System.Boolean
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.PropertyDeclaration=m
return m;