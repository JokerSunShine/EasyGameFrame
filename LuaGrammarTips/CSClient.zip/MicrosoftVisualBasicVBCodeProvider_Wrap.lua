---@class MicrosoftVisualBasicVBCodeProvider : SystemCodeDomCompilerCodeDomProvider
---instance properties
---@field public FileExtension SystemString
---@field public LanguageOptions SystemCodeDomCompilerLanguageOptions
local m = {};
---@param type SystemType
---@return SystemComponentModelTypeConverter
function m:GetConverter(type) end
---@param member SystemCodeDomCodeTypeMember
---@param writer SystemIOTextWriter
---@param options SystemCodeDomCompilerCodeGeneratorOptions
function m:GenerateCodeFromMember(member, writer, options) end
MicrosoftVisualBasicVBCodeProvider=m
return m;