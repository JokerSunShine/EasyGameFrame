---@class ICSharpCodeNRefactoryAstConstructorDeclaration : ICSharpCodeNRefactoryAstParametrizedNode
---instance properties
---@field public ConstructorInitializer ICSharpCodeNRefactoryAstConstructorInitializer
---@field public Body ICSharpCodeNRefactoryAstBlockStatement
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstConstructorDeclaration=m
return m;