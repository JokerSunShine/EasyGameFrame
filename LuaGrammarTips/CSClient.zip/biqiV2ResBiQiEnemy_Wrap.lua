---@class biqiV2.ResBiQiEnemy
---instance properties
---@field public enemyList System.Collections.Generic.List1biqiV2.EnemyInfo
local m = {};

biqiV2.ResBiQiEnemy=m
return m;