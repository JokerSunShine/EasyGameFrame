---@class ICSharpCode.SharpZipLib.Encryption.PkzipClassic : System.Security.Cryptography.SymmetricAlgorithm
local m = {};
---@param seed System.Byte[]
---@return System.Byte[]
function m.GenerateKeys(seed) end
ICSharpCode.SharpZipLib.Encryption.PkzipClassic=m
return m;