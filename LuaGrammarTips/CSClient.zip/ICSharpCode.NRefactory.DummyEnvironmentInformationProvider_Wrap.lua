---@class ICSharpCode.NRefactory.DummyEnvironmentInformationProvider
local m = {};
---@param reflectionTypeName System.String
---@param typeParameterCount System.Int32
---@param fieldName System.String
---@return System.Boolean
function m:HasField(reflectionTypeName, typeParameterCount, fieldName) end
ICSharpCode.NRefactory.DummyEnvironmentInformationProvider=m
return m;