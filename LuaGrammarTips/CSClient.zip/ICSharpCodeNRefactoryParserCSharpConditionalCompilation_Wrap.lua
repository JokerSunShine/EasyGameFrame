---@class ICSharpCodeNRefactoryParserCSharpConditionalCompilation : ICSharpCodeNRefactoryVisitorsAbstractAstVisitor
---instance properties
---@field public Symbols SystemCollectionsGenericIDictionary2SystemStringSystemObject
local m = {};
---@param symbol SystemString
function m:Define(symbol) end
---@param symbol SystemString
function m:Undefine(symbol) end
---@param condition ICSharpCodeNRefactoryAstExpression
---@return SystemBoolean
function m:Evaluate(condition) end
---@param primitiveExpression ICSharpCodeNRefactoryAstPrimitiveExpression
---@param data SystemObject
---@return SystemObject
function m:VisitPrimitiveExpression(primitiveExpression, data) end
---@param identifierExpression ICSharpCodeNRefactoryAstIdentifierExpression
---@param data SystemObject
---@return SystemObject
function m:VisitIdentifierExpression(identifierExpression, data) end
---@param unaryOperatorExpression ICSharpCodeNRefactoryAstUnaryOperatorExpression
---@param data SystemObject
---@return SystemObject
function m:VisitUnaryOperatorExpression(unaryOperatorExpression, data) end
---@param binaryOperatorExpression ICSharpCodeNRefactoryAstBinaryOperatorExpression
---@param data SystemObject
---@return SystemObject
function m:VisitBinaryOperatorExpression(binaryOperatorExpression, data) end
---@param parenthesizedExpression ICSharpCodeNRefactoryAstParenthesizedExpression
---@param data SystemObject
---@return SystemObject
function m:VisitParenthesizedExpression(parenthesizedExpression, data) end
ICSharpCodeNRefactoryParserCSharpConditionalCompilation=m
return m;