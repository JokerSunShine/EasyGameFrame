---@class ICSharpCode.NRefactory.Ast.CastType
---@field Cast @0
---@field TryCast @1
---@field Conversion @2
---@field PrimitiveConversion @3
ICSharpCode.NRefactory.Ast.CastType=m
return m;