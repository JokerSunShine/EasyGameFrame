---@class CommonDataStructStackChianStackChainStack1T
---instance properties
---@field public Top CommonDataStructStackChianStackNode1T
---@field public Count SystemInt32
local m = {};
---@return SystemBoolean
function m:IsEmpty() end
---@param item T
function m:Push(item) end
---@return T
function m:Pop() end
function m:Clear() end
---@param queue CommonDataStructQueueChainQueueChainQueue1T
---@return CommonDataStructStackChianStackChainStack1T
function m:TransformStack(queue) end
---@param oneWayChainList CommonOneWayChainListOneWayChainList1T
---@return CommonDataStructStackChianStackChainStack1T
function m:TransformOnWayChainList(oneWayChainList) end
CommonDataStructStackChianStackChainStack1T=m
return m;