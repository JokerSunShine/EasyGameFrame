---@class ExCSS.NthOfTypeSelector : ExCSS.NthChildSelector
local m = {};
---@param friendlyFormat System.Boolean
---@param indentation System.Int32 @default_value:0
---@return System.String
function m:ToString(friendlyFormat, indentation) end
ExCSS.NthOfTypeSelector=m
return m;