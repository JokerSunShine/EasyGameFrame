---@class activityV2.ServerRoleRed
---instance properties
---@field public roleId System.Int64
---@field public roleIdSpecified System.Boolean
---@field public name System.String
---@field public nameSpecified System.Boolean
---@field public rewards System.Collections.Generic.List1activityV2.ItemCountInfo
local m = {};

activityV2.ServerRoleRed=m
return m;