---@class appearanceV2.TitleInfo
---instance properties
---@field public titleId System.Int32
---@field public titleIdSpecified System.Boolean
---@field public titleDes System.String
---@field public titleDesSpecified System.Boolean
local m = {};

appearanceV2.TitleInfo=m
return m;