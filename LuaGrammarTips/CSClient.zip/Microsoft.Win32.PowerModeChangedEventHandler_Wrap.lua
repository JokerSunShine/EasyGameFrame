---@class Microsoft.Win32.PowerModeChangedEventHandler : System.MulticastDelegate
local m = {};
---@param sender System.Object
---@param e Microsoft.Win32.PowerModeChangedEventArgs
function m:Invoke(sender, e) end
---@param sender System.Object
---@param e Microsoft.Win32.PowerModeChangedEventArgs
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(sender, e, callback, object) end
---@param result System.IAsyncResult
function m:EndInvoke(result) end
Microsoft.Win32.PowerModeChangedEventHandler=m
return m;