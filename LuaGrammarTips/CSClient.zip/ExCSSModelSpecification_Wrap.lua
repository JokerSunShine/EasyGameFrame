---@class ExCSSModelSpecification
local m = {};
ExCSSModelSpecification=m
return m;