---@class ExCSS.StyleDeclaration
---instance properties
---@field public Value System.String
---@field public ParentRule ExCSS.RuleSet
---@field public Item ExCSS.Property
---@field public Properties System.Collections.Generic.List`1[ExCSS.Property]
---@field public Count System.Int32
---@field public IsReadOnly System.Boolean
local m = {};
---@param item ExCSS.Property
function m:Add(item) end
function m:Clear() end
---@param item ExCSS.Property
---@return System.Boolean
function m:Contains(item) end
---@param array ExCSS.Property[]
---@param arrayIndex System.Int32
function m:CopyTo(array, arrayIndex) end
---@param item ExCSS.Property
---@return System.Boolean
function m:Remove(item) end
---@param item ExCSS.Property
---@return System.Int32
function m:IndexOf(item) end
---@param index System.Int32
---@param item ExCSS.Property
function m:Insert(index, item) end
---@param index System.Int32
function m:RemoveAt(index) end
---@return System.String
function m:ToString() end
---@param friendlyFormat System.Boolean
---@param indentation System.Int32 @default_value:0
---@return System.String
function m:ToString(friendlyFormat, indentation) end
---@return System.Collections.Generic.IEnumerator`1[ExCSS.Property]
function m:GetEnumerator() end
ExCSS.StyleDeclaration=m
return m;