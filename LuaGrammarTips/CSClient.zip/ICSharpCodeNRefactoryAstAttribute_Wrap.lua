---@class ICSharpCodeNRefactoryAstAttribute : ICSharpCodeNRefactoryAstAbstractNode
---instance properties
---@field public Name SystemString
---@field public PositionalArguments SystemCollectionsGenericList1ICSharpCodeNRefactoryAstExpression
---@field public NamedArguments SystemCollectionsGenericList1ICSharpCodeNRefactoryAstNamedArgumentExpression
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstAttribute=m
return m;