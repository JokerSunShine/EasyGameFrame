---@class ICSharpCodeNRefactoryParserAbstractLexer
---instance properties
---@field public SkipAllComments SystemBoolean
---@field public EvaluateConditionalCompilation SystemBoolean
---@field public ConditionalCompilationSymbols SystemCollectionsGenericIDictionary2SystemStringSystemObject
---@field public Errors ICSharpCodeNRefactoryParserErrors
---@field public TagComments SystemCollectionsGenericList1ICSharpCodeNRefactoryParserTagComment
---@field public SpecialTracker ICSharpCodeNRefactoryParserSpecialTracker
---@field public SpecialCommentTags SystemString
---@field public Token ICSharpCodeNRefactoryParserToken
---@field public LookAhead ICSharpCodeNRefactoryParserToken
local m = {};
---@param symbols SystemString
function m:SetConditionalCompilationSymbols(symbols) end
function m:Dispose() end
function m:StartPeek() end
---@return ICSharpCodeNRefactoryParserToken
function m:Peek() end
---@return ICSharpCodeNRefactoryParserToken
function m:NextToken() end
---@param targetToken SystemInt32
function m:SkipCurrentBlock(targetToken) end
ICSharpCodeNRefactoryParserAbstractLexer=m
return m;