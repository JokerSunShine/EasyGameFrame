---@class ICSharpCodeNRefactoryAstTypeOfIsExpression : ICSharpCodeNRefactoryAstExpression
---instance properties
---@field public Expression ICSharpCodeNRefactoryAstExpression
---@field public TypeReference ICSharpCodeNRefactoryAstTypeReference
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstTypeOfIsExpression=m
return m;