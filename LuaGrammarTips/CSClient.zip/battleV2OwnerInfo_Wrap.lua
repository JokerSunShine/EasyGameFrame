---@class battleV2.OwnerInfo
---instance properties
---@field public id System.Int64
---@field public idSpecified System.Boolean
---@field public name System.String
---@field public nameSpecified System.Boolean
---@field public sex System.Int32
---@field public sexSpecified System.Boolean
---@field public career System.Int32
---@field public careerSpecified System.Boolean
---@field public fightValue System.Int32
---@field public fightValueSpecified System.Boolean
---@field public unionName System.String
---@field public unionNameSpecified System.Boolean
local m = {};

battleV2.OwnerInfo=m
return m;