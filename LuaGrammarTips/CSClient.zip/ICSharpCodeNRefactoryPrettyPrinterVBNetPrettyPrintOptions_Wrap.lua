---@class ICSharpCodeNRefactoryPrettyPrinterVBNetPrettyPrintOptions : ICSharpCodeNRefactoryPrettyPrinterAbstractPrettyPrintOptions
---instance properties
---@field public OutputByValModifier SystemBoolean
local m = {};
ICSharpCodeNRefactoryPrettyPrinterVBNetPrettyPrintOptions=m
return m;