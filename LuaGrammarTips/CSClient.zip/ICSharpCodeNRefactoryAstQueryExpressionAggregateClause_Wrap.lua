---@class ICSharpCodeNRefactoryAstQueryExpressionAggregateClause : ICSharpCodeNRefactoryAstQueryExpressionClause
---instance properties
---@field public FromClause ICSharpCodeNRefactoryAstQueryExpressionFromClause
---@field public MiddleClauses SystemCollectionsGenericList1ICSharpCodeNRefactoryAstQueryExpressionClause
---@field public IntoVariables SystemCollectionsGenericList1ICSharpCodeNRefactoryAstExpressionRangeVariable
local m = {};
---@param visitor ICSharpCodeNRefactoryIAstVisitor
---@param data SystemObject
---@return SystemObject
function m:AcceptVisitor(visitor, data) end
---@return SystemString
function m:ToString() end
ICSharpCodeNRefactoryAstQueryExpressionAggregateClause=m
return m;