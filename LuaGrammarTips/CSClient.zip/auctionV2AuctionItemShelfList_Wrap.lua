---@class auctionV2.AuctionItemShelfList
---instance properties
---@field public itemType System.Int32
---@field public itemTypeSpecified System.Boolean
---@field public items System.Collections.Generic.List1auctionV2.AuctionItemInfo
local m = {};

auctionV2.AuctionItemShelfList=m
return m;