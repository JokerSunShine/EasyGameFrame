---@class backV2.ResPushMemory
---instance properties
---@field public ret System.String
---@field public retSpecified System.Boolean
local m = {};

backV2.ResPushMemory=m
return m;