---@class ICSharpCodeSharpZipLibZipCompressionDeflaterHuffman
---instance fields
---@field public pending ICSharpCodeSharpZipLibZipCompressionDeflaterPending
local m = {};
---@param toReverse SystemInt32
---@return SystemInt16
function m.BitReverse(toReverse) end
function m:Reset() end
---@param blTreeCodes SystemInt32
function m:SendAllTrees(blTreeCodes) end
function m:CompressBlock() end
---@param stored SystemByte
---@param storedOffset SystemInt32
---@param storedLength SystemInt32
---@param lastBlock SystemBoolean
function m:FlushStoredBlock(stored, storedOffset, storedLength, lastBlock) end
---@param stored SystemByte
---@param storedOffset SystemInt32
---@param storedLength SystemInt32
---@param lastBlock SystemBoolean
function m:FlushBlock(stored, storedOffset, storedLength, lastBlock) end
---@return SystemBoolean
function m:IsFull() end
---@param lit SystemInt32
---@return SystemBoolean
function m:TallyLit(lit) end
---@param dist SystemInt32
---@param len SystemInt32
---@return SystemBoolean
function m:TallyDist(dist, len) end
ICSharpCodeSharpZipLibZipCompressionDeflaterHuffman=m
return m;