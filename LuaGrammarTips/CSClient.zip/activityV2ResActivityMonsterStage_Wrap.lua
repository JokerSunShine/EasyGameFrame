---@class activityV2.ResActivityMonsterStage
---instance properties
---@field public stage System.Int32
local m = {};

activityV2.ResActivityMonsterStage=m
return m;