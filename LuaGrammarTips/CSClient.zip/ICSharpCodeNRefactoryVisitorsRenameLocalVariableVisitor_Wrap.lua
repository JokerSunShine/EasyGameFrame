---@class ICSharpCodeNRefactoryVisitorsRenameLocalVariableVisitor : ICSharpCodeNRefactoryVisitorsRenameIdentifierVisitor
local m = {};
---@param variableDeclaration ICSharpCodeNRefactoryAstVariableDeclaration
---@param data SystemObject
---@return SystemObject
function m:VisitVariableDeclaration(variableDeclaration, data) end
---@param parameterDeclarationExpression ICSharpCodeNRefactoryAstParameterDeclarationExpression
---@param data SystemObject
---@return SystemObject
function m:VisitParameterDeclarationExpression(parameterDeclarationExpression, data) end
---@param foreachStatement ICSharpCodeNRefactoryAstForeachStatement
---@param data SystemObject
---@return SystemObject
function m:VisitForeachStatement(foreachStatement, data) end
ICSharpCodeNRefactoryVisitorsRenameLocalVariableVisitor=m
return m;