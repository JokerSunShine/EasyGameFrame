---@class ICSharpCode.NRefactory.Ast.INode
---instance properties
---@field public Parent ICSharpCode.NRefactory.Ast.INode
---@field public Children System.Collections.Generic.List`1[ICSharpCode.NRefactory.Ast.INode]
---@field public StartLocation ICSharpCode.NRefactory.Location
---@field public EndLocation ICSharpCode.NRefactory.Location
---@field public UserData System.Object
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptChildren(visitor, data) end
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
ICSharpCode.NRefactory.Ast.INode=m
return m;