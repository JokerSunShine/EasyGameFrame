---@class ICSharpCode.NRefactory.Visitors.RenameLocalVariableVisitor : ICSharpCode.NRefactory.Visitors.RenameIdentifierVisitor
local m = {};
---@param variableDeclaration ICSharpCode.NRefactory.Ast.VariableDeclaration
---@param data System.Object
---@return System.Object
function m:VisitVariableDeclaration(variableDeclaration, data) end
---@param parameterDeclarationExpression ICSharpCode.NRefactory.Ast.ParameterDeclarationExpression
---@param data System.Object
---@return System.Object
function m:VisitParameterDeclarationExpression(parameterDeclarationExpression, data) end
---@param foreachStatement ICSharpCode.NRefactory.Ast.ForeachStatement
---@param data System.Object
---@return System.Object
function m:VisitForeachStatement(foreachStatement, data) end
ICSharpCode.NRefactory.Visitors.RenameLocalVariableVisitor=m
return m;