---@class ICSharpCode.NRefactory.PrettyPrinter.SpecialOutputVisitor
---instance fields
---@field public ForceWriteInPreviousLine System.Boolean
local m = {};
---@param special ICSharpCode.NRefactory.ISpecial
---@param data System.Object
---@return System.Object
function m:Visit(special, data) end
---@param special ICSharpCode.NRefactory.BlankLine
---@param data System.Object
---@return System.Object
function m:Visit(special, data) end
---@param special ICSharpCode.NRefactory.Comment
---@param data System.Object
---@return System.Object
function m:Visit(special, data) end
---@param special ICSharpCode.NRefactory.PreprocessingDirective
---@param data System.Object
---@return System.Object
function m:Visit(special, data) end
ICSharpCode.NRefactory.PrettyPrinter.SpecialOutputVisitor=m
return m;