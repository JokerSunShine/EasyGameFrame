---@class ICSharpCode.SharpZipLib.GZip.GZipInputStream : ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputStream
local m = {};
---@param buf System.Byte[]
---@param offset System.Int32
---@param len System.Int32
---@return System.Int32
function m:Read(buf, offset, len) end
ICSharpCode.SharpZipLib.GZip.GZipInputStream=m
return m;