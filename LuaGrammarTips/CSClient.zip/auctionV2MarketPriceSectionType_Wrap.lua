---@class auctionV2.MarketPriceSectionType
---@field ADD @1
---@field RE_ADD @2
local m = {};
auctionV2.MarketPriceSectionType=m
return m;