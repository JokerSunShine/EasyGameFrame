---@class LuaResTool_AutoReloadLua
---fields
---@field public Macro_OpenAutoReloadLua System.String
---properties
---@field public LuaFileReloadManager XLua.LuaTable
---@field public ReloadLuaFileArrayFunction System.Action`1[System.Object]
local m = {};
function m.CheckAutoUpdateLuaState() end
function m.OpenAutoReloadLua() end
function m.CloseAutoReloadLua() end
function m.StartAutoReloadLua() end
function m.StopAutoReloadLua() end
---@param allModifiedLuaFiles System.String[]
function m.ReloadAllModifiedLuaFilesDuringPlaying(allModifiedLuaFiles) end
LuaResTool_AutoReloadLua=m
return m;