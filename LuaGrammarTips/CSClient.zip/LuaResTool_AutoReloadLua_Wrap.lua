---@class LuaResTool_AutoReloadLua
---fields
---@field public Macro_OpenAutoReloadLua SystemString
---properties
---@field public LuaFileReloadManager XLuaLuaTable
---@field public ReloadLuaFileArrayFunction SystemAction1SystemObject
local m = {};
function m.CheckAutoUpdateLuaState() end
function m.OpenAutoReloadLua() end
function m.CloseAutoReloadLua() end
function m.StartAutoReloadLua() end
function m.StopAutoReloadLua() end
---@param allModifiedLuaFiles SystemString
function m.ReloadAllModifiedLuaFilesDuringPlaying(allModifiedLuaFiles) end
LuaResTool_AutoReloadLua=m
return m;