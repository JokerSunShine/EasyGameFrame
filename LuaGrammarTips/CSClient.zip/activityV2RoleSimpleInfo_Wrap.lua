---@class activityV2.RoleSimpleInfo
---instance properties
---@field public sex System.Int32
---@field public sexSpecified System.Boolean
---@field public career System.Int32
---@field public careerSpecified System.Boolean
---@field public cloth System.Int32
---@field public clothSpecified System.Boolean
---@field public weapon System.Int32
---@field public weaponSpecified System.Boolean
---@field public wing System.Int32
---@field public wingSpecified System.Boolean
---@field public fashionCloth System.Int32
---@field public fashionClothSpecified System.Boolean
---@field public fashionWing System.Int32
---@field public fashionWingSpecified System.Boolean
---@field public fashionWeapon System.Int32
---@field public fashionWeaponSpecified System.Boolean
local m = {};

activityV2.RoleSimpleInfo=m
return m;