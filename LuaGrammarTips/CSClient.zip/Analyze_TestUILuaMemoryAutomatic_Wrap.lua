---@class Analyze_TestUILuaMemoryAutomatic : UnityEngine.MonoBehaviour
---instance fields
---@field public panelTestList System.Collections.Generic.List1System.String
local m = {};

function m:StartTest() end
Analyze_TestUILuaMemoryAutomatic=m
return m;