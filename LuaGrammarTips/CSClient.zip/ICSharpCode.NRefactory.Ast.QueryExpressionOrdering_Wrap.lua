---@class ICSharpCode.NRefactory.Ast.QueryExpressionOrdering : ICSharpCode.NRefactory.Ast.AbstractNode
---instance properties
---@field public Criteria ICSharpCode.NRefactory.Ast.Expression
---@field public Direction ICSharpCode.NRefactory.Ast.QueryExpressionOrderingDirection
local m = {};
---@param visitor ICSharpCode.NRefactory.IAstVisitor
---@param data System.Object
---@return System.Object
function m:AcceptVisitor(visitor, data) end
---@return System.String
function m:ToString() end
ICSharpCode.NRefactory.Ast.QueryExpressionOrdering=m
return m;