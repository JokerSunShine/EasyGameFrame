---@class auctionV2.SubmitBuyProductsItemRequest
---instance properties
---@field public lid System.Int64
---@field public lidSpecified System.Boolean
---@field public priceId System.Int64
---@field public priceIdSpecified System.Boolean
---@field public count System.Int32
---@field public countSpecified System.Boolean
local m = {};

auctionV2.SubmitBuyProductsItemRequest=m
return m;