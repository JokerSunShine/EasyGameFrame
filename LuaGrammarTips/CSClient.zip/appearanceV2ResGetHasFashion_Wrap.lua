---@class appearanceV2.ResGetHasFashion
---instance properties
---@field public FashionInfo System.Collections.Generic.List1appearanceV2.FashionType
local m = {};

appearanceV2.ResGetHasFashion=m
return m;