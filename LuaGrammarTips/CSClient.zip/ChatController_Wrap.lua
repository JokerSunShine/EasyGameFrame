---@class ChatController : UnityEngineMonoBehaviour
---instance fields
---@field public ChatInputField TMProTMP_InputField
---@field public ChatDisplayOutput TMProTMP_Text
---@field public ChatScrollbar UnityEngineUIScrollbar
local m = {};
ChatController=m
return m;