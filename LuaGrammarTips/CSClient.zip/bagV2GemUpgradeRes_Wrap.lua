---@class bagV2.GemUpgradeRes
---instance properties
---@field public newId System.Int32
---@field public type System.Int32
local m = {};

bagV2.GemUpgradeRes=m
return m;