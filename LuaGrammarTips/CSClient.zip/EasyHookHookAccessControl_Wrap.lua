---@class EasyHookHookAccessControl
---instance properties
---@field public IsExclusive SystemBoolean
---@field public IsInclusive SystemBoolean
local m = {};
---@param InACL SystemInt32
function m:SetInclusiveACL(InACL) end
---@param InACL SystemInt32
function m:SetExclusiveACL(InACL) end
---@return SystemInt32
function m:GetEntries() end
EasyHookHookAccessControl=m
return m;